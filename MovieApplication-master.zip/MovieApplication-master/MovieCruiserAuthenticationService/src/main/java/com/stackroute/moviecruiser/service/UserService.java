/**
 * 
 */
package com.stackroute.moviecruiser.service;

import com.stackroute.moviecruiser.exceptions.UserAlreadyExistsException;
import com.stackroute.moviecruiser.exceptions.UserNotFoundException;
import com.stackroute.moviecruiser.model.User;

/**
 * @author ubuntu
 *
 */
public interface UserService {

	boolean saveUser(User user) throws UserAlreadyExistsException;

	public User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException;;

}
