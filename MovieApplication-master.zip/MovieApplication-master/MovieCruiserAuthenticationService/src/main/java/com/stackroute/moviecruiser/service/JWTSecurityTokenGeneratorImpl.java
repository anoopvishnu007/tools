package com.stackroute.moviecruiser.service;

import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.stackroute.moviecruiser.model.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


@Service
public class JWTSecurityTokenGeneratorImpl implements SecurityTokenGenerator {

	@Override
	public Map<String, String> generateToken(User user) { 
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
		final String SECRET = Base64.getEncoder().encodeToString("ThisIsASecret".getBytes());
		Map<String, Object> headerClaims = new LinkedHashMap<>();
		headerClaims.put("alg", "HS256");
		headerClaims.put("typ", "JWT");
		Calendar c = Calendar.getInstance();
		Date now = c.getTime();
		c.add(Calendar.MINUTE, 7200);
		Date expirationDate = c.getTime();
		String jwtToken = "";
		jwtToken = Jwts.builder().setSubject(user.getUserId()).setIssuedAt(now).setExpiration(expirationDate)
				.setHeader(headerClaims).signWith(signatureAlgorithm, SECRET).compact();
		Map<String, String> map = new HashMap<>();
		map.put("token", jwtToken);
		map.put("message", "User successfully logged in");
		return map;
	}
}
