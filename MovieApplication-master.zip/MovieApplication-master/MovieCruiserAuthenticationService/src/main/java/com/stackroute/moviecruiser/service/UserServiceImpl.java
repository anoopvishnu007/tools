package com.stackroute.moviecruiser.service;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.moviecruiser.exceptions.UserAlreadyExistsException;
import com.stackroute.moviecruiser.exceptions.UserNotFoundException;
import com.stackroute.moviecruiser.model.User;
import com.stackroute.moviecruiser.repositories.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private final UserRepository userRepo;

	public UserServiceImpl(UserRepository userRepo) {
		super();
		this.userRepo = userRepo;
	}

	//Registering user details
	@Override
	public boolean saveUser(User user) throws UserAlreadyExistsException {
		if(user.getCreateddate()==null) {
			user.setCreateddate(new Date());
		}
		final Optional<User> userObject = userRepo.findById(user.getUserId());
		if (userObject.isPresent()) {
			throw new UserAlreadyExistsException("This User already exists");
		}
		userRepo.save(user);
		return true;
	}

	//Finding user details and validating the same
	@Override
	public User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException {
		final User user = userRepo.findByUserIdAndPassword(userId, password);
		if (user == null) {
			throw new UserNotFoundException("UserId and Password does not match...");
		}
		return user;
	}

}
