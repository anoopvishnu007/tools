package com.stackroute.moviecruiser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieCruiserAuthenticationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieCruiserAuthenticationServiceApplication.class, args);
	}
}
