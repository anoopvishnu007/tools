package com.stackroute.moviecruiser.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.stackroute.moviecruiser.exceptions.UserAlreadyExistsException;
import com.stackroute.moviecruiser.exceptions.UserNotFoundException;
import com.stackroute.moviecruiser.model.User;
import com.stackroute.moviecruiser.service.SecurityTokenGenerator;
import com.stackroute.moviecruiser.service.UserService;

@RestController
@EnableWebMvc
@RequestMapping("/api/v1/userservice")
@CrossOrigin("*")
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private SecurityTokenGenerator tokenGenerator;

	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody User user) {
		ResponseEntity<?> responseEntity;
		try {
			userService.saveUser(user);
			responseEntity = new ResponseEntity<String>("Successfully registered the User", HttpStatus.CREATED);
		} catch (UserAlreadyExistsException e) {
			responseEntity = new ResponseEntity<String>("{\"message\":\"" + e.getMessage() + "\")",
					HttpStatus.CONFLICT);
		}
		return responseEntity;
	}

	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody User loginDetail) {
		ResponseEntity<?> responseEntity;
		try {
			String userId = loginDetail.getUserId();
			String password = loginDetail.getPassword();

			if (userId == null || password == null) {
				throw new UserNotFoundException("userId or password not valid");
			}

			User user = userService.findByUserIdAndPassword(userId, password);

			if (user == null) {
				throw new UserNotFoundException("The user doest not exist!!");
			}

			String pswd = loginDetail.getPassword();
			if (!password.equals(pswd)) {
				throw new Exception("Invalid login credentials. Please check your UserId and Password");
			}

			Map<String, String> map = tokenGenerator.generateToken(user);
			responseEntity = new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);

		} catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"message\":\"" + e.getMessage() + "\")",
					HttpStatus.UNAUTHORIZED);
		}

		return responseEntity;
	}
}
