export class User{
    //variable declaration which are required for this application
    firstname : string;
    lastname : string;
    userId : string;
    password : string;
}