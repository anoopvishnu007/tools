import { AuthenticationService } from './../authentication.service';
import { OnInit, Component } from '@angular/core';
import { User } from './../User';
import {Router} from '@angular/router';

@Component({
    selector:'app-register',
    templateUrl:'./register.component.html',
    styleUrls:['./register.component.css']
})

export class RegisterComponent implements OnInit{

    newUser:User;
    constructor(private authService:AuthenticationService , private router:Router){
        this.newUser = new User();
    }

    ngOnInit()
    {

    }
    registerUser()
    {
        console.log('Register User' , this.newUser.userId, this.newUser.firstname);
        console.log('new user' , this.newUser);
        this.authService.registerUser(this.newUser).subscribe((data)=>{
            console.log('User Data is: ' , data);
            this.router.navigate(['/login']);
        })
    }

    resetInput(){
        
    }
}