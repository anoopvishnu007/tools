import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Input } from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'movie-container',
  templateUrl: './container.component.html',
  styleUrls: [
    './container.component.css'
  ]
})
export class ContainerComponent implements OnInit {
  
  @Input()
  movies: Array<Movie>; 
  
  @Input()
  useWatchlistApi:boolean;

  constructor(private httpClient : HttpClient,private movieService: MovieService,private matSnackBar
    : MatSnackBar) {     
  }

  ngOnInit() {
  }
  //logic for adding new movies into the watchlist
  addMovieToWatchList(movie){
     console.log(movie);
    this.movieService.saveWatchListMovies(movie).subscribe((response) =>{
        this.matSnackBar.open(response,'',{
            duration:1000
        });
    });
   }
   //logic for deleting movie from the componenet
   deleteMovieFromWatchList(movie){
          
     //logic for deleting the movie from the back-end
     this.movieService.deleteFromMyWatchList(movie).subscribe((response)=>{
      let movieIndex=this.movies.indexOf(movie)
      this.movies.splice(movieIndex,1);       
        this.matSnackBar.open(response,'',{
            duration:1000
        });
     });
   }

   //logic for updating movie inside the watchlist
   updateMovieInsidetheWatchList(movie){
     
   }
}
