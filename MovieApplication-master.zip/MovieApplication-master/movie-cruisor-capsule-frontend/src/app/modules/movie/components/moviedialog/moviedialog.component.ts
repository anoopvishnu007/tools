import { Component, OnInit, Input, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';

@Component({
  selector: 'app-moviedialog',
  templateUrl: './moviedialog.component.html',
  styleUrls: [
    './moviedialog.component.css'
    ]
})

//Component class for handling the pop-up dialog box before updating the movie comment
export class MovieDialogComponent implements OnInit {

    movie:Movie;
    comments:string;
    actionType:string;

    constructor(public snackBar : MatSnackBar, public dialogRef : MatDialogRef<MovieDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data : any, private movieService : MovieService ) {  
        this.comments=data.obj.comments;
        this.movie=data.obj;
        this.actionType=data.actionType;
    }
    ngOnInit() {     
    }
    //Cancel button logic here
    onNoClick(){
        this.dialogRef.close();
    }
    //Update button logic 
    updateComments(){
        console.log("comments ",this.comments);
        this.movie.comments=this.comments;
        this.dialogRef.close();
        //Invoking the comment updating service logic
        this.movieService.updateComments(this.movie).subscribe(response=>{
            this.snackBar.open(response,'',{
                duration:3000
            });
        });
    }
}