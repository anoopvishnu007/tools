import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'movie-watchlist',
  templateUrl: './watchlist.component.html'
})
//This component class is used for handling all the watch-listed movies
//corresponding to one particular user
export class WatchlistComponent implements OnInit {
  movies: Array<Movie>;
  useWatchlistApi=true;

  constructor(private httpClient : HttpClient,private movieService: MovieService,private matSnackBar
  : MatSnackBar) { 
    this.movies=[];
  }

  ngOnInit() {
    let message='Watch List is Empty';
        this.movieService.getMyWatchList().subscribe((movies)=> {
         if(movies.length===0){
           this.matSnackBar.open(message,'',{
                duration:1000
           });
         }
         this.movies.push(...movies);
      });
  }

}
