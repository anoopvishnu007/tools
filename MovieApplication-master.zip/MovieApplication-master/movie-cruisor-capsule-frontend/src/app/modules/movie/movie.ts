export interface Movie{
    //variable declaration which are required for this application
    id : number;
    title: string;
    poster_path: string;
    overview: string;
    release_date: string;
    comments: string;
};