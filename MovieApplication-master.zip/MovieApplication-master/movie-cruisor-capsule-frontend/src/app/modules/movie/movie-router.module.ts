import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContainerComponent } from './components/container/container.component';
import { TmdbContainerComponent } from './components/tmdb-container/tmdb-container.component';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import { SearchComponent } from './components/search/search.component';
import { AuthguardService } from '../../authGuard.service';

//This is the router module which is used for routing the application based on the incoming
//requests. While simply hitting the localhost:4200 the application will redirect to all the 
//popular movie from tmdb. If the url is appended with /top-rated, it will sho all the top-rated
//movies and the url is appended with /watchlist it will display all the movies that are added 
//into the MyWatchList segment. If the url is appened with /search, the application redirects to
//the search segment in the application. There one user can easily search various movies based on 
//there interest.
const movieRoutes: Routes=[
{
    path: 'movies',
    children: [
        {
            path: '',
            redirectTo: '/movies/popular',
            pathMatch: 'full',
	    canActivate: [AuthguardService]
        },
        {
            path: 'popular',
            component: TmdbContainerComponent,
	    canActivate: [AuthguardService],
            data: {
                 movieType : 'popular'       
            },
        },
        {
            path: 'top-rated',
            component: TmdbContainerComponent,
	    canActivate: [AuthguardService],
            data: {
                movieType : 'top_rated',
            }
        },
        {
            path: 'watchlist',
            component: WatchlistComponent,
	    canActivate: [AuthguardService]
        },
        {
            path: 'search',
            component: SearchComponent,
	    canActivate: [AuthguardService]
        }
    ]
  }
];

@NgModule({
    imports: [
        RouterModule.forChild(movieRoutes),
    ],
    exports: [
        RouterModule,
    ]
})

export class MovieRouterModule{}
