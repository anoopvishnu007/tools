import { TokenInterceptor } from './interceptor.service';
import { MovieService } from './movie.service';
import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient,HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule, Routes} from '@angular/router';
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { ContainerComponent } from './components/container/container.component';
import { MovieRouterModule } from './movie-router.module';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import { TmdbContainerComponent } from './components/tmdb-container/tmdb-container.component';
import { MovieDialogComponent } from './components/moviedialog/moviedialog.component';
import { SearchComponent } from './components/search/search.component';
import { from } from 'rxjs/observable/from';

//This module is mainly intended for declaring as well as importing all the movie related 
//modules
@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    MovieRouterModule,
    MatCardModule,
    MatButtonModule,
    MatSnackBarModule,
    MatDialogModule,
    FormsModule,
    MatInputModule
  ],
  declarations: [
    ThumbnailComponent,
    ContainerComponent,
    WatchlistComponent,
    TmdbContainerComponent,
    MovieDialogComponent,
    SearchComponent
  ],
  exports: [
    MovieRouterModule,
    ThumbnailComponent,
    WatchlistComponent,
    ContainerComponent,
    TmdbContainerComponent,
    MovieDialogComponent,
    SearchComponent
  ],
  entryComponents: [
    MovieDialogComponent
  ],
  providers: [MovieService,{
    provide:HTTP_INTERCEPTORS,
    useClass:TokenInterceptor,
    multi:true
  } ]
})
export class MovieModule { }
