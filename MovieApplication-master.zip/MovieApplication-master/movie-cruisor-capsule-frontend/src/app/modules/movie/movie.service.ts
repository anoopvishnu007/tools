import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators/map';
import { Movie } from './movie';
import { Observable } from 'rxjs/Observable';
import { retry } from 'rxjs/operators';


@Injectable()
export class MovieService {

  tmdbEndpoint : string; 
  imagePrefix : string;
  apiKey : string;
  watchlistEndPoint : string;
  movieBackendServiceEndPoint: string;
  search: string;

  constructor(private http : HttpClient) { 
    this.apiKey='api_key=e3e08ad14666c3fad3a66e070d45e6af';
    this.tmdbEndpoint='https://api.themoviedb.org/3/movie';
    this.imagePrefix = 'https://image.tmdb.org/t/p/w200'; 
    //this.watchlistEndPoint='http://localhost:3000/watchlist';
    this.movieBackendServiceEndPoint='http://localhost:8084/api/v1/movieservice';
    this.search='https://api.themoviedb.org/3/search/movie?';
  }

  
  getMovies(type : string, page: number=1): Observable<Array<Movie>>{
    const endPoint=`${this.tmdbEndpoint}/${type}?${this.apiKey}&page=${page}`;
    return this.http.get(endPoint).pipe(
      retry(3),
      map(this.pickMovieResults),
      map(this.transformPosterPath.bind(this))
    );
  }

  
  transformPosterPath(movies): Array<Movie>{
    return movies.map(movie => {
        movie.poster_path=`${this.imagePrefix}${movie.poster_path}`;
        return movie;
    });    
  }

  pickMovieResults(response){
    return response['results'];
  }

  
  saveWatchListMovies(movie){
      return this.http.post(this.movieBackendServiceEndPoint+'/movie', movie,{responseType:'text'});
  }

  //Calling the backend for retrieving all the watchlisted movies
  getMyWatchList() : Observable<Array<Movie>>{
    return this.http.get<Array<Movie>>(this.movieBackendServiceEndPoint+'/movies');
  }

  //Method for deleting movie from the WatchList
  deleteFromMyWatchList(movie : Movie){
    const url = `${this.movieBackendServiceEndPoint}/movie/${movie.id}`;
    return this.http.delete(url,{responseType:'text'});
  }

  
  updateComments(movie){
    const url = `${this.movieBackendServiceEndPoint}/movie/${movie.id}`;
    return this.http.put(url,movie,{responseType:'text'});
  }

  
  searchMovies(searchKey:string) : Observable<Array<Movie>>{
    if(searchKey.length > 0){
      const url=`${this.search}${this.apiKey}&language=en-US&page=1&include_adult=false&query=${searchKey}`;
      return this.http.get(url).
      pipe(retry(3),
      map(this.pickMovieResults),
      map(this.transformPosterPath.bind(this)));
    }
  }
}
