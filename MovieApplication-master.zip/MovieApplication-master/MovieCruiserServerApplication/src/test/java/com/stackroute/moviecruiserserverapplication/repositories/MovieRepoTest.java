package com.stackroute.moviecruiserserverapplication.repositories;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.stackroute.moviecruiserserverapplication.domain.Movie;
import com.stackroute.moviecruiserserverapplication.repository.MovieRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Transactional
public class MovieRepoTest {
	@Autowired
	private MovieRepository movieRepository;
	
	public void setRepository(MovieRepository movieRepository) {
		this.movieRepository=movieRepository;
	}
	@Test
	public void testSaveMovie() {
		movieRepository.save(new Movie(1,"2","Anoop86","Superman","good movie","www.abc.com","2015-03-23",""));
		final Movie movie =movieRepository.getOne(1);
		assertThat(movie.getId()).isEqualTo(1);
		
		
	}
	@Test
	public void testUpdateMovie() {
		movieRepository.save(new Movie(1,"2","Anoop86","Superman","good movie","www.abc.com","2015-03-23",""));
		final Movie movie =movieRepository.getOne(1);
		assertThat(movie.getTitle()).isEqualTo("Superman");
		movie.setComments("hi");
		movieRepository.save(movie);
		
		Movie updatedmovie =movieRepository.getOne(1);
		assertEquals("hi",updatedmovie.getComments());
	}
	@Test
	public void testDeleteMovie() {
		movieRepository.save(new Movie(1,"2","Anoop86","Superman","good movie","www.abc.com","2015-03-23",""));
		final Movie movie =movieRepository.getOne(1);
		assertThat(movie.getId()).isEqualTo(1);
		movieRepository.delete(movie);
		assertEquals(Optional.empty(), movieRepository.findById(1));
		
	}
	@Test
	public void testGetMovie() {
		movieRepository.save(new Movie(1,"2","Anoop86","Superman","good movie","www.abc.com","2015-03-23",""));
		final Movie movie =movieRepository.getOne(1);
		assertThat(movie.getTitle()).isEqualTo("Superman");
		
	}
	@Test
	public void testGetAllMovies() {
		movieRepository.save(new Movie(1,"2","Anoop86","Superman","good movie","www.abc.com","2015-03-23",""));
		movieRepository.save(new Movie(2,"3","Anoop86","Superman-1","good movie","www.abc.com","2015-03-23",""));
		final List<Movie> movies =movieRepository.findAll();
		assertThat(movies.get(0).getTitle()).isEqualTo("Superman");
		assertThat(movies.size()).isEqualTo(2);
		
	}
	@Test
	public void testGetAllMyMovies() {
		movieRepository.save(new Movie(1,"2","Anoop86","Superman","good movie","www.abc.com","2015-03-23",""));
		movieRepository.save(new Movie(2,"3","Anoop86","Superman-1","good movie","www.abc.com","2015-03-23",""));
		final List<Movie> movies =movieRepository.findByUserId("Anoop86");
		assertThat(movies.get(0).getTitle()).isEqualTo("Superman");
		assertThat(movies.size()).isEqualTo(2);
		
	}

}
