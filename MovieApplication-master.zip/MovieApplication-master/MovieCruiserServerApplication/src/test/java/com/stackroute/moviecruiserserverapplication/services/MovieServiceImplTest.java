package com.stackroute.moviecruiserserverapplication.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.moviecruiserserverapplication.domain.Movie;
import com.stackroute.moviecruiserserverapplication.exception.MovieAlreadyExistsException;
import com.stackroute.moviecruiserserverapplication.exception.MovieNotFoundException;
import com.stackroute.moviecruiserserverapplication.repository.MovieRepository;
import com.stackroute.moviecruiserserverapplication.service.MovieServiceImpl;

public class MovieServiceImplTest {
	@Mock
	private transient MovieRepository movieRepo;
	private transient Movie movie;
	@InjectMocks
	private transient MovieServiceImpl movieServiceImpl;
	transient Optional<Movie> options;
	@Before
	public void setUpMock() {
		MockitoAnnotations.initMocks(this);
		movie = new Movie(1, "2", "Anoop86", "Spiderman", "Superman Movie", "www.superman.com", "10-10-2018","");
		options = Optional.of(movie);
	}
	@Test
	public void testMockCreation() {
		assertNotNull("jpa repository creation fails: use @injectMocks on movieServiceImpl", movieRepo);
	}
	@Test
	public void testSaveMovieSuccess() throws MovieAlreadyExistsException {
		when(movieRepo.save(movie)).thenReturn(movie);
		final boolean flag = movieServiceImpl.saveMovie(movie);
		assertTrue("saving movie failed , the call to movieDAOImpl is returning false , check this method",flag);
		//assertTrue(flag);
		verify(movieRepo, times(1)).save(movie);
		verify(movieRepo, times(1)).findById(movie.getId());
	}
	@Test(expected = MovieAlreadyExistsException.class)
	public void testSaveMovieFailure() throws MovieAlreadyExistsException {
		when(movieRepo.findById(1)).thenReturn(options);
		when(movieRepo.save(movie)).thenReturn(movie);
		final boolean flag = movieServiceImpl.saveMovie(movie);
		assertFalse("Saving movie failed",flag);
		verify(movieRepo, times(1)).findById(movie.getId());
	}
	@Test
	public void testUpdateMovie() throws MovieNotFoundException {
		when(movieRepo.findById(1)).thenReturn(options);
		when(movieRepo.save(movie)).thenReturn(movie);
		movie.setComments("Not so good movie");
		boolean isUpdated = movieServiceImpl.updateMovie(movie);
		assertEquals("Update movie failed", true, isUpdated);
		verify(movieRepo, times(1)).save(movie);
		verify(movieRepo, times(1)).findById(movie.getId());
	}

	@Test
	public void testDeleteMovie() throws MovieNotFoundException {
		when(movieRepo.findById(1)).thenReturn(options);
		doNothing().when(movieRepo).delete(movie);
		final boolean flag = movieServiceImpl.deleteMovieById(movie.getId());
		assertTrue("Delete movie failed", flag);
		verify(movieRepo, times(1)).delete(movie);
		verify(movieRepo, times(1)).findById(movie.getId());
	}
	@Test
	public void testGetMovieById() throws MovieNotFoundException {
		when(movieRepo.findById(1)).thenReturn(options);
		final Movie movie1 = movieServiceImpl.getMovieById(1);
		assertEquals("fetching movie by id failed", movie1, movie);
		verify(movieRepo, times(1)).findById(movie.getId());
	}
	@Test
	public void testGetAllMovies(){
		final List<Movie> movies = new ArrayList<>(1);
		when(movieRepo.findAll()).thenReturn(movies);
		final List<Movie> movieList = movieServiceImpl.getAllMovies();
		assertEquals(movies, movieList);
		verify(movieRepo, times(1)).findAll();
	}

}
