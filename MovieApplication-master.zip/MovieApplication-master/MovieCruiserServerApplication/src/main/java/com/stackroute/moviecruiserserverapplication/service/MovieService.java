package com.stackroute.moviecruiserserverapplication.service;

import java.util.List;

import com.stackroute.moviecruiserserverapplication.domain.Movie;
import com.stackroute.moviecruiserserverapplication.exception.MovieAlreadyExistsException;
import com.stackroute.moviecruiserserverapplication.exception.MovieNotFoundException;

public interface MovieService {
	/**
	 * method declaration for save movie
	 * 
	 * @param movie
	 * @return
	 * @throws MovieAlreadyExistsException
	 */
	boolean saveMovie(Movie movie) throws MovieAlreadyExistsException;
	/**
	 * method declaration for updating movie
	 * 
	 * @param movie
	 * @return
	 * @throws MovieNotFoundException
	 */
	boolean updateMovie(Movie movie) throws MovieNotFoundException;
	/**
	 * method declaration for deleting a movie
	 * 
	 * @param id
	 * @return
	 * @throws MovieNotFoundException
	 */
	boolean deleteMovieById(int id) throws MovieNotFoundException;
	/**
	 * method declaration for getting any movie by its id
	 * 
	 * @param id
	 * @return Movie
	 * @throws MovieNotFoundException
	 */
	Movie getMovieById(int id) throws MovieNotFoundException;
	/**
	 * Method declaration for retrieving all the movies from database
	 * 
	 * @return List<Movie>
	 */
	List<Movie> getAllMovies();
	
	List<Movie> getMyMovies(String userId);

}
