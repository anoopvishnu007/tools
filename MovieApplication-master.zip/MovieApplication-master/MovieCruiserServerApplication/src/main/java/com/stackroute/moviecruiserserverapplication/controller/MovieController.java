package com.stackroute.moviecruiserserverapplication.controller;

import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.moviecruiserserverapplication.domain.Movie;
import com.stackroute.moviecruiserserverapplication.exception.MovieAlreadyExistsException;
import com.stackroute.moviecruiserserverapplication.exception.MovieNotFoundException;
import com.stackroute.moviecruiserserverapplication.service.MovieService;
import io.jsonwebtoken.Jwts;
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping(path = "/api/v1/movieservice")
public class MovieController {
	
	private MovieService movieService;
	
	@Autowired
	public MovieController(MovieService movieService) {
		super();
		this.movieService = movieService;
	}
	@PostMapping("/movie")
	public ResponseEntity<?> saveNewMovie(@RequestBody Movie movie,HttpServletRequest request, HttpServletResponse response){
		ResponseEntity<?> responseEntity=null;
		final String authHeader = request.getHeader("authorization");
		final String token = authHeader.substring(7);
		//System.out.println("token : " + token);
		int i=token.lastIndexOf('.');
		String tokenwithoutSignature=token.substring(0, i+1);
		//System.out.println("Token Without Signature : " +tokenwithoutSignature);
		String userId = Jwts.parser().setSigningKey("ThisIsASecret").parseClaimsJwt(tokenwithoutSignature).getBody().getSubject();
		try {
			movie.setUserId(userId);
			movieService.saveMovie(movie);
			responseEntity=new ResponseEntity<String>(movie.getTitle() +" added to WatchList", HttpStatus.CREATED);
		}catch(MovieAlreadyExistsException ex) {
			responseEntity=new ResponseEntity<String>("{\"message\":\""+ ex.getMessage() +"\"}", HttpStatus.CONFLICT);
		}catch(Exception ex) {
			responseEntity=new ResponseEntity<String>("{\"message\":\""+ ex.getMessage() +"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
		
	}
	@PutMapping(path="/movie/{id}")
	public ResponseEntity<?> updateNewMovie(@PathVariable("id") final Integer id, @RequestBody Movie movie){
		ResponseEntity<?> responseEntity=null;
		try {
			boolean  isUpdated = movieService.updateMovie(movie);
			if(isUpdated) {
				responseEntity=new ResponseEntity<String>("Movie updated succesfully", HttpStatus.OK);
			}
		}catch(MovieNotFoundException ex) {
			responseEntity=new ResponseEntity<String>("{\"message\":\""+ ex.getMessage() +"\"}", HttpStatus.NOT_FOUND);
		}catch(Exception ex) {
			responseEntity=new ResponseEntity<String>("{\"message\":\""+ ex.getMessage() +"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
		
	}
	@DeleteMapping(value="/movie/{id}")
	public ResponseEntity<?> deleteMovie(@PathVariable("id") final int id){
		ResponseEntity<?> responseEntity=null;
		try {
			movieService.deleteMovieById(id);
		}catch(MovieNotFoundException ex) {
			responseEntity=new ResponseEntity<String>("{\"message\":\""+ ex.getMessage() +"\"}", HttpStatus.NOT_FOUND);
		}catch(Exception ex) {
			responseEntity=new ResponseEntity<String>("{\"message\":\""+ ex.getMessage() +"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		responseEntity=new ResponseEntity<String>("Movie successfully deleted from the WatchList", HttpStatus.OK);

		return responseEntity;
		
	}
	@GetMapping(path="/movie/{id}")
	public ResponseEntity<?> fetchByMovieId(@PathVariable("id") final int id){
		ResponseEntity<?> responseEntity=null;
		Movie thisMovie = null;
		try {
			thisMovie=movieService.getMovieById(id);
		}catch(MovieNotFoundException ex) {
			responseEntity=new ResponseEntity<String>("{\"message\":\""+ ex.getMessage() +"\"}", HttpStatus.NOT_FOUND);
		}catch(Exception ex) {
			responseEntity=new ResponseEntity<String>("{\"message\":\""+ ex.getMessage() +"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		responseEntity=new ResponseEntity<Movie>(thisMovie, HttpStatus.OK);

		return responseEntity;
		
	}
	@GetMapping("/allmovies")
	public ResponseEntity<List<Movie>> fetchAllMovies(){
		return new ResponseEntity<List<Movie>>(movieService.getAllMovies(),HttpStatus.OK);
	}
	
	@GetMapping("/movies")
	public @ResponseBody ResponseEntity<List<Movie>> fetchMyMovies(final ServletRequest req, final ServletResponse response){
		
		
		final HttpServletRequest request = (HttpServletRequest) req;
		final String authHeader = request.getHeader("authorization");
		final String token = authHeader.substring(7);
		int i=token.lastIndexOf('.');
		String tokenwithoutSignature=token.substring(0, i+1);
		//System.out.println("Token Without Signature : " +tokenwithoutSignature);
		String userId = Jwts.parser().setSigningKey("ThisIsASecret").parseClaimsJwt(tokenwithoutSignature).getBody().getSubject();
		//System.out.println("UserID: " + userId);
		
		return new ResponseEntity<List<Movie>>(movieService.getMyMovies(userId),HttpStatus.OK);
	}
	
	

}
