package com.stackroute.moviecruiserserverapplication.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="movie")
public class Movie {
	/**
	 * id for movie
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name = "movie_id")
	private String movieId;
	/**
	 * name of the movie
	 */
	@Column(name="title")
	private String title;
	
	/**
	 * field for comments of movie
	 */
	@Column(name="overview", columnDefinition="LONGTEXT")
	private String overview;
	/**
	 * field for comments of movie
	 */
	@Column(name="comments", columnDefinition="LONGTEXT")
	private String comments;
	/**
	 * field for poster path for movie
	 */
	@Column(name="poster_path")
	private String poster_path;
	/**
	 * field for release date of movie
	 */
	@Column(name="release_date")
	private String release_date;
	
	@Column(name="user_id")
	private String userId;

	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getOverview() {
		return overview;
	}
	public void setOverview(String overview) {
		this.overview = overview;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getPoster_path() {
		return poster_path;
	}
	public void setPoster_path(String poster_path) {
		this.poster_path = poster_path;
	}
	public String getRelease_date() {
		return release_date;
	}
	public void setRelease_date(String release_date) {
		this.release_date = release_date;
	}
	public Movie() {
		
	}
	 
	public Movie(int id,String movieId,String userId, String name, String comments, String posterPath, String releaseDate,String overview) {
		super();
		this.id = id;
		this.movieId =movieId;
		this.userId = userId;
		this.title = name;
		this.comments = comments;
		this.poster_path = posterPath;
		this.release_date = releaseDate;
		this.overview = overview;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMovieId() {
		return movieId;
	}
	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}
	 


}
