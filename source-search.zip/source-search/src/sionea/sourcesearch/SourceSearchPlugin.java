package sionea.sourcesearch;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;

/**
 * Activator class
 *
 */
public class SourceSearchPlugin extends AbstractUIPlugin {
	
	private static final String IMAGE_PATH = "icons/";
	
	private static SourceSearchPlugin singleton;

    public static SourceSearchPlugin getDefault() {
        if (singleton == null)
            singleton = new SourceSearchPlugin();
        return singleton;
    }

	@Override
	public void start(BundleContext context) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("start activator");
	}

	@Override
	public void stop(BundleContext context) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	protected void initializeImageRegistry(final ImageRegistry reg) {
		Bundle b = FrameworkUtil.getBundle(getClass());  
		reg.put(IMAGE_PATH+"close.gif", ImageDescriptor.createFromURL(b.getEntry(IMAGE_PATH+"close.gif")));
		reg.put(IMAGE_PATH+"search.gif", ImageDescriptor.createFromURL(b.getEntry(IMAGE_PATH+"close.gif")));
	}

}
