# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_OldReqdefImporter;

$VERSION = '1.00';

use strict;

# use max() function to get the array element with maximum value
use List::Util qw[max];

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the old reqdef importer:\n\n";
  print "doctype:\n";
  print "The default doctype which shall be used unless a specific doctype is\n";
  print "mentioned in the input file.\n\n";
  print "version:\n";
  print "The default version which shall be used unless a specific version is\n";
  print "mentioned in the input file.\n\n";
  print "releases:\n";
  print "The default releases (comma separated) which shall be used unless\n";
  print "specific releases are mentioned in the input file.\n\n";
  print "source:\n";
  print "The default source which shall be used unless a specific source is\n";
  print "mentioned in the input file.\n\n";
  print "status:\n";
  print "The default status which shall be used unless a specific version is\n";
  print "mentioned in the input file.\n\n";
  print "map:\n";
  print "The mapping between old and new coverage types (transition from the\n";
  print "old <coverage> tag to the new <needscov> tag).\n";
  print "Syntax is: map=oldcov:newdoctype,oldcov:newdoctype,...\n";
  print "For <coverage> values not listed here, the original values will be used.\n\n";
  print "ignore:\n";
  print "A list of coverage types which have not been traced in the old format\n";
  print "and thus shall be ignored by ReqM2, too.\n\n";
  print "pre:\n";
  print "Allowed values: true, false\n";
  print "If set to 'true' (default value), the content of <description> and\n";
  print "<comment> tags will be enclosed in <pre> tags in order to preserve the\n";
  print "input format, unless the longest line is longer than 120 characters.\n";
  print "If set to 'false', the input document may use HTML style tags for\n";
  print "explicit text formatting.\n\n";
}


sub runImporter
{
  my $self = shift;
  my $file = shift;
  my $impapi = shift;
  my $params = shift;

  my $document = "";
  my @srctags = ("variation", "source", "status", "version",
                 "release", "linkreq", "refinereq", "refinedef", "refext",
                 "desc", "rationale", "comment", "verify",
                 "safetyclass", "safetyrationale");

  my @deftags = ("variation", "status", "source",
                 "release", "rationale");

  my @reqtags = ("status", "source", "version");
  my @defcov;
  my %defvalue;

  my @releases;
  my $doctype = "requirements";
  my $version = "unversioned";
  my $status = "draft";
  my $source;
  my $pre = "true";
  my @map;
  my %map;
  my @defreleases = ('unreleased');
  my @needscov;
  my @provcov;
  my @ignore;
  my %ignore;

  my @parentid;

  my $parmask = 0;

  my %warnfor = (releases => 0, version => 1, doctype => 1,
      source => 0, status => 1);

  my %params;

  $params="" if(!$params);

  $params{"releases"}=\@defreleases;
  $params{"version"}=\$version;
  $params{"doctype"}=\$doctype;
  $params{"source"}=\$source;
  $params{"status"}=\$status;
  $params{"pre"}=\$pre;
  $params{"map"}=\@map;
  $params{"ignore"}=\@ignore;
  $self->{COMMON}->parseParams("ReqM2_OldReqdefImporter", $params, \%params, \%warnfor);

  if(($pre ne "true") && ($pre ne "false"))
  {
    $main::log->error("EBOOLEAN", "pre parameter");
  }

  foreach (@map)
  {
    my @mapping=split /:/;
    $map{$mapping[0]} = $mapping[1];
  }
  foreach (@ignore)
  {
    $ignore{$_}=1;
  }

  my $node = $impapi->createSpecObjectsList($doctype);

  my $obj=$impapi->createObject();

  if(!open(FILE,"<$file"))
  {
    $main::log->error("EOPENFILE", $file);
    return 0;
  }
  my @lines=$self->{COMMON}->getUtf8Array(*FILE);
  close(FILE);

  my $inreqdef=0;
  my $srcline;

  # First of all, get the default values specified in the reqdefDefaults tag
  foreach my $line (@lines)
  {
    if($inreqdef==0 && $line=~m/<reqdefDefaults>(.*)?$/)
    {
      $document .= "\n".$1;
      $inreqdef=1;
    }
    elsif($inreqdef == 1 && $line=~m/^(.*)?<\/reqdefDefaults>/)
    {
      $document .=  "\n".$1;
      $inreqdef=0;

      $document=~s/\r//g;

      foreach my $tag (@deftags)
      {
        if($document=~m/<$tag>(.*?)<\/$tag>/s)
        {
          $defvalue{$tag}=$1;
        }
      }
      while($document=~s/<coverage>(.*?)<\/coverage>/$1/s)
      {
        push @defcov, $1;
      }
      last;
    }
    elsif($inreqdef)
    {
      $document .= "\n".$line;
    }
  }

  $inreqdef = 0;
  undef $document;

  my $baseId="";

  # Now find the actual requirements
  for (my $l=0; $l <= $#lines; $l++) 
  {
    # Find the beginning of a reqdef item
    if($inreqdef==0 && $lines[$l]=~m/<reqdef\s*reqid\s*=\s*\"(.*?)\"\s*>(.*)?$/)
    {
      if($#parentid != -1)
      {
        $obj->{id}= join(".", @parentid).".$1";
      }
      else
      {
        $obj->{id} = $1;
      }
      if ($baseId ne "")
      {
        $obj->{id} = $baseId . "." . $obj->{id};
      }

      $document .= "\n".$2;
      $inreqdef=1;
      $srcline = $l+1;

      push @parentid, $1;
    }
    # Find the end of a reqdef item and process the contained information
    # A reqdef item either ends at a </reqdef> tag or at the beginning of
    # a nested <reqdef> container. Some special treatment of inter-document
    # linking has to be made in the latter case.
    elsif($inreqdef == 1 &&  (($lines[$l]=~m/^(.*)?<\/reqdef>/) || ($lines[$l]=~m/(.*)?<reqdef\s*reqid\s*=\s*\".*?\"\s*>/)))
    {
      $document .= "\n".$1;
      $inreqdef=0;

      if($lines[$l]=~m/.*?<reqdef\s*reqid\s*=\s*\"(.*?)\"\s*>/)
      {
        # This reqdef contains a nested sub-reqdef. This sub-reqdef must become
        # the reqdef's fulfilment, which means that we have to add our own doctype to
        # the needscov list of the reqdef...
        push @needscov, $doctype;
       
        # The nested reqdef tag must be processed during the next iteration.
        $l--;
      }

      my %value;

      $document=~s/\r//g;

      # Process each tag and replace each empty tag by the specified
      # default value or "None." if even a default value is missing.
      foreach my $tag (@srctags)
      {
        if($document=~m/<$tag>(.*?)<\/$tag>/s)
        {
          $value{$tag}=$1;
          if($value{$tag} eq "")
          {
            if($defvalue{$tag})
            {
              $value{$tag}=$defvalue{$tag};
            }
          }
        }
        elsif($defvalue{$tag})
        {
          $value{$tag}=$defvalue{$tag};
        }
        else
        {
          undef $value{$tag};
        }
      }

      # Get all linked requirements
      while($document=~s/<coverage>(.*?)<\/coverage>/$1/s)
      {
        # Special treatment for "REFINE"d requirements -> New coverage
        # type is the requirement's own doctype
        if($1 eq "REFINE")
        {
          push @needscov, $doctype;
        }
        if($1 eq "REJECTED")
        {
          $value{status}="rejected";
        }
        if(defined($ignore{$1}))
        {
          # Do nothing, ignore this coverage type
        }
        else
        {
          if(exists($map{$1}))
          {
            push @needscov, $map{$1};
          }
          else
          {
            push @needscov, $1;
          }
        }
      }

      # Add default coverages, if specified and no requirement specific
      # coverage is provided
      if($#needscov < 0)
      {
        foreach my $defcov (@defcov)
        {
          if($defcov eq "REFINE")
          {
            push @needscov, $doctype;
          }
          if(defined($ignore{$defcov}))
          {
            # Do nothing, ignore this coverage type
          }
          else
          {
            if(exists($map{$defcov}))
            {
              push @needscov, $map{$defcov};
            }
            else
            {
              push @needscov, $defcov;
            }
          }
        }
      }

      # Add a "providescoverage" entry to each requirement which
      # refines another one.
      while($document=~s/<refinereq>(.*?)<\/refinereq>/$1/s)
      {
        my %provcov;
        $provcov{'linksto'} = $1;
        $provcov{'dstversion'} = $value{version} || $version;
        push @provcov, \%provcov;
      }
      # Or which has a parent requirement
      if($#parentid > 0)
      {
        my %provcov;
        # Remove the last element from parentid, because the whole parentid array
        # references the current specobject, not its parent (the id is pushed onto
        # the "parent id stack" when a <reqdef> is found).
        my @parentlist = @parentid;
        pop(@parentlist);
        $provcov{'linksto'} = join(".", @parentlist);
        $provcov{'dstversion'} = $value{version} || $version;
        push @provcov, \%provcov;
      }

      if($lines[$l]=~m/^(.*)?<\/reqdef>/)
      {
        pop @parentid;
      }

      foreach my $reqtag (@reqtags)
      {
        if((!$value{$reqtag}) && (!${$params{$reqtag}}))
        {
          $main::log->error("EPARSEFILE", $file, "Required tag '$reqtag' missing in specobject $obj->{id}");
        }
      }

      if (($pre eq "true") && ($value{comment}) && (max(map(length, split(/\n/, $value{comment}))) < 120))
      {
        $value{comment} = "<pre>" . $value{comment} . "</pre>";
      }

      if (($pre eq "true") && ($value{desc}) && (max(map(length, split(/\n/, $value{desc}))) < 120))
      {
        $value{desc} = "<pre>" . $value{desc} . "</pre>";
      }

      $releases[0]=$value{release};
      $obj->{status}=$value{status} || $status;
      $obj->{source}=$value{source} || $source;
      $obj->{sourcefile}=$file;
      $obj->{sourceline}=$srcline;
      $obj->{version}=$value{version} || $version;
      $obj->{description}=$value{desc};
      $obj->{comment}=$value{comment};
      $obj->{safetyclass}=$value{safetyclass};
      $obj->{safetyrationale}=$value{safetyrationale};
      $obj->{verifycrit}=$value{verify};
      if($releases[0])
      {
        $obj->{releases}=\@releases;
      }
      else
      {
        $obj->{releases}=\@defreleases;
      }
      $obj->{needscoverage}=\@needscov;
      $obj->{providescoverage}=\@provcov;

      # Add data to document 
      $impapi->addObject($node);

      @releases = ();
      @needscov = ();
      @provcov = ();

      undef $document;
    }
    # If a reqdef is closed, it's id has to be removed from the
    # "parent id stack".
    elsif(!$inreqdef && ($lines[$l]=~m/^(.*)?<\/reqdef>/))
    {
      pop @parentid;
    }
    elsif($inreqdef==0 && $lines[$l]=~m/<reqdefBaseID reqid="([^"]*)"/)
    {
      # remember the base ID of all following IDs
      $baseId=$1;
    }
    elsif($inreqdef==0 && $lines[$l]=~m/<\/requirements>/)
    {
      # reset the base ID to default
      $baseId="";
    }
    elsif($inreqdef)
    {
      $document .= "\n".$lines[$l];
    }
  }
  $impapi->cleanupSpecObjectList($node);

  return 1;
}

1;
