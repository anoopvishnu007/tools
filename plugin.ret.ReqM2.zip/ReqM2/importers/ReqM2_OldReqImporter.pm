# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_OldReqImporter;

$VERSION = '1.00';

use strict;

# use max() function to get the array element with maximum value
use List::Util qw[max];

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the old req importer:\n\n";
  print "doctype:\n";
  print "The default doctype which shall be used unless a specific doctype is\n";
  print "mentioned in the input file.\n\n";
  print "source:\n";
  print "The default source which shall be used unless a specific source is\n";
  print "mentioned in the input file.\n\n";
  print "version:\n";
  print "The default version which shall be used unless a specific version is\n";
  print "mentioned in the input file.\n\n";
  print "releases:\n";
  print "The default releases (comma separated) which shall be used unless\n";
  print "specific releases are mentioned in the input file.\n\n";
  print "status:\n";
  print "The default status which shall be used unless a specific version is\n";
  print "mentioned in the input file.\n\n";
  print "pre:\n";
  print "Allowed values: true, false\n";
  print "If set to 'true' (default value), the content of <description> tags";
  print "will be enclosed in <pre> tags in order to preserve the input format,\n";
  print "unless the longest line is longer than 120 characters.\n";
  print "If set to 'false', the input document may use HTML style tags for\n";
  print "explicit text formatting.\n\n";
}

sub runImporter
{
  my $self = shift;
  my $file = shift;
  my $impapi = shift;
  my $params = shift;

  my $document = "";
  my @srctags = ("variation", "version", "status", "testid", "rationale");

  my @deftags = ("variation", "status");

  my %defvalue;

  my $doctype = "designspec";
  my $version = "unversioned";
  my $status = "draft";
  my $source;
  my $pre = "true";
  my $description = "no description";
  my @releases = ();
  my @needscov;
  my @provcov;

  my %reqs;

  my $parmask = 0;

  my %warnfor = (releases => 0, version => 1, doctype => 1,
      source => 0, status => 1);

  my %params;

  $params="" if(!$params);

  $params{"releases"}=\@releases;
  $params{"version"}=\$version;
  $params{"doctype"}=\$doctype;
  $params{"source"}=\$source;
  $params{"pre"}=\$pre;
  $params{"status"}=\$status;
  $self->{COMMON}->parseParams("ReqM2_OldReqImporter", $params, \%params, \%warnfor);

  if(($pre ne "true") && ($pre ne "false"))
  {
    $main::log->error("EBOOLEAN", "pre parameter");
  }

  if(!open(FILE,"<$file"))
  {
    $main::log->error("EOPENFILE", $file);
    return 0;
  }
  my @lines=$self->{COMMON}->getUtf8Array(*FILE);
  close(FILE);

  my $inreq=0;
  my $srcline;

  # First of all, get the default values specified in the reqDefaults tag
  foreach my $line (@lines)
  {
    if($inreq==0 && $line=~m/<reqDefaults>(.*)?$/)
    {
      $document .= $1;
      $inreq=1;
    }
    elsif($inreq == 1 && $line=~m/^(.*)?<\/reqDefaults>/)
    {
      $document .= $1;
      $inreq=0;

      $document=~s/\r//g;

      foreach my $tag (@deftags)
      {
        if($document=~m/<$tag>(.*?)<\/$tag>/s)
        {
          $defvalue{$tag}=$1;
        }
      }
      last;
    }
    elsif($inreq)
    {
      $document .= $line;
    }
  }

  $inreq = 0;
  undef $document;

  my $refid;

  # Now find the actual requirements
  for (my $l=0; $l <= $#lines; $l++) 
  {
    # Find the beginning of a req item
    if($inreq==0 && $lines[$l]=~m/<req\s*refid\s*=\s*\"(.*?)\"\s*>(.*)?$/)
    {
      $refid= $1;
      $document .= $2;
      $inreq=1;
      $srcline = $l+1;
    }
    # Find the end of a req item and process the contained information
    elsif(($lines[$l]=~m/<req\s*refid\s*=\s*\"(.*?)\"\s*\/>/) || ($inreq == 1 && $lines[$l]=~m/^(.*)?<\/req>/))
    {
      if($lines[$l]=~m/<req\s*refid\s*=\s*\"(.*?)\"\s*\/>/)
      {
        $document="";
        $srcline = $l+1;
        $refid = $1;
      }
      else
      {
        $document .= $1;
      }

      $inreq=0;

      my %value;

      $document=~s/\015//g;

      if($document=~m/<req\s*refid\s*=\s*\"(.*?)\"\s*>/s)
      {
        $main::log->error("EPARSE", $srcline, $file, "<req> within <req> unsupported");
        return 0;
      }

      # Process each tag and replace each empty tag by the specified
      # default value.
      foreach my $tag (@srctags)
      {
        if($document=~m/<$tag>(.*?)<\/$tag>/s)
        {
          $value{$tag}=$1;
          if($value{$tag} eq "")
          {
            if($defvalue{$tag})
            {
              $value{$tag}=$defvalue{$tag};
            }
          }
        }
        elsif($defvalue{$tag})
        {
          $value{$tag}=$defvalue{$tag};
        }
        else
        {
          undef $value{$tag};
        }
      }

      $value{sourcefile}=$file;
      $value{sourceline}=$srcline;

      if(!defined($value{testid}))
      {
        $value{testid}="$file:$srcline";
      }

      push @{$reqs{$value{testid}}[0]}, $refid;
      $reqs{$value{testid}}[1]=\%value;

      undef $document;
    }
    elsif($inreq)
    {
      $document .= $lines[$l];
    }
  }

  my $node = $impapi->createSpecObjectsList($doctype);
  my $obj=$impapi->createObject();

  foreach my $key (keys(%reqs))
  {
    my $desc = $reqs{$key}[1]->{rationale} || $description;

    if (($pre eq "true") && ($desc) && (max(map(length, split(/\n/, $desc))) < 120))
    {
      $desc = "<pre>" . $desc . "</pre>";
    }

    $obj->{id}=$key;
    $obj->{source}=$source;
    $obj->{version}=$reqs{$key}[1]->{version} || $version;
    $obj->{status}=$reqs{$key}[1]->{status} || $status;
    $obj->{description}=$desc;
    $obj->{sourcefile}=$reqs{$key}[1]->{sourcefile};
    $obj->{sourceline}=$reqs{$key}[1]->{sourceline};
    $obj->{releases}=\@releases;
    $obj->{needscoverage}=\@needscov;
    $obj->{providescoverage}=\@provcov;

    for (my $i= 0; $i <= $#{$reqs{$key}[0]}; $i++)
    {
      my %provcov;
      $provcov{'linksto'} = ${$reqs{$key}[0]}[$i];
      $provcov{'dstversion'} = $obj->{version};
      push @provcov, \%provcov;
    }

    # Add data to document 
    $impapi->addObject($node);

    @needscov=();
    @provcov=();
  }
  $impapi->cleanupSpecObjectList($node);

  return 1;
}

1;
