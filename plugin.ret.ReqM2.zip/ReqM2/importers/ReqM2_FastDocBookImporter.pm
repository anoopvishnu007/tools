# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_FastDocBookImporter;

$VERSION = '1.00';

use strict;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the DocBook importer:\n\n";
  print "ignorelinelimit:\n";
  print "Due to a bug in LibXML, line numbers are only reported up to 65535.\n";
  print "In the default setting, the ReqM2_FastDocBookImporter.pm exits with\n";
  print "an error message when this limit is reached. If this boolean option\n";
  print "is set to 'true', this error check is ommitted and all line numbers\n";
  print "exceeding this limit are reported as '65535'.\n";
  print "Note:\n";
  print "This option may be removed after the bug in LibXML has been fixed.\n";
  print "The default value is 'false'.\n\n";
}

sub runImporter
{
  my $self = shift;
  my $file = shift;
  my $impapi = shift;
  my $params = shift;
  my $cfgtags = shift;

  my %params;

  my $ignorelinelimit = 'false';

  my %warnfor;

  $params="" if(!$params);
 
  $params{"ignorelinelimit"}=\$ignorelinelimit;

  $self->{COMMON}->parseParams("ReqM2_FastDocBookImporter", $params, \%params, \%warnfor);

  if(($ignorelinelimit ne "true") && ($ignorelinelimit ne "false"))
  {
    $main::log->error("EBOOLEAN", "ignorelinelimit parameter");
  }

  # LibXML must not try to load the DocBook DTD from the internet,
  # as we might not have network access
  my $root = XML::LibXML->load_xml(
      location => $file,
      line_numbers => 1,
      no_network => 1,
      recover => 2);
  if(!defined($root))
  {
    $main::log->warning("WPARSEFILE", $file, "No XML file");
    return 0;
  }

  my $origdoc = $impapi->getRawDocument();

  # These two nodes are added to each SpecObject. We create them first and
  # then cloneNode() them, as this saves some time.
  my $filenamenode = $root->createElement("sourcefile");
  my $linenode = $root->createElement("sourceline");

  # Find the specobjects containers
  foreach my $specobjects($root->findnodes("//specobjects"))
  {
    my $doctype = $specobjects->getAttribute("doctype");
    my $node = $impapi->createSpecObjectsList($doctype);

    foreach my $specobject($specobjects->findnodes("specobject"))
    {

      my $line = $specobject->line_number();

      if(($line >= 65535) && ($ignorelinelimit eq "false"))
      {
        $main::log->error("EGENERAL", "Line number exceeds 65535.");
      }

      my $newspecobject = $specobjects->removeChild($specobject);

      my $tmpnode;
      my $status = $specobject->firstChild->nextSibling()->nextSibling()->nextSibling();
      my $nextsibling = $status->nextSibling()->nodeName;

      # Determine the position where to insert the filename and line information
      # If there is neither a "shortdesc" nor a "source" tag, insert it directly
      # after the "status" tag.
      if(($nextsibling ne "shortdesc") &&
         ($nextsibling ne "source"))
      {
        $tmpnode = $status;
      }
      # If there is a "source" tag but no "shortdesc" tag (there is no need to
      # explicitly test for the latter, as it had to be located *before* the
      # source tag otherwise), insert it after that.
      elsif($nextsibling eq "source")
      {
        $tmpnode = $status->nextSibling();
      }
      # If there is a "shortdesc" tag but no "source tag", insert
      # it after that.
      elsif(($nextsibling eq "shortdesc") &&
            ($nextsibling ne "source"))
      {
        $tmpnode = $status->nextSibling();
      }
      # Otherwise, insert it after the "shortdesc" and the "source" tag.
      else
      {
        $tmpnode = $status->nextSibling()->nextSibling();
      }

      # Now add the filename and line information.
      my $tmpfilenode = $filenamenode->cloneNode(1);
      $tmpfilenode = $newspecobject->insertAfter($tmpfilenode, $tmpnode);
      $tmpfilenode->appendTextNode($file);
      my $tmplinenode = $linenode->cloneNode(1);
      $tmplinenode = $newspecobject->insertAfter($tmplinenode, $tmpfilenode);
      $tmplinenode->appendTextNode($line);

      $node->addChild($newspecobject);
    }
  }

  return 1;
}

1;
