# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_TrampImporter;

$VERSION = '1.00';

use strict;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the TRAMP importer:\n\n";
  print "doctype:\n";
  print "The doctype which shall be used for all specobjects.\n\n";
  print "source:\n";
  print "The source which shall be used for all specobjects.\n\n";
  print "version:\n";
  print "The version which shall be used for all specobjects.\n\n";
  print "releases:\n";
  print "The releases (comma separated) which shall be used for all specobjects.\n\n";
  print "status:\n";
  print "The status which shall be used for all specobjects.\n\n";
  print "prefix:\n";
  print "The prefix which is added to the ID of the test result before using\n";
  print "it as specobject id.\n";
  print "Reason is, that in the current TRAMP setup, the test spec item, the\n";
  print "test case (the function to be called) and the test result (the entry\n";
  print "in the result log) all have the same id, which is forbidden by ReqM2\n";
  print "if two of them (or all three) shall be included in the tracing.\n\n";
  print "outprefix:\n";
  print "The prefix which is added to the ID of the test result before using\n";
  print "it as provides-coverage-to id.\n";
  print "Reason is, that in the current TRAMP setup, the test spec item, the\n";
  print "test case (the function to be called) and the test result (the entry\n";
  print "in the result log) all have the same id, which is forbidden by ReqM2\n";
  print "if two of them (or all three) shall be included in the tracing.\n\n";
}

sub runImporter
{
  my $self = shift;
  my $file = shift;
  my $impapi = shift;
  my $params = shift;


  my $prefix = "TestCase_";
  my $outprefix = "TestSpec_";

  my $doctype = "testresults";
  my $version = "unversioned";
  my $status = "draft";
  my $source;
  my @releases = ();

  my $parmask = 0;

  my %warnfor = (releases => 0, version => 1, doctype => 1,
      source => 0, status => 1);

  my %params;

  $params="" if(!$params);

  $params{"releases"}=\@releases;
  $params{"version"}=\$version;
  $params{"doctype"}=\$doctype;
  $params{"source"}=\$source;
  $params{"status"}=\$status;
  $params{"prefix"}=\$prefix;
  $params{"outprefix"}=\$outprefix;
  $self->{COMMON}->parseParams("ReqM2_TrampImporter", $params, \%params, \%warnfor);

  # LibXML must not try to load anything from the internet,
  # as we might not have network access
  my $root = XML::LibXML->load_xml(
      location => $file,
      line_numbers => 1,
      no_network => 1,
      recover => 2);
  if(!defined($root))
  {
    $main::log->error("EPARSEFILE", $file, "No XML file");
    return 0;
  }

  my $node = $impapi->createSpecObjectsList($doctype);

  # Find the testcase containers
  foreach my $testcase ($root->findnodes("//testcase"))
  {
    # Only the successful tests must be imported, because we want the
    # specobjects related to the failed tests to remain unfulfilled
    if( (!($testcase->findnodes("failure"))) && (!($testcase->findnodes("error"))) )
    {
      my @provcov;
      my $obj=$impapi->createObject();
      my $testid = $testcase->getAttribute("name");

      # The test spec item and the test case have the same ID. This is
      # no problem when using TRAMP, but it is a problem when ReqM2 does
      # the tracing, because specobject IDs must be unique.
      my $testcaseid = $prefix.$testid;

      $testid = $outprefix.$testid;

      # There is currently no possibility to specify version information
      # for test cases. Thus we set the version required for the destination
      # specobject to the same value as the common version of all test
      # cases.
      # !!! THIS PROBLEM NEEDS TO BE SOLVED !!!
      my %provcov;
      $provcov{'linksto'} = $testid;
      $provcov{'dstversion'} = $version;
      push @provcov, \%provcov;

      $obj->{id}=$testcaseid;
      $obj->{status}=$status;
      $obj->{source}=$source;
      $obj->{sourcefile}=$file;
      $obj->{sourceline}=$testcase->line_number();
      $obj->{version}=$version;
      $obj->{description}= "Test case $testid was successful";
      $obj->{releases}=\@releases;
      $obj->{providescoverage}=\@provcov;

      $impapi->addObject($node);
    }
  }
  $impapi->cleanupSpecObjectList($node);

  return 1;
}

1;
