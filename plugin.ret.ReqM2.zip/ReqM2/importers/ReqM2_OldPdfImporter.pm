# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_OldPdfImporter;

$VERSION = '1.00';

use strict;

# This is the mapping of file names to requirement identifiers.
my %AS_IDS=(
"RTE"                      => "rte_sws_\\d{5}",
"DCM"                      => "Dcm\\d{3}",
"ECU_StateManager"         => "EcuM\\d{4}",
"COM"                      => "COM\\d{3}",
"OS"                       => "OS\\d{3}",
"CAN_Interface"            => "CANIF\\d{3}",
"FlexRayDriver"            => "FR\\d{3}",
"ECU_Configuration"        => "ecuc_sws_\\d{4}",
"NVRAMManager"             => "NVM\\d{3}",
"PDU_Router"               => "PDUR\\d{3}",
"ComManager"               => "ComM\\d{3}",
"FlexRay_TP"               => "FRTP\\d{3}",
"ICU_Driver"               => "ICU\\d{3}",
"DEM"                      => "Dem\\d{3}",
"SPI_HandlerDriver"        => "SPI\\d{3}",
"ADC_Driver"               => "ADC\\d{3}",
"LIN_Interface"            => "LINIF\\d{3}",
"WatchdogManager"          => "WDGM\\d{3}",
"FlexrayNM"                => "FRNM\\d{3}",
"CAN_TP"                   => "CanTp\\d{3}",
"RAM_Test"                 => "RamTst\\d{3}",
"CAN_Driver"               => "CAN\\d{3}",
"CAN_NM"                   => "CANNM\\d{3}",
"GPT_Driver"               => "GPT\\d{3}",
"VFB"                      => "VFB\\d{3}",
"FlashDriver"              => "FLS\\d{3}",
"FlexRayInterface"         => "FrIf\\d{5}",
"LIN_Driver"               => "LIN\\d{3}",
"EEPROM_Driver"            => "EEP\\d{3}",
"PWM_Driver"               => "PWM\\d{3}",
"FIM"                      => "FIM\\d{3}",
"BSW_Scheduler"            => "INTEGR\\d{3}",
"MCU_Driver"               => "MCU\\d{3}",
"CAN_StateManager"         => "CANSM\\d{3}",
"FlexRay_StateManager"     => "FrSm\\d{3}",
"EEPROM_Abstraction"       => "EA\\d{3}",
"WatchdogDriver"           => "WDG\\d{3}",
"Port_Driver"              => "PORT\\d{3}",
"LIN_StateManager"         => "LINSM\\d{3}",
"CompilerAbstraction"      => "COMPILER\\d{3}",
"Mem_AbstractionInterface" => "MemIf\\d{3}",
"WatchdogInterface"        => "WDGIF\\d{3}",
"CRC_Routines"             => "CRC\\d{3}",
"IPDUM"                    => "IPDUM\\d{3}",
"CAN_TransceiverDriver"    => "CanTrcv\\d{3}",
"FlexRayTransceiver"       => "FrTrcv\\d{3}",
"DIO_Driver"               => "DIO\\d{3}",
"NMInterface"              => "Nm\\d{3}",
"Flash_EEPROM_Emulation"   => "FEE\\d{3}",
"PlatformTypes"            => "PLATFORM\\d{3}",
"MemoryMapping"            => "MEMMAP\\d{3}",
"DET"                      => "DET\\d{3}",
"ComStackTypes"            => "COMTYPE\\d{3}",
"StandardTypes"            => "STD\\d{3}"
);

# These variables control the smooth concatenation of paragraphs which
# are intersected by a page break in the input PDF. It may be necessary
# to adapt these in future releases of the documents.
# 
# This is the identifier for the bottom of a page (the last line on each
# page):
my $bot_tag  = "Document ID";
# This is the number of lines which must be removed ahead of the $bot_tag:
my $pre      = 1;
# This is the nuber of lines which must be removed after the $bot_tag:
my $post     = 4;

my $pdftotextpath = "";
my $pdftotextcommand = "pdftotext -enc UTF-8 -layout";
my $try_to_detect_tables = 1;
my @defcoverages = ("uncovered");
my $doctype = ("requirements");
my $version = "unversioned";
my @releases = ();
my $attributes;
my $source;
my $status = "draft";
my $defdescription ="no description";
my $file;

my $req_tag;
my @req;
my @lines;
my %reqs;
my %attcov;
my %attmode;
my %attcomment;

my @map;
my %map;
my @ignore;
my %ignore;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the old PDF importer:\n\n";
  print "doctype:\n";
  print "The doctype which shall be used for all specobjects.\n\n";
  print "source:\n";
  print "The source which shall be used for all specobjects.\n\n";
  print "version:\n";
  print "The version which shall be used for all specobjects.\n\n";
  print "releases:\n";
  print "The releases (comma separated) which shall be used for all specobjects.\n\n";
  print "status:\n";
  print "The status which shall be used for all specobjects.\n\n";
  print "coverages:\n";
  print "The default coverages which shall be used for specobjects for which\n";
  print "no entry in the attributes file exists.\n\n";
  print "attributes:\n";
  print "The path to the attributes file which specifies special coverage\n";
  print "settings for particular specobjects.\n\n";
  print "pdftotextpath;\n";
  print "The path to the pdftotext utility used for converting the input files\n";
  print "into an ASCII representation.\n\n";
  print "map:\n";
  print "The mapping between old and new coverage types (transition from the\n";
  print "old attributes file entries tag to the new <needscov> tag).\n";
  print "Syntax is: map=oldcov:newdoctype,oldcov:newdoctype,...\n";
  print "For oldcov values not listed here, the original values will be used.\n\n";
  print "ignore:\n";
  print "A list of coverage types which have not been traced in the old format\n";
  print "and thus shall be ignored by ReqM2, too.\n";
}

sub runImporter
{
  my $self = shift;
  $file = shift;
  my $impapi = shift;
  my $params = shift;

  my $cygfn;

  my $parmask = 0;

  my %warnfor = (releases => 0, version => 1, doctype => 1,
      source => 0, status => 1, coverages => 1);

  my %params;

  $params="" if(!$params);

  $params{"releases"}=\@releases;
  $params{"version"}=\$version;
  $params{"doctype"}=\$doctype;
  $params{"source"}=\$source;
  $params{"status"}=\$status;
  $params{"map"}=\@map;
  $params{"ignore"}=\@ignore;
  $params{"coverages"}=\@defcoverages;
  $params{"attributes"}=\$attributes;
  $params{"pdftotextpath"}=\$pdftotextpath;
  $self->{COMMON}->parseParams("ReqM2_OldPdfImporter", $params, \%params, \%warnfor);

  $pdftotextpath .="/" if $pdftotextpath;

  foreach (@map)
  {
    my @mapping=split /:/;
    $map{$mapping[0]} = $mapping[1];
  }
  foreach (@ignore)
  {
    $ignore{$_}=1;
  }

  my $txtname;

  if($file)
  {
    $file=~m/(AUTOSAR_SWS_)(.*?).pdf/;

    $txtname="$1$2.txt";
    $req_tag=$AS_IDS{$2};
  }
  else
  {
    $main::log->error("ENOINPUTFILE");
    return 0;
  }

  if($req_tag=~m/^$/)
  {
    $main::log->error("EGENERAL", "Could not find requirement ID for $file. This probably is no AUTOSAR document.");
    return 0;
  }

  system("$pdftotextpath$pdftotextcommand \"$file\" \"$txtname\"");

  if(!open(FILE,"<$txtname"))
  {
    $main::log->error("EOPENFILE", $txtname);
    return 0;
  }
  @lines=$self->{COMMON}->getUtf8Array(*FILE);
  close(FILE);

  if(!unlink("$txtname"))
  {
    $main::log->error("EDELETE", $txtname);
    return 0;
  }

  remove_pagebreaks();

  if($attributes)
  {
    if(load_attributes() == 0)
    {
      $main::log->error("EOPENFILE", $attributes);
      return 0;
    }
  }

  find_requirements($impapi, $doctype);

  return 1;
}

sub remove_pagebreaks()
{
  for (my $i=0; $i<=$#lines; $i++)
  {
    if($lines[$i]=~m/$bot_tag/)
    {
      splice @lines,$i-$pre,$pre+$post+1;
    }
  }
}

sub load_attributes
{
  if(!open(FILE,"<$attributes"))
  {
    return 0;
  }
  my @lines=<FILE>;
  close(FILE);

  foreach(@lines)
  {
    my $id;
    m/^(.*?)\s(.)\s(.*?)(\s.*)$/;

    if(($2 ne "r") && ($2 ne "+"))
    {
      $main::log->warning("WPARSEFILE", $attributes, "Illegal mode '$2' for requirement $1");
    }

    $id=$1;
    $attcov{$id}=$3;
    $attmode{$id}=$2;
    $attcomment{$id}=$4;

  }
  return 1;
}

sub find_requirements
{
  my $impapi=shift;
  my $doctype = shift;

  my $k;
  my $i=0;
  my $tag=0;
  my %seen;

  for ($k=0;$k<=$#lines;$k++)
  {
    $_=$lines[$k];

    s/</&lt;/g;
    s/>/&gt;/g;

    if(m/^\r?\n?$/ && $tag==1)
    {
      $tag=0;
      $i++;
    }
    if(m/($req_tag)\s?:/)
    {
      if($tag==1)
      {
        $i++;
      }
      $tag=1;
    }

    if($tag==1)
    {
      s/-\r?\n?$//;
      s/\s+/ /g;
      $req[$i].=$_;
    }

  }
  
  my $node = $impapi->createSpecObjectsList($doctype);
  my $obj=$impapi->createObject();

  foreach (@req)
  {
    my @needscov;

    m/.*?($req_tag)\s?:\s(.*)/g;

    my $id = $1;
    my $description = $2;

    if($seen{$id})
    {
      $main::log->warning("WPARSE", "Duplicate ID $id found. Renamed to $id\_$seen{$id}");
      $seen{$id}++;
      $id.="_$seen{$id}";
    }
    else
    {
      $seen{$id}++;
    }

    $obj->{id}=$id;
    $obj->{description}=$description || $defdescription;
    $obj->{status}=$status;
    $obj->{source}=$source;
    $obj->{sourcefile}=$file;
    $obj->{version}= $version;
    $obj->{releases}=\@releases;

    undef $obj->{comment};

    if($attcov{$id})
    {
      $obj->{comment}=$attcomment{$id} if ($attcomment{$id}=~m/\w/);
    }

    # Fetch coverages from attributes file or use the default value
    if($attcov{$id})
    {
      push @needscov, split /,/, $attcov{$id};

      if($attmode{$id} eq "+")
      {
        push @needscov, @defcoverages;
      }
    }
    else
    {
      push @needscov, @defcoverages;
    }

    # change spec object status for speciat coverage doctype REJECTED
    $obj->{status} = "rejected" if (grep(/REJECTED/, @needscov));

    # filter out the ignored doctypes
    my @not_ignored_needscov
      = grep((join($",keys(%ignore)) !~ /\b$_\b/), @needscov);

    # apply the doctypes mapping to non-ignored doctypes and assign
    # ref to anonymous array
    $obj->{needscoverage}
      = [  map((exists($map{$_}) ? $map{$_} : $_ ), @not_ignored_needscov) ];

    $impapi->addObject($node);
  }
  $impapi->cleanupSpecObjectList($node);
}

1;
