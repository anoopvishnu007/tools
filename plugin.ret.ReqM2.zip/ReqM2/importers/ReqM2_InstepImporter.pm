# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_InstepImporter;

$VERSION = '1.00';

use strict;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the instep importer:\n\n";
  print "doctype:\n";
  print "The doctype which shall be used for all specobjects.\n\n";
}

sub runImporter
{
  my $self = shift;
  my $file = shift;
  my $impapi = shift;
  my $params = shift;

  my %tagmapping = (
        id => PropertyType_ID831196288,
        status => State,
        version => RevisionNumber,
        description => PropertyType_ID2141977983,
        safetyclass => PropertyType_ID1902190591,
        safetyrationale => PropertyType_ID826199808,
        verifycrit => PropertyType_ID1293190143,
        release => PropertyType_ID1735756543,
        needsobj => PropertyType_ID1168892287
                  );

  my $allowedsafetyclass="(^NONE\$)|(^QM\$)|(^ASIL-A\$)|(^ASIL-B\$)|(^ASIL-C\$)|(^ASIL-D\$)";
  my $allowedstatus="(^draft\$)|(^approved\$)|(^rejected\$)";

  my $doctype = "requirements";

  my $parmask = 0;

  my %params;

  my %warnfor = (doctype => 1);

  $params = "" if(!$params);
  
  $params{"doctype"}=\$doctype;
  $self->{COMMON}->parseParams("ReqM2_InstepImporter", $params, \%params, \%warnfor);
  

  my $node = $impapi->createSpecObjectsList($doctype);

  if(!open(FILE,"<$file"))
  {
    $main::log->error("EOPENFILE", $file);
    return 0;
  }
  my $lines= join " ", $self->{COMMON}->getUtf8Array(*FILE);
  close(FILE);

  $lines =~s/\x0d\x0a//g;

  my @lines = split /<ProductIncrement/, $lines; 

  shift @lines;

  foreach $lines (@lines)
  {
    if(($lines =~ m/\sName=\"_/) || ($lines=~m/$tagmapping{id}=\"\"/))
    {
      next;
    }

    my %values;
    my $obj=$impapi->createObject();
    my @needsobj;
    my @release;

    foreach my $reqmtag (keys %tagmapping)
    {
      if($lines =~ m/$tagmapping{$reqmtag}=\"(.*?)\"/)
      {
        if($1)
        {
          $values{$reqmtag}=$1;
        }
      }
    }

    if(!$values{status} || !($values{status}=~m/$allowedstatus/))
    {
      $values{status}="draft";
    }
    if(!$values{safetyclass} || !($values{safetyclass}=~m/$allowedsafetyclass/))
    {
      $values{safetyclass}="NONE";
    }


    foreach my $reqmtag (keys %tagmapping)
    {
      if ($reqmtag eq "needsobj")
      {
        if(defined($values{needsobj}))
        {
          push @needsobj, (split /\s*,\s*/, $values{$reqmtag});
        }
      }
      elsif ($reqmtag eq "release")
      {
        if(defined($values{release}))
        {
          push @release, (split /\s*,\s*/, $values{$reqmtag});
        }
      }
      else
      {
        $obj->{$reqmtag}=$values{$reqmtag};
      }
    }
    $obj->{releases}=\@release if ($#release >= 0);
    $obj->{needscoverage}=\@needsobj if ($#needsobj >= 0);

    $impapi->addObject($node);

  }
  $impapi->cleanupSpecObjectList($node);

  return 1;
}

1;
