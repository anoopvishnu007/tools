# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_DocBookImporter;

$VERSION = '1.00';

use strict;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the DocBook importer:\n\n";
  print "source:\n";
  print "The default source which shall be used unless a specific source is\n";
  print "mentioned in the input file.\n\n";
  print "version:\n";
  print "The default version which shall be used unless a specific version is\n";
  print "mentioned in the input file.\n\n";
  print "releases:\n";
  print "The default releases (comma separated) which shall be used unless\n";
  print "specific releases are mentioned in the input file.\n\n";
  print "status:\n";
  print "The default status which shall be used unless a specific version is\n";
  print "mentioned in the input file.\n\n";
}

sub runImporter
{
  my $self = shift;
  my $file = shift;
  my $impapi = shift;
  my $params = shift;
  my $cfgtags = shift;

  my $cmdstatus;
  my $cmdsource;
  my $cmdversion;
  my @cmdreleases;

  my %params;

  my %warnfor;

  $params="" if(!$params);
  
  $params{"status"}=\$cmdstatus;
  $params{"source"}=\$cmdsource;
  $params{"version"}=\$cmdversion;
  $params{"releases"}=\@cmdreleases;
  $self->{COMMON}->parseParams("ReqM2_DocBookImporter", $params, \%params, \%warnfor);
 

  my @simpletags = @{${$cfgtags}{simpletags}};
  my @defaulttags = @{${$cfgtags}{defaultsimpletags}};
  my $lists=\%{${$cfgtags}{lists}};
  my $listlists=\%{${$cfgtags}{listlists}};
  my $listlisttags=\%{${$cfgtags}{listlisttags}};
  my %defaultlist;

  # LibXML must not try to load the DocBook DTD from the internet,
  # as we might not have network access
  my $root = XML::LibXML->load_xml(
      location => $file,
      line_numbers => 1,
      no_network => 1,
      recover => 2);
  if(!defined($root))
  {
    $main::log->warning("WPARSEFILE", $file, "No XML file");
    return 0;
  }
  # Find the specobjects containers
  foreach my $specobjects($root->getElementsByTagName("specobjects"))
  {
    my $doctype = $specobjects->getAttribute("doctype");
    my $node = $impapi->createSpecObjectsList($doctype);

    my $title = $specobjects->getAttribute("title");
    if($title)
    {
      my $att = $root->createAttribute("title", $title);
      if(!defined($att))
      {
        $main::log->error("ECREATEATTRIB", "$title");
      }
      if(!defined($node->addChild($att)))
      {
        $main::log->error("EADDATTRIB", "$title");
      }
    } 

    my $defaults = $specobjects->findnodes("defaults")->[0];

    my $idprefix;
    my %defaulttag;
    my @defaultreleases;

    # Get the default values configured for the current
    # specobjects container
    if($defaults)
    {
      my $idprefixtag = $defaults->findnodes("idprefix")->[0];
      if(defined($idprefixtag))
      {
        $idprefix=$idprefixtag->textContent();
      }

      foreach my $tag (@simpletags)
      {
        my $value=$defaults->findnodes($tag)->[0];
        if(defined($value) && $value->textContent())
        {
          if ($value->exists(".//node() | .//@*"))
          {
            $defaulttag{$tag}=$value->toString(0);
            # Remove the outer tags
            $defaulttag{$tag}=~s/<\s*\/?$tag\s*>//gm;
          }
          else
          {
              $defaulttag{$tag}="";
          }
        }
      }

      foreach my $tagname (keys %{$lists})
      {
        my @tmparray;

        foreach my $value ($defaults->findnodes("$tagname/$lists->{$tagname}"))
        {
          push @tmparray, $value->textContent();
        }

        if(@tmparray)
        {
          $defaultlist{$tagname} = \@tmparray;
        }

      }
    }

    # Find each specobject
    foreach my $specobject ($specobjects->getElementsByTagName("specobject"))
    {
      my $obj=$impapi->createObject();

      my @releases;
      my @depends;
      my @conflicts;
      my @needscov;
      my @provcov;

      # Use the filename and line number of the input document
      # if no other values are specified.
      $obj->{sourcefile}=$file;
      $obj->{sourceline}=$specobject->line_number();

      # Copy the tags into the output document
      foreach my $tag (@simpletags)
      {
        my $value=$specobject->findnodes($tag)->[0];
        if(defined($value))
        {
          if($tag eq "id" && defined($idprefix))
          {
            $obj->{$tag}=$idprefix.$value->textContent();
          }
          elsif($value->textContent() && $value->exists(".//node() | .//@*"))
          {
            $obj->{$tag}=$value->toString(0);
            # Remove the outer tags
            $obj->{$tag}=~s/<\s*\/?$tag\s*>//gm;
          }
          else
          {
            $obj->{$tag}="";
          }
        }
        elsif(defined($defaulttag{$tag}))
        {
          $obj->{$tag}=$defaulttag{$tag};
        }
        else
        {
          if (($tag eq "status") && defined($cmdstatus))
          {
            $obj->{$tag}=$cmdstatus;
          }
          if (($tag eq "source") && defined($cmdsource))
          {
            $obj->{$tag}=$cmdsource;
          }
          if (($tag eq "version") && defined($cmdversion))
          {
            $obj->{$tag}=$cmdversion;
          }
        }
      }

      foreach my $tagname (keys %{$lists})
      {
        my @tmparray;

        # If the outer list container exists, look if there are list elements
        if(defined($specobject->findnodes("$tagname")->[0]))
        {
          foreach my $value ($specobject->findnodes("$tagname/$lists->{$tagname}"))
          {
            push @tmparray, $value->textContent();
          }
        }
        # Only if the outer container does not exist, do fill in the default values
        else
        {
          if($defaultlist{$tagname})
          {
            push @tmparray, @{$defaultlist{$tagname}};
          }
          else
          {
            if(($tagname eq "releases") && @cmdreleases)
            {
              push @tmparray, @cmdreleases;
            }
          }
        }

        $obj->{$tagname}=\@tmparray;
      }

      foreach my $tagname (keys %{$listlists})
      {
        my @tmparray;
        foreach my $provcov ($specobject->findnodes("$tagname/$listlists->{$tagname}"))
        {
          my %subtag; 
          foreach my $subtag (@{$listlisttags->{$listlists->{$tagname}}})
          {
            if($provcov->findnodes("$subtag")->[0])
            {
              $subtag{$subtag}=$provcov->findnodes("$subtag")->[0]->textContent();
            }
          }
          push @tmparray, \%subtag;
        }
        $obj->{$tagname}=\@tmparray;
      }

      if(!defined($obj->{id}))
      {
        $obj->{id}=$file.".".$specobject->line_number();
      }
      $impapi->addObject($node);
    }
    $impapi->cleanupSpecObjectList($node);
  }

  return 1;
}

1;
