# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_OldCImporter;

$VERSION = '1.00';

use strict;

# use max() function to get the array element with maximum value
use List::Util qw[max];

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the old C importer:\n\n";
  print "doctype:\n";
  print "The default doctype which shall be used unless a specific doctype is\n";
  print "mentioned in the input file.\n\n";
  print "source:\n";
  print "The default source which shall be used unless a specific source is\n";
  print "mentioned in the input file.\n\n";
  print "version:\n";
  print "The default version which shall be used unless a specific version is\n";
  print "mentioned in the input file.\n\n";
  print "releases:\n";
  print "The default releases (comma separated) which shall be used unless\n";
  print "specific releases are mentioned in the input file.\n\n";
  print "status:\n";
  print "The default status which shall be used unless a specific version is\n";
  print "mentioned in the input file.\n\n";
  print "pre:\n";
  print "Allowed values: true, false\n";
  print "If set to 'true' (default value), the content of <description> tags\n";
  print "(which is created from the synopsis, description, testobject,\n";
  print "precondition, execution, input and output tags of the original\n";
  print "document) will be enclosed in <pre> tags in order to preserve the\n";
  print "input format, unless the longest line is longer than 120 characters.\n";
  print "If set to 'false', the input document may use HTML style tags for\n";
  print "explicit text formatting.\n\n";
}

sub runImporter
{
  my $self = shift;
  my $file = shift;
  my $impapi = shift;
  my $params = shift;

  my $document = "";
  my @srctags = ("name","synopsis","description","testobject","precondition", "version",
                "execution","input","output","particularities","restore");

  my $doctype = "sourcecode";
  my $version = "unversioned";
  my $status = "draft";
  my $pre = "true";
  my $source;
  my @releases = ();
  my @needscov;
  my @provcov;

  my $parmask = 0;

  my %warnfor = (releases => 0, version => 1, doctype => 1,
      source => 0, status => 1);

  my %params;

  $params="" if(!$params);

  $params{"releases"}=\@releases;
  $params{"version"}=\$version;
  $params{"doctype"}=\$doctype;
  $params{"source"}=\$source;
  $params{"status"}=\$status;
  $params{"pre"}=\$pre;
  $self->{COMMON}->parseParams("ReqM2_OldCImporter", $params, \%params, \%warnfor);

  if(($pre ne "true") && ($pre ne "false"))
  {
    $main::log->error("EBOOLEAN", "pre parameter");
  }

  my $node = $impapi->createSpecObjectsList($doctype);
  my $obj=$impapi->createObject();

  if(!open(FILE,"<$file"))
  {
    $main::log->error("EOPENFILE", $file);
    return 0;
  }
  my @lines = $self->{COMMON}->getUtf8Array(*FILE);
  close(FILE);

  my $intest=0;
  my $srcline;

  for (my $l=0; $l <= $#lines; $l++) 
  {
    # Find the beginning of a test specificatin item.  Prevent
    # matching of preprocessor inclusion directives like of
    #   #include <test.h>
    if($intest==0 && $lines[$l]=~m/<test\b.*?>(.*)?$/ && $lines[$l]!~m/#\s*include/ )
    {
      $document .= $1;
      $intest=1;
      $srcline = $l+1;
    }
    # Find the end of a specification item and process the contained information    
    elsif($intest == 1 && $lines[$l]=~m/^(.*)?<\/test>/)
    {
      $document .= $1;
      $intest=0;

      my(%value);

      # convert DOS line endings into UNIX line feeds
      $document=~s/\r//g;

      foreach my $tag (@srctags)
      {
        if($document=~m/<$tag>(.*?)<\/$tag>/s)
        {
          $value{$tag}=$1;
          if($value{$tag} eq ""){$value{$tag}="None.";}
        }
        else
        {
          $value{$tag}="None.";
        }
      }

      $document=~s/<requirements>(.*?)<\/requirements>/$1/s;

      # Get all linked requirements
      while($document=~s/<requirement>.*?<id>(.*?)<\/id>.*?<version>(.*?)<\/version>.*?<\/requirement>/$1/s)
      {
        my %provcov;
        $provcov{'linksto'} = $1;
        $provcov{'dstversion'} = $2;
        push @provcov, \%provcov;
      }

      my $description = "Test Synopsis: $value{synopsis}\n".
                        "Test Description: $value{description}\n".
                        "Test Object: $value{testobject}\n".
                        "Test Precondition: $value{precondition}\n".
                        "Test Execution: $value{execution}\n".
                        "Test Input: $value{input}\n" .
                        "Test Output: $value{output}";

      if (($pre eq "true") && ($description) && (max(map(length, split(/\n/, $description))) < 120))
      {
        $description = "<pre>" . $description . "</pre>";
      }

      $obj->{id}= $value{name};
      $obj->{status}=$status;
      $obj->{source}=$source;
      $obj->{sourcefile}=$file;
      $obj->{sourceline}=$srcline;
      $obj->{version}=$version;
      $obj->{description}=$description;
      $obj->{releases}=\@releases;
      $obj->{needscoverage}=\@needscov;
      $obj->{providescoverage}=\@provcov;

      # Add data to document 
      $impapi->addObject($node);

      @provcov = ();

      undef $document;
    }
    elsif($intest)
    {
      $document .= "\n".$lines[$l];
    }
  }
  $impapi->cleanupSpecObjectList($node);

  return 1;
}

1;
