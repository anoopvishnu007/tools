#!/usr/bin/perl -w

my $changelog = "changelog/ChangeLog.xml";
my $history   = "changelog/VersionHistory.xml";

my @versions;
my @vdates;

my @changes;
my @cdates;

getVersionHistory($history);
getChanges($changelog);

sortlist(\@versions, \@vdates);
sortlist(\@changes, \@cdates);

print "<chapter>\n";
print "<title>Release Notes</title>\n";
print "<section>\n";
print "<title>General Info</title>\n";
print "<para>Version: $versions[0]</para>\n";
print "<para>Release date: $vdates[0]</para>\n";
print "</section>\n";
print "<section>\n";
print "<title>Changelog</title>\n";
print "<para><itemizedlist>\n";

for(my $i = 0; $i <= $#vdates; $i++)
{
  my $entries = 0;
  print "<listitem>\n";
  print "<para>Version $versions[$i], release date $vdates[$i]</para>\n";
  print "<para><itemizedlist>\n";
  for(my $k = 0; $k <= $#cdates; $k++)
  {
    if(defined($vdates[$i+1]) && isOlderOrSame($cdates[$k], $vdates[$i]) &&
       !isOlderOrSame($cdates[$k], $vdates[$i+1]))
    {
      print "<listitem>$changes[$k]</listitem>\n";
      $entries++;
    }
  }
  if(!$entries)
  {
    print "<listitem>No changelog entries for this release.</listitem>\n";
  }
  print "</itemizedlist></para>\n";
  print "</listitem>\n";
}


print "</itemizedlist></para>\n";
print "</section>\n";
print "</chapter>\n";

exit 0;

sub getVersionHistory
{
  my $file = shift;

  open(FILE, "<$file") || die "Could not open $file.\n";
  my @lines=<FILE>;
  close(FILE);

  foreach my $line (@lines)
  {
    if($line =~ m/<version\s+version\s*=\s*"(\S+)"\s+date\s*=\s*"(\S+)"\s*\/>/)
    {
      push @versions, $1;
      push @vdates, $2;
    }
  }
}

sub getChanges
{
  my $file = shift;

  my $changestring = "";

  open(FILE, "<$file") || die "Could not open $file.\n";
  my @lines=<FILE>;
  close(FILE);

  my $inChange = 0;
  foreach my $line (@lines)
  {
    if($inChange && ($line =~ m/<\/change>/))
    {
      push @changes, $changestring;
      $inChange = 0;
      $changestring="";
    }
    elsif(!$inChange && ($line =~ m/<change\s+date\s*=\s*"(\S+)"\s+arch\s*=\s*"(\S+)"\s*>/))
    {
      push @cdates, $1;
      $inChange = 1;
      next;
    }
    elsif($inChange)
    {
      $changestring .= $line;
    }
  }
}


sub sortlist
{
  my $dataref = shift;
  my $dateref = shift;

  my $i;
  my $k;

  for (my $i = 0; $i<=$#$dateref; $i++)
  {
    for(my $k = $i+1; $k<=$#$dateref; $k++)
    {
      my $tmpdate;
      my $tmpdata;
      if(isOlderOrSame($$dateref[$i], $$dateref[$k]))
      {
        $tmpdate=$$dateref[$i];
        $$dateref[$i]=$$dateref[$k];
        $$dateref[$k]=$tmpdate;

        $tmpdata=$$dataref[$i];
        $$dataref[$i]=$$dataref[$k];
        $$dataref[$k]=$tmpdata;
      }
    }
  }
}

sub isOlderOrSame
{
  my $is = shift;
  my $than = shift;

  my $retval = 0;

  my @date1 = split /-/, $is;
  my @date2 = split /-/, $than;
  if(
       ($date1[0]<$date2[0]) ||
       (($date1[0] == $date2[0]) && ($date1[1]<$date2[1])) ||
       (($date1[0] == $date2[0]) && ($date1[1] == $date2[1]) && ($date1[2]<$date2[2])) ||
       (($date1[0] == $date2[0]) && ($date1[1] == $date2[1]) && ($date1[2] == $date2[2]))
    )
  {
    $retval = 1;
  }

  return $retval;
}

sub printvs
{
  for (my $i=0; $i<=$#vdates; $i++)
  {
    print "$versions[$i] - $vdates[$i]\n";
  }
}

sub printcs
{
  print "\nChanges:\n";
  for (my $i=0; $i<=$#cdates; $i++)
  {
    print "$changes[$i] - $cdates[$i]\n";
  }
}

