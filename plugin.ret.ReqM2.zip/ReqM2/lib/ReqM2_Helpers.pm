# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_Helpers;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 637 $';

use strict;

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;
  my $doc = shift;

  $common->checkArguments("ReqM2Helpers::new", ["ReqM2_Common", "XML::LibXML::Document"], \@args);

  my $self = {COMMON => $common, DOC => $doc};

  bless($self, $type);
  return $self;
}

# Searches for node "nodename" in context "context"
# and sets its content to "value".
# Returns the context of the changed node.
sub setValue
{
  my $self = shift;
  my @args = @_;
  my $context = shift;
  my $nodename = shift;
  my $value = shift;

  $self->{COMMON}->checkArguments("ReqM2Helpers::setValue", ["XML::LibXML::Document|XML::LibXML::Element", "", ""], \@args);

  my $node = $context->findnodes($nodename)->[0];
  if($node)
  {
    $node->firstChild->setData($value);
    $main::log->debug("DNODETOVAL", $nodename, $value);
  }
  else
  {
    $main::log->error("ENONODE", $nodename);
  }

  return $node;
}

# Adds node "nodename" next to node "context" and
# sets its content to "value" (if specified).
# Returns the context of the new node.
sub addSibling
{
  my $self = shift;
  my @args = @_;
  my $context = shift;
  my $nodename = shift;
  my $value = shift;

  my $node = $self->{DOC}->createElement($nodename);
  if(!defined($node))
  {
    $main::log->error("ECREATENODE", $nodename);
  }
  my $newnode = $context->addSibling($node);
  if(!defined($newnode))
  {
    $main::log->error("EADDNODE", $nodename);
  }

  if(defined($value))
  {
    $self->{COMMON}->checkArguments("ReqM2Helpers::addSibling", ["XML::LibXML::Document|XML::LibXML::Element", "", ""], \@args);
    my $content = $self->{DOC}->createTextNode($value);
    if(!defined($content))
    {
      $main::log->error("ECREATETXTNODE", "$nodename/$value");
    }
    my $newcontent = $newnode->addChild($content);
    if(!defined($newcontent))
    {
      $main::log->error("EADDTXTNODE", "$nodename/$value");
    }
    $main::log->debug("DNODETOVAL", $nodename, $value);
  }
  else
  {
    $self->{COMMON}->checkArguments("ReqM2Helpers::addSibling", ["XML::LibXML::Document|XML::LibXML::Element", ""], \@args);
    $main::log->debug("DNODE", $nodename);
  }

  return $node;
}

# Adds node "nodename" next to node "context" and
# sets its content to "value" (if specified).
# If a node of the specified name already exists
# in the given context, only sets its content to
# the new value.
# Returns the context of the new node.
sub addOrReplaceSibling
{
  my $self = shift;
  my @args = @_;
  my $context = shift;
  my $nodename = shift;
  my $value = shift;


  my $node = $context->findnodes("../$nodename")->[0];

  if(!defined($node))
  {
    $node = $self->{DOC}->createElement($nodename);
    if(!defined($node))
    {
      $main::log->error("ECREATENODE", $nodename);
    }
    my $newnode = $context->addSibling($node);
    if(!defined($newnode))
    {
      $main::log->error("EADDNODE", $nodename);
    }

    if(defined($value))
    {
      my $content = $self->{DOC}->createTextNode($value);
      if(!defined($content))
      {
        $main::log->error("ECREATETXTNODE", "$nodename/$value");
      }
      my $newcontent = $newnode->addChild($content);
      if(!defined($newcontent))
      {
        $main::log->error("EADDTXTNODE", "$nodename/$value");
      }
      $main::log->debug("DNODETOVAL", $nodename, $value);
    }
    else
    {
      $main::log->debug("DADD", $nodename);
    }
  }
  else
  {
    if(defined($value))
    {
      $self->{COMMON}->checkArguments("ReqM2Helpers::addOrReplaceSibling", ["XML::LibXML::Document|XML::LibXML::Element", "", ""], \@args);
      $node->firstChild->setData($value);
      $main::log->debug("DREPLACE", $nodename, $value);
    }
    else
    {
      $self->{COMMON}->checkArguments("ReqM2Helpers::addOrReplaceSibling", ["XML::LibXML::Document|XML::LibXML::Element", ""], \@args);
      $main::log->debug("DREPLACEIGN");
    }
  }

  return $node;
}

# Adds a child node "nodename" to "context" and sets its
# content to "value" (if specified).
# Returns the context of the new node.
sub addChild
{
  my $self = shift;
  my @args = @_;
  my $context = shift;
  my $nodename = shift;
  my $value = shift;

  my $newnode = $context->addChild(XML::LibXML::Element->new($nodename));
  if(!defined($newnode))
  {
    $main::log->error("EADDNODE", $nodename);
  }

  if(defined($value))
  {
    $self->{COMMON}->checkArguments("ReqM2Helpers::addChild", ["XML::LibXML::Document|XML::LibXML::Element", "", ""], \@args);
    my $content = $self->{DOC}->createTextNode("$value");
    if(!defined($content))
    {
      $main::log->error("ECREATETXTNODE", "$nodename/$value");
    }
    my $newcontent = $newnode->addChild($content);
    if(!defined($newcontent))
    {
      $main::log->error("EADDTXTNODE", "$nodename/$value");
    }
    $main::log->debug("DNODETOVAL", $nodename, $value);
  }
  else
  {
    $self->{COMMON}->checkArguments("ReqM2Helpers::addChild", ["XML::LibXML::Document|XML::LibXML::Element", ""], \@args);
    $main::log->debug("DADD", $nodename);
  }

  return $newnode;
}

# Adds a child node "nodename" to "context" and sets its
# content to "value" (if specified). If a child of the
# specified name already exists below the given context,
# only set its content to the new value.
# Returns the context of the new node.
sub addOrReplaceChild
{
  my $self = shift;
  my @args = @_;
  my $context = shift;
  my $nodename = shift;
  my $value = shift;

  my $node = $context->findnodes("./$nodename")->[0];

  if(!defined($node))
  {
    $node = $context->addChild(XML::LibXML::Element->new($nodename));
    if(!defined($node))
    {
      $main::log->error("ECREATENODE", $nodename);
    }

    if(defined($value))
    {
      my $content = $self->{DOC}->createTextNode("$value");
      if(!defined($content))
      {
        $main::log->error("ECREATETXTNODE", "$nodename/$value");
      }
      my $newcontent = $node->addChild($content);
      if(!defined($newcontent))
      {
        $main::log->error("EADDTXTNODE", "$nodename/$value");
      }
      $main::log->debug("DADDTO", $nodename, $value);
    }
    else
    {
      $main::log->debug("DADD", $nodename);
    }
  }
  else
  {
    if(defined($value))
    {
      $self->{COMMON}->checkArguments("ReqM2Helpers::addOrReplaceChild", ["XML::LibXML::Document|XML::LibXML::Element", "", ""], \@args);
      $node->firstChild->setData($value);
      $main::log->debug("DREPLACE", $nodename, $value);
    }
    else
    {
      $self->{COMMON}->checkArguments("ReqM2Helpers::addOrReplaceChild", ["XML::LibXML::Document|XML::LibXML::Element", ""], \@args);
      $main::log->debug("DREPLACEIGN");
    }
  }

  return $node;
}

1;
