# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_SpecObj;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 668 $';

use strict;

my %defaultprefixes=(idprefix => "id");

my @attributes = ("id", "status", "version");

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;
  my $fn = shift;
  my $xsd = shift;

  $common->checkArguments("ReqM2_SpecObj::new", ["ReqM2_Common","", ""], \@args);

  my $self = {COMMON => $common, FN => $fn, XSD => $xsd, DATA => {}};

  bless($self, $type);
  return $self;
}

sub loadSpecFile
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_SpecObj::loadSpecFile", [], \@args);

  $main::log->debug("DLOADINGSPEC");

  my $specfile = XML::LibXML->load_xml(
      location => $self->{FN},
      line_numbers => 1);
  if(!defined($specfile))
  {
    $main::log->error("EOPENFILE", $self->{FN});
  }

  $self->{DATA}=$specfile;

  return 1;
}

sub addDefaultValues
{
  my $self = shift;
  my @args = @_;
  my $tags = shift;

  $self->{COMMON}->checkArguments("ReqM2_SpecObj::addDefaultValues", ["HASH"], \@args);

  my $root = ($self->{DATA}->getDocumentElement);

  $main::log->debug("DADD", "default values");
  
  foreach my $specobjects ($root->findnodes("/specdocument/specobjects"))
  {
    my @specobject=$specobjects->findnodes("specobject");


    # Adding the id-prefix has to be done separately, as this cannot
    # simply be copied.
    foreach my $defprefix (keys %defaultprefixes)
    {
      my $prefix = $specobjects->findnodes("defaults/$defprefix")->[0];
      if(defined($prefix))
      {
        $prefix = $prefix->textContent();

        foreach my $specobject (@specobject)
        { 
          my $tag=$specobject->findnodes("$defaultprefixes{$defprefix}")->[0];
          my $val="$prefix".$tag->textContent();
          $tag->firstChild->setData($val);
          $main::log->debug("DADDTO", "default prefix $prefix", $tag->textContent());
        }
      }
    }

    foreach my $defaulttag (@{${$tags}{defaulttags}})
    {
      my $defval = $specobjects->findnodes("defaults/$defaulttag")->[0];
      if(defined($defval))
      {
        foreach my $specobject (@specobject)
        {
          my $predecessor=$self->getPosition($tags, $specobject, $defaulttag);
          if($predecessor)
          {
            my $copy=$defval->cloneNode(1);
            if(!defined($copy))
            {
              $main::log->error("ECOPYNODE", "defaults/$defaulttag");
            }

            my $sibling = $specobject->findnodes($predecessor)->[0];
            if(!defined($sibling))
            {
              $main::log->error("EFINDPRED", $predecessor, $defaulttag);
            }

            if(!defined($specobject->insertAfter($copy, $sibling)))
            {
              $main::log->error("EADDAFTER", $defaulttag, $predecessor);
            }
            $main::log->debug("DADDTO", "default tag $defaulttag", 
                $specobject->findnodes("id")->[0]->textContent());
          }
        }
      }
    }
  }

  # Now that all default tags have been added, the document can
  # be validated
  # !LINKSTO ReqM2ReqSpec.TracingUnit.0002, 1
  my $schema=XML::LibXML::Schema->new(
      location => $self->{XSD});
  if(!defined($schema))
  {
    $main::log->error("EOPENFILE", $self->{XSD});
  }

  $main::log->debug("DVALIDATE", "document with default values");
  
  $schema->validate($self->{DATA});

}

# This function returns the node in 'specobject' after which
# node 'tagname' has to be inserted.
# Returns 0 if a node of the given name already exists or
# if 'tagname' is not defined in the schema (i.e. if it is not
# found in 'tags');
sub getPosition
{
  my $self = shift;
  my @args = @_;
  my $tags = shift;
  my $specobject = shift;
  my $tagname = shift;

  $self->{COMMON}->checkArguments("ReqM2_SpecObj::getPosition", ["HASH","XML::LibXML::Element",""], \@args);

  my @tags=@{${$tags}{tags}};
  my $i;

  $main::log->debug("DCALCPOS", $tagname);

  for ($i=0; $i<=$#tags; $i++)
  {
    last if($tags[$i] eq $tagname);
  }
 
  if($i>$#tags)
  {
    $main::log->debug("DTAGNOTSPEC", $tagname);
    return 0;
  } 

  my $k;

  for ($k=$i; $k>0; $k--)
  {
    last if ($specobject->findnodes("$tags[$k]"));
  }

  if($k == $i)
  {
    $main::log->debug("DTAGEXISTS", $tagname);
    return 0;
  }
  else
  {
    $main::log->debug("DTAGWRONGORDERORDER", $tagname, $tags[$k]);
    return $tags[$k];
  }
}

sub verifyDoctypes
{
  my $self = shift;
  my @args = @_;
  my $cfg = shift;

  $self->{COMMON}->checkArguments("ReqM2_SpecObj::verifyDoctypes", [""], \@args);

  my $retval = 1;

  $main::log->debug("DVERIFY", "doctypes");

  my $alloweddoctypes = $cfg->{DATA}->findnodes("//alloweddoctypes")->[0];
  my $root = ($self->{DATA}->getDocumentElement);
  if(!defined($root))
  {
    $main::log->error("ENODOCROOT");
  }
  my @specobjects = $root->getElementsByTagName("specobjects");

  foreach my $specobjects (@specobjects)
  {
    my $doctype = $specobjects->getAttribute("doctype");
    if(!defined($doctype))
    {
      $main::log->error("ENOATT", "doctype");
    }

    if ($doctype=~m/\s/)
    {
      $main::log->error("EWHITESPACE", $doctype);
    }

    # Check if an "<alloweddoctypes>" container exists
    # If yes, check if each specified doctype is listed in this container
    if ((defined($alloweddoctypes)) && (!($alloweddoctypes->findnodes("alloweddoctype[.='$doctype']"))))
    {
      $main::log->warning("WDTFORBIDDEN", $doctype);
    }

  }

  return $retval;
}

# !LINKSTO ReqM2ReqSpec.TracingUnit.0005, 1,
# !        ReqM2ReqSpec.TracingUnit.0006, 1,
# !        ReqM2ReqSpec.TracingUnit.0007, 1,
# !        ReqM2ReqSpec.TracingUnit.0008, 1
sub verifyOptionalTags
{
  my $self = shift;
  my @args = @_;
  my $cfg  = shift;

  $self->{COMMON}->checkArguments("ReqM2_SpecObj::verifyOptionalTags", [""], \@args);

  # This is currently not needed, but we keep it, because it is evaluated by
  # the caller and there may once be changes which need reporting a failure.
  my $retval = 1;

  my $root = ($self->{DATA}->getDocumentElement);
  if(!defined($root))
  {
    $main::log->error("ENODOCROOT");
  }
  my @specobjects = $root->getElementsByTagName("specobjects");

  $main::log->debug("DVERIFY", "optional tags");

  foreach my $specobjects (@specobjects)
  {
    my @specobject = $specobjects->getElementsByTagName("specobject");


    # Check for attributes
    # This will be removed in future versions when attributes become
    # mandatory.
    foreach my $specobject (@specobject)
    {
      my $id = $specobject->findnodes("id")->[0]->textContent();
      if(!defined($id))
      {
        $main::log->error("ENONODE", "id");
      }
      foreach my $att (@attributes)
      {
        my $attval = $specobject->getAttribute($att);
        if($attval)
        {
          if($attval ne ($specobject->findnodes($att)->[0]->textContent()))
          {
            $main::log->error("EATTDIFF", $att, $att, $id);
          }
        }
        else
        {
#          $main::log->warning("Attribute \"$att\" is missing in specobject $id. ".
#             "This will become mandatory in the next releases.\n");
        }
      }
    }


    my $doctype = $specobjects->getAttribute("doctype");
    if(!defined($doctype))
    {
      $main::log->error("ENOATT", "doctype");
    }

    # Find the corresponding configuration section in the ReqM2 configuration
    my $docconfig = "/reqmconfig/docconfig/document[doctype = '$doctype']";

    # Loop over all configured items
    for my $doccfg ($cfg->{DATA}->findnodes($docconfig))
    {
      my @requiredtag = $doccfg->getElementsByTagName("requiredtag");
      my @forbiddentag = $doccfg->getElementsByTagName("forbiddentag");
      my @requirediftag = $doccfg->getElementsByTagName("requirediftag");
      my @forbiddeniftag = $doccfg->getElementsByTagName("forbiddeniftag");

      foreach my $specobject (@specobject)
      {
        # Check for generally required tags
        foreach my $requiredtag (@requiredtag)
        {
          $main::log->debug("DCHECKSPECOBJ", $specobject->findnodes("id")->[0]->textContent(),
              "required", $requiredtag->textContent());
          my $empty = $requiredtag->getAttribute("empty");
          if(defined($empty))
          {
            $empty=0 if $empty eq "false";
            $empty=1 if $empty eq "true";
          }
          my $optionaltag = $specobject->getElementsByTagName($requiredtag->textContent)->[0];
          if(!$optionaltag)
          {
            $main::log->warning("WRTMISSING", $requiredtag->textContent(), $specobject->findnodes("id")->[0]->textContent(),
                   $specobject->line_number(), $self->{FN});
          }
          elsif(!$empty && !$optionaltag->hasChildNodes())
          {
            $main::log->warning("WRTEMPTY", $requiredtag->textContent(), $specobject->findnodes("id")->[0]->textContent(),
                   $specobject->line_number(), $self->{FN});
          }
        }
        # Check for generally forbidden tags
        foreach my $forbiddentag (@forbiddentag)
        {
          $main::log->debug("DCHECKSPECOBJ", $specobject->findnodes("id")->[0]->textContent(),
              "forbidden", $forbiddentag->textContent());
          if($specobject->getElementsByTagName($forbiddentag->textContent))
          {
            $main::log->warning("WFTFOUND", $forbiddentag->textContent(), $specobject->findnodes("id")->[0]->textContent(),
                   $specobject->line_number(), $self->{FN});
          }
        }
        # Check for conditionally required tags
        foreach my $requirediftag (@requirediftag)
        {
          $main::log->debug("DCHECKSPECOBJ", $specobject->findnodes("id")->[0]->textContent(),
              "requiredif", $requirediftag->textContent());
          my $tagrequiredif = $requirediftag->getElementsByTagName("tagrequiredif")->[0];
          my $ifpresenttag = $requirediftag->getElementsByTagName("ifpresenttag")->[0];
          my $ifpresentvalue = $requirediftag->getElementsByTagName("ifpresentvalue")->[0];
          my $presenttag = $specobject->getElementsByTagName($ifpresenttag->textContent);

          my $empty = $tagrequiredif->getAttribute("empty");
          if(defined($empty))
          {
            $empty=0 if $empty eq "false";
            $empty=1 if $empty eq "true";
          }

          # If the tag specified by ifpresenttag is present in the currens specobject
          # AND
          # if EITHER ifpresentvalue is not set
          #    OR if ifpresentvalue is set AND is equal to the content of the tag specified by ifpresenttag
          # AND
          # if the tag specified by tagrequiredif is not present, then return an error.
          my $optionaltag = $specobject->getElementsByTagName($tagrequiredif->textContent)->[0];
          if( ($presenttag) &&
              ((!$ifpresentvalue) || (($ifpresentvalue) && ($ifpresentvalue->textContent eq $presenttag->textContent))) &&
              (!$optionaltag))
          {
            $main::log->warning("WRTMISSINGCOND", $tagrequiredif->textContent(), $specobject->findnodes("id")->[0]->textContent(),
                $ifpresenttag->textContent(), $specobject->line_number(), $self->{FN});
          }
          elsif(!$empty && !$optionaltag->hasChildNodes())
          {
            $main::log->warning("WRTEMPTY", $tagrequiredif->textContent(), $specobject->findnodes("id")->[0]->textContent(),
                   $specobject->line_number(), $self->{FN});
          }
        }

        # Check for conditionally forbidden tags
        foreach my $forbiddeniftag (@forbiddeniftag)
        {
          $main::log->debug("DCHECKSPECOBJ", $specobject->findnodes("id")->[0]->textContent(),
              "forbiddenif", $forbiddeniftag->textContent());
          my $tagforbiddenif = $forbiddeniftag->getElementsByTagName("tagforbiddenif")->[0];
          my $ifpresenttag = $forbiddeniftag->getElementsByTagName("ifpresenttag")->[0];
          my $ifpresentvalue = $forbiddeniftag->getElementsByTagName("ifpresentvalue")->[0];
          my $presenttag = $specobject->getElementsByTagName($ifpresenttag->textContent);

          # If the tag specified by ifpresenttag is present in the current specobject
          # AND
          # if EITHER ifpresentvalue is not set
          #    OR if ifpresentvalue is set AND is equal to the content of the tag specified by ifpresenttag
          # AND
          # if the tag specified by tagforbiddenif is present, then return an error.
          if( ($presenttag) &&
              ((!$ifpresentvalue) || (($ifpresentvalue) && ($ifpresentvalue->textContent eq $presenttag->textContent))) &&
              ($specobject->getElementsByTagName($tagforbiddenif->textContent)))
          {
            $main::log->warning("WFTFOUNDCOND", $tagforbiddenif->textContent(), $specobject->$specobject->findnodes("id")->[0]->textContent(),
                $ifpresenttag->textContent(), $specobject->line_number(), $self->{FN});
          }
        }
      }
    }
  }
  return $retval;
}

1;

