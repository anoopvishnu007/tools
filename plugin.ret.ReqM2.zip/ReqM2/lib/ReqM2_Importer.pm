# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_Importer;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 643 $';

use strict;
use Hash::Util;

########################################################################
# These variables get their values from the XML schema.                #
########################################################################
# These are all allowed top level input fields
# example: my @tags=('id', 'status', 'shortdesc', 'source', ...
my @tags;

# These are the input fields which are lists rather than scalar values
# and the corresponding sub-tags
# example: my $lists={releases => 'release',
#                     dependencies => 'dependson', ...
my $lists;

# These are input fields which are lists of lists and the name of the
# corresponding sub-lists
# example: $listlists={providescoverage => 'provcov'};
my $listlists;

# This is the mapping of the sublist-tags to the list of lists
# example: $listlisttags={provcov => \@<anonymous_list>};
# with @anonymous_list=('linksto', 'dstversion');
my $listlisttags;

########################################################################

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;
  my $doc = shift;
  my $topnode = shift;
  my $tags = shift;

  $common->checkArguments("ReqM2_Importer::new", ["ReqM2_Common","XML::LibXML::Document",
      "XML::LibXML::Element","HASH"], \@args);

  my $self = {COMMON => $common, DOC => $doc, TOPNODE => $topnode};

  # Fill in the tags allowed by the schema
  @tags=@{${$tags}{tags}};
  $lists=\%{${$tags}{lists}};
  $listlists=\%{${$tags}{listlists}};
  $listlisttags=\%{${$tags}{listlisttags}};

  bless($self, $type);
  return $self;
}

sub createSpecObjectsList
{
  my $self = shift;
  my @args = @_;
  my $doctype = shift;

  $self->{COMMON}->checkArguments("ReqM2_Importer::createSpecObjectsList", [""], \@args);

  $main::log->debug("DCREATEOBJLIST", $doctype);
  my $node = XML::LibXML::Element->new("specobjects");
  if(!defined($node))
  {
    $main::log->error("ECREATENODE", "specobjects.");
  }
  my $att = $self->{DOC}->createAttribute("doctype", $doctype);
  if(!defined($att))
  {
    $main::log->error("ECREATEATTRIB", "$doctype");
  }

  if(!defined($node->addChild($att)))
  {
    $main::log->error("EADDATTRIB", "$doctype");
  }
  
  if(!defined($self->{TOPNODE}->addChild($node)))
  {
    $main::log->error("EADDNODE", "specobjects");
  }

  return $node;
}

sub cleanupSpecObjectList
{
  my $self = shift;
  my @args = @_;
  my $node = shift;

  $self->{COMMON}->checkArguments("ReqM2_Importer::cleanupSpecObjectList", [""], \@args);

  $main::log->debug("DCLEANUP");

  if(!defined($node))
  {
    $main::log->error("ENODEUNDEF");
  }

  # Removing empty specobjects
  if($node->findvalue("count(specobject)") == 0)
  {
    $main::log->debug("DREMOVECONT");
    my $parnode = $node->parentNode;
    if(!defined($parnode))
    {
      $main::log->error("EPARNODEUNDEF");
    }
    $node->removeChildNodes();
    $parnode->removeChild($node);
  }

  # Removing empty tags in specobjects
  foreach my $tag ($node->findnodes("specobject/*"))
  {
    if(!$tag->hasChildNodes())
    {
      my $parnode = $tag->parentNode;
      $parnode->removeChild($tag);
    }
  }
}

sub getRawDocument
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Importer::getRawDocument", [], \@args);

  return $self->{DOC};
}

sub createObject
{
  my $self = shift;
  my @args = @_;
  my %specobject;

  $self->{COMMON}->checkArguments("ReqM2_Importer::createObject", [], \@args);

  $main::log->debug("DCREATEOBJ");
  # Only allow for the tag names which are defined in the schema
  if(!defined(Hash::Util::lock_keys(%specobject, @tags)))
  {
    $main::log->error("ELOCKHASH");
  }

  $self->{OBJ}=\%specobject;

  return \%specobject;
}

sub addObject
{
  my $self = shift;
  my @args = @_;
  my $node = shift;

  $self->{COMMON}->checkArguments("ReqM2_Importer::addObject", [""], \@args);

  my @mandatorytags = ("id", "status", "version");

  $main::log->debug("DADDOBJECT", $node);
  # Adds the contents of obj to the document...
  my $objnode=$self->{DOC}->createElement("specobject");
  if(!defined($objnode))
  {
    $main::log->error("ECREATENODE", "specobject");
  }
  if(!defined($node->addChild($objnode)))
  {
    $main::log->error("EADDNODE", "specobject");
  }

  $main::log->debug("DADD", "mandatory tags");
  foreach my $tag (@mandatorytags)
  {
    if(!defined($self->{OBJ}->{$tag}))
    {
      $main::log->error("ETAGMISSING", $tag);
    }
  }

  foreach my $key (@tags)
  {
    $main::log->debug("DCHECKELEM", $key);
    # The hash entry is a list element and needs further treatment
    if(exists($lists->{$key}))
    {
      $main::log->debug("DELEMENT", $key, "list");
      if($#{$self->{OBJ}->{$key}} >= 0)
      {
        $main::log->debug("DCREATELISTCONT", $key);
        # First, create the container
        my $list=$self->{DOC}->createElement($key);
        if(!defined($list))
        {
          $main::log->error("ECREATENODE", $key);
        }
        if(!defined($objnode->addChild($list)))
        {
          $main::log->error("EADDNODE", $key);
        }

        # Then add the sub-tags
        foreach my $value (@{$self->{OBJ}->{$key}})
        {
          $main::log->debug("DADD", "list element $value");
          my $tag=$self->{DOC}->createElement($lists->{$key});
          if(!defined($tag))
          {
            $main::log->error("ECREATENODE", $lists->{$key});
          }
          my $cnt=$self->{DOC}->createTextNode($value);
          if(!defined($cnt))
          {
            $main::log->error("ECREATETXTNODE", $value);
          }
          my $listnode=$list->addChild($tag);
          if(!defined($list))
          {
            $main::log->error("EADDNODE", $key);
          }
          if(!defined($listnode->addChild($cnt)))
          {
            $main::log->error("EADDTXTNODE", $value);
          }
        }
      }
    }
    # The hash entry is a lists of lists
    elsif(exists($listlists->{$key}))
    {
      $main::log->debug("DELEMENT", $key, "list of lists");

        $main::log->debug("DCREATELISTLISTCONT", $key);
        # First, create the container
        my $list=$self->{DOC}->createElement($key);
        if(!defined($list))
        {
          $main::log->error("ECREATENODE", $key);
        }
        if(!defined($objnode->addChild($list)))
        {
          $main::log->error("EADDNODE", $key);
        }

        foreach my $value (@{$self->{OBJ}->{$key}})
        {
          $main::log->debug("DCREATELISTOFLISTS", $listlists->{$key});
          my $listoflists=$self->{DOC}->createElement($listlists->{$key});
          if(!defined($listoflists))
          {
            $main::log->error("ECREATENODE", $listlists->{$key});
          }
          if(!defined($list->addChild($listoflists)))
          {
            $main::log->error("EADDNODE", $listlists->{$key});
          }
          foreach my $tag (@{$listlisttags->{$listlists->{$key}}})
          {
            if($value->{$tag})
            {

              $main::log->debug("DADD", "list of lists $tag");
              my $listtag=$self->{DOC}->createElement($tag);
              if(!defined($listtag))
              {
                $main::log->error("ECREATENODE", $tag);
              }
              my $tagnode=$listoflists->addChild($listtag);
              if(!defined($tagnode))
              {
                $main::log->error("EADDNODE", $tag);
              }
              my $cnt=$self->{DOC}->createTextNode($value->{$tag});
              if(!defined($cnt))
              {
                $main::log->error("ECREATETXTNODE", $value->{$tag});
              }
              if(!defined($tagnode->addChild($cnt)))
              {
                $main::log->error("EADDTXTNODE", $value->{$tag});
              }
            }
          }
        }

    }
    # The hash entry is a scalar element and can be added directly
    else
    {
      if($self->{OBJ}->{$key})
      {
        $main::log->debug("DADD", "element $key");
        my $tag=$self->{DOC}->createElement($key);
        if(!defined($tag))
        {
          $main::log->error("ECREATENODE", $key);
        }
        my $cnt=$self->{DOC}->createTextNode($self->{OBJ}->{$key});
        if(!defined($cnt))
        {
          $main::log->error("ECREATETXTNODE",  $self->{OBJ}->{$key});
        }
        my $tagnode=$objnode->addChild($tag);
        if(!defined($tagnode))
        {
          $main::log->error("EADDNODE", $key);
        }
        if(!defined($tagnode->addChild($cnt)))
        {
          $main::log->error("EADDTXTNODE", $self->{OBJ}->{$key});
        }
      }
    }
  }
}

1;
