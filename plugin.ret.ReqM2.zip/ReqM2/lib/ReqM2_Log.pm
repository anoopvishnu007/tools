# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_Log;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 646 $';

use strict;
use ReqM2_Messages;

my %errid;
my %errmsg;

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;

  $common->checkArguments("ReqM2_Log::new", ["ReqM2_Common"], \@args);

  my $self = {COMMON => $common};

  $self->{INFO} = 1;
  $self->{DEBUG} = 0;
  $self->{WERROR} = 0;

  my $ReqM2_Messages = ReqM2_Messages->new($common);

  my @errmsg = $ReqM2_Messages->getMessages("error");
  my @wrnmsg = $ReqM2_Messages->getMessages("warning");
  my @infmsg = $ReqM2_Messages->getMessages("info");
  my @dbgmsg = $ReqM2_Messages->getMessages("debug");

  for(my $i=0; $i<$#errmsg; $i+=3)
  {
    $self->{ERRID}->{$errmsg[$i+1]}=$errmsg[$i];
    $self->{ERRMSG}->{$errmsg[$i+1]}=$errmsg[$i+2];
  }

  for(my $i=0; $i<$#wrnmsg; $i+=3)
  {
    $self->{WRNID}->{$wrnmsg[$i+1]}=$wrnmsg[$i];
    $self->{WRNMSG}->{$wrnmsg[$i+1]}=$wrnmsg[$i+2];
  }

  for(my $i=0; $i<$#infmsg; $i+=3)
  {
    $self->{INFID}->{$infmsg[$i+1]}=$infmsg[$i];
    $self->{INFMSG}->{$infmsg[$i+1]}=$infmsg[$i+2];
  }

  for(my $i=0; $i<$#dbgmsg; $i+=3)
  {
    $self->{DBGID}->{$dbgmsg[$i+1]}=$dbgmsg[$i];
    $self->{DBGMSG}->{$dbgmsg[$i+1]}=$dbgmsg[$i+2];
  }
  bless($self, $type);
  return $self;
}

sub setLogfile
{
  my $self = shift;
  my @args =@_;
  my $cfg = shift;

  $self->{COMMON}->checkArguments("ReqM2_Log::setLogfile", [""], \@args);

  my $file;

  if($cfg->{LOGFILE})
  {
    if(open($file, ">>", $cfg->{LOGFILE}) == 0)
    {
      $self->error("ECREATE", $cfg->{LOGFILE});
    }
    $self->{LOGFILE}=$file;
#    $self->debug("Set logfile to $cfg->{LOGFILE}.");
  }
  return 1;
}

sub setDbgfile
{
  my $self = shift;
  my @args =@_;
  my $cfg = shift;

  $self->{COMMON}->checkArguments("ReqM2_Log::setDbgfile", [""], \@args);

  my $file;

  if($cfg->{DBGFILE})
  {
    if(open($file, ">>", $cfg->{DBGFILE}) == 0)
    {
      $self->error("ECREATE", $cfg->{DBGFILE});
    }
    $self->{DBGFILE}=$file;
#    $self->debug("Set debug logfile to $cfg->{DBGFILE}.");
  }
  return 1;
}

sub enableDebug
{
  my $self = shift;
  my @args =@_;

  $self->{COMMON}->checkArguments("ReqM2_Log::enableDebug", [], \@args);

  $self->{DEBUG} = 1;
}

sub disableDebug
{
  my $self = shift;
  my @args =@_;

  $self->{COMMON}->checkArguments("ReqM2_Log::disableDebug", [], \@args);

  $self->{DEBUG} = 0;
}

sub enableInfo
{
  my $self = shift;
  my @args =@_;

  $self->{COMMON}->checkArguments("ReqM2_Log::enableInfo", [], \@args);

  $self->{INFO} = 1;
}

sub disableInfo
{
  my $self = shift;
  my @args =@_;

  $self->{COMMON}->checkArguments("ReqM2_Log::disableInfo", [], \@args);

  $self->{INFO} = 0;
}

sub warnAsError
{
  my $self = shift;
  my @args =@_;

  $self->{COMMON}->checkArguments("ReqM2_Log::warnAsError", [], \@args);

  $self->{WERROR} = 1;
}


# The following functions basically all do the same. Unfortunately, they differ
# in small details, so they are implemented individually in order to retain
# readability.
sub error
{
  my $self = shift;
  my $errid = shift;
  my @errinfo = @_;

  my $time=localtime(time);
	my @caller = (caller(1)); # Determine which function caused the error
	my $caller = @caller?$caller[3]:"main";
  my $errmsg;

  if((!$self->{ERRMSG}->{$errid}) || (!$self->{ERRID}->{$errid}))
  {
    $self->error("EERROR", "Unknown error id $errid");
  }
  else
  {
    $errmsg = sprintf("(E%03d) $time - ERROR: $caller: $self->{ERRMSG}->{$errid}\n", $self->{ERRID}->{$errid}, @errinfo);
  }

  if($self->{LOGFILE})
  {
    print {$self->{LOGFILE}} $errmsg;
    close($self->{LOGILFE});
  }
  else
  {
    print STDERR $errmsg;
  }

  exit(1);
}





sub warning
{
  my $self = shift;
  my $wrnid = shift;
  my @wrninfo = @_;

  my $time=localtime(time);
	my @caller = (caller(1)); # Determine which function caused the warning
	my $caller = @caller?$caller[3]:"main";

  my $wrnmsg;

  if((!$self->{WRNMSG}->{$wrnid}) || (!$self->{WRNID}->{$wrnid}))
  {
    $self->error("EERROR", "Unknown warning id $wrnid");
  }
  else
  {
    $wrnmsg = sprintf("(W%03d) $time - WARNING: $caller: $self->{WRNMSG}->{$wrnid}\n", $self->{WRNID}->{$wrnid}, @wrninfo);
  }

  if($self->{LOGFILE})
  {
    print {$self->{LOGFILE}} $wrnmsg;
  }
  else
  {
    print STDERR $wrnmsg;
  }

  # If the "all warnings are errors" switch is set, close the logfile
  # (if opened) and exit with an error code
  if($self->{WERROR} == 1)
  {
    if($self->{LOGFILE})
    {
      close($self->{LOGILFE});
    }
    exit(1);
  }
}

sub info
{
  my $self = shift;
  my $infid = shift;
  my @infinfo = @_;

  my $time=localtime(time);
	my @caller = (caller(1)); # Determine which function caused the info message
	my $caller = @caller?$caller[3]:"main";

  my $infmsg;

	if($self->{INFO})
	{
	  if((!$self->{INFMSG}->{$infid}) || (!$self->{INFID}->{$infid}))
	  {
   	 	$self->error("EERROR", "Unknown info id $infid");
	  }
	  else
	  {
	    $infmsg = sprintf("(I%03d) $time - INFO: $caller: $self->{INFMSG}->{$infid}\n", $self->{INFID}->{$infid}, @infinfo);
	  }

  	print $infmsg;
	}
}

sub debug
{
  my $self = shift;
  my $dbgid = shift;
  my @dbginfo = @_;

  my $time=localtime(time);
	my @caller = (caller(1)); # Determine which function caused the debug info message
	my $caller = @caller?$caller[3]:"main";

  my $dbgmsg;

	if($self->{DEBUG})
	{	
	  if((!$self->{DBGMSG}->{$dbgid}) || (!$self->{DBGID}->{$dbgid}))
	  {
    	$self->error("EERROR", "Unknown debug id $dbgid");
	  }
	  else
	  {
	    $dbgmsg = sprintf("(D%03d) $time - DEBUG: $caller: $self->{DBGMSG}->{$dbgid}\n", $self->{DBGID}->{$dbgid}, @dbginfo);
	  }

	  if($self->{DBGFILE})
	  {
	    print {$self->{DBGFILE}} $dbgmsg;
	  }
	  else
	  {
	    print STDERR $dbgmsg;
	  }
	}
}

1;
