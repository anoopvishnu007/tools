# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_Trace;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 685 $';

use strict;

require ReqM2_Helpers;

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;
  my $config = shift;
  my $requiredStatus = shift;
  my $toolinfo = shift;

  $common->checkArguments("ReqM2_Trace::new", ["ReqM2_Common","ReqM2_ReqM2Cfg", "", "HASH"], \@args);

  my $doc = XML::LibXML::Document->new("1.0", "UTF-8");
  if(!defined($doc))
  {
    $main::log->error("ECREATE", "tracing results document");
  }

  my $helpers = ReqM2_Helpers->new($common, $doc);

  my $self = {COMMON=>$common, DOC => $doc, HELPERS => $helpers, STATUS => $requiredStatus};

  # General note:
  # There is no need to perform error checks on functions from ReqM2_Helpers,
  # as this is already done by the functions themselves.

  # Add top level container
  my $toplevel=$helpers->addChild($doc, "tracingresults");

  # Add containers for environment information and actual tracing results
  my $env=$helpers->addChild($toplevel, "environment");
  my $cmd=$helpers->addChild($toplevel, "cmdline");
  my $inf=$helpers->addChild($toplevel, "inputfiles");
  my $cfg=$helpers->addChild($toplevel, "configuration");
  my $spec=$helpers->addChild($toplevel, "specdocument");

  my $time= localtime(time);
  # Add environment information
  # !LINKSTO ReqM2ReqSpec.TracingUnit.0019, 1
  $main::log->debug("DADDTOOUTPUT", "environment information");
  $helpers->addChild($env, "toolname", $toolinfo->{name});
  $helpers->addChild($env, "toolversion", $toolinfo->{version});
  $helpers->addChild($env, "libxmlversion", $toolinfo->{libxmlversion});
  $helpers->addChild($env, "libxml2compileversion", $toolinfo->{libxml2compileversion});
  $helpers->addChild($env, "libxml2runtimeversion", $toolinfo->{libxml2runtimeversion});
  $helpers->addChild($env, "mainrev", $main::REVISION);
  $helpers->addChild($env, "commonrev", $ReqM2_Common::REVISION);
  $helpers->addChild($env, "helpersrev", $ReqM2_Helpers::REVISION);
  $helpers->addChild($env, "importerrev", $ReqM2_Importer::REVISION);
  $helpers->addChild($env, "logrev", $ReqM2_Log::REVISION);
  $helpers->addChild($env, "reqm2cfgrev", $ReqM2_ReqM2Cfg::REVISION);
  $helpers->addChild($env, "specobjrev", $ReqM2_SpecObj::REVISION);
  $helpers->addChild($env, "tracerev", $ReqM2_Trace::REVISION);
  $helpers->addChild($env, "versionrev", $ReqM2_Version::REVISION);
  $helpers->addChild($env, "perlversion", "$^V");
  $helpers->addChild($env, "commandline", $toolinfo->{cmdline});
  $helpers->addChild($env, "timestamp", $time);

  # Add command line details
  $main::log->debug("DADDTOOUTPUT", "command line details");
  foreach my $opt(keys(%{$toolinfo->{cmdopts}}))
  {
    my $cmdparam=$helpers->addChild($cmd, "cmdparam");
    $helpers->addChild($cmdparam, "name", $opt);
    my $value=${$toolinfo->{cmdopts}}{$opt};

    # Only add the <values> container, if the option is defined with a
    # trailing ":". Reason is, that getopt() also assigns a "1" to
    # options which do not expect a value...
    if($value && $toolinfo->{optstring}=~m/$opt:/)
    {
      my $values=$helpers->addChild($cmdparam, "values");
      foreach my $val(split /,/, $value)
      {
        $helpers->addChild($values, "value", $val);
      }
    }
  }

  # Add list of input files
  $main::log->debug("DADDTOOUTPUT", "input file list");
  foreach my $fn (@{$toolinfo->{filelist}})
  {
    $helpers->addChild($inf, "inputfile", $fn);
  }

  # Copy configuration information
  $main::log->debug("DADDTOOUTPUT", "configuration information");
  foreach my $child($config->{DATA}->findnodes("/reqmconfig")->[0]->nonBlankChildNodes())
  {
    my $child2=$child->cloneNode(1);
    if(!defined($child2))
    {
      $main::log->error("ECOPYNODE", "reqmconfig");
    }
    if(!defined($cfg->addChild($child2)))
    {
      $main::log->error("EADDNODE", "reqmconfig");
    }
  }

  bless($self, $type);
  return $self;
}

# Add loaded document to internal data representation
sub addDocument
{
  my $self = shift;
  my @args =@_;
  my $spec = shift;
  my $elide = shift;

  $self->{COMMON}->checkArguments("ReqM2_Trace::addDocument", ["ReqM2_SpecObj", ""], \@args);

  my @elide=split /,/, $elide;

  # This is the root element of the loaded document
  my $root = $spec->{DATA}->documentElement;

  my @specobjects=$root->findnodes("/*/specobjects");

  $main::log->debug("DADD", "document");
  foreach my $specobject (@specobjects)
  {
    $main::log->debug("DADD", "specobject");
    # Add specobject from source document
    my $child = $self->{DOC}->findnodes("/*/specdocument")->[0]->addChild($specobject);
    if(!defined($child))
    {
      $main::log->error("EADDNODE", "specobject");
    }

    # The following two loops replace the simple "needsobj" and "linksto"
    # lists by more detailed structures which will later store information
    # about the success of the tracing on a per-link basis. Unfortunately,
    # there is no easy way to move nodes in LibXML, thus we have to delete
    # and re-create them.

    # Add a new child to each required coverage type, which stores
    # if the corresponding coverage is fulfilled and, if yes, by which
    # specobject.
    foreach my $covnode ($child->findnodes("specobject/needscoverage/needsobj"))
    {
      # Store the content of the "needsobj" node
      my $covvalue=$covnode->textContent();

      # If a needsobj is listed in the "elide" list, it shall be removed
      # from the needscoverage list, because it is ignored during tracing.
      if(grep /^$covvalue$/, @elide)
      {
        $covnode->setNodeName("ignoreddoctype");
        next;
      }

      if(!defined($covvalue))
      {
        $main::log->error("EDETERMINE", "needsobj");
      }
      $main::log->debug("DMOVENEEDSOBJ", $covvalue);
      # Delete the content of the "needsobj" node
      $covnode->removeChildNodes();
      # Rename the "needsobj" node to "needscov"...
      $covnode->setNodeName("needscov");
      # ...and add the corresponding tags, including the old "needsobj" node
      $self->{HELPERS}->addChild($covnode, "needsobj", $covvalue);
      # !LINKSTO ReqM2ReqSpec.TracingUnit.0015, 1
      $self->{HELPERS}->addChild($covnode, "objcovstatus", "uncovered");
      $self->{HELPERS}->addChild($covnode, "coveredby");
    }

    # Add nodes for the status of the whole spec object
    foreach my $specnode ($child->findnodes("specobject"))
    {
      $main::log->debug("DADD", "inlinks container");

      $self->{HELPERS}->addChild($specnode, "inlinks");

      $main::log->debug("DADD", "objstatus 'unprocessed'");

      $self->{HELPERS}->addChild($specnode, "objstatus", "unprocessed");

      # If the object has "needscoverage" entries, set its gobal coverage
      # to 'uncovered'. Otherwise, it is automatically 'covered'
      if($specnode->findvalue("count(needscoverage/needscov/needsobj)") > 0)
      {
        # !LINKSTO ReqM2ReqSpec.TracingUnit.0016, 1
        $main::log->debug("DADD", "covstatus 'uncovered'");
        $self->{HELPERS}->addChild($specnode, "covstatus", "uncovered");
      }
      else
      {
        # !LINKSTO ReqM2ReqSpec.TracingUnit.0016, 1,
        # !        ReqM2ReqSpec.TracingUnit.0017, 1
        $main::log->debug("DADD", "covstatus 'covered'");
        $self->{HELPERS}->addChild($specnode, "covstatus", "covered");
      }

      # Add parent counter for detection of circular dependencies
      $main::log->debug("DADD", "numparent '0'");
      $self->{HELPERS}->addChild($specnode, "numparent", "0");
    }





    # Add a new child to each provided coverage, which stores
    # if the referenced spec object is fulfilled.
    foreach my $covnode ($child->findnodes("specobject/providescoverage/provcov/linksto"))
    {
      $main::log->debug("DADDTO", "linkstatus", "linksto provcov container");
      $self->{HELPERS}->addSibling($covnode, "linkstatus", "notlinked");
    }
  }
}

# Validate consistency of all loaded documents
sub validateDocumentSet
{
  my $self = shift;
  my @args =@_;

  $self->{COMMON}->checkArguments("ReqM2_Trace::validateDocumentSet", [], \@args);

  my %seen = ();

  # !LINKSTO ReqM2ReqSpec.TracingUnit.0001, 1
  $main::log->debug("DCHECKDUP", "specobject ids");
  foreach my $child ($self->{DOC}->getElementsByTagName("id"))
  {
    if ($seen{$child->textContent})
    {
      $main::log->warning("WDUPLICATEID", $child->textContent());
    }
    $seen{$child->textContent} = 1;
  }


  $main::log->debug("DCHECKDUP", "providescoverage entries");
  foreach my $node ($self->{DOC}->findnodes("/*/*/specobjects/specobject"))
  {
    undef %seen;
    my $id = $node->findnodes("id")->[0]->textContent();
    foreach my $child ($node->findnodes("providescoverage/provcov/linksto"))
    {
      if ($seen{$child->textContent()})
      {
        $main::log->error("EPROVCOVDUP", $child->textContent(), $id);
      }
      $seen{$child->textContent} = 1;
    }
  }


  $main::log->debug("DCHECKCIRC");
  # Check for circular dependencies by the help of topological sorting
  # ==================================================================
  # Set the numparent value of each node according to the number of
  # its predecessors.
  # !LINKSTO ReqM2ReqSpec.TracingUnit.0018, 1
  foreach my $node ($self->{DOC}->findnodes("/*/*/specobjects/specobject"))
  {
    foreach my $child ($node->findnodes("providescoverage/provcov/linksto"))
    {
      my $id=$child->textContent();
      if(!defined($id))
      {
        $main::log->error("ENONODE", "id");
      }
      my $dstnode = $self->{DOC}->findnodes("/*/*/specobjects/specobject[id='$id']")->[0];
      if($dstnode)
      {
        my $count = $dstnode->findnodes("numparent")->[0]->textContent();
        $count++;
        $self->{HELPERS}->setValue($dstnode, "numparent", "$count");
      }
    }
  }
  # Iteratively "remove" all nodes with numparent=0 (by setting numparent to -1) and
  # adjust the numparent values of their (direct) childs.
  while(my $node = $self->{DOC}->findnodes("/*/*/specobjects/specobject[numparent='0']")->[0])
  {
    foreach my $child ($node->findnodes("providescoverage/provcov/linksto"))
    {
      my $id=$child->textContent();
      if(!defined($id))
      {
        $main::log->error("ENONODE", "id");
      }
      my $dstnode = $self->{DOC}->findnodes("/*/*/specobjects/specobject[id='$id']")->[0];
      if($dstnode)
      {
        my $count = $dstnode->findnodes("numparent")->[0]->textContent();
        $count--;
        $self->{HELPERS}->setValue($dstnode, "numparent", "$count");
      }
    }
    $self->{HELPERS}->setValue($node, "numparent", "-1");
  }
  # If there are still nodes left with numparent != -1 when this point is reached,
  # topological sorting failed due to circular dependencies in the input data.
  if($self->{DOC}->findnodes("/*/*/specobjects/specobject[numparent != '-1']"))
  {
    $main::log->warning("WCIRCDEPEND");
  }

  return 1;
}

sub linkCoverages
{
  my $self = shift;
  my @args =@_;
  my $cfg = shift;
  my $prop = shift;

  $self->{COMMON}->checkArguments("ReqM2_Trace::linkCoverages", ["ReqM2_ReqM2Cfg", ""], \@args);

  my $root=XML::LibXML::XPathContext->new($self->{DOC}->documentElement);
  if(!defined($root))
  {
    $main::log->error("ENODOCROOT");
  }

  if(!$prop)
  {
    $main::log->warning("WPSET");
  }

  # Find all specobjects containers
  $main::log->debug("DCOLLECT", "specobjects containers");
  my @specobjectsctr=$root->findnodes("/*/*/specobjects");

  # We need two turns. First we propagate the "covered" states,
  # then we propagate the "uncovered" and "partially" states.
  # The second turn is omitted if the -P option is set.
  # In the end, none of the objects should be left in the
  # "unprocessed" state.
  my @turns;
  if($prop) {@turns=("covered", "uncovered");}
  else {@turns=("covered");}
  foreach my $turn (@turns)
  {
    my $filter;
    if($turn eq "covered")
    {
      $main::log->debug("DLINKINGCOV", "covered");
      if($prop) {$filter = "(covstatus='covered')";}
      else{$filter = "(covstatus='covered') or (covstatus='partially') or (covstatus='uncovered')";}
    }
    else
    {
      $main::log->debug("DLINKINGCOV", "uncovered");
      $filter = "(covstatus='partially') or (covstatus='uncovered')";
    }

    # Repeat until all unprocessed nodes of the current turn are processed
    while($root->findvalue("count(/*/*/specobjects/specobject[
          ($filter)
          and
          (objstatus='unprocessed')
          ])") > 0)
    {
      foreach my $specobjects (@specobjectsctr)
      {
        # This is the doctype of the current specobjects
        my $doctype = $specobjects->getAttribute("doctype");
        if(!defined($doctype))
        {
          $main::log->error("ENOATT", "doctype");
        }

        # Find all specobjects in the current container, which are
        # still unprocessed
        $main::log->debug("DCOLLECTUNPROC", $turn, $doctype);
        my @specobjectctr = $specobjects->findnodes("specobject[
            ($filter)
            and
            (objstatus='unprocessed')
            ]");
        foreach my $specobject (@specobjectctr)
        {
          my $srcid = $specobject->findnodes("id")->[0]->textContent();
          if(!defined($srcid))
          {
            $main::log->error("ENONODE", "id");
          }
          $main::log->debug("DPROCOBJ", $srcid);
          # Tag the current specobject as "in process"
          $main::log->debug("DSETOBJSTATUS", $srcid, "inprocess");
          my $objstatus = $self->{HELPERS}->setValue($specobject, "objstatus", "inprocess");

          # Set the semantic free outgoing links.
          $main::log->debug("DCOLLECT", "sematic free outgoing links");
          my @targets = $specobject->findnodes("links/link/target");
          foreach my $target (@targets)
          {
            my $dst=$target->textContent();
            my $inlinks = $root->findnodes("/*/*/*/specobject[id='$dst']/inlinks")->[0];
            # A semantic free link must not necessarily link to an existing Id
            if(!$inlinks) {next;}
            if(!$inlinks->findnodes("inlink[.='$srcid']"))
            {
              $self->{HELPERS}->addChild($inlinks, "inlink", "$srcid");
            }
          }

          # These are all outgoing links of the current node
          $main::log->debug("DCOLLECT", "referenced specobjects");
          my @linkstoctr = $specobject->findnodes("providescoverage/provcov/linksto");
          foreach my $linksto (@linkstoctr)
          {
            # This is the ID of the referenced object
            my $dst=$linksto->textContent();
            if(!defined($dst))
            {
              $main::log->error("EDETERMINE", "destination's id");
            }

            # This is the version the referenced object must have
            my $reqversion=$linksto->findnodes("../dstversion")->[0]->textContent;
            if(!defined($reqversion))
            {
              $main::log->error("EDETERMINE", "destination's version");
            }

            # This is the specobject referenced by the current outgoing link
            my $dest = $root->findnodes("/*/*/*/specobject[id='$dst']")->[0];

            $main::log->debug("DPROCREFOBJ", $dst);
            if(!$dest)
            {
              # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1,
              # !        ReqM2ReqSpec.TracingUnit.0013, 1
              my $linkstatus = $self->{HELPERS}->setValue($linksto, "../linkstatus", "linkerror");
              $self->{HELPERS}->addOrReplaceSibling($linkstatus, "linkerror", "referenced object does not exist");
              next;
            }

            # These are the covstatus and objstatus nodes of the referenced object, which
            # are filled in depending on the success of linking
            my $destcovstatus = $dest->findnodes("covstatus")->[0];
            if(!defined($destcovstatus))
            {
              $main::log->error("EDETERMINE", "destination's covstatus");
            }
            my $destobjstatus = $dest->findnodes("objstatus")->[0];
            if(!defined($destobjstatus))
            {
              $main::log->error("EDETERMINE", "destination's objstatus");
            }

            # This is the particular needsobj-node referenced by the current outgoing link
            my $needsobj = $dest->findnodes("needscoverage/needscov/needsobj[.='$doctype']")->[0];
            my $ignoredobj = $dest->findnodes("needscoverage/ignoreddoctype[.='$doctype']")->[0];

            $main::log->debug("DCHECKNEEDSOBJ", $dst, $srcid);
            if(!$needsobj && !$ignoredobj)
            {
              # None of the needed coverages of the linked object corresponds
              # to doctype of the current specobject.
              # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1,
              # !        ReqM2ReqSpec.TracingUnit.0013, 1
              my $linkstatus = $self->{HELPERS}->setValue($linksto, "../linkstatus", "linkerror");
              $self->{HELPERS}->addOrReplaceSibling($linksto, "linkdestdoctype", $dest->findnodes("../\@doctype")->[0]->textContent());
              $self->{HELPERS}->addOrReplaceSibling($linkstatus, "linkerror", "unrequested coverage");
            }
            elsif($ignoredobj)
            {
              $self->{HELPERS}->setValue($linksto, "../linkstatus", "ignored");
              $main::log->warning("WDTIGNORED", $doctype, $srcid, $dst);
            }
            elsif($needsobj)
            {
              my $errorstring;
              # These are the tracing relevant tags of the referenced object
              # !LINKSTO ReqM2ReqSpec.TracingUnit.0009, 1
              my @dsttracedtags = $cfg->getTracedTags($dest->findnodes("../../specobjects")->[0]->getAttribute("doctype"));

              $main::log->debug("DCHECKTRACING", $dst, $srcid);
              # Check if both linked objects correspond in the values of tracing relevant tags
              foreach my $tracedtag (@dsttracedtags)
              {
                my @srcnodes = $specobject->findnodes("$tracedtag");

                # Create an error if the referencing object does not provide a tracing relevant tag
                # required by the referenced object
                # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
                if(!@srcnodes)
                {
                  $errorstring = "tracing relevant tag missing: $tracedtag";
                }

                # Get the values of the tracing relevant tag
                my @srcvals = map($_->textContent(), @srcnodes);
                my @dstvals = map($_->textContent(), $dest->findnodes("$tracedtag"));

                # Both arrays must contain at least one common entry
                my $match = 0;
                foreach my $dst (@dstvals)
                {
                  $match = 1 if grep($dst eq $_, @srcvals);
                }
                # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
                if(!$match)
                {
                  $errorstring = "tracing relevant tag mismatch: $tracedtag";
                }
              }

              my $deststatus = $dest->findnodes("status")->[0]->textContent;
              if(!defined($destcovstatus))
              {
                $main::log->error("EDETERMINE", "destination's status");
              }
              $main::log->debug("DCHECKSTATUS", $dst);
              # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
              if(!grep (/$deststatus/, (split /,/, $self->{STATUS})))
              {
                $errorstring="destination status \'$deststatus\' excluded from tracing";
              }

              my $srcstatus = $specobject->findnodes("status")->[0]->textContent;
              if(!defined($srcstatus))
              {
                $main::log->error("EDETERMINE", "status");
              }
              $main::log->debug("DCHECKSTATUS", $srcid);
              # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
              if(!grep (/$srcstatus/, (split /,/, $self->{STATUS})))
              {
                $errorstring="source status \'$srcstatus\' excluded from tracing";
              }

              my $destversion = $dest->findnodes("version")->[0]->textContent;
              if(!defined($destversion))
              {
                $main::log->error("linkCoverages: Could not determine linksto version.\n");
              }
              $main::log->debug("DCHECKVERSION");
              # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
              if($destversion ne $reqversion)
              {
                $errorstring="destination version $destversion does not match required version $reqversion.\n";
              }

              # Add referencing node to coveredby list of referenced node
              $main::log->debug("DADDTO", $srcid, "coveredby list of $dst");
              my $covby = $needsobj->findnodes("../coveredby")->[0];
              if(!defined($covby))
              {
                $main::log->error("EDETERMINE", "destination's coveredby");
              }
              my $srcidnode;

              # If a linkedfrom with $srcid already exists, set srcidnode to this node,
              # otherwise we get duplicated entries.
              my $nodeexists = $covby->findnodes("./linkedfrom/srcid[.='$srcid']")->[0];
              if(defined($nodeexists))
              {
                $main::log->debug("DLINKEDFROMEXISTS", $srcid);
                $srcidnode = $nodeexists;
              }
              else
              {
                my $destobj = $self->{HELPERS}->addChild($covby, "linkedfrom");
                $srcidnode = $self->{HELPERS}->addChild($destobj, "srcid", $srcid);
              }
              # An error occurred, so we set the link information accordingly
              if($errorstring)
              {
                $main::log->debug("DLINKERROR", $srcid, $dst);
                $main::log->debug("DSETSRCSTATUS");
                # !LINKSTO ReqM2ReqSpec.TracingUnit.0013, 1,
                # !        ReqM2ReqSpec.TracingUnit.0014, 1
                $self->{HELPERS}->addOrReplaceSibling($srcidnode, "srcstatus", "$errorstring");
                my $linkstatus = $self->{HELPERS}->setValue($linksto, "../linkstatus", "linkerror");
                $self->{HELPERS}->addOrReplaceSibling($linksto, "linkdestdoctype", $dest->findnodes("../\@doctype")->[0]->textContent());
                $self->{HELPERS}->addOrReplaceSibling($linkstatus, "linkerror", "$errorstring");
              }
              # No error occurred, so we set the link information according to the status
              # of the referencing object
              else
              {
                if($turn eq "covered")
                {
                  $main::log->debug("DNOLINKERR", "$srcid <-> $dst", "covered");
                  $main::log->debug("DOBJTOCOVERED");
                  # In the "covered" turn, the destination status can simply be set to 'covered' as well,
                  # because we know that the source object has to be covered
                  $self->{HELPERS}->setValue($needsobj, "../objcovstatus", "covered");
                  # Set link status of referencing node to "linked"
                  # !LINKSTO ReqM2ReqSpec.TracingUnit.0012, 1,
                  $self->{HELPERS}->setValue($linksto, "../linkstatus", "linked");
                  $self->{HELPERS}->addOrReplaceSibling($linksto, "linkdestdoctype", $dest->findnodes("../\@doctype")->[0]->textContent());
                }
                else
                {
                  # In the uncovered run, we set the link error of the destination to "source not covered",
                  # because this must be the case here, otherwise the source object would not take part in
                  # this run.
                  $main::log->debug("DNOLINKERR", "$srcid <-> $dst", "uncovered");
                  $main::log->debug("DSETSRCSTATUS");
                  # !LINKSTO ReqM2ReqSpec.TracingUnit.0013, 1,
                  # !        ReqM2ReqSpec.TracingUnit.0014, 1
                  my $linkstatus = $self->{HELPERS}->setValue($linksto, "../linkstatus", "linkerror");
                  $self->{HELPERS}->addOrReplaceSibling($linksto, "linkdestdoctype", $dest->findnodes("../\@doctype")->[0]->textContent());
                  $self->{HELPERS}->addOrReplaceSibling($linkstatus, "linkerror", "source not covered");
                  $self->{HELPERS}->addOrReplaceSibling($srcidnode, "srcstatus", "source not covered");
                }
              }
            }

            if($turn eq "uncovered")
            {
              $main::log->debug("DUNCOVTURN");
              foreach my $needscov ($dest->findnodes("needscoverage/needscov"))
              {
                # Now check the status of all incoming links and set the objcovstate accordingly.
                # If srcstatus is set, the link is erroneous.
                my $notcovnodes=$needscov->findvalue("count(coveredby/linkedfrom/srcstatus)");
                my $allnodes=$needscov->findvalue("count(coveredby/linkedfrom)");
                my $deststate=$needscov->findnodes("objcovstatus")->[0];
                if(!defined($deststate))
                {
                  $main::log->error("EDETERMINE", "destination's objcovstatus");
                }

                if ($notcovnodes != 0)
                {
                  # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
                  if ($notcovnodes == $allnodes)
                  {
                    $main::log->debug("DOBJTOUNCOVERED");
                    $deststate->firstChild->setData("uncovered");
                  }
                  else
                  {
                    $main::log->debug("DOBJTOPART");
                    $deststate->firstChild->setData("partially");
                  }
                }
              }
            }

            # If some incoming links of the destination object are partially covered, set its
            # global status to 'partially' as well.
            # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
            if($dest->findvalue("count(needscoverage/needscov/objcovstatus[.='partially'])") != 0)
            {
              $main::log->debug("DCOVTOPART", $dst);
              $destcovstatus->firstChild()->setData("partially");
            }
            # If all incoming links of the destination object are covered, set its
            # global status to 'covered' as well.
            # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
            elsif($dest->findvalue("count(needscoverage/needscov/objcovstatus[.='uncovered'])") == 0)
            {
              $main::log->debug("DSETCOVSTATUS", "covered", $dst, "covered");
              $destcovstatus->firstChild()->setData("covered");
            }
            # If all incoming links are uncovered, then set the global status of the destination
            # object to 'uncovered'.
            # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
            elsif($dest->findvalue("count(needscoverage/needscov/objcovstatus[.='covered'])") == 0)
            {
              $main::log->debug("DSETCOVSTATUS", "uncovered", $dst, "uncovered");
              $destcovstatus->firstChild()->setData("uncovered");
            }
            # If some of the incoming links are covered and others uncovered, set the global
            # status of the destination object to 'partially'.
            # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
            else
            {
              $main::log->debug("DCOVRESETTOPART", $dst);
              $destcovstatus->firstChild()->setData("partially");
            }
            # If we are in the "uncovered" turn, i.e. the current object is uncovered,
            # then the destination object must be set to 'unprocessed' again (but only
            # if the link really could be established), in order to propagate the
            # 'uncovered' coverage in the next loop iteration.
            # !LINKSTO ReqM2ReqSpec.TracingUnit.0011, 1
            if(($turn eq "uncovered") &&
               ($linksto->findnodes("../linkstatus")->[0]->textContent() eq "linked"))
            {
              $main::log->debug("DOBJTOUNPROC", $srcid, $dst);
              $destobjstatus->firstChild()->setData("unprocessed");
              # The coverage status of the destination object must be set to "partially"
              # if it had been set to "covered" already.
              if($destcovstatus->textContent() ne "uncovered")
              {
                $main::log->debug("DRESETTOPART", $srcid, $dst);
                $destcovstatus->firstChild()->setData("partially");
              }
            }
          }
          # All outgoing links have been processed.
          $main::log->debug("DSETOBJSTATUS", $srcid, "processed");
          $self->{HELPERS}->setValue($specobject, "objstatus", "processed");
        }
      }
    }
  }

  # !LINKSTO ReqM2ReqSpec.TracingUnit.0021, 1
  if($root->findvalue("count(/*/*/specobjects/specobject[objstatus='unprocessed'])") > 0)
  {
    $main::log->error("EFATAL",  __FILE__, __LINE__, "Illegal condition: unprocessed specobjects left after tracing");
  }
}

sub createReport
{
  my $self = shift;
  my @args = @_;
  my $outFile = shift;

  $self->{COMMON}->checkArguments("createReport", [""], \@args);

  if(!open(FILE, ">$outFile"))
  {
    $main::log->error("EOPENFILE", $outFile);
    exit 1;
  }
  $main::log->debug("DWRITETRACREPORT", $outFile);
  print FILE $self->{DOC}->toString(1);
  close(FILE);
}

1;
