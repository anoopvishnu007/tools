# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_ReqM2Cfg;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 643 $';

use strict;

require ReqM2_Helpers;

# !LINKSTO ReqM2ReqSpec.TracingUnit.0003, 1
my @mandatorytags = ("id", "status", "version");

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;
  my $fn = shift;
  my $xsd = shift;

  $common->checkArguments("ReqM2_ReqM2Cfg::new", ["ReqM2_Common","", ""], \@args);

  my $self = {COMMON => $common, FN => $fn, XSD => $xsd, DATA => {}};

  if(! -f $fn)
  {
    return 0;
  }

  bless($self, $type);
  return $self;
}

sub parseSchema
{
  my $self = shift;
  my @args = @_;
  my $fn = shift;

  $self->{COMMON}->checkArguments("ReqM2_ReqM2Cfg::parseSchema", [""], \@args);

  my %tags;

  my @tags;
  my @simpletags;
  my %lists;
  my %listlists;
  my %listlisttags;
  my @defaulttags;
  my @defaultsimpletags;

  my %mandatorytags;

  $main::log->debug("DPARSESCHEMA");

  my $schema = XML::LibXML->load_xml(location => $fn);
  if(!defined($schema))
  {
    $main::log->error("EOPENSCHEMA", $fn);
  }

  # Get a list of all nodes defined in the schema. For more information,
  # see ReqM2_Importer.pm where this list is used.
  my @deftags = $schema->findnodes("//xs:element[\@name='specobject']/xs:complexType/xs:sequence/xs:element");

  $main::log->debug("DCOLLECT", "specobject tags");

  foreach my $deftags (@deftags)
  {
    my $att=$deftags->getAttribute("name");

    $mandatorytags{$att} = 1;

    if(defined($att))
    {
      push @tags, $att;

      # Ignore mixed nodes, as their only purpose is the use of DocBook tags. These tags
      # are ignored by ReqM2 and treated as plain text.
      if($deftags->hasChildNodes() && (!$deftags->findnodes("xs:complexType[\@mixed='true']")))
      {
        my @childnodes = $deftags->findnodes("xs:complexType/xs:sequence/xs:element");
        foreach my $child (@childnodes)
        {
          my $childatt=$child->getAttribute("name");
          if(!defined($childatt))
          {
            $main::log->error("ENOATT", "name");
          }

          if($child->hasChildNodes() && (!$deftags->findnodes("xs:complexType[\@mixed='true']")))
          {
            my @sublist;
            $listlists{$att}=$childatt;

            my @childchildnodes = $child->findnodes("xs:complexType/xs:sequence/xs:element");
            foreach my $childchild (@childchildnodes)
            {
              my $childchildatt = $childchild->getAttribute("name");
              if(!defined($childchildatt))
              {
                $main::log->error("ENOATT", "name");
              }

              push @sublist, $childchildatt;
            }
            $main::log->debug("DNODEIS", $att, "list-of-lists node");
            $listlisttags{$childatt}=\@sublist;
          }
          else
          {
            $main::log->debug("DNODEIS", $att, "list node");
            $lists{$att}=$childatt;
          }
        }
      }
      else
      {
        $main::log->debug("DNODEIS", $att, "single node");
        push @simpletags, $att;
      }
    }
  }

  # !LINKSTO ReqM2ReqSpec.TracingUnit.0003, 1
  foreach my $mandatorytag (@mandatorytags)
  {
    if(!defined($mandatorytags{$mandatorytag}))
    {
      $main::log->error("ENOMANDTAG", $mandatorytag);
    }
  }


  # Get a list of all default nodes defined in the schema.
  @deftags = $schema->findnodes("//xs:element[\@name='defaults']/xs:complexType/xs:sequence/xs:element");

  $main::log->debug("DCOLLECT", "default specobject tags");

  foreach my $deftags (@deftags)
  {
    my $att=$deftags->getAttribute("name");
    if(defined($att))
    {
      push @defaulttags, $att;
      if(!($deftags->hasChildNodes()))
      {
        push @defaultsimpletags, $att;
        $main::log->debug("DDEFAULTTAG", $att, "list node");
      }
      else
      {
        $main::log->debug("DDEFAULTTAG", $att, "single node");
      }
    }
  }

  $main::log->debug("DSTORESCHEMA");

  $tags{tags}=\@tags;
  $tags{simpletags}=\@simpletags;
  $tags{lists}=\%lists;
  $tags{listlists}=\%listlists;
  $tags{listlisttags}=\%listlisttags;
  $tags{defaulttags}=\@defaulttags;
  $tags{defaultsimpletags}=\@defaultsimpletags;

  return %tags;
}


sub loadConfig
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_ReqM2Cfg::loadConfig", [], \@args);

  my $cfgfile = XML::LibXML->load_xml(
      location => $self->{FN});
  if(!defined($cfgfile))
  {
    $main::log->error("EOPENFILE", $self->{FN});
  }

  my $schema=XML::LibXML::Schema->new(
      location => $self->{XSD});
  if(!defined($schema))
  {
    $main::log->error("EOPENSCHEMA", $self->{XSD});
  }

  $main::log->debug("DVALIDATE", "configuration");

  eval{$schema->validate($cfgfile);};
  if($@)
  {
    $main::log->error("EEVAL", $@);
  }

  # If we came here, the configuration file has been parsed successfully.
  $self->{DATA}=$cfgfile;

  $main::log->debug("DSEARCHLOGFILE");

  # Determine if a logfile is configured
  my $logfile=$self->{DATA}->findnodes("/reqmconfig/logfile")->[0];
  if($logfile)
  {
    $self->{LOGFILE}=$logfile->textContent();
  }

  $main::log->debug("DSEARCHDBGFILE");

  # Determine if a debug logfile is configured
  my $dbgfile=$self->{DATA}->findnodes("/reqmconfig/dbgfile")->[0];
  if($dbgfile)
  {
    $self->{DBGFILE}=$dbgfile->textContent();
  }

  $main::log->debug("DCHECKCONS");

  # Check consistency of required, forbidden and traced tags
  # !LINKSTO ReqM2ReqSpec.TracingUnit.0010, 1
  my @doctypes=$self->getContentList(\@{$self->{DATA}->findnodes("/reqmconfig/docconfig/document/doctype")});

  foreach my $doctype (@doctypes)
  {
    my @requiredtags=$self->getContentList(\@{$self->{DATA}->findnodes("/reqmconfig/docconfig/document[doctype='$doctype']/requiredtags/requiredtag")});
    my @requirediftags=$self->getContentList(\@{$self->{DATA}->findnodes("/reqmconfig/docconfig/document[doctype='$doctype']/requirediftags/requirediftag/tagrequiredif")});
    my @forbiddentags=$self->getContentList(\@{$self->{DATA}->findnodes("/reqmconfig/docconfig/document[doctype='$doctype']/forbiddentags/forbiddentag")});
    my @forbiddeniftags=$self->getContentList(\@{$self->{DATA}->findnodes("/reqmconfig/docconfig/document[doctype='$doctype']/forbiddeniftags/forbiddeniftag/tagforbiddenif")});
    my @ifpresenttags=$self->getContentList(\@{$self->{DATA}->findnodes("/reqmconfig/docconfig/document[doctype='$doctype']/*/*/ifpresenttag")});
    my @tracedtags=$self->getContentList(\@{$self->{DATA}->findnodes("/reqmconfig/docconfig/document[doctype='$doctype']/tracedtags/tracedtag")});

    # !!! TO DO: Clean up code duplication !!!
    # !LINKSTO ReqM2ReqSpec.TracingUnit.0003, 1
    foreach my $mandatorytag (@mandatorytags)
    {
      foreach my $tag (@requirediftags)
      {
        if ($tag eq $mandatorytag)
        {
          $main::log->error("EMANDTAGWRONG", $mandatorytag, "requiredif");
        }
      }
      foreach my $tag (@forbiddentags)
      {
        if ($tag eq $mandatorytag)
        {
          $main::log->error("EMANDTAGWRONG", $mandatorytag, "forbidden");
        }
      }
      foreach my $tag (@forbiddeniftags)
      {
        if ($tag eq $mandatorytag)
        {
          $main::log->error("MEMANDTAGWRONG", $mandatorytag, "forbiddenif");
        }
      }
      foreach my $tag (@tracedtags)
      {
        if ($tag eq $mandatorytag)
        {
          $main::log->error("EMANDTAGWRONG", $mandatorytag, "traced");
        }
      }
      foreach my $tag (@requiredtags)
      {
        if ($tag eq $mandatorytag)
        {
          $main::log->warning("WNONEED", $mandatorytag, "required");
        }
      }
      foreach my $tag (@ifpresenttags)
      {
        if ($tag eq $mandatorytag)
        {
          $main::log->warning("WNONEED", $mandatorytag, "ifpresent");
        }
      }
    }

    # The order of these entries is important! Combinations of @tags1 and @tags2 with the same index are forbidden within one doctype.
    my @tags1=(\@forbiddentags,
               \@forbiddentags,
               \@forbiddentags,
               \@forbiddentags,
               \@forbiddentags,
               \@forbiddeniftags,
               \@forbiddeniftags,
               \@forbiddeniftags,
               \@forbiddeniftags,
               \@requiredtags,
               \@requiredtags);
    my @tags2=(\@requiredtags,
               \@requirediftags,
               \@forbiddeniftags,
               \@tracedtags,
               \@ifpresenttags,
               \@requiredtags,
               \@requirediftags,
               \@tracedtags,
               \@ifpresenttags,
               \@requirediftags,
               \@ifpresenttags);
    my @stat1=("forbidden",
               "forbidden",
               "forbidden",
               "forbidden",
               "forbidden",
               "forbiddenif",
               "forbiddenif",
               "forbiddenif",
               "forbiddenif",
               "required",
               "required");
    my @stat2=("required",
               "requiredif",
               "forbiddenif",
               "traced",
               "ifpresent",
               "required",
               "requiredif",
               "traced",
               "ifpresent",
               "requiredif",
               "ifpresent");

    # Search for forbidden combinations and report an error if one is found
    for (my $idx=0; $idx<=$#tags1; $idx++)
    {
      $main::log->debug("DCHECKTAGS", $stat1[$idx], $stat2[$idx], $doctype);
      foreach my $tag1 (@{$tags1[$idx]})
      {
        foreach my $tag2 (@{$tags2[$idx]})
        {
          if($tag1 eq $tag2)
          {
            $main::log->error("ETAGCOLLIDE", $tag1, $stat1[$idx], $stat2[$idx], $doctype);
          }
        }
      }
    }

    $main::log->debug("DCHECKTAGS", "traced", "required", $doctype);

    # This has to be treated separately, because here we search for a missing configuration
    foreach my $tag1 (@tracedtags)
    {
      my $flag = 0;
      foreach my $tag2 (@requiredtags)
      {
        if($tag1 eq $tag2)
        {
          $flag = 1;
        }
      }
      $main::log->error("ETAGNOTREQ", $tag1, $doctype) if(!$flag);
    }
  }
  return 1;
}

# !LINKSTO ReqM2ReqSpec.TracingUnit.0009, 1
sub getTracedTags
{
  my $self = shift;
  my @args = @_;
  my $doctype = shift;

  $self->{COMMON}->checkArguments("ReqM2_ReqM2Cfg::getTracedTags", [""], \@args);

  my @tagnames;

  $main::log->debug("DLOADINGTAGS");
  my @tags = $self->{DATA}->findnodes("/reqmconfig/docconfig/document[doctype='$doctype']/tracedtags/tracedtag");
  foreach my $tag (@tags)
  {
    push @tagnames, $tag->textContent();
  }

  return @tagnames;
}

sub getContentList
{
  my $self = shift;
  my @args = @_;
  my $nodelist = shift;

  $self->{COMMON}->checkArguments("ReqM2_ReqM2Cfg::getContentList", ["ARRAY"], \@args);

  my @contentlist;

  $main::log->debug("DGETCONTENT");

  foreach my $node (@{$nodelist})
  {
    my $content = $node->textContent();
    push @contentlist, $content if $content;
  }

  return @contentlist;
}

1;
