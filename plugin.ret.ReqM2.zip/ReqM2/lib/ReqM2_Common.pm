# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_Common;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 685 $';

use strict;
use Hash::Util 0.007_000;
use Encode 2.035_000;
use Encode::Guess 2.003_000;

sub new
{
  my $type = shift;

  my $self = { };

  bless($self, $type);
  return $self;
}

sub setEncoding
{
  my $self = shift;
  my @args = @_;
  my $enc = shift;
  $self->checkArguments("ReqM2Common::setEncoding", [""], \@args);

  $self->{ENC} = $enc;
}

sub getUtf8Array
{
  my $self = shift;
  my @args = @_;
  local *FH = shift;

  $self->checkArguments("ReqM2Common::getUtf8Array", [""], \@args);

  my $data = $self->getUtf8Data(*FH);

  my @lines = split /\n/, $data;

  return @lines;
}

sub getUtf8Data
{
  my $self = shift;
  my @args = @_;
  local *FH = shift;

  $self->checkArguments("ReqM2Common::getUtf8Data", [""], \@args);


  my $data = join '', <FH>;

  $data = $self->toUtf8($data);

  return $data;
}

sub toUtf8
{
  my $self = shift;
  my @args = @_;
  my $data = shift;

  $self->checkArguments("ReqM2Common::toUtf8", [""], \@args);

  my $enc;

  if(defined($self->{ENC}))
  {
    if(defined(Encode::find_encoding($self->{ENC})))
    {
      $enc = $self->{ENC};
    }
    else
    {
      $main::log->warning("WENCUNSUP", "$self->{ENC}");
    }
  }
  else
  {
    my $decoder = Encode::Guess->guess($data);
    if(!ref($decoder))
    {
      $main::log->warning("WENKUNKNOWN");
    }
    else
    {
      $enc = $decoder->name;
      $main::log->debug("DFOUNDENC", $enc);
    }
  }

  if($enc && $enc ne "utf8")
  {
    if (!defined(Encode::from_to($data, $enc, "utf8")))
    {
      $main::log->warning("WNOCONVERT");
    }
  }

  return $data;
}


sub parseParams
{
  my $self = shift;
  my @args = @_;
  my $name = shift;
  my $params = shift;
  # This hash contains references to the variables which will take the
  # parameter values.
  my $reqparam = shift;
  my $warnfor = shift;

  $self->checkArguments("ReqM2Common::parseParams", ["","","HASH", "HASH"], \@args);

  # This assignment avoids too many confusing, nested curly brackets...
  my %reqparam = %{$reqparam};

  my $parmask = 0;
  my $parbit = 1;

  # These are the keywords of the required parameters
  my @parid = keys(%reqparam);

PARAM:
  # Loop over all parameters passed to the transformer
  foreach my $param (split /;/, $params)
  {
    my $found = 0;
    my $parbit = 1;
    # Loop over all allowed parameters
    foreach my $parid (@parid)
    {
      if($param =~ m/$parid\s*=\s*(.*)/)
      {
        $found = 1;
        if($parmask & $parbit)
        {
          $main::log->error("EPARAMTWICE", $name, $parid);
          return 0;
        }
        if(defined($1))
        {
          my $partype = ref($reqparam{$parid});
          if($partype eq "SCALAR")
          {
            ${$reqparam{$parid}} = $1;
          }
          elsif($partype eq "ARRAY")
          {
            @{$reqparam{$parid}} = split /,/, $1;
          }
          else
          {
            $main::log->error("EPARAMUNSUP", $name, $partype, $parid);
          }
        }
        else
        {
          undef(${$reqparam{$parid}});
        }
        $parmask |= $parbit;
        next PARAM;
      }
      $parbit <<= 1;
    }
    if(!$found)
    {
      $main::log->error("EPARAMILLEGAL", $name, $param);
      return 0;
    }
  }

  $parbit = 1;
  foreach my $parid (@parid)
  {
    my $partype = ref($reqparam{$parid});
    if(!($parmask & $parbit))
    {
      if($partype eq "SCALAR")
      {
        if(defined(${$reqparam{$parid}}) && defined(${$warnfor}{$parid}))
        {
          $main::log->warning("WDEFAULT", $name, $parid, ${$reqparam{$parid}});
        }
      }
      elsif($partype eq "ARRAY")
      {
        if(defined(${$reqparam{$parid}}[0]) && defined(${$warnfor}{$parid}))
        {
          $main::log->warning("WDEFAULT", $name, $parid, ${$reqparam{$parid}}[0]);
        }
      }
      else
      {
        $main::log->error("EPARAMUNSUP", $name, $partype, $parid);
      }
    }
    $parbit <<= 1;
  }

}

# Check the number and types of arguments given to a subroutine
sub checkArguments
{
  my $self = shift;
  my @ownargs = @_;
  my $name = shift;
  my $types = shift;
  my $args = shift;

  # Prevent infinite recursion...
  if($name ne "ReqM2Common::checkArguments")
  {
    $self->checkArguments("ReqM2Common::checkArguments", ["", "ARRAY", "ARRAY"], \@ownargs);
  }

  my @args = @{$args};
  my @types = @{$types};

  my $i = 0;

  if($#args != $#types)
  {
    $main::log->error("EPARAMNUM", $name, $#args, $#types);
  }
  # Perform the next checks only if the tested subroutine requires at least
  # one argument
  if($#args != 0)
  {
    foreach my $arg (@args)
    {
      if(!defined($arg))
      {
        $main::log->error("EPARAMUNDEF", $name, $i);
      }

      my $type = ref($arg);
      my $typeok = 0;
      if($types[$i])
      {
        foreach my $subtype (split /\|/, $types[$i])
        {
          if($type eq $subtype)
          {
            $typeok = 1;
            last;
          }
        }
      }
      elsif($type eq "")
      {
        $typeok = 1;
      }

      if(!$typeok)
      {
        $main::log->error("EPARAMREFTYPE", $name, $i, $type);
      }
      $i++;
     }
  }
}


1;
