# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_Validate;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 638 $';

use strict;

require ReqM2_Helpers;

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;

  $common->checkArguments("ReqM2_Validate::new", ["ReqM2_Common"], \@args);

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub loadInFiles
{
  my $self = shift;
  my @args = @_;
  my $filenames = shift;

  $self->{COMMON}->checkArguments("ReqM2_Validate::loadInFiles", ["ARRAY"], \@args);

  my @infiles;

  foreach my $filename (@{$filenames})
  {
    my $infile = XML::LibXML->load_xml(
        location => $filename,
        line_numbers => 1
        );
    if(!defined($infile))
    {
      $main::log->error("EOPENFILE", $filename);
    }
    else
    {
      push @infiles, $infile;
    }
  }
  $self->{INFILES} = \@infiles;
}

sub loadOutFile
{
  my $self = shift;
  my @args = @_;
  my $filename = shift;

  $self->{COMMON}->checkArguments("ReqM2_Validate::loadOutFile", [""], \@args);

  my $outfile = XML::LibXML->load_xml(
        location => $filename,
        line_numbers => 1
        );
  if(!defined($outfile))
  {
    $main::log->error("EOPENFILE", $filename);
  }
  else
  {
    $self->{OUTFILE} = $outfile;
  }
}

# Check that for each specobject in the infiles there is excatly one in the outfile
sub checkSpecInEqSpecOut
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Validate::checkSpecInEqSpecOut", [], \@args);

  my $retval;

  foreach my $infile (@{$self->{INFILES}})
  {
    my @inids = $infile->findnodes("//specobject/id");
    foreach my $inid (@inids)
    {
      my $id = $inid->textContent();
      my @outids = $self->{OUTFILE}->findnodes("//specobject[./id='$id']");
      if(!@outids)
      {
        $main::log->warning("WSPECOBJNOTFOUNDINO", $id);
        $retval = 0;
      }
      elsif($#outids > 0)
      {
        $main::log->warning("WSPECOBJMULDEFINO", $id, ($#outids+1));
        $retval = 0;
      }
      else
      {
        $retval = 1;
      }
    }
  }

  return $retval;
}

# Check that for each specobject in the outfile there is excatly one in the infiles
sub checkSpecOutEqSpecIn
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Validate::checkSpecOutEqSpecIn", [], \@args);

  my $retval;
  my $ctr;

  foreach my $outid (@{$self->{OUTFILE}->findnodes("//specobject/id")})
  {
    my $id = $outid->textContent();
    $ctr = 0;

    foreach my $infile (@{$self->{INFILES}})
    {
      my @inids = $infile->findnodes("//specobject[./id='$id']");
      if(@inids)
      {
        $ctr+=($#inids+1);
      }
    }
    if($ctr == 0)
    {
      $main::log->warning("WSPECOBJNOTFOUNDINI", $id);
      $retval = 0;
    }
    elsif($ctr > 1)
    {
      $main::log->warning("WSPECOBJMULTDEFINI", $id, $ctr);
      $retval = 0;
    }
    else
    {
      $retval = 1;
    }
  }

  return $retval;
}

# Check that the content of the tags is equal in input and output specobjects
sub checkTags
{
  my $self = shift;
  my @args = @_;

  # These are the tags which are ignored in the simple compare-loop. This list
  # also contains tags which must be compared but require some special treatment,
  # like <needscoverage>.
  my @ignoretags=("needscoverage", "objcovstatus", "coveredby", "srcstatus",
                  "linkstatus", "linkerror", "objstatus", "covstatus", "numparent");

  $self->{COMMON}->checkArguments("ReqM2_Validate::checkTags", [], \@args);

  my $retval = 1;

  foreach my $infile (@{$self->{INFILES}})
  {
    my @insos = $infile->findnodes("//specobject");
    foreach my $inso (@insos)
    {
      my $err = 0;
      my $id = $inso->findnodes("id")->[0]->textContent();
      my $outso = $self->{OUTFILE}->findnodes("//specobject[./id='$id']")->[0];

      my @inneedsobj  = map {$_->textContent()} $inso->findnodes("needscoverage/needsobj");
      my @outneedsobj  = map {$_->textContent()} $outso->findnodes("needscoverage/needscov/needsobj");

      # Recursively, walk through all "standard" tags
      if(!compareXmlBranch($inso, $outso, \@ignoretags))
      {
        $err = 1;
      }

      # The <needscoverage> container has a different structure in the input
      # and output files, thus it needs some extra treatment...

      # Do the number of <needsobj> match?
      if($#inneedsobj != $#outneedsobj)
      {
        $err = 1;
      }

      # Do the needed coverage types match?
      foreach my $in (@inneedsobj)
      {
        if(!grep(/$in/, @outneedsobj))
        {
          $err = 1;
        }
      }

      # If a mismatch was found, print a warning.
      if($err == 1)
      {
        $main::log->warning("WSPECOBJDIFF", $id);
        $retval = 0;
      }
    }
  }

  return $retval;
}

# Check that all output specobjects have been processed and analyzed for cyclic dependencies
sub checkProcessed
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Validate::checkProcessed", [], \@args);

  my $retval = 1;

  foreach my $specobject (@{$self->{OUTFILE}->findnodes("//specobject")})
  {
    my $id = $specobject->findnodes("id")->[0]->textContent();
    my $obstat = $specobject->findnodes("objstatus")->[0]->textContent();
    my $numpar = $specobject->findnodes("numparent")->[0];

    if($obstat ne "processed")
    {
      $main::log->warning("WSPECOBJNOTPROC", $id);
      $retval = 0;
    }
    if(!defined($numpar))
    {
      $main::log->warning("WSPECOBJNOTANL", $id);
      $retval = 0;
    }
  }

  return $retval;
}

# Recursively walk through all branches and compare the tags
sub compareXmlBranch
{
  my $src = shift;
  my $dst = shift;
  my $ign = shift;

  my $retval = 1;

  my @schildren;
  my @dchildren;

  # Remove all children which are in the ignore list
  foreach my $tmpnode ($src->nonBlankChildNodes())
  {
    my $name = $tmpnode->nodeName;
    if(!grep(/$name/, @{$ign}))
    {
      push @schildren, $tmpnode;
    }
  }
  foreach my $tmpnode ($dst->nonBlankChildNodes())
  {
    my $name = $tmpnode->nodeName;
    if(!grep(/$name/, @{$ign}))
    {
      push @dchildren, $tmpnode;
    }
  }

  my $name = $src->nodeName;
  # Do the number of children match?
  if($#schildren != $#dchildren)
  {
    $retval = 0;
  }
  # If there are children, walk recursively through them
  elsif(@schildren)
  {
    for(my $i=0; $i <= $#schildren; $i++)
    {
      if(!compareXmlBranch($schildren[$i], $dchildren[$i], $ign))
      {
        $retval = 0;
      }
    }
  }
  # Otherwise, compare this tag's content
  else
  {
    if($src->textContent() ne $dst->textContent())
    {
      $retval = 0;
    }
  }

  return $retval;
}

1;
