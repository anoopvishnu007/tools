# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_Messages;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 598 $';

use strict;

my @errmsg = (
  0, "ENOERROR", "No Error.",
  1, "EADDATTRIB", "Could not add attribute %s.",
  2, "EADDNODE", "Could not add node %s.",
  3, "EADDAFTER", "Could not add %s after %s.",
  4, "EADDTXTNODE", "Could not add textnode %s.",
  5, "EATTDIFF", "Attribute '%s' differs from tag '%s' in specobject %s.",
  6, "EBOOLEAN", "Only 'true' and 'false' is allowed for '%s'.",
  7, "ECOPYNODE", "Could not copy node %s.",
  8, "ECREATEATTRIB", "Could not create attribute %s.",
  9, "ECREATE", "Could not create %s.",
 10, "ECREATEDOC", "Could not create document.",
 11, "ECREATENODE", "Could not create node %s.",
 12, "ECREATETXTNODE", "Could not create text node %s.",
 13, "EDELETE", "Could not delete %s.",
 14, "EENCODE", "Character encoding may only be specified in mode -i. Option -n is not allowed in this mode.",
 15, "EEVAL", "Eval error: %s",
 16, "EEXPORT", "Export of %s failed.",
 17, "EFATAL", "Fatal error. File %s, line %s: %s.",
 18, "EFINDPRED", "Could not find predecessor %s of %s.",
 19, "EFORMAT", "Format error in version file %s.",
 20, "EDETERMINE", "Could not determine %s.",
 21, "ELOCKHASH", "Could not lock hash keys.",
 22, "EMANDTAGWRONG", "Mandatory tag '%s' may not be '%s'.",
 23, "EMODE", "Exactly one mode of -i, -t, -r or -v must be selected.",
 24, "EMODEV", "Options -x, -p, -o, -O, -s and -e are not allowed in mode -v.",
 25, "ENOATT", "Could not find attribute %s.",
 26, "ENOCONFIG", "No configuration file specified.",
 27, "ENODEUNDEF", "node is undefined",
 28, "ENODOCROOT", "Could not find document root.",
 29, "ENOELIDE", "No eliding of doctypes possible in mode %s. Option -e is not allowed in this mode.",
 30, "ENOFILEINPATH", "File %s not found in %s.",
 31, "ENOINFILE", "No input file specified.",
 32, "ENOINPUTFILES", "Either -f may be used or the input files may be specified directly.",
 33, "ENOIOFILE", "At least one output and one input file must be specified in mode -v.",
 34, "ENOMANDTAG", "Mandatory tag %s not present in schema.",
 35, "ENONODE", "Node '%s' not found.",
 36, "ENOPARSTRING", "No parameter string is used in mode -t. Option -p is not allowed in this mode.",
 37, "ENOPATH", "-o does not allow path components. Use -O for specifying the output folder.",
 38, "ENOPROP", "Not propagating the coverage state may only be specified in mode -t. Option -P is not allowed in this mode.",
 39, "ENOSTATUS", "No status is used in mode %s. Option -s is not allowed in this mode.",
 40, "ENOTAG", "Required tag '%s' missing in specobject %s.",
 41, "ENOTRANS", "A transformer must be specified in mode -i or -r.",
 42, "ENOTRANSINT", "No transformer is used in mode -t. Option -x is not allowed in this mode.",
 43, "EOPENFILE", "Could not open %s.",
 44, "EOPENSCHEMA", "Could not open schema file %s.",
 45, "EPARAMILLEGAL", "%s: Illegal parameter %s.",
 46, "EPARAMNUM", "%s: Wrong number of arguments %s. Expected: %s.",
 47, "EPARAMREFTYPE",  "%s: Parameter #%s is of wrong ref type %s.",
 48, "EPARAMTWICE", "%s: Parameter '%s' specified twice.",
 49, "EPARAMUNDEF", "%s: Parameter %s is undefined",
 50, "EPARAMUNSUP", "%s: Unsupported parameter type %s for parameter '%s'.",
 51, "EPARNODEUNDEF", "parent node is undefined",
 52, "EPARSE", "Parse error in  line %s of %s: %s.",
 53, "EPARSEFILE", "Parse error in file %s: %s.",
 54, "EPROVCOVDUP", "Duplicate providescoverage to %s in %s.",
 55, "EQUALWRONG", "Only 'exp', 'devel' and 'stable' are allowed as qualification level in %s.",
 56, "ETAGCOLLIDE", "Tag '%s' both '%s' and '%s' for doctype '%s'.",
 57, "ETAGMISSING", " Mandatory tag %s is missing.",
 58, "ETAGNOTREQ", "Tag '%s' 'traced' but not 'required' for doctype '%s'.",
 59, "EVALIDATE", "Validation failed.",
 60, "EWHITESPACE", "Doctype '%s' contains a whitespace.",
 61, "EERROR", "Error in log handler: %s",
 62, "EMODULE", "Error in external module %s: %s",
999, "EGENERAL", "General error: %s"
);


my @wrnmsg = (
  0, "WNOWARN", "No Warning.",
  1, "WINPUTDATA", "Error in input data: %s.",
  2, "WPARSEFILE", "Parse problem in %s: %s.",
  3, "WPARSE", "Parse problem: %s.",
  4, "WENCUNSUP", "Character encoding '%s' is not supported. Using raw data.",
  5, "WENKUNKNOWN", "Could not determine input data encoding. Using raw data.",
  6, "WNOCONVERT", "Could not convert input data. Using raw data.",
  7, "WDEFAULT", "%s: No %s specified. Using '%s' as default.",
  8, "WNONEED", "No need to set mandatory tag '%s' to '%s'.",
  9, "WDTFORBIDDEN", "Doctype %s forbidden by configuration.",
 10, "WRTMISSING", "Required tag '%s' missing in node %s (line %s, file %s).",
 11, "WRTEMPTY", "Required tag '%s' must not be empty in node %s (line %s, file %s).",
 12, "WFTFOUND", "Forbidden tag '%s' found in node %s (line %s, file %s).",
 13, "WRTMISSINGCOND", "Required tag '%s' missing in node %s but %s is present (line %s, file %s).",
 14, "WFTFOUNDCOND", "Forbidden tag '%s' found in node %s although %s is present (line %s, file %s).",
 15, "WDUPLICATEID", "Duplicate specobject Id '%s'.",
 16, "WCIRCDEPEND", "Input data contains circular dependencies.",
 17, "WPSET", "-P option is set, coverages will not be propagated.",
 18, "WDTIGNORED", "Doctype %s of %s ignored by %s.",
 19, "WSPECOBJNOTFOUNDINO", "Input SpecObject %s is not found in the output file.",
 20, "WSPECOBJMULDEFINO", "Input SpecObject %s is defined %s times in the output file.",
 21, "WSPECOBJNOTFOUNDINI", "Output SpecObject %s is not found in the input files.",
 22, "WSPECOBJMULTDEFINI", "Output SpecObject %s is defined %s times in the input files.",
 23, "WSPECOBJDIFF", "Specobjects %s differs in input and output file.",
 24, "WSPECOBJNOTPROC", "Output SpecObject %s has not been processed.",
 25, "WSPECOBJNOTANL", "Output SpecObject %s has not been analyzed for cyclic dependencies.",
 26, "WSTDERR", "Could not open %s. Using STDERR instead.",
 27, "WIMPORTFAILED", "Import of %s failed.",
 28, "WMULTFILENAME", "Only the first specified filename %s will be used for exporting.",
999, "WGENERAL", "General warning: %s"
);

my @infmsg = (
  0, "INOINFO", "No Info Message",
  1, "IVERSION", "%s V %s",
  2, "ICOPYRIGHT", "Copyright (C)2010 Elektrobit Automotive GmbH Erlangen. All rights reserved.",
  3, "ICFGLOADED", "Configuration loaded.",
  4, "IMODE", "Running in %s mode.",
  5, "IVALIDPASSED", "Validation passed.",
999, "IGENERAL", "General info: %s"
);
my @dbgmsg = (
  0, "DNODEBUG", "No Debug Message",
  1, "DNODETOVAL", "%s -> %s",
  2, "DNODE", "%s",
  3, "DLINKERROR", "Link error in processing %s <-> %s.",
  4, "DADDTO", "Adding %s to %s",
  5, "DADD", "Adding %s",
  6, "DADDFORTRACING", "Added %s for tracing.",
  7, "DADDTOOUTPUT", "Adding %s output file.",
  8, "DADDOBJECT", "addObject(%s)",
  9, "DSETCOVSTATUS", "All objcovstatus are '%s'. Setting covstatus of %s to '%s'.",
 10, "DCALCPOS", "Calculating position of tag '%s' in document.",
 11, "DCHECKCONS", "Checking consistency of input files.",
 12, "DCHECKELEM", "Checking element %s.",
 13, "DCHECKTAGS", "Checking for '%s' and '%s' tags in doctype '%s'.",
 14, "DCHECKCIRC", "Checking for circular dependencies.",
 15, "DCHECKDUP", "Checking for duplicate %s.",
 16, "DCHECKNEEDSOBJ", "Checking if %s contains doctype of %s as needsobj.",
 17, "DCHECKSTATUS", "Checking if status of %s allows for tracing.",
 18, "DCHECKTRACING", "Checking if tracing relevant tags of %s and %s match.",
 19, "DCHECKVERSION", "Checking if versions match.",
 20, "DCHECKSPECOBJ", "Checking specobject %s for %s tag '%s'",
 21, "DCLEANUP", "cleanupSpecObjectList()",
 22, "DCOLLECT", "Collecting %s",
 23, "DCOLLECTUNPROC", "Collecting still unprocessed specobject containers in '%s' turn for doctype '%s'.",
 24, "DCONFIGFOUND", "Configuration found.",
 25, "DCREATEOBJ", "createObject()",
 26, "DCREATEOBJLIST", "createSpecObjectsList(%s)",
 27, "DCREATELISTCONT", "Creating container for list %s.",
 28, "DCREATELISTLISTCONT", "Creating container for list of lists %s.",
 29, "DCREATEDATA", "Creating internal data structure.",
 30, "DCREATELISTOFLISTS", "Creating list of lists %s.",
 31, "DDEFAULTTAG", "Default tag '%s' is a %s.",
 32, "DELEMENT", "Element %s is a %s.",
 33, "DEXPORT", "Exporting data to %s.",
 34, "DFOUNDENC", "Found input data encoding '%s'.",
 35, "DGENERATE", "Generating '%s'.",
 36, "DGETCONTENT", "getContentList()",
 37, "DLINKEDFROMEXISTS", "Linkedfrom ID %s already exists. Replacing.",
 38, "DLINKINGCOV", "Linking coverages in turn '%s'.",
 39, "DLINKINGOBJ", "Linking specobjects of input file.",
 40, "DLOADANDVALIDATE", "Loading and validating file %s",
 41, "DLOADING", "Loading input file '%s'.",
 42, "DLOADINGSPEC", "Loading spec file.",
 43, "DLOADINGTAGS", "Loading tracing relevant tags.",
 44, "DMOVENEEDSOBJ", "Moving needsobj '%s' to needscov container.",
 45, "DOBJTOUNCOVERED", "No incoming link is covered. Setting objcovstatus to 'uncovered'.",
 46, "DNOLINKERR", "No link error occurred in processing %s. Turn is '%s'.",
 47, "DNODEIS", "Node '%s' is a %s.",
 48, "DCOVTOPART", "One objcovstatus is 'partially'. Setting covstatus of %s to 'partially', too.",
 49, "DPARSESCHEMA", "Parsing schema.",
 50, "DPROCREFOBJ", "Processing referenced specobject %s.",
 51, "DPROCOBJ", "Processing specobject %s.",
 52, "DREPLACE", "Replace %s -> %s",
 53, "DREPLACEIGN", "Replace: No value specified. Ignoring.",
 54, "DNOMATCH", "%s does not match %s.",
 55, "DRUNEXPORT", "Running exporter.",
 56, "DRUNIMPORT", "Running importer.",
 57, "DSEARCHDBGFILE", "Searching for debug logfile configuration.",
 58, "DSEARCHLOGFILE", "Searching for logfile configuration.",
 59, "DOBJTOCOVERED", "Setting objcovstatus to 'covered' and linkstatus to 'linked'.",
 60, "DSETOBJSTATUS", "Setting objstatus of %s to '%s'.",
 61, "DSETSRCSTATUS", "Setting srcstatus, linkstatus and linkerror.",
 62, "DOBJTOPART", "Some links are uncovered. Setting objcovstatus to 'partially'.",
 63, "DCOVRESETTOPART", "Some objcovstatus are 'covered', some 'uncovered'. Setting covstatus of %s to 'partially'.",
 64, "DRESETTOPART", "Specobject %s is uncovered. Setting covstatus of already covered %s to 'partially' again.",
 65, "DOBJTOUNPROC", "Specobject %s participates in 'uncovered' turn. Setting objstatus of %s to 'unprocessed' again.",
 66, "DREMOVECONT", "specobjects container is empty -> removing.",
 67, "DSTARTIMPORT", "Staring exporter unit, using %s.",
 68, "DSTARTEXPORT", "Staring importer unit, using %s.",
 69, "DSTARTTRACE", "Starting tracing unit.",
 70, "DSTORESCHEMA", "Storing schema information.",
 71, "DTAGEXISTS", "Tag '%s' already exists in document.",
 72, "DTAGWRONGORDERORDER", "Tag '%s' belongs after tag '%s'.",
 73, "DTAGNOTSPEC", "Tag '%s' s not specified in schema.",
 74, "DUNCOVTURN", "Uncovered turn. Checking incoming links.",
 75, "DVALIDATE", "Validating %s",
 76, "DVERIFY", "Verifying %s.",
 77, "DWRITEIMPDATA", "Writing imported data to %s.",
 78, "DWRITETRACREPORT", "Writing tracing report to %s.",
 79, "DWRITETRACRESULT", "Writing tracing results to %s.",
999, "DGENERAL", "General debug message: %s"
);

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;

  $common->checkArguments("ReqM2_Log::new", ["ReqM2_Common"], \@args);

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub getMessages
{
	my $self = shift;
	my $type = shift;

	if($type eq "error")
	{
		return @errmsg;
	}
	elsif($type eq "warning")
	{
		return @wrnmsg;
	}
	elsif($type eq "info")
	{
		return @infmsg;
	}
	elsif($type eq "debug")
	{
		return @dbgmsg;
	}
	else
	{
		# We can't use the general warning mechanism here, as this is not yet initialized.
		print STDERR "Fatal error: ReqM2_Messages::getMessages: Unknown message type '$type' requested.\n";
		exit(1);
	}
}

1;
