# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1
package ReqM2_Version;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 643 $';

use strict;

sub new
{
  my $type = shift;
  my @args = @_;
  my $common = shift;
  my $file = shift;

  $common->checkArguments("ReqM2_Version::new", ["ReqM2_Common",""], \@args);

  my $self = {COMMON => $common};

  my $name;
  my $major;
  my $minor;
  my $patch;
  my $qualification;

  if(!open(FILE, "$file"))
  {
    $main::log->error("EOPENFILE", $file);
    $self = 0;
  }
  else
  {
    my @lines = <FILE>;
    close (FILE);

    $main::log->debug("DCOLLECT", "version information");

    foreach my $line (@lines)
    {
      if ($line=~m/^NAME=(\w+)/){$name=$1;}
      if ($line=~m/^MAJOR=(\d+)/){$major=$1;}
      if ($line=~m/^MINOR=(\d+)/){$minor=$1;}
      if ($line=~m/^PATCH=(\d+)/){$patch=$1;}
      if ($line=~m/^QUALIFICATION=(\w+)/){$qualification=$1;}
    }

    if(defined($name) && defined($major) && defined($minor) &&
       defined($patch) && defined($qualification))
    {
      if($qualification=~m/(exp$)|(^devel$)|(^stable$)/)
      {
        $self->{NAME}=$name;
        $self->{VERSION}="$major.$minor.$patch ($qualification)";
        bless($self, $type);
      }
      else
      {
        $main::log->error("EQUALWRONG", $file);
        $self = 0;
      }
    }
    else
    {
      $main::log->error("EFORMAT", $file);
      $self = 0;
    }
  }

  return $self;
}

sub getName
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Version::getName", [], \@args);

  return $self->{NAME};
}

sub getVersion
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Version::getVersion", [], \@args);

  return $self->{VERSION};
}

sub getLibXMLVersion
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Version::getLibXMLVersion", [], \@args);

  return $XML::LibXML::VERSION;
}

sub getLibXML2Version
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Version::getLibXML2Version", [], \@args);

  return XML::LibXML::LIBXML_DOTTED_VERSION;
}

sub getLibXMLRTVersion
{
  my $self = shift;
  my @args = @_;

  $self->{COMMON}->checkArguments("ReqM2_Version::getLibXMLRTVersion", [], \@args);

  return XML::LibXML::LIBXML_RUNTIME_VERSION;
}

1;
