# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_DotExporter;

$VERSION = '1.00';

use strict;
use File::Spec::Functions;
use File::Basename;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\n Use -p parameter to give a pattern. Only nodes matching thhis pattern are included. E.g. -p \"pattern=SafetyOS.*\"\n\n";
}

sub runExporter
{
  my $self = shift;
  my $file = shift;
  my $xmldat = shift;
  my $outdir = shift;
  my $outfile = shift;
  my $params = shift;

  my $data;
  
  #default value for the pattern is "match everything"
  my $pattern = ".*";
  my $root = $xmldat->documentElement();
  
  #don't warn if the "pattern" parameter is not given
  my %warnfor = ();
  my %params;
  $params="" if(!$params);
  $params{"pattern"}=\$pattern;
  $self->{COMMON}->parseParams("ReqM2_DotExporter", $params, \%params, \%warnfor);

  $data = "digraph ReqGraph {\nrankdir=\"LR\";\n";
  my @specobject=$root->findnodes("/tracingresults/specdocument/specobjects/specobject");
  foreach my $specobject (@specobject)
  {
    my $id = $specobject->findnodes("id")->[0]->textContent;
    my $doctype = $specobject->findnodes("../\@doctype")->[0]->textContent;
    
    #skip unwanted nodes
    unless ($id =~ m/$pattern/)
    {
      next;
    }
    
    my $covstatus = $specobject->findnodes("covstatus")->[0]->textContent;
    if($covstatus eq "covered")
    {
      $data .= "\"$id\" [shape=box,peripheries=2,color=green,style=filled];\n";
    }
    else
    {
      $data .= "\"$id\" [shape=box,peripheries=2,color=red,style=filled];\n";
    }


    my @linksto = $specobject->findnodes("providescoverage/provcov/linksto[../linkstatus='linked']");
    foreach my $linksto (@linksto)
    {
      my $linksto_id = $linksto->textContent();
      
      #skip unwanted nodes
      unless ($linksto_id =~ m/$pattern/)
      {
        next;
      }
      $data .= "\"$id\" -> \"" . $linksto_id . "\" [color=green];\n";
    }
    

    @linksto = $specobject->findnodes("providescoverage/provcov/linksto[../linkstatus='linkerror']");
    foreach my $linksto (@linksto)
    {
      my $linksto_id = $linksto->textContent();
      
      #skip unwanted nodes
      unless ($linksto_id =~ m/$pattern/)
      {
        next;
      }
      $data .= "\"$id\" -> \"" . $linksto_id . "\" [color=red];\n";
    }
  }
  # To prevent an error in case no test is specified yet
  $data .= "}";

  if (($outdir ne File::Spec->curdir()) && (! -d $outdir) && ((mkdir "$outdir") == 0))
  {
    $main::log->error("ECREATE", $outdir);
  }
  # Write the data returned by the exporter to the output file
  if(open (FILE, ">".catfile($outdir, $outfile)) != 0)
  {
    $main::log->debug("DEXPORT", "$outdir/$outfile");
    binmode FILE, ":utf8";
    print FILE $data;
    close (FILE);
  }
  else
  {
    $main::log->error("EOPENFILE", "$outdir/$outfile");
  }

  return 1;
}

1;
