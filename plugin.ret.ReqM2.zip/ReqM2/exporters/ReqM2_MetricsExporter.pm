# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_MetricsExporter;

$VERSION = '1.00';

use strict;
use File::Spec::Functions;
use XML::LibXML 1.070_000;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the Metrics exporter:\n\n";
  print "cfgfile:\n";
  print "The configuration file defining which metrics to export. See the\n";
  print "user's guide for more information on the file format.\n\n";
  print "module:\n";
  print "The name of the module the metrics are valid for. If not set, they\n";
  print "will be added to the \"system\" container.\n\n";


}

sub runExporter
{
  my $self = shift;
  my $file = shift;
  my $xmldat = shift;
  my $outdir = shift;
  my $outfile = shift;
  my $params = shift;

  my %tags;

  my %knowntags = ("req"=>1, "tst"=>1);

  my $cfgfile;
  my $module;

  my $parmask = 0;

  my %warnfor = ("cfgfile" => 1);

  my %params;

  $params="" if(!$params);

  $params{"cfgfile"}=\$cfgfile;
  $params{"module"}=\$module;
  $self->{COMMON}->parseParams("ReqM2_MetricsExporter", $params, \%params, \%warnfor);

  if(!$cfgfile)
  {
    $main::log->error("ENOCONFIG");
  }

  parseConfig($cfgfile, \%tags, \%knowntags);

  my $nrreq = 0;
  my $nrreqimplneed = 0;
  my $nrreqimpl = 0;
  my $nrreqtstneed = 0;
  my $nrreqtst = 0;
  my $nrtstnoreq = 0;
  my $nrspecnoreq = 0;

  my $nrtst = 0;

  my $root = $xmldat->documentElement();

  # This constructs the XPath expressions for finding all SpecObjects which need "left-V" or "right-V" coverage
	my $needstest = "./needscoverage/needscov/needsobj='" . join ("' or ./needscoverage/needscov/needsobj='", @{$tags{"tst"}}) . "'";
	my $needsimpl = "./needscoverage/needscov/needsobj='" . join ("' or ./needscoverage/needscov/needsobj='", @{$tags{"req"}}) . "'";

  # Just for the statistics
  foreach my $tstdt (@{$tags{"tst"}})
  {
    $nrtst += $root->findvalue("count(//specobjects[\@doctype='$tstdt']/specobject)");

    $nrtstnoreq += $root->findvalue("count(//specobjects[\@doctype='$tstdt']/specobject[./providescoverage/provcov/linkstatus='linkerror'])");
  }

  # Process requirements ("left V")
  foreach my $reqdt (@{$tags{"req"}})
  {
    $nrreq += $root->findvalue("count(//specobjects[\@doctype='$reqdt']/specobject)");
    $nrreqtstneed+=$root->findvalue("count(//specobjects[\@doctype='$reqdt']/specobject[$needstest])");
    $nrreqimplneed+=$root->findvalue("count(//specobjects[\@doctype='$reqdt']/specobject[$needsimpl])");
  
    $nrspecnoreq += $root->findvalue("count(//specobjects[\@doctype='$reqdt']/specobject[./providescoverage/provcov/linkstatus='linkerror'])");

    # Determining the number of objects which indeed are fulfilled is a bit more complicated,
    # as we can't simply sum them up using XPath (this would yield duplicates)

    # These are all nodes which need one of the specifed "right-V" SpecObjects
    my @needtest = $root->findnodes("//specobjects[\@doctype='$reqdt']/specobject[$needstest]");
    foreach my $node (@needtest)
    {
      # Now we check that all incoming links from the "right-V" SpecObjects are covered:
      my $uncovered = 0;
      foreach my $tst (@{$tags{"tst"}})
      {
        $uncovered += $node->findvalue("count(./needscoverage/needscov[./needsobj='$tst' and ./objcovstatus!='covered'])")
      }
      if(!$uncovered)
      {
        $nrreqtst++;
      }
    }

    # The same now for the "left-V" SpecObjects
    my @needimpl = $root->findnodes("//specobjects[\@doctype='$reqdt']/specobject[$needsimpl]");
    foreach my $node (@needimpl)
    {
      # Now we check that all incoming links from the "left-V" SpecObjects are covered:
      my $uncovered = 0;
      foreach my $req (@{$tags{"req"}})
      {
        $uncovered += $node->findvalue("count(./needscoverage/needscov[./needsobj='$req' and ./objcovstatus!='covered'])")
      }
      if(!$uncovered)
      {
        $nrreqimpl++;
      }
    }
  }

  my $percreqimpl = $nrreqimplneed ? sprintf("%.2f", $nrreqimpl / $nrreqimplneed) : "NaN";
  my $percreqtst = $nrreqtstneed ? sprintf("%.2f", $nrreqtst / $nrreqtstneed) : "NaN";
 
  my $nrreqnotimpl = $nrreqimplneed - $nrreqimpl;
  my $nrreqnottst = $nrreqtstneed - $nrreqtst;

  my %metrics = 
         ("NrReq" =>           $nrreq,
          "NrTestCasesSpec" => $nrtst,
          "NrReqImplNeed" =>   $nrreqimplneed,
          "NrReqImpl" =>       $nrreqimpl,
          "NrReqTstNeed" =>    $nrreqtstneed,
          "NrReqTst" =>        $nrreqtst,
          "NrReqNotImpl" =>    $nrreqnotimpl,
          "NrReqNotTst" =>     $nrreqnottst,
          "NrTstNoReq" =>      $nrtstnoreq,
          "NrSpecNoReq" =>     $nrspecnoreq,
          "PercReqImpl" =>     $percreqimpl,
          "PercReqTst" =>      $percreqtst);

  my $dom = XML::LibXML::Document->new("1.0", "UTF-8");
  my $system = XML::LibXML::Element->new("system");

  $system->setAttribute("xmlns", "http://schema.elektrobit.com/tresos/SoftwareMetrics");
  $system->setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
  $system->setAttribute("xsi:schemaLocation", "http://schema.elektrobit.com/tresos/SoftwareMetrics SoftwareMetrics.xsd");

  my $datactr = $system;

  if($module)
  {
    my $modnode = XML::LibXML::Element->new("module");
    $modnode->setAttribute("name", "$module");
    $system->addChild($modnode);
    $datactr = $modnode;
  }

  for my $metname (sort(keys(%metrics)))
  {
    my $metnode =  XML::LibXML::Element->new("metrics");
    $metnode->setAttribute("type", "$metname");
    my $metval =  XML::LibXML::Element->new("value");
    if($metname eq "PercReqImpl" || $metname eq "PercReqTst")
    {
      $metval->setAttribute("type", "float");
    }
    else
    {
      $metval->setAttribute("type", "integer");
    }
    my $value = XML::LibXML::Text->new("$metrics{$metname}");
    $metval->addChild($value);
    $metnode->addChild($metval);
    $datactr->addChild($metnode);
  }

  $dom->addChild($system);

  $file = $outdir?"$outdir/$outfile":"$outfile";

  open(FILE, ">$file") || $main::log->error("EOPENFILE", $file);
  print FILE $dom->toString(1);
  close(FILE);

  return 1;
}

sub parseConfig
{
  my $cfgfile = shift;
  my $tags = shift;
  my $knowntags = shift;

  my %tmptags;
  my $curtag;
  my $l=0;

  open(CFGFILE, "<$cfgfile") || $main::log->error("EOPENFILE", $cfgfile);

  foreach my $line (<CFGFILE>)
  {
    $line=~s/#.*//;
    $line=~s/\s+//g;
    if($line=~s/(\w+):(.*)/$2/)
    {
      $curtag = $1;
      if(!$knowntags->{$curtag})
      {
        $main::log->error("EPARSE", $l, $cfgfile, "General parse error");
      }
    }
    if ($line && !$curtag)
    {
      $main::log->error("EPARSE", $l, $cfgfile, "General parse error");
    }

    if($line)
    {
      $line.="," unless $line=~m/\w+,$/;
      $tmptags{$curtag}.=$line;
    }
    $l++;
  }

  foreach my $key (keys(%tmptags))
  {
    my @tags = split /,/, $tmptags{$key};
    $tags->{$key} = \@tags;
  }

  close(CFGFILE);

}

1;
