# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_HtmlExporter;

$VERSION = '1.10';

use strict;
use File::Copy;
use Cwd;
use File::Spec::Functions;
use File::Basename;

# use max() function to get the array element with maximum value
use List::Util qw[max];

our $graphviz_enabled;
our $graphviz_path;
our $graphviz_img_dir;
our $graphviz_img_html;
our $graphviz_img_tree;
our $output_file_name;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nNo options are available for the HTML exporter:\n\n";
}

sub runExporter
{
  my $self = shift;
  my $file = shift;
  my $xmldat = shift;
  my $outdir = shift;
  my $outfile = shift;
  my $params = shift;

  my @scalar = ("source", "sourcefile", "sourceline", "version", "description", "comment");

  my $data;

  my $color;
  my $value;

  my $root = $xmldat->documentElement();

  my @doctypes;

  my @specobjects=$root->findnodes("/*/*/specobjects");

  my %numdt;
  
  #parameter handling
  $graphviz_enabled = 0;
  if ($params) {
    my @params_array = split("/,/", $params);
  
    $graphviz_enabled = 0;
    $graphviz_path = "";
    $graphviz_img_dir = catfile($outdir, "images");
    $graphviz_img_html = "icon_html.png";
    $graphviz_img_tree = catfile("images", "icon_tree.png");
    $output_file_name = "$outfile";
  
    for my $currentparam (@params_array)
    {
  	  if (index($currentparam, "graphviz") != -1)
      {
  		#graphviz parameter is present
  		my @graphvizpath_array = split("=",$currentparam);
  		$graphviz_path = $graphvizpath_array[1];
  		if (-e $graphviz_path) 
  		{
		  $graphviz_enabled = 1;
		}
		else 
		{
		  $main::log->error("ENOFILEINPATH", "dot.exe", $graphviz_path);
		}
  	  }
    }
  }
  
  #prepare output directory
  if (($outdir ne File::Spec->curdir()) && (! -d $outdir) && ((mkdir "$outdir") == 0))
  {
    $main::log->error("ECREATE", $outdir);
  }
  
  #prepare output directories for graphviz files
  if ($graphviz_enabled == 1)
  {
	if ((! -d $graphviz_img_dir) && (mkdir $graphviz_img_dir) == 0)
	{
	  $main::log->error("ECREATE", $graphviz_img_dir);
	}
	
	if ((! -d $graphviz_img_dir) && (mkdir $graphviz_img_dir) == 0)
	{
	  $main::log->error("ECREATE", $graphviz_img_dir);
	}
	
	  #prepare icons
	  copy(catfile(main::getResPath(), "icon_tree.png"), "$graphviz_img_dir");
    copy(catfile(main::getResPath(), "icon_html.png"), "$graphviz_img_dir");
  }
  
  foreach my $specobject (@specobjects)
  {
    my $doctype = $specobject->getAttribute("doctype");
    if(!grep(/^$doctype$/, @doctypes))
    {
      $numdt{$doctype} = 0;
      push @doctypes, $doctype;
    }
    $numdt{$doctype}++;
  }

  my $numobj=$root->findvalue("count(/*/*/specobjects/specobject)");
  my $numcov=$root->findvalue("count(/*/*/specobjects/specobject[covstatus='covered'])");
  my $numpart=$root->findvalue("count(/*/*/specobjects/specobject[covstatus='partially'])");
  my $numuncov=$root->findvalue("count(/*/*/specobjects/specobject[covstatus='uncovered'])");
  my $numtop=$root->findvalue("count(/*/*/specobjects/specobject[(count(providescoverage/provcov)=0) and (count(needscoverage/needscov)!=0)])");
  my $numbottom=$root->findvalue("count(/*/*/specobjects/specobject[(count(needscoverage/needscov)=0) and (count(providescoverage/provcov)!=0)])");
  my $numstandalone=$root->findvalue("count(/*/*/specobjects/specobject[(count(needscoverage/needscov)=0) and (count(providescoverage/provcov)=0)])");
  my $numinter = $numobj - ($numtop + $numbottom + $numstandalone);

  my $covcnt = {"covered" => 0, "partially" => 0, "uncovered" => 0};
  my $levcnt = {"top" => 0, "inter" => 0, "bottom" => 0, "standalone" => 0};

  my %dtcount;

  $data  = "<html>\n <head>\n  <title>ReqM2 Tracing Report</title>\n";
  $data .= "<script type=\"text/javascript\">\n";
  $data .= "var coverage = \"all\";\n";
  $data .= "var doctype = \"all\";\n";
  $data .= "var level = \"all\";\n";
  $data .= "function showAll()\n";
  $data .= "{\n";
  $data .= "  coverage = \"all\";\n";
  $data .= "  for (i=0; i<$numcov; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"covered_\"+i);\n";
  $data .= "    table.style.display = \"\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numpart; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"partially_\"+i);\n";
  $data .= "    table.style.display = \"\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numuncov; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"uncovered_\"+i);\n";
  $data .= "    table.style.display = \"\";\n";
  $data .= "  }\n";
  $data .= "  changeInfo();\n";
  $data .= "}\n";
  $data .= "function showCovered()\n";
  $data .= "{\n";
  $data .= "  coverage = \"covered\";\n";
  $data .= "  for (i=0; i<$numcov; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"covered_\"+i);\n";
  $data .= "    table.style.display = \"\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numpart; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"partially_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numuncov; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"uncovered_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  changeInfo();\n";
  $data .= "}\n";
  $data .= "function showPartially()\n";
  $data .= "{\n";
  $data .= "  coverage = \"partially\";\n";
  $data .= "  for (i=0; i<$numcov; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"covered_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numpart; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"partially_\"+i);\n";
  $data .= "    table.style.display = \"\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numuncov; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"uncovered_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  changeInfo();\n";
  $data .= "}\n";
  $data .= "function showUncovered()\n";
  $data .= "{\n";
  $data .= "  coverage = \"uncovered\";\n";
  $data .= "  for (i=0; i<$numcov; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"covered_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numpart; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"partially_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numuncov; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"uncovered_\"+i);\n";
  $data .= "    table.style.display = \"\";\n";
  $data .= "  }\n";
  $data .= "  changeInfo();\n";
  $data .= "}\n";

  $data .= "function showAllDoctypes()\n";
  $data .= "{\n";

  foreach my $doctype (@doctypes)
  {
    $data .= "  doctype = \"all\";\n";
    $data .= "  for (i=0; i<$numdt{$doctype}; i++)\n";
    $data .= "  {\n";
    $data .= "    table = document.getElementById(\"$doctype\_\"+i);\n";
    $data .= "    table.style.display = \"\";\n";
    $data .= "  }\n";
  }
  $data .= "  changeInfo();\n";
  $data .= "}\n";

  foreach my $doctype (@doctypes)
  {
    my $fnname = $doctype;
    $fnname=~s/\./_/g;
    $data .= "function show$fnname()\n";
    $data .= "{\n";
    $data .= "doctype = \"$doctype\";\n";
    foreach my $hidetype (@doctypes)
    {
      if($hidetype ne $doctype)
      {
        $data .= "  for (i=0; i<$numdt{$hidetype}; i++)\n";
        $data .= "  {\n";
        $data .= "    table = document.getElementById(\"$hidetype\_\"+i);\n";
        $data .= "    table.style.display = \"none\";\n";
        $data .= "  }\n";
      }
    }

    $data .= "  for (i=0; i<$numdt{$doctype}; i++)\n";
    $data .= "  {\n";
    $data .= "    table = document.getElementById(\"$doctype\_\"+i);\n";
    $data .= "    table.style.display = \"\";\n";
    $data .= "  }\n";
    $data .= "  changeInfo();\n";
    $data .= "}\n";
  }

  $data .= "function showAllLevels()\n";
  $data .= "{\n";
  $data .= "  level = \"all\";\n";
  $data .= "  for (i=0; i<$numtop; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_top_\"+i);\n";
  $data .= "    table.style.display = \"block\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numbottom; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_bottom_\"+i);\n";
  $data .= "    table.style.display = \"block\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numinter; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_inter_\"+i);\n";
  $data .= "    table.style.display = \"block\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numstandalone; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_standalone_\"+i);\n";
  $data .= "    table.style.display = \"block\";\n";
  $data .= "  }\n";
  $data .= "  changeInfo();\n";
  $data .= "}\n";

  $data .= "function showTopLevel()\n";
  $data .= "{\n";
  $data .= "  level = \"top\";\n";
  $data .= "  for (i=0; i<$numtop; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_top_\"+i);\n";
  $data .= "    table.style.display = \"block\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numbottom; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_bottom_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numinter; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_inter_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numstandalone; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_standalone_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  changeInfo();\n";
  $data .= "}\n";

  $data .= "function showBottomLevel()\n";
  $data .= "{\n";
  $data .= "  level = \"bottom\";\n";
  $data .= "  for (i=0; i<$numtop; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_top_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numbottom; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_bottom_\"+i);\n";
  $data .= "    table.style.display = \"block\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numinter; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_inter_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numstandalone; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_standalone_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  changeInfo();\n";
  $data .= "}\n";

  $data .= "function showStandAlone()\n";
  $data .= "{\n";
  $data .= "  level = \"standalone\";\n";
  $data .= "  for (i=0; i<$numtop; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_top_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numbottom; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_bottom_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numinter; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_inter_\"+i);\n";
  $data .= "    table.style.display = \"none\";\n";
  $data .= "  }\n";
  $data .= "  for (i=0; i<$numstandalone; i++)\n";
  $data .= "  {\n";
  $data .= "    table = document.getElementById(\"level_standalone_\"+i);\n";
  $data .= "    table.style.display = \"block\";\n";
  $data .= "  }\n";
  $data .= "  changeInfo();\n";
  $data .= "}\n";


  $data .= "function changeInfo()\n";
  $data .= "{\n";
  $data .= "  document.getElementById('cov').innerHTML=coverage;\n";
  $data .= "  document.getElementById('dt').innerHTML=doctype;\n";
  $data .= "  document.getElementById('lvl').innerHTML=level;\n";
  $data .= "}\n";

  $data .="</script>\n";
 
  $data .=" </head>\n <body>\n";
  $data .="Statistics:<br>\n";
  $data .="<table border=\"2\">\n";
  $data .="<tr><td><a href=\"#\" onclick=\"showAll()\">Number of Objects:</a></td><td>$numobj</td></tr>\n";
  $data .="<tr><td><a href=\"#\" onclick=\"showCovered()\">Number of covered Objects:</a></td><td>$numcov</td></tr>\n";
  $data .="<tr><td><a href=\"#\" onclick=\"showPartially()\">Number of partially covered Objects:</a></td><td>$numpart</td></tr>\n";
  $data .="<tr><td><a href=\"#\" onclick=\"showUncovered()\">Number of uncovered Objects:</a></td><td>$numuncov</td></tr>\n";
  $data .="</table>\n";
  $data .="<br>\n";
  $data .="Available doc types:<br>\n";
  $data .="<a href=\"#\" onclick=\"showAllDoctypes()\">All</a>\n";
  foreach my $doctype (@doctypes)
  {
    my $fnname = $doctype;
    $fnname=~s/\./_/g;
    $data .="<a href=\"#\" onclick=\"show$fnname()\">$doctype</a>\n";
  }

  $data .= "<br><br>\n";
  $data .= "Hierarchy levels:<br>\n";
  $data .= "<a href=\"#\" onclick=\"showAllLevels()\">Show all SpecObjects</a><br>\n";
  $data .= "<a href=\"#\" onclick=\"showTopLevel()\">Show only top-level SpecObjects (no providescoverage)</a><br>\n";
  $data .= "<a href=\"#\" onclick=\"showBottomLevel()\">Show only bottom-level SpecObjects (no needscoverage)</a><br>\n";
  $data .= "<a href=\"#\" onclick=\"showStandAlone()\">Show only stand-alone SpecObjects (no needs- and no providescoverage)</a><br>\n";
  $data .= "<br>\n";

  $data .= "Now showing:<br>\n";
  $data .= "<table border = \"2\">\n";
  $data .= "<tr><td>Coverage</td><td>Doctype</td><td>Hierarchy level</td></tr>\n";
  $data .= "<tr><td id=\"cov\">all</td><td id=\"dt\">all</td><td id=\"lvl\">all</td></tr>\n";
  $data .= "</table><br>\n";

  $data .="Detailed information:<br>\n";

  foreach my $specobjects (@specobjects)
  {
    my $doctype = $specobjects->getAttribute("doctype");
    $dtcount{$doctype} = 0 if(!$dtcount{$doctype});
    $data .= "  <table border=\"2\" width=\"70%\" id=\"$doctype\_$dtcount{$doctype}\">\n";
    $data .= "    <tr>\n      <td bgcolor=\"#9999ff\">$doctype</td>\n";
    $data .= "    </tr>\n    <tr>\n      <td bgcolor=\"#9999ff\">\n";

    $dtcount{$doctype}++;

    my @specobject = $specobjects->findnodes("specobject");
    foreach my $specobject (@specobject)
    {
      my $covstate = $specobject->findnodes("covstatus")->[0]->textContent();
      my $levstate;
      if (($specobject->findvalue("count(needscoverage/needscov)") == 0) &&
          ($specobject->findvalue("count(providescoverage/provcov)") == 0))
      {
        $levstate = "standalone";
      }
      elsif ($specobject->findvalue("count(providescoverage/provcov)") == 0)
      {
        $levstate = "top";
      }
      elsif ($specobject->findvalue("count(needscoverage/needscov)") == 0)
      {
        $levstate = "bottom";
      }
      else
      {
        $levstate = "inter";
      }
      my $count = $covcnt->{$covstate};
      my $levcount = $levcnt->{$levstate};
      $data .= "   <br>\n";
      $data .="    <div id=\"$covstate\_$count\">\n";
      $data .="    <div id=\"level_$levstate\_$levcount\">\n";
      $covcnt->{$covstate}++;
      $levcnt->{$levstate}++;

      $value = $specobject->findnodes("id")->[0]->textContent();
      $data .= "<a name=\"$value\"/>\n";
      $data .="      <table border=\"2\" width=\"100%\">\n";
      if ($graphviz_enabled == 1)
      {
      	$data .= tableRowWithLink("ID", $value, "#ffffff");
      } 
      else 
      {
      	$data .= tableRow("ID", $value, "#ffffff");
      }

      if($covstate eq "covered"){$color="#00ff00";}
      elsif($covstate eq "partially"){$color="#ffff00";}
      else{$color="#ff0000";}

      $data .= tableRow("Coverage status", $covstate, $color);

      $value = $specobject->findnodes("status")->[0]->textContent();
      if($value ne "approved"){$color="#ff0000";}else{$color="#ffffff";}
      $data .= tableRow("Status", $value, $color);

      foreach my $scalar (@scalar)
      {
        my @node = $specobject->findnodes("$scalar");
        if (@node)
        {
          # Read all element contents as string, even possibly included
          # HTML formatting tags.
          if ($node[0]->exists(".//node() | .//@*"))
          {
            $value = $node[0]->toString(0);
            # Remove the outer tags
            $value =~ s/<\s*\/?$scalar\s*>//gm;
          }
          else
          {
              $value = "";
          }

          # If HTML style formatting tags are used, the XML library will
          # convert them to &lt;...&gt; during import, so we have to decode
          # them here to get the tags back.
          $value =~ s/&amp;/&/g;
          $value =~ s/&lt;/</g;
          $value =~ s/&gt;/>/g;

          $data .= tableRow($scalar, $value, "#ffffff");
        }
      }
      
      #create .dot files for graphviz
      if ($graphviz_enabled == 1) 
      {
      	printSpecObject($specobject, $root);
      }

      my @needscoverage = $specobject->findnodes("needscoverage");
      if(@needscoverage)
      {
        $data .= "<tr><td bgcolor=\"#ddddff\" width=\"20%\">Individual Coverages</td>\n<td><table width=\"100%\">";
        my @ignored  = $needscoverage[0]->findnodes("ignoreddoctype");
        foreach my $ignored (@ignored)
        {
          $data .= tableRow("Doctype", $ignored->textContent." (ignored)", "#ffff00");
        }

        my @needscov = $needscoverage[0]->findnodes("needscov");
        foreach my $needscov (@needscov)
        {
          my $linkedid = "<table border=\"2\">\n";
          my $needsobj = $needscov->findnodes("needsobj")->[0]->textContent();
          my $objcovstatus = $needscov->findnodes("objcovstatus")->[0]->textContent();
          my @linkedfrom = $needscov->findnodes("coveredby")->[0]->findnodes("linkedfrom/srcid");
          foreach my $linkedfrom (@linkedfrom)
          {
            my $srccolor="#00ff00";
            my $srcstatus="OK";
            if((my $srcstatusnode=$linkedfrom->findnodes("../srcstatus")->[0]))
            {
              $srcstatus=$srcstatusnode->textContent();
              $srccolor="#ff0000";
            }
            if ($graphviz_enabled == 1)
            {
            	$linkedid .= "<tr><td bgcolor=\"$srccolor\"><a href=\"images/".$linkedfrom->textContent().".svg\"><img src=\"$graphviz_img_tree\" width=\"15\" height=\"15\" border=\"0\"></a><a href=\"#".$linkedfrom->textContent()."\" onclick=\"showAll(); showAllDoctypes();\">".
                  $linkedfrom->textContent(). "</a></td><td bgcolor=\"$srccolor\">$srcstatus</td></tr>";	
            }
            else 
            {
            	$linkedid .= "<tr><td bgcolor=\"$srccolor\"><a href=\"#".$linkedfrom->textContent()."\" onclick=\"showAll(); showAllDoctypes();\">".
                  $linkedfrom->textContent(). "</a></td><td bgcolor=\"$srccolor\">$srcstatus</td></tr>";
            }
          }
          $linkedid .= "</table>\n";
          if($objcovstatus eq "covered"){$color="#00ff00";}
          elsif($objcovstatus eq "partially"){$color="#ffff00";}
          else{$color="#ff0000";}
          $data .= tableRow("Doctype", $needsobj, $color);

          $data .= tableRow("Linked from", $linkedid, "#ffffff");
        }
        $data .= "</table></td>\n</tr>\n";
      }

      my @providescoverage = $specobject->findnodes("providescoverage");
      if(@providescoverage)
      {
        my @provcov = $providescoverage[0]->findnodes("provcov");
        my $linkedid = "<table border=\"2\">";
        foreach my $provcov (@provcov)
        {
          my $linksto = $provcov->findnodes("linksto")->[0]->textContent();
          my $dstversion = $provcov->findnodes("dstversion")->[0]->textContent();
          my $linkstatus = $provcov->findnodes("linkstatus")->[0]->textContent();
          my $linkerror = "";
          my $color = "#00ff00";
          if($linkstatus eq "linkerror")
          {
            $linkerror = ": ".$provcov->findnodes("linkerror")->[0]->textContent();
            $color = "#ff0000";
          }
          if($linkstatus eq "ignored")
          {
            $color = "#ffff00";
          }
          elsif(($linkstatus eq "referenced") || ($linkstatus eq "notlinked"))
          {
            $color = "#ff0000";
          }
          if ($graphviz_enabled == 1)
          {
          	$linkedid .= "<tr><td bgcolor=\"$color\"><a href=\"images/$linksto.svg\"><img src=\"$graphviz_img_tree\" width=\"15\" height=\"15\" border=\"0\"></a><a href=\"#$linksto\" onclick=\"showAll(); showAllDoctypes();\">$linksto</a></td><td>Version: $dstversion</td><td bgcolor=\"$color\">$linkstatus$linkerror</td></tr>";
          } 
          else
          {
          	$linkedid .= "<tr><td bgcolor=\"$color\"><a href=\"#$linksto\" onclick=\"showAll(); showAllDoctypes();\">$linksto</a></td><td>Version: $dstversion</td><td bgcolor=\"$color\">$linkstatus$linkerror</td></tr>";
          }
        }
        $linkedid.="</table>";
        $data .= tableRow("Links to", $linkedid, "#ffffff");
      }


      $data .= "    </table></div></div>\n";
    }
    $data .= "      </td>\n    </tr>\n  </table>\n";
  }

  $data .= " </body>\n</html>\n";

  # Write the data returned by the exporter to the output file
  if(open (FILE, ">".catfile($outdir, $outfile)))
  {
    $main::log->debug("DEXPORT", "$outdir/$outfile");
    binmode FILE, ":utf8";
    print FILE $data;
    close (FILE);
  }
  else
  {
    $main::log->error("EOPENFILE", "$outdir/$outfile");
  }

  return 1;
}

sub tableRow
{
  my $title = shift;
  my $value = shift;
  my $color = shift;
  my $retval;

  $retval  = "      <tr>\n";
  $retval .= "        <td bgcolor=\"#ddddff\" width=\"20%\">$title</td>\n";
  $retval .= "        <td bgcolor=\"$color\">$value</td>\n";
  $retval .= "      <tr>\n";

  return $retval
}

sub tableRowWithLink
{
  my $title = shift;
  my $value = shift;
  my $color = shift;
  my $retval;

  $retval  = "      <tr>\n";
  $retval .= "        <td bgcolor=\"#ddddff\" width=\"20%\">$title</td>\n";
  $retval .= "        <td bgcolor=\"$color\"><a href=\"images/$value.svg\"><img src=\"$graphviz_img_tree\" width=\"15\" height=\"15\" border=\"0\"></a>$value</td>\n";
  $retval .= "      <tr>\n";

  return $retval
}


#Needed for graphviz export. Prints the current node.
sub printSpecObject
{
	my $specobject = $_[0];
	my $root = $_[1];
	
	my $data  = "digraph ReqGraph {\n";
  	$data .= "  rankdir=\"LR\"\n";
    my $id = $specobject->findnodes("id")->[0]->textContent;
    my $doctype = $specobject->findnodes("../\@doctype")->[0]->textContent;
    
    #reqm can produce IDs that consist of a path, which can contain '/' characters. Replace them by underscores
    #because $id also serves as a filename
    $id =~ s/\/|\\|:/_/g;

	my $covstatus = $specobject->findnodes("covstatus")->[0]->textContent;
	$data .= printNode($id, $doctype, $covstatus, 1);
    $data .= printParents($specobject, $root);
    $data .= printChildren($specobject, $root);
    $data .= "}";
    
    #print "current file $graphviz_img_dir/$id.dot\n";
    if(open (FILE, ">".catfile($graphviz_img_dir, "$id.dot")))
  	{
    	$main::log->debug("DEXPORT", "$graphviz_img_dir/$id.dot");
    	binmode FILE, ":utf8";
    	print FILE $data;
    	close (FILE);
    
      my $cwd = getcwd();  
    	chdir($graphviz_img_dir);
    	system($graphviz_path, "-Tsvg", "-o$id.svg", "$id.dot");
    	chdir($cwd);
  	}
  	else
  	{
    	$main::log->error("EOPENFILE", "$id.dot");
  	}
}

#Needed for graphviz export. Prints all parents of the passed node.
sub printParents
{
	my $currentspecobj = $_[0];
	my $root = $_[1];
	my $data = "";
	
	my $id = $currentspecobj->findnodes("id")->[0]->textContent;
	my @linksto = $currentspecobj->findnodes("providescoverage/provcov/linksto");
    my $arraySize = scalar (@linksto);
    #print "  Number of found links: " . scalar(@linksto) . "\n";
    	
	foreach my $linksto (@linksto)
	{
		my $linkedid = $linksto->textContent();
		my $covstatus = "";
		my $doctype = "";
		
		my @foundnodes = $root->findnodes("/tracingresults/specdocument/specobjects/specobject[id='$linkedid']");
		if (scalar(@foundnodes) > 1) 
		{
		  $main::log->warning("EINPUTDATA", "Found " . scalar(@foundnodes) . " specobjects with id \"$linkedid\" (expected 0 or 1)");
		}
		elsif (scalar(@foundnodes) == 1)
		{
		  $data .= printParents($foundnodes[0], $root);
		  $covstatus = $foundnodes[0]->findnodes("covstatus")->[0]->textContent;
		  $doctype = $foundnodes[0]->findnodes("../\@doctype")->[0]->textContent;
		}
		
		#print the new parent node
		$data .= printNode($linkedid, $doctype, $covstatus, 0);
		
		#print the edge between the current node and the new parent node
		$data .= "  \"$id\" -> \"" . $linkedid . "\" [color=purple];\n";
	}
	return $data;
}

#Needed for graphviz export. Prints all children of the passed node.
sub printChildren
{
	my $currentspecobj = $_[0];
	my $root = $_[1];
	my $data = "";
	
	my $id = $currentspecobj->findnodes("id")->[0]->textContent;
	my @linkedfroms = $currentspecobj->findnodes("needscoverage/needscov/coveredby/linkedfrom");
    my $arraySize = scalar (@linkedfroms);
    #print "  Number of found linkfroms: " . scalar(@linkedfroms) . "\n";
    
	foreach my $linkedfrom (@linkedfroms)
	{
		my $linkedid = $linkedfrom->findnodes("srcid")->[0]->textContent;
		my $covstatus = "";
		my $doctype = "";
		
		my @foundnodes = $root->findnodes("/tracingresults/specdocument/specobjects/specobject[id='$linkedid']");
		if (scalar(@foundnodes) != 1) 
		{
			$main::log->warning("EINPUTDATA", "Found " . scalar(@foundnodes) . " specobjects with id \"$linkedid\" (expected 1)");
		} 
		else 
		{
			$data .= printChildren($foundnodes[0], $root);
			$covstatus = $foundnodes[0]->findnodes("covstatus")->[0]->textContent;
			$doctype = $foundnodes[0]->findnodes("../\@doctype")->[0]->textContent;
		}
		
		#print the new child node
		$data .= printNode($linkedid, $doctype, $covstatus, 0);
		
		#print the edge between the current node and the new child node
		$data .= "  \"$linkedid\" -> \"$id\" [color=orange];\n";
	}
	return $data;
}


sub printNode
{
	my $nodename = $_[0];
	my $doctype = $_[1];
	my $covstatus = $_[2];
	my $iscenternode = $_[3];
	
	
	#determine shape from doctype
	my $shape = "";
	if (($doctype eq "reqspec") || ($doctype eq "requirements"))
	{
		$shape = "box";
	} 
	elsif ($doctype eq "testspec")
	{
		$shape = "note";
	}
	elsif ($doctype eq "testcasespec")
	{
		$shape = "tab";
	}
	elsif ($doctype eq "testsrc")
	{
		$shape = "folder";
	}
	elsif ($doctype eq "testresults")
	{
		$shape = "component";
	}
	else
	{
		#error, no doctype given
		$shape = "Mcircle";
		#make sure doctype isn't empty (this would bring trouble with graphviz's <FONT> tag)
		$doctype = "invalid";
	}
	
	
	#determine if a node is the center node (this is the node that has the same name as the produced graphviz file)
	#if so, draw it with two peripheries
	my $peripheries = 1;
	if ($iscenternode == 1)
	{
		$peripheries = 2;
	}


	#determine color from covstatus
	my $color = "";
	if ($covstatus eq "covered")
	{
		$color = "green";
	} 
	elsif ($covstatus eq "partially") 
	{
		$color = "yellow";
	}
	elsif ($covstatus eq "uncovered")
	{
		$color = "red";
	}
	else
	{
		$color = "white";
	}
	
	my $data = "  \"$nodename\" [shape=$shape, peripheries=\"$peripheries\", label=<<TABLE BGCOLOR=\"$color\" BORDER=\"0\">";
	$data .= "<TR><TD HREF=\"../$output_file_name#$nodename\"><IMG SRC=\"$graphviz_img_html\"/></TD><TD HREF=\"$nodename.svg\">$nodename</TD></TR>";
	$data .= "<TR><TD COLSPAN=\"2\" ALIGN=\"LEFT\"><FONT POINT-SIZE=\"12\">$doctype</FONT></TD></TR></TABLE>>];\n";
	return $data;
}

1;
