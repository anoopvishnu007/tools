# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_CheckExporter;

$VERSION = '1.00';

use strict;
use File::Copy::Recursive qw(fcopy rcopy dircopy fmove rmove dirmove);
use Cwd;
use FindBin;
use File::Spec::Functions;
use File::Basename;


sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the CheckExporter:\n\n";
  print "rules:\n";
  print "Allowed values: path to rules.xml file\n";
  print "This file defines the rules that this exporter checks.\n";
}

sub runExporter
{
  my $self = shift;
  my $file = shift;
  my $xmldat = shift;
  my $outdir = shift;
  my $outfile = shift;
  my $params = shift;

  my $oreqm_root = $xmldat->documentElement();
  my $rules_file;
  
  my %warnfor =
      ("rules" => 1);
  my %params;
  $params="" if(!$params);
  $params{"rules"}=\$rules_file;
  $self->{COMMON}->parseParams("ReqM2_CheckExporter", $params, \%params, \%warnfor);
  
  unless ($rules_file) {
    $main::log->error("EPARAMUNDEF", "ReqM2_CheckExporter", "rules");
  }

  my $rules_root = XML::LibXML->load_xml(
      location => $rules_file,
      line_numbers => 1,
      no_network => 1,
      recover => 2);
   
  foreach my $rule($rules_root->findnodes("//rule"))
  {
    my $rule_name = $rule->findnodes("name")->[0]->textContent();
    my $rule_comment = $rule->findnodes("comment")->[0]->textContent();
    
    # loops over all condition checks
    foreach my $condition_check($rule->findnodes("conditioncheck"))
    {
      my $applyto = $condition_check->findnodes("applyto")->[0]->textContent;
      my $condition = $condition_check->findnodes("condition")->[0]->textContent;
      
      print "$rule_name: condition check xpath $applyto with condition $condition\n";
      apply_condition_check($oreqm_root, $rule_name, $applyto, $condition);
    }

    # loops over all regex checks
    foreach my $regex_check($rule->findnodes("regexcheck"))
    {
      my $applyto = $regex_check->findnodes("applyto")->[0]->textContent;
      my $regex = $regex_check->findnodes("regex")->[0]->textContent;
      my $report = $regex_check->findnodes("report")->[0]->textContent;
      
      print "$rule_name: regex check xpath $applyto with regex $regex and report $report\n";
      apply_regex_check($oreqm_root, $rule_name, $applyto, $regex, $report);
    }
    
  }
  return 1;
}


sub apply_condition_check
{
  my $oreqm_root = $_[0];
  my $rule_name = $_[1];
  my $applyto = $_[2];
  my $condition = $_[3];
  
  # loops over all 'applyto' nodes
  foreach my $current_node($oreqm_root->findnodes($applyto)) {
    my $current_id = $current_node->findnodes("id")->[0]->textContent;
    my $is_violation = $current_node->findvalue($condition);
    print_result($rule_name, "CC", $is_violation, $current_id);
  }
}


sub apply_regex_check
{
  my $oreqm_root = $_[0];
  my $rule_name = $_[1];
  my $applyto = $_[2];
  my $regex = $_[3];
  my $report = $_[4];
  
  # loops over all 'applyto' nodes
  foreach my $current_node($oreqm_root->findnodes($applyto)) {
    my $string = $current_node->textContent;
    my $matches = "false";
    if ($string =~ m/$regex/) {
      $matches = "true";
    }
    
    my $report_string = $current_node->findnodes($report)->[0]->textContent;
    print_result($rule_name, "RC", $matches, $report_string);
  }
}


sub print_result
{
  my $rule_name = $_[0];
  my $check_type = $_[1];
  my $passed = $_[2];         # pass "true" or "false" as a string here
  my $node_name = $_[3];
  
  print "$rule_name: $check_type ";
  if ($passed eq "true") {
    print " OK ";
  } else {
    print "NOK ";
  }
  print "$node_name\n";
}