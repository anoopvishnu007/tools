# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_TrampReqExporter;

$VERSION = '1.00';

use strict;
use File::Spec::Functions;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the TRAMP requirement exporter:\n\n";
  print "reqtype:\n";
  print "The doctype of the document containing a requirement specification.\n\n";
  print "tsttype:\n";
  print "The doctype of the document containing a test specification.\n\n";
}

sub runExporter
{
  my $self = shift;
  my $file = shift;
  my $xmldat = shift;
  my $outdir = shift;
  my $outfile = shift;
  my $params = shift;

  my @reqtype;
  my @tsttype;

  my $parmask = 0;

  my $data;

  my %warnfor = (reqtype => 1, tsttype => 1);
  my %params;

  $params="" if(!$params);

  $params{"reqtype"}=\@reqtype;
  $params{"tsttype"}=\@tsttype;
  $self->{COMMON}->parseParams("ReqM2_TrampReqExporter", $params, \%params, \%warnfor);

  my $filter = "needsobj='".join ("' or needsobj='", @tsttype)."'";

  my $root = $xmldat->documentElement();

  foreach my $doctype (@reqtype)
  {
    my @specobjects=$root->findnodes("/tracingresults/specdocument/specobjects[\@doctype='$doctype']");
    foreach my $specobjects (@specobjects)
    {
      my @specobject = $specobjects->findnodes("specobject");
      foreach my $specobject (@specobject)
      {
        my $tst = 0;
        my $tststat="true";
        my $id = $specobject->findnodes("id")->[0]->textContent;
        my $desc = defined($specobject->findnodes("description")->[0]) ? $specobject->findnodes("description")->[0]->textContent : "";
        my $stat = $specobject->findnodes("covstatus")->[0]->textContent;
        if($filter)
        {
          $tst = $specobject->findvalue("count(needscoverage/needscov[$filter])");
        }

        # Specobjects which are not covered get their "test"-flag set to "true", so
        # that they will show up in red in the test protocol (because no test case will
        # exists for them either). Of course this is not safe: E.g. if a specobject
        # needs coverage of type design, but instead is covered by a test case, it will
        # show up in green - but hey, that's how TRAMP works...
        if (($stat eq "covered") && ($tst == 0))
        {
          $tststat = "false";
        }

        # Replace semicolons by underscores, as these will break TRAMP
        $id=~s/;/_/g;
        $desc=~s/;/_/gm;
        $desc=~s/\s+/ /gm;
        $desc="[ReqM2: ".substr ($desc, 0, 70)."...]";
        $data .= "$id;$desc;$tststat\n";
      }
    }
  }

  if (($outdir ne File::Spec->curdir()) && (! -d $outdir) && ((mkdir "$outdir") == 0))
  {
    $main::log->error("ECREATE", "$outdir");
  }
  # Write the data returned by the exporter to the output file
  if($data)
  {
    if(open (FILE, ">".catfile($outdir, $outfile)))
    {
      $main::log->debug("DEXPORT", "$outdir/$outfile");
      binmode FILE, ":utf8";
      print FILE $data;
      close (FILE);
    }
    else
    {
      $main::log->error("EOPENFILE", "$outdir/$outfile");
    }
  }

  return 1;
}

1;
