# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_StatisticsExporter;

$VERSION = '1.00';

use strict;
use File::Spec::Functions;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe statistics exporter has no command line options.\n\n";
}

sub runExporter
{
  my $self = shift;
  my $file = shift;
  my $xmldat = shift;
  my $outdir = shift;
  my $outfile = shift;
  my $params = shift;

  my $labelcol = "#9999ff";
  my $cellcol  = "#bbffbb";
  my $nullcol  = "#ddddff";

  my $root = $xmldat->documentElement();

  # Get a list of all doctypes
  my @specobjects = $root->findnodes("/tracingresults/specdocument/specobjects");
  my @doctype = map {$_->getAttribute("doctype")} @specobjects;
  my %seen = ();
  @doctype = grep { ! $seen{$_} ++ } @doctype;

  # This holds a list of all used status values:
  my @status;
  # This holds the references to a particular doctypes status values;
  my %doctype;

  # For each doctype, get the list of SpecObjects
  foreach my $doctype (@doctype)
  {
    my %status;
    my @specobject = $root->findnodes("/tracingresults/specdocument/specobjects[\@doctype=\"$doctype\"]/specobject");
    
    foreach my $specobject (@specobject)
    {
      my $status = $specobject->findnodes("./status")->[0]->textContent();
      $doctype{$doctype}->{$status}++;
      push @status, $status;
    }
  }

  # Make the status list entries unique
  %seen=();
  @status = grep { ! $seen{$_} ++ } @status;

  my $data;

  $data  = "<html><head><title>Doctype Statictics</title></head><body>\n";
  $data .= "<center><table border=\"2\">\n";
  $data .= "<tr>\n";
  $data .= "<td bgcolor=\"$labelcol\">&nbsp;</td>";
  foreach my $doctype (@doctype)
  {
    $data .= "<td bgcolor=\"$labelcol\">$doctype</td>";
  }
  $data .= "\n";
  $data .= "</tr>\n";
  foreach my $status (@status)
  {
    $data .= "<tr>\n";
    $data .= "<td bgcolor=\"$labelcol\">$status</td>";
    foreach my $doctype (@doctype)
    {
      my $num = $doctype{$doctype}->{$status};
      if (defined($num))
      {
        $data .= "<td bgcolor=\"$cellcol\">$num</td>";
      }
      else
      {
        $data .= "<td bgcolor=\"$nullcol\">0</td>";
      }
    }
    $data .= "\n";
    $data .= "</tr>\n";
  }
  $data .= "</table>\n";
  $data .= "Number of specobjects of a particular doctype and status.\n";
  $data .= "</center>\n";
  $data .= "</body></html>\n";

  if (($outdir ne File::Spec->curdir()) && (! -d $outdir) && ((mkdir "$outdir") == 0))
  {
    $main::log->error("ECREATE", $outdir);
  }
  # Write the data returned by the exporter to the output file
  if($data)
  {
    if(open (FILE, ">".catfile($outdir, $outfile)))
    {
      $main::log->debug("DEXPORT", "$outdir/$outfile");
      binmode FILE, ":utf8";
      print FILE $data;
      close (FILE);
    }
    else
    {
      $main::log->error("EOPENFILE", "$outdir/$outfile");
    }
  }

  return 1;
}

1;
