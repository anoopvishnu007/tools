# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_Html5Exporter;

$VERSION = '1.00';

use strict;
use File::Copy::Recursive qw(fcopy rcopy dircopy fmove rmove dirmove);
use Cwd;
use FindBin;
use File::Spec::Functions;
use File::Basename;

our $graphviz_enabled;
our $graphviz_path;
our $graphviz_img_dir;
our $graphviz_img_html;
our $graphviz_img_tree;
our $resource_dir;
our $output_file_name;

our %children_hash;
our %parents_hash;

our @dotfiles;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the HTML5 testspec exporter:\n\n";
  print "graphviz:\n";
  print "Allowed values: true, false\n";
  print "Enable generation of graphviz graphics.\n";
  print "If enabled, GRAPHVIZ_DOT must point to the dot.executable.\n\n";
  print "graphvizpath:\n";
  print "Path to the dot executable.\n";
  print "NOTE: This command line parameter is obsolete in will be removed in the\n";
  print "      following release. Use the GRAPHVIZ_DOT environment variable\n";
  print "      instead\n\n";
}

sub runExporter
{
  my $self = shift;
  my $file = shift;
  my $xmldat = shift;
  my $outdir = shift;
  my $outfile = shift;
  my $params = shift;

  my $data;
  my $root = $xmldat->documentElement();

  my @doctypes;

  my @specobjects=$root->findnodes("/*/*/specobjects");

  my %numdt;
  
  #parameter handling
  $graphviz_enabled = 'false';
  $resource_dir = catfile($outdir, "resources");
  
  #cache already visited nodes here
  %parents_hash = ();
  %children_hash = ();
  
  my %warnfor =
      ("graphvizpath" => 0);
  my %params;
  $params="" if(!$params);
  $params{"graphvizpath"}=\$graphviz_path;
  $params{"graphviz"}=\$graphviz_enabled;
  $self->{COMMON}->parseParams("ReqM2_Html5Exporter", $params, \%params, \%warnfor);

  if(($graphviz_enabled ne 'true') &&
     ($graphviz_enabled ne 'false'))
  {
    $main::log->error("EBOOLEAN", "graphviz");
  }

  if (defined($graphviz_path)) {
    $main::log->warning("WGENERAL",
        "The graphvizpath parameter is obsolete and will be removed in the next release. ".
        "Use the graphviz parameter to enable creation of graphics and set the path to the ".
        "dot.exe executable in the GRAPHVIZ_DOT environment variable instead.");
      $graphviz_enabled = 'true';
  }
  else
  {
    if($ENV{'GRAPHVIZ_DOT'})
    {
      $graphviz_path = $ENV{'GRAPHVIZ_DOT'};
      # Filter out quotation marks, as otherwise system() treats them as part of the file name... 
      $graphviz_path =~s/\"//g;
    }
  }

  $graphviz_img_dir = catfile($outdir, "images");
  
  #must be in the same dir as the graphviz SVGs are
  $graphviz_img_html = "icon_html.png";
  $graphviz_img_tree = catfile("images", "icon_tree.png");
  $output_file_name = "$outfile";

  if ($graphviz_enabled eq 'true') {
    if (!$graphviz_path)
    {
      $main::log->error("EGENERAL", "Path to dot.exe is not set.");
    }
    if (!(-e $graphviz_path)) 
    {
      $main::log->error("ENOFILEINPATH", "dot.exe", $graphviz_path);
    }
  }

  
  #prepare output directory
  if (($outdir ne File::Spec->curdir()) && (! -d $outdir) && ((mkdir "$outdir") == 0))
  {
    $main::log->error("ECREATE", $outdir);
  }
  
  #prepare resources directory
  if ((! -d $resource_dir) && (mkdir $resource_dir) == 0)
  {
    $main::log->error("ECREATE", $resource_dir);
  }
  fcopy(catfile($FindBin::Bin, "exporters", "ReqM2_Html5Exporter", "icon_edit.png"),  $resource_dir);
  fcopy(catfile($FindBin::Bin, "exporters", "ReqM2_Html5Exporter", "icon_tree.png"),  $resource_dir);
  fcopy(catfile($FindBin::Bin, "exporters", "ReqM2_Html5Exporter", "icon_hide.png"),  $resource_dir);
  fcopy(catfile($FindBin::Bin, "exporters", "ReqM2_Html5Exporter", "stylesheet.xsl"), $resource_dir);
  fcopy(catfile($FindBin::Bin, "exporters", "ReqM2_Html5Exporter", "scripts.js"),     $resource_dir);
  fcopy(catfile($FindBin::Bin, "exporters", "ReqM2_Html5Exporter", "style.css"),      $resource_dir);
  
  #prepare output directories for graphviz files
  if ($graphviz_enabled eq 'true')
  {
    if ((! -d $graphviz_img_dir) && (mkdir $graphviz_img_dir) == 0)
    {
      $main::log->error("ECREATE", $graphviz_img_dir);
    }
    fcopy(catfile($FindBin::Bin, "exporters", "ReqM2_Html5Exporter", "icon_html.png"),  $graphviz_img_dir);

    #now create all the *.dot files
    foreach my $specobjects (@specobjects)
    {
      my $doctype = $specobjects->getAttribute("doctype");
      my @specobject = $specobjects->findnodes("specobject");
      foreach my $specobject (@specobject)
      {
        #create .dot files for graphviz
        printSpecObject($specobject, $root);
      }
    }
   
    createGraphs();

    #use xsltproc, which must be in $PATH, to convert the *.oreqm file to the output  HTML file
    system("xsltproc", "--stringparam", "graphvizpath", "\"$graphviz_path\"", "-o", catfile($outdir, $outfile), catfile($resource_dir, "stylesheet.xsl"), "$file");
  } else {
    #use xsltproc, which must be in $PATH, to convert the *.oreqm file to the output  HTML file
    system("xsltproc", "-o", catfile($outdir, $outfile), catfile($resource_dir, "stylesheet.xsl"), "$file");
  }
   
  return 1;
}

sub createGraphs()
{
  my $maxcmdlen = 8000;

  while(@dotfiles)
  {
    my @cmdargs;
    my $len = 0;

    while(@dotfiles)
    {
      my $next = shift @dotfiles;
      $len += length($next);

      # If the maximum command line length is exceeded, write the filename
      # back into the @dotfiles array and start graphviz for the current set
      # of dot files.
      if($len > $maxcmdlen)
      {
        push @dotfiles, $next;
        last;
      }
      push @cmdargs, $next;
    };

    my $cwd = getcwd();
    chdir($graphviz_img_dir);
    system($graphviz_path, "-Tsvg", "-O", @cmdargs);
    chdir($cwd);
  }
}

#Needed for graphviz export. Prints a specobject to a file.
sub printSpecObject
{
  my $specobject = $_[0];
  my $root = $_[1];

  my $data  = "digraph ReqGraph {\n";
  $data .= "  rankdir=\"LR\"\n";
  my $id = $specobject->findnodes("id")->[0]->textContent;
  my $doctype = $specobject->findnodes("../\@doctype")->[0]->textContent;
  my $replacedid = IDToFilename($id);

  my $covstatus = $specobject->findnodes("covstatus")->[0]->textContent;
  $data .= printNode($id, $doctype, $covstatus, 1);
  $data .= printParents($specobject, $root);
  $data .= printChildren($specobject, $root);
  $data .= "}";
    
  if(open (FILE, ">".catfile($graphviz_img_dir, "$replacedid.dot")))
  {
    $main::log->debug("DEXPORT", "$graphviz_img_dir/$replacedid.dot");
    binmode FILE, ":utf8";
    print FILE $data;
    close (FILE);

    # Save the names of all created .dot files
    push @dotfiles, "$replacedid.dot";
  }
  else
  {
    $main::log->error("EOPENFILE", "$id.dot");
  }
}


#Needed for graphviz export. Prints all parents of the passed node.
sub printParents
{
  my $currentspecobj = $_[0];
  my $root = $_[1];
  my $data = "";

  my $id = $currentspecobj->findnodes("id")->[0]->textContent;
  
  if (exists $parents_hash{$id})
  {
    return $parents_hash{$id};
  }
  
  my @linksto = $currentspecobj->findnodes("providescoverage/provcov/linksto");
  my $arraySize = scalar (@linksto);

  foreach my $linksto (@linksto)
  {
    my $linkedid = $linksto->textContent();
    my $covstatus = "";
    my $doctype = "";

    my @foundnodes = $root->findnodes("/tracingresults/specdocument/specobjects/specobject[id='$linkedid']");
    
    # Don't print anything if the link destination wasn't found
    if (scalar(@foundnodes) == 1) 
    {
      $data .= printParents($foundnodes[0], $root);
      $covstatus = $foundnodes[0]->findnodes("covstatus")->[0]->textContent;
      $doctype = $foundnodes[0]->findnodes("../\@doctype")->[0]->textContent;
    }

    #print the new parent node
    $data .= printNode($linkedid, $doctype, $covstatus, 0);

    #print the edge between the current node and the new parent node
    $data .= "  \"$id\" -> \"" . $linkedid . "\" [color=purple];\n";
  }
  
  $parents_hash{$id} = $data;
  return $data;
}


#Needed for graphviz export. Prints all children of the passed node.
sub printChildren
{
  my $currentspecobj = $_[0];
  my $root = $_[1];
  my $data = "";

  my $id = $currentspecobj->findnodes("id")->[0]->textContent;
  
  if (exists $children_hash{$id})
  {
    return $children_hash{$id};
  }
  
  my @linkedfroms = $currentspecobj->findnodes("needscoverage/needscov/coveredby/linkedfrom");
  my $arraySize = scalar (@linkedfroms);
    
  foreach my $linkedfrom (@linkedfroms)
  {
    my $linkedid = $linkedfrom->findnodes("srcid")->[0]->textContent;
    my $covstatus = "";
    my $doctype = "";

    my @foundnodes = $root->findnodes("/tracingresults/specdocument/specobjects/specobject[id='$linkedid']");
    if (scalar(@foundnodes) != 1) 
    {
      $main::log->warning("WINPUTDATA", "Found " . scalar(@foundnodes) . " specobjects with id \"$linkedid\" (expected 1)");
    } 
    else 
    {
      $data .= printChildren($foundnodes[0], $root);
      $covstatus = $foundnodes[0]->findnodes("covstatus")->[0]->textContent;
      $doctype = $foundnodes[0]->findnodes("../\@doctype")->[0]->textContent;
    }

    #print the new child node
    $data .= printNode($linkedid, $doctype, $covstatus, 0);

    #print the edge between the current node and the new child node
    $data .= "  \"$linkedid\" -> \"$id\" [color=orange];\n";
  }
  
  $children_hash{$id} = $data;
  return $data;
}


#Needed for graphviz export. Draws the current node.
sub printNode
{
  my $nodename = $_[0];
  my $doctype = $_[1];
  my $covstatus = $_[2];
  my $iscenternode = $_[3];

  my $shape = "box";
  
  if ($doctype eq "") {
    $doctype = "invalid";
  }

  #determine if a node is the center node (this is the node that has the same name as the produced graphviz file)
  #if so, draw it with two peripheries
  my $peripheries = 1;
  if ($iscenternode == 1)
  {
    $peripheries = 2;
  }

  #determine color from covstatus
  my $color = "";
  if ($covstatus eq "covered")
  {
    $color = "green";
  } 
  elsif ($covstatus eq "partially") 
  {
    $color = "yellow";
  }
  elsif ($covstatus eq "uncovered")
  {
    $color = "red";
  }
  else
  {
    $color = "white";
  }

  my $replacedid = IDToFilename($nodename);
  my $data = "  \"$nodename\" [shape=$shape, peripheries=\"$peripheries\", label=<<TABLE BGCOLOR=\"$color\" BORDER=\"0\">";
  $data .= "<TR><TD HREF=\"../$output_file_name#$nodename\"><IMG SRC=\"$graphviz_img_html\"/></TD><TD HREF=\"$replacedid.dot.svg\">$nodename</TD></TR>";
  $data .= "<TR><TD COLSPAN=\"2\" ALIGN=\"LEFT\"><FONT POINT-SIZE=\"12\">$doctype</FONT></TD></TR></TABLE>>];\n";
  return $data;
}


#expects a string as parameter. Replaces all slashes, backslashes, colons and whitespaces by underscores. 
#ReqM2 can produce IDs that consist of a path, which can contain '/' characters. 
#Replace them by underscores because $id also serves as a filename
sub IDToFilename
{
  my $id = $_[0];
  $id =~ s/\//_/g;    #replace slash by underscore
  $id =~ s/\\/_/g;    #replace backslash by underscore
  $id =~ s/\s/_/g;    #replace whitespace by underscore
  $id =~ s/:/_/g;     #replace colon by underscore
  return $id;
}

1;
