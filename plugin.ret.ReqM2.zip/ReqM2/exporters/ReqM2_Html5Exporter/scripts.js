/* searching works in two modes: "plaintext search" and "match regular expression" */
var search_in_regex_mode = false;

/* keyword definitions */
var filter_any = "any";

/* color definitions */
var color_inactive_filter = "#FFFFFF";
var color_active_filter   = "#BBBBBB";

function show_all() {
  for (i = 0; i < spobjs.length; i++) {
    document.getElementById(spobjs[i]).style.display='';
  }
}


function get_doctype_by_element(the_table) {
  return the_table.getAttribute("data-doctype");
}


function get_covstatus_by_element(the_table) {
  return the_table.getAttribute("data-covstatus");
}


function get_attribute_by_element(the_table, attr) {
  return the_table.getAttribute("data-" + attr);
}


function hide(id) {
  document.getElementById(id).style.display='none';
  
  //decrement counter
  var count_old = document.getElementById("id_now_showing").innerHTML;
  var count_new = count_old - 1;
  document.getElementById("id_now_showing").innerHTML = count_new;
}


/*
 * Filters the list of specobjects.
 * Pass the filter criteria for: 'coverage', 'status', 'hierarchy', 'doctype', 'needscoverage', 'providescoverage'.
 *
 * Values for 'coverage' are:          'covered', 'partially', 'uncovered', 'any'.
 * Values for 'status' are:            'draft', 'approved', 'proposed' or 'rejected'.
 * Values for 'doctype' are:           'reqspec', 'designspec', ..., 'any'.
 * Values for 'needscoverage' are:     'any', '', or a comma separated list of doctypes.
 * Values for 'providescoverage' are:  'any', '', or a comma separated list of doctypes.
 * Values for 'safetyclass' are:       'any', 'NONE', 'QM', 'NFS', 'ASIL-A', ..., 'ASIL-D', 'SIL-1', ... , 'SIL-4'
 * Values for 'linkerror' are:         'any', 'linkerrorgeneral', 'linkerrorexistence', 'linkerroruncovered', 'linkerrorunrequested', 'linkerrorversion'.
 * 
 */
function filter() {
  var cov = document.getElementById("id_now_showing_coverage").innerHTML;
  var st  = document.getElementById("id_now_showing_status").innerHTML;
  var dt  = document.getElementById("id_now_showing_doctype").innerHTML;
  var nc  = document.getElementById("id_now_showing_needscoverage").innerHTML;
  var pc  = document.getElementById("id_now_showing_providescoverage").innerHTML;
  var rl  = document.getElementById("id_now_showing_releases").innerHTML;
  var sc  = document.getElementById("id_now_showing_safetyclass").innerHTML;
  var le  = document.getElementById("id_now_showing_linkerror").innerHTML;
  var ss  = document.getElementById("id_now_showing_search").innerHTML.trim();  /* I had trouble with strings consisting of whitespaces only. trim() helps. */
  
  var number_of_matches = 0;
  var i = spobjs.length;
  while (i--) {
    var the_table = document.getElementById(spobjs[i]);
    
    var current_cov = get_attribute_by_element(the_table, 'covstatus');
    var current_st  = get_attribute_by_element(the_table, 'status');
    var current_dt  = get_attribute_by_element(the_table, 'doctype');
    var current_nc  = get_attribute_by_element(the_table, 'needscoverage');
    var current_pc  = get_attribute_by_element(the_table, 'providescoverage');
    var current_rl  = get_attribute_by_element(the_table, 'releases');
    var current_sc  = get_attribute_by_element(the_table, 'safetyclass');
    var current_le  = get_attribute_by_element(the_table, 'linkerror');
    
    if (   matches(current_cov, cov) 
        && matches(current_dt, dt) 
        && matches(current_st, st) 
        && contains_list(current_nc, nc) 
        && contains_list(current_pc, pc) 
        && contains_list(current_rl, rl) 
        && matches(current_sc, sc) 
        && contains_list(current_le, le) 
        && contains_string(spobjs[i], ss)
       ) {
      the_table.style.display='';
      number_of_matches++;
    } else {
      the_table.style.display='none';
    }
  }
  document.getElementById("id_now_showing").innerHTML = number_of_matches;
}


/*
 * Checks if v1 is equal to v2. If v2 is set to 'any', this always returns true.
 * If v2 starts with '!', the result is negated.
 */
function matches(v1, v2) {
  if (v2 == filter_any) {
    return true;
  } else {
    if (v2[0] != '!') {
      return (v1 == v2);
    } else {
      return (v1 != v2.slice(1));
    }
  }
}


/*
 * list is a comma separated string of doctypes, e.g. 'reqspec, designspec, src'.
 * Checks if value is 'any' (which always returns true), 'any' (true if list isn't 'none') or contained in the list.
 * If value starts with '!', the result is negated.
 */
function contains_list(list, value) {
  if (value == filter_any) {
    return true;
  } else if (value == filter_any) {
    return list != 'none';
  } else {
    var found = false;
    var search = value;
    if (value[0] == '!') {
      search = value.slice(1);
    }

    if (list.length != 0) {
      var items = list.split(",");
      var i = items.length;
      //I read on the internet, a reversed while-loop is much faster than a for-loop. Seems to be true.
      while (i--) {
        if (items[i] == search) {
          found = true;
        }
      }
    }
    if (value[0] != '!') {
      return found;
    } else {
      return !found;
    }
  }
}


/*
 * Checks if string s2 is contained in string s1.
 * If s2 is the empty string, this function also returns true.
 * If s2 starts with '!', the result is negated.
 */
function contains_string(s1, s2) {
  var search_string = s2;
  
  if (s2[0] == '!') {
    invert = true;
    search_string = search_string.slice(1);
  } else {
    invert = false;
  }

  if (search_string == '') {
    return true;
  }
  
  var found = false;
  if (search_in_regex_mode) {
    if (s1.match(search_string)) {  
      found = true;
    } else {
      found = false;
    }
  } else {
    if (s1.toLowerCase().indexOf(search_string.toLowerCase()) != -1) {
      found = true;
    } else {
      found = false;
    }
  }
  
  if (invert) {
    return !found;
  } else {
    return found;
  }
}


function change_filter_criteria(key, value) {
  var the_td = document.getElementById("id_now_showing_" + key);
  the_td.innerHTML = value;
  if ((key != "search" && value == "any") || (key == "search" && value == "")) {
    the_td.style.backgroundColor = color_inactive_filter;
  } else {
    //grey background indicates that the filter is enabled
    the_td.style.backgroundColor = color_active_filter;
  }
  filter();
}


/*
 * Deactivates all filters, so that all specobjects are shown.
 */
function reset_filters() {
  document.getElementById("id_now_showing_coverage").innerHTML = "any";
  document.getElementById("id_now_showing_coverage").style.backgroundColor         = color_inactive_filter;
  document.getElementById("id_now_showing_status").innerHTML = "any";
  document.getElementById("id_now_showing_status").style.backgroundColor           = color_inactive_filter;
  document.getElementById("id_now_showing_doctype").innerHTML = "any";
  document.getElementById("id_now_showing_doctype").style.backgroundColor          = color_inactive_filter;
  document.getElementById("id_now_showing_needscoverage").innerHTML = "any";
  document.getElementById("id_now_showing_needscoverage").style.backgroundColor    = color_inactive_filter;
  document.getElementById("id_now_showing_providescoverage").innerHTML = "any";
  document.getElementById("id_now_showing_providescoverage").style.backgroundColor = color_inactive_filter;
  document.getElementById("id_now_showing_releases").innerHTML = "any";
  document.getElementById("id_now_showing_releases").style.backgroundColor = color_inactive_filter;
  document.getElementById("id_now_showing_safetyclass").innerHTML = "any";
  document.getElementById("id_now_showing_safetyclass").style.backgroundColor      = color_inactive_filter;
  document.getElementById("id_now_showing_linkerror").innerHTML = "any";
  document.getElementById("id_now_showing_linkerror").style.backgroundColor        = color_inactive_filter;
  document.getElementById("id_now_showing_search").innerHTML = "";
  document.getElementById("id_now_showing_search").style.backgroundColor           = color_inactive_filter;
  filter();
}


/*
 * Gets the current filter criteria (e.g. 'src' or '!designspec') and inverts it,
 * that is, if it starts with '!', then remove it, otherwise add it.
 * Write the output (e.g. '!src' or 'designspec') back to the "now_showing" table.
 *
 * At the end, filtering is invoked.
 */
function invert_filter(key) {
  var element = document.getElementById("id_now_showing_" + key);
  var current_value = element.innerHTML;
  
  if (current_value == filter_any) {
    alert("Filtering for '" + current_value + "' can't be inverted!");
    return;
  }
  
  //get first character
  var first_char = current_value.substr(0,1);
  
  //invert
  if (first_char == '!') {
    var new_value = current_value.slice(1);
  } else {
    var new_value = '!' + current_value;
  }
  
  //write back to 'now showing' table
  element.innerHTML = new_value;
  
  filter();
}


/*
 * The user has clicked on on link that leads him to a specobject.
 * Make sure this specobject is visible.
 */
function follow_link(id) {
  var the_table = document.getElementById(id);
  the_table.style.display='';
}


/*
 * Copies the IDs of all currently selected specobjects to the clipboard.
 */
function download_ids() {
  var id_list = [];
  for (i = 0; i < spobjs.length; i++) {
    if (document.getElementById(spobjs[i]).style.display=='') {
      id_list.push(spobjs[i]);
    }
  }
  
  //show a new page in the browser with a list of all specobject IDs
  var new_window = window.open("Specobject ID list", "about:blank");
  for (i = 0; i < id_list.length; i++) {
    new_window.document.writeln(id_list[i] + "<br/>");
  }
  new_window.stop();
}
