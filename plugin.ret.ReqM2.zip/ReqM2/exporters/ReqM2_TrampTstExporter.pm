# !LINKSTO WikiReqSpec.GeneralToolReqs.6, 1
package ReqM2_TrampTstExporter;

$VERSION = '1.00';

use strict;
use File::Spec::Functions;

sub new
{
  my $type = shift;
  my $common = shift;

  my $self = {COMMON => $common};

  bless($self, $type);
  return $self;
}

sub help
{
  print "\n\nThe following options are available for the TRAMP testspec exporter:\n\n";
  print "reqtype:\n";
  print "The doctype of the document containing a requirement specification.\n\n";
  print "tsttype:\n";
  print "The doctype of the document containing a test specification.\n\n";
  print "removepf:\n";
  print "Prefix which shall be removed from the test specification Id when generating\n";
  print "TRAMP input. TRAMP requires that the test specification and the test case\n";
  print "itself have the same Id, whereas ReqM2 forbids two specobjects with the same\n";
  print "Id. Using this feature, you can use prefices to decide between the test\n";
  print "specification and the actual test case on ReqM2 level, but still retain\n";
  print "TRAMP compatibility.\n\n";
}

sub runExporter
{
  my $self = shift;
  my $file = shift;
  my $xmldat = shift;
  my $outdir = shift;
  my $outfile = shift;
  my $params = shift;

  my @reqtype;
  my @tsttype;
  my $removepf;

  my $parmask = 0;

  my $data;

  my %warnfor = (reqtype => 1, tsttype => 1);

  my %params;

  $params="" if(!$params);

  $params{"reqtype"}=\@reqtype;
  $params{"tsttype"}=\@tsttype;
  $params{"removepf"}=\$removepf;
  $self->{COMMON}->parseParams("ReqM2_TrampTstExporter", $params, \%params, \%warnfor);

  my $root = $xmldat->documentElement();

  foreach my $doctype (@tsttype)
  {
    my @specobjects=$root->findnodes("/tracingresults/specdocument/specobjects[\@doctype='$doctype']");
    foreach my $specobjects (@specobjects)
    {
      my @specobject = $specobjects->findnodes("specobject");
      foreach my $specobject (@specobject)
      {
        my @reqlist;
        my $id = $specobject->findnodes("id")->[0]->textContent;
        if(defined($removepf))
        {
          $id=~s/^$removepf//;
        }
        my $desc = defined($specobject->findnodes("description")->[0]) ? $specobject->findnodes("description")->[0]->textContent : "";
        my @linksto = $specobject->findnodes("providescoverage/provcov/linksto");
        foreach my $linksto (@linksto)
        {
          my $dstid=$linksto->textContent();
          my $dstobject=$root->findnodes("/tracingresults/specdocument/specobjects/specobject[id='$dstid']")->[0];
          if(defined($dstobject))
          {
            my $dstdoctype=$dstobject->findnodes("..")->[0]->getAttribute("doctype");
            if(!grep(/^$dstdoctype$/, @reqtype))
            {
              next;
            }
          }
          push @reqlist, $dstid;
        }
        my $reqlist = join ",", @reqlist;

        # Replace semicolons by underscores, as these will break TRAMP.
        # Only description and reqlist need to be adapted, because they are
        # out of control of the requirements' author. The testid should not
        # contain semicolons anyway, as usually it is a valid C identifier
        # (the name of the test function) and we'd get into trouble if the
        # id here is different from that seen by Ts5Atl.
        $desc=~s/;/_/gm;
        $reqlist=~s/;/_/gm;
        $desc=~s/\s+/ /gm;
        $desc="[ReqM2: ".substr ($desc, 0, 70)."...]";
        $data .= "$id;$desc;$reqlist;true\n";
      }
    }
  }

  if (($outdir ne File::Spec->curdir()) && (! -d $outdir) && ((mkdir "$outdir") == 0))
  {
    $main::log->error("ECREATE", $outdir);
  }
  if($data)
  {
    # Write the data returned by the exporter to the output file
    if(open (FILE, ">".catfile($outdir, $outfile)))
    {
      $main::log->debug("DEXPORT", "$outdir/$outfile");
      binmode FILE, ":utf8";
      print FILE $data;
      close (FILE);
    }
    else
    {
      $main::log->error("EOPENFILE", "$outdir/$outfile");
    }
  }

  return 1;
}

1;
