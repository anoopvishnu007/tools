#!/usr/bin/perl -w
# !LINKSTO WikiReqSpec.GeneralToolReqs.6,1,
# !        ReqM2ReqSpec.General.1, 1
package main;

# !LINKSTO ReqM2ReqSpec.General.3, 1
require 5.010_000;

# Do NOT touch! This is updated by SVN!
$REVISION = '$Revision: 685 $';

use strict;
# !LINKSTO ReqM2ReqSpec.General.2, 1
use Getopt::Std;
use FindBin;
use Cwd 'abs_path';
use File::Basename;
use File::Spec::Functions;

no warnings 'once';

# Enable processing of "--help" and "--version"
$Getopt::Std::STANDARD_HELP_VERSION = 1;

# Determine my own location and set some important folders
my $MyPath = "$FindBin::Bin";
my $cfgPath = catfile($FindBin::Bin, "config", "ReqM2cfg.xml");
my $xsdPath = catfile($FindBin::Bin, "schemas");
my $verPath = catfile($FindBin::Bin, "lib", "ReqM2_Version.dat");

# We have to use the FindBin module here, in order to
# *prepend* the search path to @INC
use lib catfile($FindBin::Bin, "lib");
use lib catfile($FindBin::Bin, "importers");
use lib catfile($FindBin::Bin, "exporters");

# !LINKSTO ReqM2ReqSpec.General.2, 1
use XML::LibXML 1.070_000;

# Some variables
my $retVal = 0;
my %opts;
my $outFile;
my $ver;
my $cfg;
my $cmdline;
my $filelist;

my $optstring="itrvDqEPx:p:n:o:O:c:s:e:f:";


# Include all required sub-modules
require ReqM2_Importer; import ReqM2_Importer;
require ReqM2_ReqM2Cfg; import ReqM2_ReqM2Cfg;
require ReqM2_Version;  import ReqM2_Version;
require ReqM2_SpecObj;  import ReqM2_SpecObj;
require ReqM2_Trace;    import ReqM2_Trace;
require ReqM2_Log;      import ReqM2_Log;
require ReqM2_Common;   import ReqM2_Common;
require ReqM2_Validate; import ReqM2_Validate;

my $common = ReqM2_Common->new();

# Needed for the output file
foreach (@ARGV) {$cmdline.="$_ ";}

# The $log is the only global variable
our $log;

$log = ReqM2_Log->new($common);
$ver = ReqM2_Version->new($common, "$verPath");
if($ver == 0) {exit 1;}

# Find out what I should actually do
printUsage() if ((getopts($optstring, \%opts) == 0) || (parseCmdLine() == 0));

$opts{'O'} = abs_path($opts{'O'}) if defined($opts{'O'});

# If -f is specified, use the listfile's entries as file list, @ARGV otherwise
if(defined($opts{'f'}))
{
  $filelist=readFileList(abs_path($opts{'f'}));
}
else
{
  $filelist = \@ARGV;
}

# Absolute paths for all given file names
foreach my $fn (@{$filelist})
{
  # Apply abs_path() to the directory part of the path only, as the
  # file itself might not yet exist at this point and thus abs_path()
  # could return an error.
  $fn = catfile(abs_path(dirname($fn)), basename($fn));
}

$log->enableDebug() if(defined($opts{'D'}));
$log->disableInfo() if(defined($opts{'q'}));
$log->warnAsError() if(defined($opts{'E'}));

$main::log->info("IVERSION", $ver->getName(), $ver->getVersion());
$main::log->info("ICOPYRIGHT");

# Load configuration
$cfgPath = $opts{'c'} if(defined($opts{'c'}));
$cfgPath = abs_path($cfgPath);
$cfg = ReqM2_ReqM2Cfg->new($common, $cfgPath, catfile($xsdPath, "ReqM2cfg.xsd"));

if(!$cfg)
{
  # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0001,1
  $log->error("EOPENFILE", "$cfgPath");
}

$main::log->debug("DCONFIGFOUND");

$cfg->loadConfig();

$main::log->info("ICFGLOADED");

if($log->setLogfile($cfg) == 0)
{
  $log->warning("WSTDERR", "$cfg->{LOGFILE}");
}
if($log->setDbgfile($cfg) == 0)
{
  $log->warning("WSTDERR", "$cfg->{DBGFILE}");
}

my %tags=$cfg->parseSchema(catfile($xsdPath, "SpecObj.xsd"));

# Do what I should actually do
if(defined($opts{'i'}))
{
  $main::log->info("IMODE", "importer");
  doImport();
}
elsif(defined($opts{'t'}))
{
  $main::log->info("IMODE", "tracing");
  doTrace();
}
elsif(defined($opts{'r'}))
{
  $main::log->info("IMODE", "exporter");
  doExport();
}
elsif(defined($opts{'v'}))
{
  $main::log->info("IMODE", "validator");
  doValidate();
}
else
{
  $log->error("EFATAL",  __FILE__ ,  __LINE__ , "Reached unreachable point");
}

close ($log->{LOGFILE}) if ($log->{LOGFILE});
exit $retVal;

#---------- Subroutines -------------------------------

sub doImport
{
  my @args = @_;
  $common->checkArguments("main::doImport", [], \@args);

  # Load importer module 
  eval "require $opts{'x'}; import $opts{'x'};";

  if ($@)
  {
    $main::log->error("EMODULE", "$opts{'x'}.pm", $@);
  }

  $main::log->debug("DSTARTIMPORT", "$opts{'x'}");

  my $outFile = basename("${$filelist}[0].reqm");
  $outFile = $opts{'o'} if(defined($opts{'o'}));

  if(dirname($outFile) ne File::Spec->curdir())
  {
    $main::log->error("ENOPATH");
  }

  $outFile = catfile("$opts{'O'}","$outFile") if(defined($opts{'O'}));

  # Create document with top level node
  $main::log->debug("DCREATEDATA");
  my $doc = XML::LibXML::Document->new("1.0", "UTF-8");
  if(!defined($doc))
  {
    $main::log->error("ECREATEDOC");
  }
  my $topnode = XML::LibXML::Element->new("specdocument");
  if(!defined($topnode))
  {
    $main::log->error("ECREATENODE", "specdocument.\n");
  }
  if(!defined($doc->addChild($topnode)))
  {
    $main::log->error("EADDNODE", "specdocument.\n");
  }

  $common->setEncoding($opts{'n'}) if(defined($opts{'n'}));
  
  # Some useful API calls
  my $impapi = ReqM2_Importer->new($common, $doc, $topnode, \%tags);

  # Run importer
  $main::log->debug("DRUNIMPORT");
  my $imp = $opts{'x'}->new($common);

  # The importer gets the source filename as well as the handle to
  # the importer helper API and the option string
  foreach my $fn (@{$filelist})
  {
    if(!($imp->runImporter($fn, $impapi, $opts{'p'}, \%tags) != 0))
    {
      $log->warning("WIMPORTFAILED", "$fn");
    }
  }

  # Only write an output file if the input file contained specobjects
  if($doc->findvalue("count(//specobject)") > 0)
  {
    # Write the imported data to the output file in ReqM2 format
    if(open (FILE, ">$outFile") != 0)
    {
      $main::log->debug("DWRITEIMPDATA", "$outFile");
      print FILE $doc->toString(1);
      close (FILE);
    }
    else
    {
      $log->error("EOPENFILE", "$outFile");
    }
  }
}

sub doTrace
{
  my @args = @_;
  $common->checkArguments("main::doTrace", [], \@args);

  my %toolinfo = (
      name => $ver->getName(),
      version => $ver->getVersion(),
      libxmlversion => $ver->getLibXMLVersion(),
      libxml2compileversion => $ver->getLibXML2Version(),
      libxml2runtimeversion => $ver->getLibXMLRTVersion(),
      cmdline => $cmdline,
      optstring => $optstring,
      cmdopts => \%opts,
      filelist => $filelist
      );


  my $outFile = "reqm2_traceout.oreqm";
  $outFile = $opts{'o'} if(defined($opts{'o'}));

  if(dirname($outFile) ne File::Spec->curdir())
  {
    $main::log->error("ENOPATH");
  }
  $outFile = catfile($opts{'O'},"$outFile") if(defined($opts{'O'}));

  # By default, trace "approved" and "rejected" objects
  my $requiredStatus = "approved,rejected";
  $requiredStatus = $opts{'s'} if(defined($opts{'s'}));

  $main::log->debug("DSTARTTRACE");

  my $tracer = ReqM2_Trace->new($common, $cfg, $requiredStatus, \%toolinfo);

  $opts{'e'}="" if !defined($opts{'e'});
  # Load each specified input file, verify the optional tags and
  # add it to the internal representation of the whole document
  foreach my $file (@{$filelist})
  {
    my $spec = ReqM2_SpecObj->new($common, $file, catfile($xsdPath,"SpecObj.xsd"));
    $main::log->debug("DLOADANDVALIDATE", "$file");
    $spec->loadSpecFile();
    $spec->addDefaultValues(\%tags);
    if($spec->verifyDoctypes($cfg) && $spec->verifyOptionalTags($cfg))
    {
      $main::log->debug("DADDFORTRACING", "$file");
      $tracer->addDocument($spec, $opts{'e'});
    }
  }

  # Verify the consistency of the whole document
  $main::log->debug("DCHECKCONS");
  $tracer->validateDocumentSet();
  # Do the actual tracing
  $main::log->debug("DLINKINGOBJ");
  my $prop = defined($opts{'P'})?0:1;
  $tracer->linkCoverages($cfg, $prop);
  # Write the tracing result to the result file
  $main::log->debug("DWRITETRACRESULT", "$outFile");
  $tracer->createReport($outFile);

  my $infile = XML::LibXML->load_xml(
      location => $outFile);
  if(!defined($infile))
  {
    $main::log->error("EOPENFILE", "$outFile");
  }
  my $schema=XML::LibXML::Schema->new(
      location => catfile($xsdPath, "Output.xsd"));
  if(!defined($schema))
  {
    $main::log->error("EOPENFILE", "Output.xsd");
  }

  # !LINKSTO ReqM2ReqSpec.TracingUnit.0020, 1
  $main::log->debug("DVALIDATE", "$outFile");
  eval{$schema->validate($infile);};
  if($@)
  {
    $log->error("EEVAL", "$@");
  }
}

sub doExport
{
  my @args = @_;
  $common->checkArguments("main::doExport", [], \@args);

  # Load exporter module 
  eval "require $opts{'x'}; import $opts{'x'};";

  if ($@)
  {
    $main::log->error("EMODULE", "$opts{'x'}.pm", $@);
  }

  $main::log->debug("DSTARTEXPORT", "$opts{'x'}");

  my $outFile = basename("${$filelist}[0].dat");

  $outFile = $opts{'o'} if(defined($opts{'o'}));

  if(dirname($outFile) ne File::Spec->curdir())
  {
    $main::log->error("ENOPATH");
  }

  my $outDir = File::Spec->curdir();
  $outDir = "$opts{'O'}" if(defined($opts{'O'}));

  if($#{$filelist} > 0)
  {
    $main::log->warning("WMULTFILENAME", "${$filelist}[0]");
  }

  $main::log->debug("DLOADING", "${$filelist}[0]");
  my $infile = XML::LibXML->load_xml(
      location => ${$filelist}[0]);
  if(!defined($infile))
  {
    $main::log->error("EOPENFILE", "${$filelist}[0]");
  }
  my $schema=XML::LibXML::Schema->new(
      location => catfile($xsdPath, "Output.xsd"));
  if(!defined($schema))
  {
    $main::log->error("EOPENFILE", "Output.xsd");
  }

  $main::log->debug("DVALIDATE", "${$filelist}[0]");
  eval{$schema->validate($infile);};
  if($@)
  {
    $log->error("EEVAL", "$@");
  }
  else
  {
    # Run exporter
    my $exp = $opts{'x'}->new($common);

    # The exporter gets the filename as well as the LibXML representation,
    # of the results file, so it can choose which format to use as input
    # for the transformation.
    $main::log->debug("DRUNEXPORT");
    my $outdata=$exp->runExporter(${$filelist}[0], $infile, $outDir, $outFile, $opts{'p'});

    if(!$outdata)
    {
      $log->error("EEXPORT", "$outFile");
    }
  }
}

sub doValidate
{
  my @args = @_;
  $common->checkArguments("main::doValidate", [], \@args);

  my $outfile = shift(@{$filelist});
  my @infiles = @{$filelist};

  my $ret = 0;

  my $validate = ReqM2_Validate->new($common);


  $validate->loadOutFile($outfile);
  $validate->loadInFiles(\@infiles);

  $ret += $validate->checkSpecInEqSpecOut();
  $ret += $validate->checkSpecOutEqSpecIn();
  $ret += $validate->checkTags();
  $ret += $validate->checkProcessed();

  if($ret != 4)
  {
    $main::log->error("EVALIDATE");
  }
  else
  {
    $main::log->info("IVALIDPASSED");
  }
}

sub doHelp
{
  my @args = @_;
  $common->checkArguments("main::doHelp", [], \@args);

  # Load im-/exporter module 
  eval "require $opts{'x'}; import $opts{'x'};";

  if ($@)
  {
    $main::log->error("EMODULE", "$opts{'x'}.pm", $@);
  }

  my $impexp = $opts{'x'}->new();
  $impexp->help();
}


sub printUsage
{
  my @args = @_;
  $common->checkArguments("main::printUsage", [], \@args);

  print STDERR "Usage: ReqM2.pl (-i | -t | -r) [-x transformer] [-p param ]\n";
  print STDERR "                [-o outfile ] [-O outdir] [-c cfgfile] [-D] [-q]\n";
  print STDERR "                [-E] [-s status,status,...] [-e doctype,doctype,...]\n";
  print STDERR "                [-P] -f filelist | infile [infile [...]]\n";
  print STDERR "       ReqM2.pl -v outfile infile [infile [...]]\n";
  print STDERR "       ReqM2.pl -v -f filelist outfile\n";
  print STDERR "Modes:\n";
  print STDERR "      -i Read infile, convert to ReqM2 format using the transformer and write to outfile\n";
  print STDERR "      -t Read infiles, do tracing and write results to outfile\n";
  print STDERR "      -r Read infile, create tracing report using the transformer and write to outfile\n";
  print STDERR "      -v Validate contents of outfile and infile(s)\n";
  print STDERR "Options:\n";
  print STDERR "      -x Transformer to use for reading input files or writing tracing reports\n";
  print STDERR "      -p Parameter string passed to transformer\n";
  print STDERR "      -n Character encoding of the input file\n";
  print STDERR "      -o Name of the output file\n";
  print STDERR "      -O Name of the output directory\n";
  print STDERR "      -c Name of the configuration file (default: $cfgPath)\n";
  print STDERR "      -s Status required for specobject to be traced (default: approved,rejected)\n";
  print STDERR "      -e elide doctypes in needscoverage list\n";
  print STDERR "      -D Print debug messages\n";
  print STDERR "      -q Quiet, no info messages\n";
  print STDERR "      -E Treat all warnings as errors\n";
  print STDERR "      -P Do not propagate the coverage status\n";
  print STDERR "      -f File with a list of input file names\n";
  exit 1;
}

sub parseCmdLine
{
  my @args = @_;
  $common->checkArguments("main::parseCmdLine", [], \@args);

  my $retVal = 0;
  # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0002,1
  # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0003,1
  if(
      (!defined($opts{'i'}) && !defined($opts{'t'}) && !defined($opts{'r'}) && !defined($opts{'v'})) ||
      (defined($opts{'i'}) && (defined($opts{'t'}) || defined($opts{'r'}) || defined($opts{'v'}))) ||
      (defined($opts{'t'}) && (defined($opts{'r'}) || defined($opts{'v'}))) ||
      (defined($opts{'r'}) && (defined($opts{'v'})))
    )
  {
    $log->error("EMODE");
  }
  # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0004,1
  elsif(
      (defined($opts{'i'}) && !defined($opts{'x'})) ||
      (defined($opts{'r'}) && !defined($opts{'x'}))
    )
  {
    $log->error("ENOTRANS");
  }
  # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0006,1
  elsif(($#ARGV < 0) && (!defined($opts{'f'})))
  {
    $log->error("ENOINFILE");
  }
  elsif(($#ARGV >= 0) && (defined($opts{'f'})))
  {
    $log->error("ENOINPUTFILES");
  }
  elsif(defined($opts{'v'}) && (($#ARGV < 1) && (!defined($opts{'f'}))))
  {
    $log->error("ENOIOFILE");
  }
  else
  {
    # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0008,1
    if(defined($opts{'t'}) && defined($opts{'x'}))
    {
      $log->error("ENOTRANSINT");
    }
    # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0008,1
    if(defined($opts{'t'}) && defined($opts{'p'}))
    {
      $log->error("ENOPARSTRING");
    }
    # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0010,1
    if(defined($opts{'i'}) && defined($opts{'s'}))
    {
      $log->error("ENOSTATUS", "-i");
    }
    # !LINKSTO ReqM2ReqSpec.CommandlineChecks.0009,1
    if(defined($opts{'r'}) && defined($opts{'s'}))
    {
      $log->error("ENOSTATUS", "-r");
    }
    if(defined($opts{'i'}) && defined($opts{'e'}))
    {
      $log->error("ENOELIDE", "-i");
    }
    if(defined($opts{'n'}) && ((defined($opts{'t'})) || (defined($opts{'r'}))))
    {
      $log->error("EENCODE");
    }
    if(defined($opts{'P'}) && ((defined($opts{'i'})) || (defined($opts{'r'}))))
    {
      $log->error("ENOPROP");
    }
    if(defined($opts{'r'}) && defined($opts{'e'}))
    {
      $log->error("ENOELIDE", "-r");
    }
    if(defined($opts{'v'}) &&
        (defined($opts{'x'}) || defined($opts{'p'}) || defined($opts{'o'}) || defined($opts{'O'}) ||
         defined($opts{'s'}) || defined($opts{'e'}))
      )
    {
      $log->error("EMODEV");
    }
    # If we came to this point, no error has occurred.
    $retVal = 1;
  }
  return $retVal;
}

# These are called by Getopt::Std in case of "--help" or "--version"
sub HELP_MESSAGE
{
  my @args = @_;
  $common->checkArguments("main::HELP_MESSAGE", ["GLOB","","",""], \@args);

  if(defined($opts{'x'}))
  {
    doHelp();
  }
  else
  {
    printUsage();
  }
}

sub VERSION_MESSAGE
{
  my @args = @_;
  $common->checkArguments("main::VERSION_MESSAGE", ["GLOB","","",""], \@args);

  if($ver->getVersion())
  {
    print "Version: ", $ver->getVersion(), "\n";
    print "XML::LibXML version: ", $ver->getLibXMLVersion(), "\n";
    print "Compiled for libxml2 version: ", $ver->getLibXML2Version(), "\n";
    print "Using libxml2 runtime version: ", $ver->getLibXMLRTVersion(), "\n";
    print "ReqM2 revision: $main::REVISION\n";
    print "ReqM2_Common revision: $ReqM2_Common::REVISION\n";
    print "ReqM2_Helpers revision: $ReqM2_Helpers::REVISION\n";
    print "ReqM2_Importer revision: $ReqM2_Importer::REVISION\n";
    print "ReqM2_Log revision: $ReqM2_Log::REVISION\n";
    print "ReqM2_ReqM2Cfg revision: $ReqM2_ReqM2Cfg::REVISION\n";
    print "ReqM2_SpecObj revision: $ReqM2_SpecObj::REVISION\n";
    print "ReqM2_Trace revision: $ReqM2_Trace::REVISION\n";
    print "ReqM2_Validate revision: $ReqM2_Validate::REVISION\n";
    print "ReqM2_Version revision: $ReqM2_Version::REVISION\n";
  }
}

sub getResPath
{
  my @args = @_;
  $common->checkArguments("main::getResPath", [], \@args);

	return catfile($MyPath, "res");
}

sub readFileList
{
  my $fn = shift;
  my @files;

  if(!open(FILE, "<$fn"))
  {
    $log->error("EOPENFILE", "$fn");
  }
  my @lines=<FILE>;
  close(FILE);

  foreach my $line (@lines)
  {
    $line =~ s/#.*//;
    $line =~ s/^\s*//;
    $line =~ s/\s*$//;
    $line =~ s/\r//;
    $line =~ s/\n//;
    push @files, $line if($line);
  }

  if(!@files)
  {
    $log->error("EFILELIST", "$fn");
  }
  return \@files;
}


