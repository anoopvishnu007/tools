#!/usr/bin/perl -w

use strict;
use XML::LibXML;

# Tags to be converted to attributes
my @att = ("id", "status", "version");

my $backup = 1;

my $filename=$ARGV[$#ARGV];

if($#ARGV == 1)
{
  $backup = 0;
}
elsif(($#ARGV < 0) || ($#ARGV > 1) ||
     (($#ARGV == 1 ) && ($ARGV[0] ne "-b")))
{
  die "Usage: TagsToAtts.pl [-b] inputfile\n".
      "   -b: Do not create a backup file.\n\n";
}

my $infile = XML::LibXML->load_xml(
    location => $filename);

my $root = $infile->getDocumentElement();
my @specobject = $root->findnodes("//specobject");

foreach my $specobject (@specobject)
{
  foreach my $att (@att)
  {
    my $node = $specobject->findnodes($att)->[0];
    my $val = $node->textContent();
    my $attr = XML::LibXML::Attr->new($att, $val);
    $specobject->addChild($attr);
    $specobject->removeChild($node);
  }
}

rename "$filename", "$filename.bak" if $backup == 1;
$infile->toFile($filename, 1);
