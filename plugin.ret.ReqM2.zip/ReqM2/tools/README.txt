TagsToAtts.pl
=============

This script converts older ReqM2 files to the file format
required by ReqM2 v0.7 and higher.
In principle, it moves the contents of the <id>, <status>
and <version> tags into corresponding attributes of the
<specobject> container and deletes the original tags
hereafter.

Usage:
======
TagsToAtts.pl [-b] inputfile

This converts "inputfile" into the new file format and
creates a backup file "inputfile.bak".
If the option -b is specified, no backup file will be
created.

ATTENTION! Files processed by this tool can no longer be
read by ReqM2 v0.6 and lower!
