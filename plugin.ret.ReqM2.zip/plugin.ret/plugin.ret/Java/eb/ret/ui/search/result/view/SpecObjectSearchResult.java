/**
 * 
 */
package eb.ret.ui.search.result.view;

import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.ui.search.query.SpecObjectSearchQuery;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.IEditorMatchAdapter;
import org.eclipse.search.ui.text.IFileMatchAdapter;
import org.eclipse.search.ui.text.Match;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;

/**
 * Search result class of specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchResult extends AbstractTextSearchResult implements
		IEditorMatchAdapter, IFileMatchAdapter {

	/**
	 * Specobject search query
	 */
	private final SpecObjectSearchQuery query;

	/**
	 * Constructor
	 * 
	 * @param query
	 *            search query
	 */
	public SpecObjectSearchResult(final SpecObjectSearchQuery query) {
		super();
		this.query = query;
	}

	@Override
	public ImageDescriptor getImageDescriptor() {

		return null;
	}

	@Override
	public String getLabel() {
		SpecObjectSearchParams params = query.getParams();
		final String searchString = params.getSearchString();
		SearchForType searchFor = params.getSearchFor();
		int matchCount = getMatchCount();
		StringBuilder builder = new StringBuilder();
		builder.append("\"");
		builder.append(searchString);
		builder.append("\"");
		builder.append("-");
		builder.append(matchCount);
		builder.append(" ");
		builder.append("matches");
		builder.append(" in ");

		if (SearchForType.DESCRIPTION == searchFor) {
			builder.append(" specobject description ");

		} else if (SearchForType.COMMENTS == searchFor) {
			builder.append(" specobject comments ");
		} else {
			LimitToType limitToType = params.getLimitToType();
			builder.append(" specobject id ");
			if (LimitToType.DECLARATIONS == limitToType) {
				builder.append("declarations");
			} else if (LimitToType.REFERENCES == limitToType) {
				builder.append("references");
			}
		}
		builder.append(" in ");
		builder.append(params.getScope().getDescription());
		return builder.toString();
	}

	@Override
	public String getTooltip() {
		return getLabel();
	}

	@Override
	public Match[] computeContainedMatches(
			final AbstractTextSearchResult result, final IFile file) {
		return getMatches(file);
	}

	@Override
	public IFile getFile(final Object element) {
		if (element instanceof IFile) {
			return (IFile) element;
		}
		return null;
	}

	@Override
	public boolean isShownInEditor(final Match match, final IEditorPart editor) {
		boolean isShownInEditor = false;
		final IEditorInput editorInput = editor.getEditorInput();
		if (editorInput instanceof IFileEditorInput) {
			final IFileEditorInput finput = (IFileEditorInput) editorInput;
			isShownInEditor = match.getElement().equals(finput.getFile());
		}
		return isShownInEditor;
	}

	@Override
	public Match[] computeContainedMatches(

	final AbstractTextSearchResult result, final IEditorPart editor) {
		Match[] matches = new Match[0];
		final IEditorInput editorInput = editor.getEditorInput();
		if (editorInput instanceof IFileEditorInput) {
			final IFileEditorInput finput = (IFileEditorInput) editorInput;
			matches = getMatches(finput.getFile());
		}
		return matches;
	}

	@Override
	public ISearchQuery getQuery() {
		return query;
	}

	@Override
	public IFileMatchAdapter getFileMatchAdapter() {
		return this;
	}

	@Override
	public IEditorMatchAdapter getEditorMatchAdapter() {
		return this;
	}

}
