/**
 * 
 */
package eb.ret.ui.search.query;

import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.ui.search.result.view.SpecObjectSearchResult;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.ISearchResult;
import org.eclipse.search.ui.text.AbstractTextSearchResult;

/**
 * This class is the search query class for specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchQuery implements ISearchQuery {

	private static final String SPECOBJECT_SEARCH = "Specobject Search";

	/**
	 * search result object
	 */
	private SpecObjectSearchResult result;

	private final SpecObjectSearchParams params;

	/**
	 * 
	 * @param params
	 */
	public SpecObjectSearchQuery(SpecObjectSearchParams params) {
		this.params = params;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.search.ui.ISearchQuery#run(org.eclipse.core.runtime.
	 * IProgressMonitor)
	 */
	@Override
	public IStatus run(final IProgressMonitor monitor)
			throws OperationCanceledException {
		final AbstractTextSearchResult textResult = (AbstractTextSearchResult) getSearchResult();
		textResult.removeAll();

		// gets the specobject model search engine
		final SpecObjectModelSearchEngine specObjModelSE = new SpecObjectModelSearchEngine(
				textResult, params);
		return specObjModelSE.search(monitor);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.search.ui.ISearchQuery#getLabel()
	 */
	@Override
	public String getLabel() {
		return SPECOBJECT_SEARCH;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.search.ui.ISearchQuery#canRerun()
	 */
	@Override
	public boolean canRerun() {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.search.ui.ISearchQuery#canRunInBackground()
	 */
	@Override
	public boolean canRunInBackground() {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.search.ui.ISearchQuery#getSearchResult()
	 */
	@Override
	public ISearchResult getSearchResult() {
		if (result == null) {
			result = new SpecObjectSearchResult(this);
		}
		return result;
	}

	public SpecObjectSearchParams getParams() {
		return params;
	}

}
