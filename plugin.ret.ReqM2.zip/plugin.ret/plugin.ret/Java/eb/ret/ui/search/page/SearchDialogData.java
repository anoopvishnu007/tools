/**
 * 
 */
package eb.ret.ui.search.page;

/**
 * @author anoopvn
 * 
 */
public class SearchDialogData {
	/**
	 * Stores the value of search is case sensitive or not
	 */
	private boolean caseSensitive;
	/**
	 * Stores the value of search is a regular expression or not
	 */
	private boolean regExSearch;
	/**
	 * Stores the search string
	 */
	private String searchString;
	/**
	 * Stores the specobject id search limitto type
	 */
	private int limitToTypeValue;
	/**
	 * Stores the search type
	 */
	private int searchForValue;
	/**
	 * Stores the search scope
	 */
	private int scope;
	/**
	 * Stores the file extensions of this search
	 */
	private String fileExtnString;

	public boolean isCaseSensitive() {
		return caseSensitive;
	}

	public void setCaseSensitive(boolean caseSensitive) {
		this.caseSensitive = caseSensitive;
	}

	public boolean isRegExSearch() {
		return regExSearch;
	}

	public void setRegExSearch(boolean regExSearch) {
		this.regExSearch = regExSearch;
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	public int getLimitToTypeValue() {
		return limitToTypeValue;
	}

	public void setLimitToTypeValue(int limitToTypeValue) {
		this.limitToTypeValue = limitToTypeValue;
	}

	public int getSearchForValue() {
		return searchForValue;
	}

	public void setSearchForValue(int searchForValue) {
		this.searchForValue = searchForValue;
	}

	public String getFileExtnString() {
		return fileExtnString;
	}

	public void setFileExtnString(String fileExtnString) {
		this.fileExtnString = fileExtnString;
	}

	public int getScope() {
		return scope;
	}

	public void setScope(int scope) {
		this.scope = scope;
	}
}
