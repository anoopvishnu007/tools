package eb.ret.ui.search.page;

import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.ui.search.page.control.FileTypeControl;
import eb.ret.ui.search.page.control.LimitToControl;
import eb.ret.ui.search.page.control.SearchForControl;
import eb.ret.ui.search.page.control.SearchTextPatternControl;
import eb.ret.ui.search.query.SpecObjectSearchQuery;
import eb.ret.util.PatternConstructor;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.DialogPage;
import org.eclipse.jface.resource.JFaceColors;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.search.ui.ISearchPage;
import org.eclipse.search.ui.ISearchPageContainer;
import org.eclipse.search.ui.NewSearchUI;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * The search page implementation of specobject search functionality
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchDialogPage extends DialogPage implements
		ISearchPage {

	private static final String MSG_INVALID_REGEXP = "Entered regular expression is not valid";
	private static final String SEARCH_TEXT_HINT = "Search string (*=any string, ?=any character);";
	/**
	 * Page elements object which contains the page controls
	 */
	private final SpecObjectSearchPageElements pageElements = new SpecObjectSearchPageElements();
	/**
	 * Meta character star
	 */
	public static final String META_CHAR_STAR = "*";

	/**
	 * Gets the SpecObjectSearchPageElements object corresponding to the search
	 * page
	 * 
	 * @return SpecObjectSearchPageElements
	 */
	public SpecObjectSearchPageElements getPageElements() {
		return pageElements;
	}

	@Override
	public void createControl(final Composite parent) {

		initializeDialogUnits(parent);
		// Initialize the main window with parentDialog
		final Composite parentDialog = new Composite(parent, SWT.NONE);
		parentDialog.setFont(parent.getFont());
		final GridLayout layout = new GridLayout(2, true);
		parentDialog.setLayout(layout);

		// Add Search Text Pattern control to the parentDialog
		new SearchTextPatternControl(parentDialog, this).createControl();

		createSeparator(parentDialog);

		new SearchForControl(parentDialog, this).createControl();

		new LimitToControl(parentDialog, this).createControl();

		new FileTypeControl(parentDialog, this).createControl();
		setControl(parentDialog);

		Dialog.applyDialogFont(parentDialog);
		pageElements.loadSearchData();
	}

	/**
	 * creates an empty separator label
	 * 
	 * @param parentDialog
	 */
	private void createSeparator(final Composite parentDialog) {
		final Label separator = new Label(parentDialog, 0);
		separator.setVisible(true);
		final GridData data = new GridData(SWT.FILL, SWT.FILL, false, false, 2,
				1);
		data.heightHint = convertHeightInCharsToPixels(1) / 3;
		separator.setLayoutData(data);
	}

	/*
	 * Overrides method from IDialogPage to make public
	 */
	@Override
	public int convertWidthInCharsToPixels(final int chars) {
		return super.convertWidthInCharsToPixels(chars);
	}

	/*
	 * Overrides method from IDialogPage to make public
	 */
	@Override
	public int convertHeightInCharsToPixels(final int chars) {
		return super.convertHeightInCharsToPixels(chars);
	}

	@Override
	public boolean performAction() {
		LimitToType limitToType = LimitToType.get(pageElements
				.getLimitToSelection());
		SearchForType searchFor = SearchForType.get(pageElements
				.getSearchForSelection());
		SpecObjectSearchPageUtil util = new SpecObjectSearchPageUtil(this);
		SpecObjectSearchParams params = new SpecObjectSearchParams(
				pageElements.isCaseSensitiveFlag(),
				pageElements.isRegularExpressionSearch(), false, pageElements
						.getSearchPattern().getText(), limitToType, searchFor,
				getSearchPattern(), util.createSearchScope(pageElements
						.getPageContainer().getSelectedScope()));
		SpecObjectSearchQuery searchQuery = new SpecObjectSearchQuery(params);
		NewSearchUI.runQueryInBackground(searchQuery);
		return true;
	}

	@Override
	public void setContainer(final ISearchPageContainer container) {
		pageElements.setPageContainer(container);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.dialogs.DialogPage#dispose()
	 */
	@Override
	public void dispose() {
		pageElements.saveSearchData();
		super.dispose();
	}

	/**
	 * Initialize the search pattern combo value with selected text in the
	 * editor if any text selected
	 * 
	 * @return true when initialized with selected text else false
	 */
	private boolean initializeControlValues() {
		boolean isInitialized = false;
		final ISelection selection = pageElements.getPageContainer()
				.getSelection();
		ITextSelection textSelection = null;
		if (selection instanceof ITextSelection && !selection.isEmpty()) {
			textSelection = (ITextSelection) selection;
			final String text = textSelection.getText();
			if (text != null) {
				pageElements.getSearchPattern().setText(text);
				pageElements.getSearchPattern().select(0);
				pageElements.getExtensions().setText(META_CHAR_STAR);
				isInitialized = true;
			}
		}
		pageElements.getSearchPattern().setFocus();
		return isInitialized;
	}

	/*
	 * Implements method from IDialogPage
	 */
	@Override
	public void setVisible(final boolean visible) {
		if (visible) {
			initializeControlValues();
			updateOKStatus();
		}
		super.setVisible(visible);
	}

	/**
	 * Gets the search pattern of the search string
	 * 
	 * @return search pattern
	 */
	public Pattern getSearchPattern() {
		return PatternConstructor.createPattern(pageElements.getSearchPattern()
				.getText(), pageElements.isCaseSensitive(), pageElements
				.isRegExSearch(), false);
	}

	/**
	 * Updates the status of the search page according to the search validations
	 */
	public void updateOKStatus() {
		boolean regexStatus = true;
		boolean hasTextPattern = false;
		final String searchPattern = pageElements.getSearchPattern().getText();
		if (searchPattern != null && !searchPattern.trim().isEmpty()) {
			hasTextPattern = true;
			regexStatus = validateRegex(pageElements.getSearchPattern()
					.getText());
		}
		final boolean hasFilePattern = pageElements.getExtensions() != null
				&& pageElements.getExtensions().getText().length() > 0;
		pageElements.getPageContainer().setPerformActionEnabled(
				regexStatus && hasFilePattern && hasTextPattern);
	}

	/**
	 * Validates the given string is a regular expression or not if the check
	 * box regular expression is checked
	 * 
	 * @param patternText
	 *            the string to check
	 * @return return true if the given string is a valid regular expression
	 *         else false
	 */
	private boolean validateRegex(final String patternText) {
		if (pageElements.isRegularExpressionSearch()) {
			try {

				PatternConstructor.createPattern(patternText,
						pageElements.isCaseSensitive(),
						pageElements.isRegularExpressionSearch(), false);
			} catch (final PatternSyntaxException e) {

				setStatusMessage(true, MSG_INVALID_REGEXP);
				return false;
			}
			setStatusMessage(false, "");
		} else {
			setStatusMessage(false, SEARCH_TEXT_HINT);
		}
		return true;
	}

	/**
	 * Sets the search string status message
	 * 
	 * @param error
	 *            true when set an error status else false
	 * @param message
	 *            message
	 */
	private void setStatusMessage(final boolean error, final String message) {
		Label statusLabel = pageElements.getStatusLabel();
		statusLabel.setText(message);
		if (error) {
			statusLabel.setForeground(JFaceColors.getErrorText(statusLabel
					.getDisplay()));
		} else {
			statusLabel.setForeground(null);
		}
	}
}
