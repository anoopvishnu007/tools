/**
 * 
 */
package eb.ret.ui.search.result.view;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.viewers.DelegatingStyledCellLabelProvider.IStyledLabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StyledString;
import org.eclipse.jface.viewers.StyledString.Styler;
import org.eclipse.osgi.util.TextProcessor;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.AbstractTextSearchViewPage;
import org.eclipse.search.ui.text.Match;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import java.util.Arrays;
import java.util.Comparator;

/**
 * @author anoopvn
 * 
 */
public class FileLabelProvider extends LabelProvider implements
		IStyledLabelProvider {

	/**
	 * match high light background color name
	 */
	private static final String BG_COLOR_NAME = "org.eclipse.search.ui.match.highlight";
	/**
	 * Styler for label
	 */
	public static final Styler HIGHLIGHT_STYLE = StyledString
			.createColorRegistryStyler(null, BG_COLOR_NAME);

	/**
	 * label provider object
	 */
	private final WorkbenchLabelProvider labelProvider;
	/**
	 * Text search view page
	 */
	private final AbstractTextSearchViewPage specObjSearchPage;
	/**
	 * comparator class object for label
	 */
	private final Comparator<Object> matchComparator;
	/**
	 * Line match image
	 */
	private final Image lineMatchImage;

	/**
	 * /** Constructor
	 * 
	 * @param page
	 *            search view page
	 * @param orderFlag
	 *            order
	 */
	public FileLabelProvider(final AbstractTextSearchViewPage page) {
		super();
		labelProvider = new WorkbenchLabelProvider();

		specObjSearchPage = page;
		lineMatchImage = null;
		matchComparator = new Comparator<Object>() {
			@Override
			public int compare(final Object obj1, final Object obj2) {
				return ((SpecObjectFileMatch) obj1).getOriginalOffset()
						- ((SpecObjectFileMatch) obj2).getOriginalOffset();
			}
		};
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.viewers.LabelProvider#getText(java.lang.Object)
	 */
	@Override
	public String getText(final Object object) {
		return getStyledText(object).getString();
	}

	@Override
	public StyledString getStyledText(final Object element) {
		if (element instanceof SpecObjectFileMatch) {
			return getLineElementLabel((SpecObjectFileMatch) element);
		}

		if (!(element instanceof IResource)) {
			return new StyledString();
		}

		final IResource resource = (IResource) element;
		if (!resource.exists()) {
			new StyledString("");
		}

		final String name = getResourceName(resource);
		return getColoredLabelWithCounts(resource, new StyledString(name));

	}

	/**
	 * Gets the line element label string
	 * 
	 * @param specObjectMatch
	 *            the line element
	 * @return styled label string
	 */
	private StyledString getLineElementLabel(
			final SpecObjectFileMatch specObjectMatch) {
		final int lineNumber = specObjectMatch.getLine();
		final String lineNumberString = Integer.valueOf(lineNumber) + " :";

		final StyledString str = new StyledString(lineNumberString,
				StyledString.QUALIFIER_STYLER);

		final Match[] matches = specObjectMatch.getMatches(specObjSearchPage
				.getInput());
		Arrays.sort(matches, matchComparator);

		final String content = specObjectMatch.getContents();

		int lineStartPosition = getLineStart(matches, content,
				specObjectMatch.getOffset());

		for (int i = 0; i < matches.length; i++) {
			final SpecObjectFileMatch match = (SpecObjectFileMatch) matches[i];
			final int start = match.getOriginalOffset()
					- match.getLineStartOffset() - match.getOriginalLength();

			if (lineStartPosition < start) {
				str.append(content.substring(lineStartPosition, start));
			}
			final int end = start + match.getOriginalLength();
			str.append(content.substring(start, end), HIGHLIGHT_STYLE);
			lineStartPosition = end;
		}
		return str.append(content.substring(lineStartPosition));
	}

	/**
	 * Evaluates the line start position of match
	 * 
	 * @param matches
	 *            array of matches
	 * @param lineContent
	 *            line content
	 * @param lineOffset
	 *            line offset
	 * @return line start position
	 */
	private int getLineStart(final Match[] matches, final String lineContent,
			final int lineOffset) {
		int max = lineContent.length();
		if (matches.length > 0) {
			final SpecObjectFileMatch match = (SpecObjectFileMatch) matches[0];
			max = match.getOriginalOffset() - lineOffset;
			if (max < 0) {
				return 0;
			}
		}
		for (int i = 0; i < max; i++) {
			final char chr = lineContent.charAt(i);
			if (!Character.isWhitespace(chr) || chr == '\n' || chr == '\r') {
				return i;
			}
		}
		return max;
	}

	/**
	 * Gets the colored label with match counts
	 * 
	 * @param element
	 *            the element to get the match count for *
	 * @param coloredName
	 *            styled label string
	 * @return styled label string
	 */
	private StyledString getColoredLabelWithCounts(final Object element,
			final StyledString coloredName) {
		final AbstractTextSearchResult result = specObjSearchPage.getInput();
		if (result == null) {
			return coloredName;
		}

		final int matchCount = result.getMatchCount(element);
		if (matchCount <= 1) {
			return coloredName;
		}

		final String countInfo = "(" + Integer.valueOf(matchCount)
				+ ") matches";
		coloredName.append(' ').append(countInfo, StyledString.COUNTER_STYLER);
		return coloredName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.viewers.LabelProvider#getImage(java.lang.Object)
	 */
	@Override
	public Image getImage(final Object element) {
		if (element instanceof SpecObjectFileMatch) {
			return lineMatchImage;
		}
		if (!(element instanceof IResource)) {
			return null;
		}

		final IResource resource = (IResource) element;
		return labelProvider.getImage(resource);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.viewers.BaseLabelProvider#dispose()
	 */
	@Override
	public void dispose() {
		super.dispose();
		labelProvider.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.eclipse.jface.viewers.BaseLabelProvider#isLabelProperty(java.lang
	 * .Object, java.lang.String)
	 */
	@Override
	public boolean isLabelProperty(final Object element, final String property) {
		return labelProvider.isLabelProperty(element, property);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.eclipse.jface.viewers.BaseLabelProvider#removeListener(org.eclipse
	 * .jface.viewers.ILabelProviderListener)
	 */
	@Override
	public void removeListener(final ILabelProviderListener listener) {
		super.removeListener(listener);
		labelProvider.removeListener(listener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.eclipse.jface.viewers.BaseLabelProvider#addListener(org.eclipse.jface
	 * .viewers.ILabelProviderListener)
	 */
	@Override
	public void addListener(final ILabelProviderListener listener) {
		super.addListener(listener);
		labelProvider.addListener(listener);
	}

	/**
	 * Adds special marks so that that the given string is readable in a BIDI
	 * environment.
	 * 
	 * @param string
	 *            the string
	 * @param delimiters
	 *            the additional delimiters
	 * @return the processed styled string
	 */
	private static String processPathString(final String string,
			final String delimiters) {
		return TextProcessor.process(string, delimiters);
	}

	/**
	 * Returns the label of a path.
	 * 
	 * @param path
	 *            the path
	 * @param isOSPath
	 *            if true, the path represents an OS path, if false it is a
	 *            workspace path.
	 * @return the label of the path to be used in the UI.
	 */
	public static String getPathLabel(final IPath path, final boolean isOSPath) {
		String label;
		if (isOSPath) {
			label = path.toOSString();
		} else {
			label = path.makeRelative().toString();
		}
		return processPathString(label, "/\\:.");
	}

	/**
	 * Returns a label for a resource name.
	 * 
	 * @param resource
	 *            the resource
	 * @return the label of the resource name.
	 */
	public static String getResourceName(final IResource resource) {
		return processPathString(resource.getName(), ":.");
	}
}
