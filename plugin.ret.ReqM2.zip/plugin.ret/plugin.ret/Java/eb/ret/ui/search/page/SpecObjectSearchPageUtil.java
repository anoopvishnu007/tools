package eb.ret.ui.search.page;

import eb.ret.ui.search.result.view.SpecObjectFileMatch;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.search.ui.ISearchPageContainer;
import org.eclipse.search.ui.text.FileTextSearchScope;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IWorkingSet;

import java.util.ArrayList;
import java.util.List;

/**
 * This class contains utility methods for specobject search page
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchPageUtil {

	/**
	 * Dialog store page
	 */
	public static final String PAGE_NAME = "RETSearchPage";
	/**
	 * Dialog store constant to store case sensitive check value
	 */
	public static final String STORE_CASE_SENS = "CASE_SENSITIVE";
	/**
	 * Dialog store constant to store regular expression check value
	 */
	public static final String STORE_REGEXSEARCH = "REG_EX_SEARCH";
	/**
	 * Dialog store constant to store searchFor value
	 */
	private static final String STORE_SEARCHFOR = "SEARCH_FOR_VAL";
	/**
	 * Dialog store constant to store limitTo value
	 */
	private static final String STORE_LIMITTO = "LIMIT_TO_VAL";
	/**
	 * Dialog store constant to maintain history
	 */
	public static final String STORE_HISTORY = "HISTORY";
	/**
	 * Dialog store constant to maintain history size
	 */
	public static final String STORE_HIST_SIZE = "HISTORY_SIZE";
	/**
	 * History size value for extension storage
	 */
	public static final int STORE_EXTN_SIZE = 12;
	/**
	 * Section name for the stored file extensions.
	 * 
	 */
	private static final String STORE_EXTENSIONS = "EXTENSIONS";
	/**
	 * Search dialog page
	 */
	private final SpecObjectSearchDialogPage searchDialog;
	/**
	 * Search dialog page elements
	 */
	public SpecObjectSearchPageElements pageElements;

	/**
	 * Constructor
	 * 
	 * @param searchDialog
	 */
	public SpecObjectSearchPageUtil(
			final SpecObjectSearchDialogPage searchDialog) {
		this.searchDialog = searchDialog;
		pageElements = searchDialog.getPageElements();
	}

	/**
	 * Created a file text search scope according to the given integer value
	 * 
	 * @param scope
	 *            selected scope value
	 * @return an object of FileTextSearchScope
	 */
	public FileTextSearchScope createSearchScope(final int scope) {
		switch (scope) {

		case ISearchPageContainer.SELECTION_SCOPE:
			return getSelectedResourcesScope();
		case ISearchPageContainer.SELECTED_PROJECTS_SCOPE:
			return getEnclosingProjectScope();
		case ISearchPageContainer.WORKING_SET_SCOPE:
			return getWorkingSetScope();
		default:
			return FileTextSearchScope.newWorkspaceScope(
					pageElements.getExtensionStrings(), false);
		}
	}

	private FileTextSearchScope getWorkingSetScope() {
		final IWorkingSet[] workingSets = pageElements.getPageContainer()
				.getSelectedWorkingSets();
		return FileTextSearchScope.newSearchScope(workingSets,
				pageElements.getExtensionStrings(), false);
	}

	/**
	 * gets the selected resources scope
	 * 
	 * @return the selected resources scope
	 */
	public FileTextSearchScope getSelectedResourcesScope() {

		final List<IResource> resources = new ArrayList<IResource>();
		ISearchPageContainer container = pageElements.getPageContainer();
		final ISelection sel = container.getSelection();
		if (sel instanceof IStructuredSelection && !sel.isEmpty()) {
			IStructuredSelection structerdSel = ((IStructuredSelection) sel);
			for (Object selection : structerdSel.toArray()) {
				addResourcesInScope(resources, selection);
			}
		} else if (container.getActiveEditorInput() != null) {
			resources.add(((IFileEditorInput) container.getActiveEditorInput())
					.getFile());
		}
		final IResource[] resourceArray = resources
				.toArray(new IResource[resources.size()]);
		return FileTextSearchScope.newSearchScope(resourceArray,
				pageElements.getExtensionStrings(), false);
	}

	/**
	 * Adds the resources in the selected scope to the passed set
	 * 
	 * @param resources
	 *            object of resources set
	 * @param scope
	 *            selected scope
	 */
	private void addResourcesInScope(final List<IResource> resources,
			final Object scope) {
		if (scope instanceof IWorkingSet) {
			final IWorkingSet workingSet = (IWorkingSet) scope;
			addWorkingSetResources(resources, workingSet);
		} else if (scope instanceof SpecObjectFileMatch) {
			final IResource resource = ((SpecObjectFileMatch) scope)
					.getParent();
			if (resource != null && resource.isAccessible()) {
				resources.add(resource);
			}
		} else if (scope instanceof IAdaptable) {
			final IResource resource = (IResource) ((IAdaptable) scope)
					.getAdapter(IResource.class);
			if (resource != null && resource.isAccessible()) {
				resources.add(resource);
			}
		}
	}

	/**
	 * Adds the resources in the selected working set to the passed set
	 * 
	 * @param resources
	 *            object of resources set
	 * @param workingSet
	 */
	private void addWorkingSetResources(final List<IResource> resources,
			final IWorkingSet workingSet) {
		if (!workingSet.isAggregateWorkingSet() && !workingSet.isEmpty()) {

			final IAdaptable[] elements = workingSet.getElements();
			for (IAdaptable element : elements) {
				final IResource resource = (IResource) element
						.getAdapter(IResource.class);
				if (resource != null && resource.isAccessible()) {
					resources.add(resource);
				}
			}
		}
	}

	/**
	 * Gets the enclosing project scope
	 * 
	 * @return the enclosing project scope
	 */
	public FileTextSearchScope getEnclosingProjectScope() {
		FileTextSearchScope scope = null;
		final String[] enclosedProjectNames = pageElements.getPageContainer()
				.getSelectedProjectNames();
		if (enclosedProjectNames == null) {
			scope = FileTextSearchScope.newWorkspaceScope(
					pageElements.getExtensionStrings(), false);
		} else {
			List<IResource> projectList = new ArrayList<IResource>();

			final IWorkspaceRoot root = ResourcesPlugin.getWorkspace()
					.getRoot();
			for (String projectName : enclosedProjectNames) {
				IResource resource = root.getProject(projectName);
				projectList.add(resource);
			}
			IResource[] resources = projectList
					.toArray(new IResource[projectList.size()]);
			scope = FileTextSearchScope.newSearchScope(resources,
					pageElements.getExtensionStrings(), false);
		}
		return scope;
	}

}
