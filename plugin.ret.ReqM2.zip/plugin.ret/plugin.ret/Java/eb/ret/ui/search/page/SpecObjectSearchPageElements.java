package eb.ret.ui.search.page;

import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.plugin.RETPlugin;

import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.search.ui.ISearchPageContainer;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.fieldassist.ContentAssistCommandAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * This class holds the controls in the specobject search page
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchPageElements {

	/**
	 * integer value representing the limitTo selection. By default ALL has to
	 * be selected
	 */
	private int limitToSel = LimitToType.ALL.getValue();
	/**
	 * integer value representing the searchFor selection. By default ID has to
	 * be selected
	 */
	private int searchForSel = SearchForType.ID.getValue();
	/**
	 * search text pattern combo
	 */
	private Combo searchPattern;

	/**
	 * Limit to group control
	 */
	private Group limitToGroup;
	/**
	 * search page container object
	 */
	private ISearchPageContainer pageContainer;
	/**
	 * File extensions combo control
	 */
	private Combo extensions;
	/**
	 * Label for the search pattern control
	 */
	private Label statusLabel;
	/**
	 * Regular expression flag
	 */
	private boolean regExSearch;
	/**
	 * Case sensitive flag
	 */
	private boolean caseSensitiveFlag;
	/**
	 * Page is loading first time flag
	 */
	private boolean firstTime = true;
	/**
	 * search pattern content assist for regular expression search
	 */
	private ContentAssistCommandAdapter patternContAssist;
	/**
	 * case sensitive check box
	 */
	private Button caseSensitive;
	/**
	 * regular expression check box
	 */
	private Button regularExpression;
	/**
	 * File extension control
	 */
	private Combo fileTypeTextField;
	/**
	 * Browse button to select file extensions
	 */
	private Button fileTypeBrowseBut;
	/**
	 * Dialog store page
	 */
	public static final String PAGE_NAME = "RETSearchPage";
	/**
	 * Dialog store constant to store case sensitive check value
	 */
	public static final String STORE_CASE_SENS = "CASE_SENSITIVE";
	/**
	 * Dialog store constant to store regular expression check value
	 */
	public static final String STORE_REGEXSEARCH = "REG_EX_SEARCH";
	/**
	 * Dialog store constant to store searchFor value
	 */
	private static final String STORE_SEARCHFOR = "SEARCH_FOR_VAL";
	/**
	 * Dialog store constant to store limitTo value
	 */
	private static final String STORE_LIMITTO = "LIMIT_TO_VAL";
	/**
	 * Search pattern scope constant
	 */
	private static final String SEARCH_SCOPE = "scope";
	/**
	 * Search pattern file extensions constant
	 */
	private static final String FILE_PATTERNS = "fileNamePatterns";
	/**
	 * Search pattern text constant
	 */
	private static final String TEXT_PATTERN = "textPattern";

	/**
	 * File extensions separator string
	 */
	private static final String TYPE_DELIMITER = ",";
	private static final String SEARCH_DATA_COUNT = null;
	private final List<SearchDialogData> searchDialogDataList = new ArrayList<SearchDialogData>();
	private final List<String> searchExtnList = new ArrayList<String>();

	/**
	 * gets the search pattern combo control
	 * 
	 * @return search pattern combo control
	 */
	public Combo getSearchPattern() {
		return searchPattern;
	}

	/**
	 * Sets the search pattern combo control
	 * 
	 * @param searchPattern
	 *            search pattern combo control
	 */
	public void setSearchPattern(final Combo searchPattern) {
		this.searchPattern = searchPattern;
	}

	/**
	 * 
	 * @return the limitTo selection in the pageElements
	 */
	public int getLimitToSelection() {
		return limitToSel;
	}

	/**
	 * sets the limitTo selection from the user
	 * 
	 * @param limitToSelection
	 */
	public void setLimitToSelection(final int limitToSelection) {
		this.limitToSel = limitToSelection;
	}

	/**
	 * 
	 * @return the searchFor selection in the pageElements
	 */
	public int getSearchForSelection() {
		return searchForSel;
	}

	/**
	 * sets the searchFor selection from the user
	 * 
	 * @param limitToSelection
	 */
	public void setSearchForSelection(final int searchForSel) {
		this.searchForSel = searchForSel;
	}

	/**
	 * Gets the limit to group
	 * 
	 * @return
	 */
	public Group getLimitToGroup() {
		return limitToGroup;
	}

	/**
	 * Sets the limit to group
	 * 
	 * @param limitToGroup
	 */
	public void setLimitToGroup(final Group limitToGroup) {
		this.limitToGroup = limitToGroup;
	}

	/**
	 * Gets the page container
	 * 
	 * @return
	 */
	public ISearchPageContainer getPageContainer() {
		return pageContainer;
	}

	/**
	 * Sets the page container
	 * 
	 * @param pageContainer
	 */
	public void setPageContainer(final ISearchPageContainer pageContainer) {
		this.pageContainer = pageContainer;
	}

	/**
	 * Gets the file type extensions
	 * 
	 * @return
	 */
	public String[] getExtensionStrings() {
		String extensions = getExtensions().getText();
		String[] extns = new String[0];
		if (extensions.contains(TYPE_DELIMITER)) {
			extns = extensions.split(TYPE_DELIMITER);
		} else {
			extns = new String[] { extensions };
		}
		return extns;
	}

	/**
	 * Gets the extension combo control
	 * 
	 * @return
	 */
	public Combo getExtensions() {
		return extensions;
	}

	/**
	 * Sets the file type extensions
	 * 
	 * @param extensions
	 */
	public void setExtensions(final Combo extensions) {
		this.extensions = extensions;
	}

	/**
	 * gets the status label
	 * 
	 * @return
	 */
	public Label getStatusLabel() {
		return statusLabel;
	}

	/**
	 * Sets the status label
	 * 
	 * @param statusLabel
	 */
	public void setStatusLabel(final Label statusLabel) {
		this.statusLabel = statusLabel;
	}

	/**
	 * Gets the case sensitive flag
	 * 
	 * @return
	 */
	public boolean isCaseSensitive() {
		return caseSensitiveFlag;
	}

	/**
	 * Gets the regular expression flag
	 * 
	 * @return
	 */
	public boolean isRegularExpressionSearch() {
		return regExSearch;
	}

	/**
	 * Sets the regular expression search flag
	 * 
	 * @param isRegularExSearch
	 */
	public void setRegularExSearch(final boolean isRegularExSearch) {
		this.regExSearch = isRegularExSearch;
	}

	/**
	 * Gets the first time flag
	 * 
	 * @return
	 */
	public boolean isFirstTime() {
		return firstTime;
	}

	/**
	 * Sets the first time flag
	 * 
	 * @param firstTime
	 */
	public void setFirstTime(final boolean firstTime) {
		this.firstTime = firstTime;
	}

	/**
	 * Gets the case sensitive button
	 * 
	 * @return
	 */
	public Button getCaseSensitive() {
		return caseSensitive;
	}

	/**
	 * Sets the case sensitive button
	 * 
	 * @param caseSensitive
	 */
	public void setCaseSensitive(final Button caseSensitive) {
		this.caseSensitive = caseSensitive;
	}

	/**
	 * Gets the regular expression button
	 * 
	 * @return
	 */
	public Button getRegularExpression() {
		return regularExpression;
	}

	/**
	 * Sets the regular expression button
	 * 
	 * @param regularExpression
	 */
	public void setRegularExpression(final Button regularExpression) {
		this.regularExpression = regularExpression;
	}

	/**
	 * Returns the regular expression search value
	 * 
	 * @return
	 */
	public boolean isRegExSearch() {
		return getRegularExpression().getSelection();
	}

	/**
	 * Sets the regular expression search value
	 * 
	 * @param regExSearch
	 */
	public void setRegExSearch(final boolean regExSearch) {
		getRegularExpression().setSelection(regExSearch);
	}

	/**
	 * Returns the case sensitive flag value
	 * 
	 * @return
	 */
	public boolean isCaseSensitiveFlag() {
		return getCaseSensitive().getSelection();
	}

	/**
	 * Sets the case sensitive flag
	 * 
	 * @param caseSensitiveFlag
	 */
	public void setCaseSensitiveFlag(final boolean caseSensitiveFlag) {
		getCaseSensitive().setSelection(caseSensitiveFlag);
	}

	/**
	 * Returns the pattern content assist control
	 * 
	 * @return
	 */
	public ContentAssistCommandAdapter getPatternContAssist() {
		return patternContAssist;
	}

	/**
	 * Returns the page settings for this specobject search page.
	 * 
	 * @return the page settings to be used
	 */
	public IDialogSettings getDialogSettings() {
		return RETPlugin.getDefault().getDialogSettingsSection(PAGE_NAME);
	}

	/**
	 * Sets the pattern content assist control
	 * 
	 * @param patternContAssist
	 */
	public void setPatternContAssist(
			final ContentAssistCommandAdapter patternContAssist) {
		this.patternContAssist = patternContAssist;
	}

	public Combo getFileTypeTextField() {
		return fileTypeTextField;
	}

	public void setFileTypeTextField(Combo fileTypeTextField) {
		this.fileTypeTextField = fileTypeTextField;
	}

	public Button getFileTypeBrowseBut() {
		return fileTypeBrowseBut;
	}

	public void setFileTypeBrowseBut(Button fileTypeBrowseBut) {
		this.fileTypeBrowseBut = fileTypeBrowseBut;
	}

	public void loadSearchData() {
		final IDialogSettings settings = getDialogSettings();
		int searchDataCount = 0;
		try {
			searchDataCount = settings.getInt(SEARCH_DATA_COUNT);
			SearchDialogData dialogData = null;
			for (int i = 0; i < searchDataCount; i++) {
				IDialogSettings searchData = settings.getSection(TEXT_PATTERN
						+ searchDataCount);
				if (searchData != null) {
					dialogData = new SearchDialogData();
					final String textPattern = searchData.get(TEXT_PATTERN);
					if (textPattern != null) {
						dialogData.setSearchString(textPattern);
					}
					dialogData.setCaseSensitive(searchData
							.getBoolean(STORE_CASE_SENS));
					dialogData.setRegExSearch(searchData
							.getBoolean(STORE_REGEXSEARCH));
					if (searchData.get(STORE_LIMITTO) != null) {
						dialogData.setLimitToTypeValue(searchData
								.getInt(STORE_LIMITTO));
					}
					if (searchData.get(STORE_SEARCHFOR) != null) {

						dialogData.setSearchForValue(searchData
								.getInt(STORE_SEARCHFOR));
					}
					if (searchData.get(FILE_PATTERNS) != null) {
						dialogData.setFileExtnString(searchData
								.get(FILE_PATTERNS));

					}
					if (searchData.get(SEARCH_SCOPE) != null) {
						dialogData.setScope(searchData.getInt(SEARCH_SCOPE));
					}
					searchDialogDataList.add(dialogData);
				}
			}
			if (dialogData != null) {
				insertDialogDataToSearchPage(dialogData);
			}
		} catch (NumberFormatException ex) {
			if (searchDataCount != 0) {
				ErrorLogger.logError(ex.getMessage(), ex);
			}
		}

	}

	private void insertDialogDataToSearchPage(SearchDialogData dialogData) {
		getSearchPattern().setText(dialogData.getSearchString());
		setCaseSensitiveFlag(dialogData.isCaseSensitive());
		setRegExSearch(dialogData.isRegExSearch());
		setLimitToSelection(dialogData.getLimitToTypeValue());
		setSearchForSelection(dialogData.getSearchForValue());
		getExtensions().setText(dialogData.getFileExtnString());
		searchExtnList.add(dialogData.getFileExtnString());
		getPageContainer().setSelectedScope(dialogData.getScope());
	}

	public void saveSearchData() {
		final IDialogSettings settings = getDialogSettings();
		int searchDataCount = 0;
		try {
			if (settings.get(SEARCH_DATA_COUNT) != null) {
				searchDataCount = settings.getInt(SEARCH_DATA_COUNT);
			} else {
				searchDataCount++;
			}
			for (int i = 0; i < searchDataCount; i++) {
				IDialogSettings searchData = settings.getSection(TEXT_PATTERN
						+ searchDataCount);
				if (searchData == null) {
					searchData = settings.addNewSection(TEXT_PATTERN
							+ searchDataCount);
				}
				searchData.put(TEXT_PATTERN, getSearchPattern().getText());
				searchData.put(STORE_CASE_SENS, isCaseSensitiveFlag());
				searchData.put(STORE_REGEXSEARCH, isRegExSearch());
				searchData.put(STORE_LIMITTO, getLimitToSelection());
				searchData.put(STORE_SEARCHFOR, getSearchForSelection());
				searchData.put(FILE_PATTERNS, getExtensionStrings());
				searchData.put(SEARCH_SCOPE, getPageContainer()
						.getSelectedScope());
			}
			settings.put(SEARCH_DATA_COUNT, searchDataCount);
		} catch (NumberFormatException ex) {
			if (searchDataCount != 0) {
				ErrorLogger.logError(ex.getMessage(), ex);
			}
		}

	}

}
