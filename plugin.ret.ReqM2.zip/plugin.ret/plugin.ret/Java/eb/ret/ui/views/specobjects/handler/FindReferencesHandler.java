package eb.ret.ui.views.specobjects.handler;

import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.search.query.SpecObjectSearchQuery;
import eb.ret.ui.views.specobjects.SpecObjectsView;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.search.ui.NewSearchUI;
import org.eclipse.search.ui.text.FileTextSearchScope;
import org.eclipse.swt.widgets.TableItem;

/**
 * Handler class for finding the reference of a specobject id
 * 
 * @author nikhilcr
 * 
 */
public class FindReferencesHandler extends AbstractHandler {

	@Override
	public Object execute(final ExecutionEvent event) throws ExecutionException {
		final SpecObjectsView view = (SpecObjectsView) WorkspaceUtils
				.getViewPart(SpecObjectsView.class);
		final TableItem[] items = view.getViewer().getTable().getSelection();
		for (int i = 0; i < items.length; i++) {
			if (items[i] != null
					&& SpecobjectType.class.isAssignableFrom(items[i].getData()
							.getClass())) {
				searchQuery(items[i]);
			}
		}
		return null;
	}

	/**
	 * Creates a search query and does a search
	 * 
	 * @param item
	 */
	private void searchQuery(final TableItem item) {
		SpecObjectSearchParams params = new SpecObjectSearchParams(true, false,
				true, ((SpecobjectType) item.getData()).getId(),
				LimitToType.REFERENCES, SearchForType.ID, null,
				FileTextSearchScope.newWorkspaceScope(null, false));
		NewSearchUI.runQueryInBackground(new SpecObjectSearchQuery(params));
	}

}
