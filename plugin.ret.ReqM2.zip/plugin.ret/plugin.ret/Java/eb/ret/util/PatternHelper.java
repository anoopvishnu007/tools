package eb.ret.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.PatternSyntaxException;

/**
 * Helper class to create pattern using pattern constructor class
 * 
 * @author anoopvn
 * 
 */
public final class PatternHelper {

	/**
	 * Escape character
	 */
	private static final String ESCAPE_CHAR = "\\\\";

	/**
	 * List of characters to skip from any pattern substitution operation
	 */
	public static List<Character> characterList = new ArrayList<Character>();
	static {
		characterList.add('(');
		characterList.add(')');
		characterList.add('{');
		characterList.add('}');
		characterList.add('.');
		characterList.add('[');
		characterList.add(']');
		characterList.add('$');
		characterList.add('^');
		characterList.add('+');
		characterList.add('|');
	}

	/**
	 * Constructor
	 */
	private PatternHelper() {

	}

	/**
	 * Expression holder class represents the pattern text
	 * 
	 * @author anoopvn
	 * 
	 */
	private static class ExpressionHolder {

		public String findString;
		public int length;
		public final StringBuilder builder = new StringBuilder(length);

		public int inCharGroup = 0;
		public int inBraces = 0;
		public boolean inQuote = false;

		public ExpressionHolder(final String findString) {

			this.findString = findString;
			this.length = findString.length();

		}
	}

	/**
	 * Substitutes \R in a regex find pattern with (?>\r\n?|\n)
	 * 
	 * @param findString
	 *            the string to substitute
	 * @return the new string
	 * @throws PatternSyntaxException
	 *             if "\R" is at an illegal position
	 */
	public static String substituteLinebreak(final String findString)
			throws PatternSyntaxException {

		final ExpressionHolder stringHolder = new ExpressionHolder(findString);
		for (int i = 0; i < stringHolder.length; i++) {
			final char chr = stringHolder.findString.charAt(i);
			if (chr == '[' || chr == ']') {
				markGroupCharacter(stringHolder, chr);
			} else if (chr == '{' || chr == '}') {
				markBraceCharacter(stringHolder, chr);
			} else if (chr == '\\') {
				if (checkAndHandleEscapeChar(stringHolder, i)) {
					i++;
				}
			} else {
				stringHolder.builder.append(chr);
			}

		}
		return stringHolder.builder.toString();
	}

	/**
	 * Handles escape characters 'E','R','Q'
	 * 
	 * @param stringHolder
	 *            expression holder object
	 * @param index
	 *            character index
	 * @return true if changed else false
	 */
	private static boolean checkAndHandleEscapeChar(
			final ExpressionHolder stringHolder, final int index) {
		boolean changeFlag = false;
		final char chr = stringHolder.findString.charAt(index);

		if (index + 1 < stringHolder.length) {
			final char secondChar = stringHolder.findString.charAt(index + 1);
			if (secondChar == 'E' || secondChar == 'R' || secondChar == 'Q') {

				markEscapeCharacter(stringHolder, index);
				changeFlag = true;
			}
		} else {
			stringHolder.builder.append(chr);
		}
		return changeFlag;
	}

	/**
	 * Marks escape characters 'E','R','Q'
	 * 
	 * @param stringHolder
	 *            expression holder object
	 * @param index
	 *            character index
	 */
	private static void markEscapeCharacter(
			final ExpressionHolder stringHolder, final int index) {
		final char chr = stringHolder.findString.charAt(index);
		switch (chr) {
		case 'E':
			if (stringHolder.inQuote) {
				stringHolder.inQuote = false;
			}
			stringHolder.builder.append('\\').append(chr);
			break;
		case 'R':
			if (stringHolder.inCharGroup > 0 || stringHolder.inBraces > 0) {
				final String msg = "Illegal position for \\R";
				throw new PatternSyntaxException(msg, stringHolder.findString,
						index);
			}
			stringHolder.builder.append("(?>\\r\\n?|\\n)");
			break;
		case 'Q':
			stringHolder.inQuote = true;
			stringHolder.builder.append('\\').append(chr);
			break;

		default:
			break;
		}
	}

	/**
	 * Marks the brace characters '{','}'
	 * 
	 * @param stringHolder
	 *            expression holder object
	 * @param chr
	 *            the character
	 */
	private static void markBraceCharacter(final ExpressionHolder stringHolder,
			final char chr) {
		switch (chr) {
		case '{':
			stringHolder.builder.append(chr);
			if (!stringHolder.inQuote && stringHolder.inCharGroup == 0) {
				stringHolder.inBraces++;
			}
			break;

		case '}':
			stringHolder.builder.append(chr);
			if (!stringHolder.inQuote && stringHolder.inCharGroup == 0) {
				stringHolder.inBraces--;
			}
			break;
		default:
			break;
		}

	}

	/**
	 * Mark group characters '[',']'
	 * 
	 * @param stringHolder
	 *            expression holder object
	 * @param chr
	 *            the character
	 */
	private static void markGroupCharacter(final ExpressionHolder stringHolder,
			final char chr) {
		switch (chr) {

		case '[':
			stringHolder.builder.append(chr);
			if (!stringHolder.inQuote) {
				stringHolder.inCharGroup++;
			}
			break;

		case ']':
			stringHolder.builder.append(chr);
			if (!stringHolder.inQuote) {
				stringHolder.inCharGroup--;
			}
			break;

		default:
			break;
		}

	}

	/**
	 * inserts the regular expression conditions to the pattern
	 * 
	 * @param pattern
	 *            pattern string
	 * @param buffer
	 *            string buffer
	 * @return
	 */
	public static StringBuffer appendAsRegEx(final String pattern,
			final StringBuffer buffer) {
		boolean isEscaped = false;
		for (int i = 0; i < pattern.length(); i++) {
			final char chr = pattern.charAt(i);

			if (chr == '\\') {
				isEscaped = true;
			} else if (characterList.contains(Character.valueOf(chr))) {
				isEscaped = appendEscape(buffer, isEscaped);
				buffer.append('\\');
				buffer.append(chr);
			} else if (chr == '?' || chr == '*') {
				if (isEscaped) {
					buffer.append('\\');
					buffer.append(chr);
					isEscaped = false;

				} else {
					buffer.append(chr == '?' ? '.' : ".*");
				}
			} else {
				isEscaped = appendEscape(buffer, isEscaped);
				buffer.append(chr);
			}

		}
		isEscaped = appendEscape(buffer, isEscaped);
		return buffer;
	}

	/**
	 * Appends escape characters to the buffer
	 * 
	 * @param buffer
	 *            the string buffer
	 * @param isEscaped
	 *            true for appending the escape character else false
	 * @return if escaped return false else true
	 */
	private static boolean appendEscape(final StringBuffer buffer,
			final boolean isEscaped) {
		boolean flag = isEscaped;
		if (flag) {
			buffer.append(ESCAPE_CHAR);
			flag = false;
		}
		return flag;
	}

	/**
	 * Escapes the meta characters(*,?) in the given string
	 * 
	 * @param patternText
	 *            string to escape
	 * @return meta character escaped string
	 */
	public static String escapeMetaCharacters(final String patternText) {
		String content = patternText;
		if (content != null && content.contains("*") || content.contains("?")) {
			content = content.replaceAll("[\\?]", "\\\\?");
			content = content.replaceAll("[\\*]", "\\\\*");
		}
		return content;
	}
}
