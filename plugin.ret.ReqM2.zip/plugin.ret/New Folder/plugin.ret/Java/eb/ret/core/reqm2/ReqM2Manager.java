package eb.ret.core.reqm2;

import static eb.ret.core.reqm2.processor.ReqM2Executor.REQM_EXTN;

import eb.ret.core.reqm2.data.IRETData;
import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.core.reqm2.processor.ReqM2Executor;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;

import java.io.File;
import java.util.List;

/**
 * This class manages the execution of ReqM2 tool.
 * 
 * @author Kiren SK
 * 
 */
public final class ReqM2Manager {
    /**
     * Constant for reqm2 importer output folder
     */
    public static final String REQM2_DIR = "reqm2Output";

    /**
     * Private instance for the singleton class
     */
    private static ReqM2Manager manager;
    /**
     * Error to be displayed for exception from cleanup process.
     */
    private static final String ERR_CLEANUP = "Error while performing clean up on ";
    /**
     * Error to be displayed for exception from folder creation.
     */
    private static final String ERR_FOLD_CREATE = "Error While creating ReqM2 Output folder";

    /**
     * private constructor declaring ReqM2Manager as singleton.
     */
    private ReqM2Manager() {

    }

    /**
     * To get access to instance of ReqM2Manager.
     * 
     * @return ReqM2Manager singleton instance.
     */
    public static ReqM2Manager getInstance() {

        synchronized (ReqM2Manager.class) {
            if( manager == null ) {
                manager = new ReqM2Manager();
            }
        }
        return manager;
    }

    /*
     * !LINKSTO eclipse.ret.req.InputFileAddedInDirectory,1, !
     * eclipse.ret.req.InputFileRenamed,1
     */
    /**
     * Determines the importer.Invokes the output folder creation. Invokes the actual Executor module
     * 
     * @param file
     */
    public void processReqM2File( final IFile file ) {

        final String inputPath = file.getLocation().toOSString();

        ReqM2Executor.executeReqM2FileImporter( file.getName(),
                                                inputPath,
                                                createOutputDirectory( file ),
                                                getInputDirectory( file ) );

    }

    private RETDirectory getInputDirectory( final IResource iResource ) {
        RETDirectory directory = null;
        IResource folder = iResource;
        if( folder.getType() == IResource.FILE ) {
            folder = iResource.getParent();
        }
        if( folder != null && folder.getRawLocation() != null ) {
            final IPath dirPath = folder.getProjectRelativePath();
            final IRETData inputData = ReqM2InputData.getRETData();
            final List<RETDirectory> dirList = inputData.getRETInputDirectories( folder.getProject() );

            for( final RETDirectory retDirectory : dirList ) {
                final IPath retPath = WorkspaceUtils.getIPath( retDirectory.getPath() );
                if( retPath.isPrefixOf( dirPath ) ) {
                    directory = retDirectory;
                    break;
                }
            }
        }

        return directory;
    }

    /*
     * !LINKSTO eclipse.ret.req.InputFileRemoved,1
     */
    /**
     * Removes the REQM2 files for the corresponding IFile. Deletes the folders recursively till the Derived Path or
     * there are other files present.
     * 
     * @param file
     */
    public void removeReqM2File( final IFile file ) {

        String path = getOutputFilePath( file );
        path = ReqM2Executor.getOutputFileName( path );
        File fileRemoved = new File( path );
        File parentRemoveFile = fileRemoved.getParentFile();
        String derivedPath = null;
        final IPath derPath = getDerivedDirectoryPath( file );
        if( derPath == null ) {
            derivedPath = file.getProject().getLocation().toOSString();
        } else {
            derivedPath = WorkspaceUtils.getLocation( derPath );
        }
        do {
            parentRemoveFile = fileRemoved.getParentFile();
            fileRemoved.setWritable( true );
            fileRemoved.setExecutable( true );
            fileRemoved.delete();

            fileRemoved = parentRemoveFile;
            if( (parentRemoveFile == null)
                || (parentRemoveFile.listFiles() != null && parentRemoveFile.listFiles().length != 0) ) {
                break;
            }
        } while (!derivedPath.equals( parentRemoveFile.getPath() ));

    }

    /*
     * !LINKSTO eclipse.ret.req.RemoveInputDirectory,1, !
     * eclipse.ret.req.InputDirectoryRemoved,1
     */
    /**
     * handling removal of IFolders. Recursively calls the sub folders and invokes child Files for removal.
     * 
     * @param folder
     */
    public void removeReqM2Directory( final IFolder folder ) {
        try {
            if( folder.exists() ) {
                final IResource[] childResources = folder.members();
                for( final IResource childResource : childResources ) {
                    if( childResource.getType() == IResource.FILE ) {
                        removeReqM2File( (IFile)childResource );
                    } else if( childResource.getType() == IResource.FOLDER ) {
                        removeReqM2Directory( (IFolder)childResource );
                    }
                }

            }
        } catch( final Exception e ) {
            ErrorLogger.logError( "Error while removing directory ", e );
        }
        refreshReqM2OutputFolder( folder.getProject() );
    }

    /**
     * Deletes all the folders and files with in the reqm2output folder of the corresponding project
     * 
     * @param project
     */
    public void clearReqM2Output( final IProject project, final IProgressMonitor monitor ) {
        try {
            final IFolder reqmOutFolder = getReqM2ImpOutputFolder( project );
            final IResource[] childElems = reqmOutFolder.members();
            for( final IResource child : childElems ) {
                child.delete( IResource.FORCE, monitor );
            }
        } catch( final CoreException e ) {
            ErrorLogger.logError( ERR_CLEANUP + project.getName(), e );
        }
    }

    /*
     * !LINKSTO eclipse.ret.req.InputFiles,1, !
     * eclipse.ret.req.InnerDirectories,1
     */
    /**
     * Verifies given IResource is a element of input directories If the resource is of a file its directory is taken to
     * verify.
     * 
     * @param iResource
     * @return boolean indicating the presence of file in input directory list.
     */
    public boolean isRETDirectory( final IResource iResource ) {
        boolean isRET = false;
        IResource folder = iResource;
        if( folder.getType() == IResource.FILE ) {
            folder = iResource.getParent();
        }
        if( folder != null && folder.getRawLocation() != null ) {
            final IPath dirPath = folder.getProjectRelativePath();
            final IRETData inputData = ReqM2InputData.getRETData();
            final List<String> dirList = inputData.getDirectoriesPath( folder.getProject() );

            for( final String retDirectory : dirList ) {
                final IPath retPath = WorkspaceUtils.getIPath( retDirectory );
                if( retPath.isPrefixOf( dirPath ) ) {
                    isRET = true;
                    break;
                }
            }
        }

        return isRET;
    }

    /**
     * Checks if the iResource comes under any of the dir's sub folders
     * 
     * @param dir the RET input directory
     * @param iResource the resource to be checked for
     * @return true if the resource comes under any of the dir's sub folders, else false
     */
    public boolean isSubdirectory( final RETDirectory dir, final IResource iResource ) {
        IResource folder = iResource;
        if( folder.getType() == IResource.FILE ) {
            folder = iResource.getParent();
        }
        if( folder != null && folder.getRawLocation() != null ) {
            final IPath subFolderPath = folder.getProjectRelativePath();
            final IPath dirPath = WorkspaceUtils.getIPath( dir.getPath() );
            if( dirPath.isPrefixOf( subFolderPath ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * This creates the output Path based on default derived path, Creates that folder if it is not present.
     * 
     * @param resourceFile
     * @return the output path
     */
    private String createOutputDirectory( final IFile resourceFile ) {

        final String outpath = getOutputFilePath( resourceFile.getParent() );

        final File outputFolder = new File( outpath );
        if( !outputFolder.exists() ) {
            outputFolder.mkdirs();
        }
        return outpath;

    }

    /**
     * Get the default output location for a project.
     * 
     * @param resource
     * @return defaultOutputPath for a project or the root directory of the project.
     */
    private IPath getDerivedDirectoryPath( final IResource resource ) {
        IPath path = null;
        final IProject resProject = resource.getProject();

        if( resProject.isOpen() ) {
            final IJavaProject javaProject = JavaCore.create( resource.getProject() );

            try {
                if( javaProject.exists() ) {
                    path = javaProject.getOutputLocation();
                }
            } catch( final Exception e ) {
                ErrorLogger.logError( "Error while retrieving Default outputLocation ", e );

            }
        }

        return path;
    }

    /*
     * !LINKSTO eclipse.ret.req.ProjectSharing,1, !
     * eclipse.ret.req.ReqM2ImporterOutputVisibility,1, !
     * eclipse.ret.req.TextSearch,1, ! eclipse.ret.req.FileSearch,1, !
     * eclipse.ret.req.ProjectBasedOutputLocation,1, !
     * eclipse.ret.req.SwitchWorkspace,1
     */
    /**
     * This methods checks for reqM2output folder with in the default output location (project home for general project)
     * If folder is not there it creates a folder.
     * 
     * @param resourceFile
     * @return the ReqM2 output folder
     */
    public IFolder getReqM2ImpOutputFolder( final IResource resourceFile ) {
        final IPath classPath = getDerivedDirectoryPath( resourceFile );
        final IProject project = resourceFile.getProject();
        IFolder reqmFolder = null;
        if( classPath == null ) {
            reqmFolder = project.getFolder( REQM2_DIR );
        } else {
            final IFolder outputFolder = resourceFile.getWorkspace().getRoot().getFolder( classPath );
            reqmFolder = outputFolder.getFolder( REQM2_DIR );
        }

        if( !reqmFolder.exists() )

        {
            final IProgressMonitor progressMonitor = new NullProgressMonitor();
            try {
                reqmFolder.create( IResource.FORCE, true, new NullProgressMonitor() );
                reqmFolder.setDerived( true, progressMonitor );
                reqmFolder.setHidden( true );

            } catch( final CoreException e ) {
                ErrorLogger.logError( ERR_FOLD_CREATE, e );
            }
        }
        return reqmFolder;
    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2ImporterOutputDirectory,1
     */
    /**
     * Frame the output file path from the resource. The output folder will be with in the default output location
     * 
     * @param resourceFile
     * @return
     */
    private String getOutputFilePath( final IResource resourceFile ) {

        final StringBuilder pathBuilder = new StringBuilder( getReqM2ImpOutputFolder( resourceFile ).getLocation()
                                                                                                    .toOSString() );

        pathBuilder.append( File.separator );
        pathBuilder.append( resourceFile.getProjectRelativePath().toOSString() );
        return pathBuilder.toString();
    }

    /**
     * checks if the given file is with in the reqm2 output folder
     * 
     * @param file
     * @return boolean
     */
    public boolean isReqM2OutputFile( final IFile file ) {

        final IPath reqM2FolderPath = getReqM2ImpOutputFolder( file ).getFullPath();
        return (REQM_EXTN.equals( file.getFileExtension() ) && reqM2FolderPath.isPrefixOf( file.getFullPath() ));

    }

    /**
     * refresh the reqm output folder for the given project. The refresh is done in a separate thread
     * 
     * @param project
     */
    public void refreshReqM2OutputFolder( final IProject project ) {
        if( !ReqM2Manager.getInstance().getReqM2ImpOutputFolder( project ).isSynchronized( IResource.DEPTH_INFINITE ) ) {
            final Job refreshJob = new Job( "refreshjob" ) {
                @Override
                protected IStatus run( final IProgressMonitor monitor ) {

                    try {
                        ReqM2Manager.getInstance()
                                    .getReqM2ImpOutputFolder( project )
                                    .refreshLocal( IResource.DEPTH_INFINITE, monitor );
                    } catch( final CoreException e ) {
                        ErrorLogger.logError( "Error in refreshing ReqM outputfolder ", e );
                    }

                    return Status.OK_STATUS;
                }
            };
            refreshJob.schedule();
        }
    }
}