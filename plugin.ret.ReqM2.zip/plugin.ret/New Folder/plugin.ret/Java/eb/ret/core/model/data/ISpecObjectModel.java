package eb.ret.core.model.data;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.transaction.ResourceSetListener;

/**
 * Interface to handle the creation and modification of specobject model.
 * 
 * @author tintobaby
 * 
 */
public interface ISpecObjectModel {

    /**
     * To get the ResourceSet object holds the Resources corresponding to the .reqm files.
     * 
     * @return ResourceSet
     */
    public ResourceSet getSpecObjectResourceSet();

    /**
     * load and update the resource corresponding to the given URI.
     * 
     * @param reqmURI Platform URI for the .reqm file.
     * 
     */
    public void loadSpecObjectResource( URI reqmURI );

    /**
     * Remove the specobject resource from the resource set.
     * 
     * @param reqmURI
     */
    public void removeSpecObjectResource( URI reqmURI );

    /**
     * To add the ResourceSetListener to the editing domain.
     * 
     * @param listener.
     */
    public void addResourceChangeListener( ResourceSetListener listener );

}
