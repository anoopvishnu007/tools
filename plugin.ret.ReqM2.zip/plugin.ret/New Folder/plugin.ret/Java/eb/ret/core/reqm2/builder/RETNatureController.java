package eb.ret.core.reqm2.builder;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.runtime.CoreException;

/**
 * @author Kiren SK
 * @version 1.0
 * @created 17-Aug-2012 2:34:17 PM
 * 
 *          This class acts as a controlled for RETNature. Used for activating and deactivating the RETNature.
 * 
 */
public final class RETNatureController {

    /**
     * EMF query2 index nature id
     */
    private static final String INDEX_NATURE_ID = "org.eclipse.emf.query2.index.ui.queryIndexNature";

    /**
     * Default constructor for RETNatureController
     */
    private RETNatureController() {

    }

    /**
     * This function is invoked when RET Nature for a specific Project in the workspace is activated. RET Nature should
     * enable RET Build.
     * 
     * @param project
     * @throws CoreException
     */
    public static void activateRETNature( final IProject project ) throws CoreException {

        if( isRETProject( project ) ) {
            return;
        }
        activateNature( project, RETNature.NATURE_ID );
        activateNature( project, INDEX_NATURE_ID );

    }
    /**
     * Activates a nature for a project
     * 
     * @param project the project
     * @param natureId nature id of the nature to be activated
     * @throws CoreException
     */
    private static void activateNature(final IProject project,final String natureId) throws CoreException{
        final IProjectDescription description = project.getDescription();
        final String[] natures = description.getNatureIds();

        // Add the nature
        final String[] newNatures = new String[natures.length + 1];
        System.arraycopy( natures, 0, newNatures, 0, natures.length );
        newNatures[natures.length] =natureId ;
        description.setNatureIds( newNatures );
        project.setDescription( description, null );
    }
    /**
     * This function is invoked when RET Nature for a specific Project in the workspace is deactivated. RET Nature
     * should disable RET Build.
     * 
     * @param project
     * @throws CoreException
     */
    public static void deactivateRETNature( final IProject project ) throws CoreException {
        deactivateNature(project, RETNature.NATURE_ID);
        deactivateNature(project, INDEX_NATURE_ID);
    }
    
    /**
     * Deactivates a nature for a project
     * 
     * @param project the project
     * @param natureId nature id of the nature to be deactivated
     * @throws CoreException
     */
    private static void deactivateNature(final IProject project,final String natureId) throws CoreException{
        final IProjectDescription description = project.getDescription();
        final String[] natures = description.getNatureIds();
        String[] newNatures = description.getNatureIds();
        for( int i = 0; i < natures.length; ++i ) {
            if( natureId.equals( natures[i] ) ) {
                newNatures = removeNature( natures, i );
                description.setNatureIds( newNatures );
                project.setDescription( description, null );
                break;
            }
        }
    }
    
    /**
     * removes the particular nature from position 'index' in nature array.
     * 
     * @param natures
     * @param index
     * @return the updated nature array
     * @throws CoreException
     */
    private static String[] removeNature( final String[] natures, final int index ) throws CoreException {
        final String[] newNatures = new String[natures.length - 1];
        System.arraycopy( natures, 0, newNatures, 0, index );
        System.arraycopy( natures, index + 1, newNatures, index, natures.length - index - 1 );
        return newNatures;
    }

    /**
     * Evaluates a project whether it is RET Nature enabled.
     * 
     * @param project
     * @return true if project is RET enabled
     * @throws CoreException
     */
    public static boolean isRETProject( final IProject project ) throws CoreException {
        boolean isRETNature = false;
        if( project != null && project.isOpen() ) {
            isRETNature = project.hasNature( RETNature.NATURE_ID );
        }

        return isRETNature;
    }

    /**
     * Adds RET Builder for the given project
     * 
     * @param project
     * @throws CoreException
     */
    public static void addRETBuild( final IProject project ) throws CoreException {

        final IProjectDescription desc = project.getDescription();
        final ICommand[] commands = desc.getBuildSpec();
        if( !hasRETBuilder( commands ) ) {
            ICommand[] newCommands = new ICommand[commands.length + 1];
            System.arraycopy( commands, 0, newCommands, 0, commands.length );
            final ICommand command = project.getDescription().newCommand();
            command.setBuilderName( ReqM2InputBuilder.BUILDER_ID );
            newCommands[newCommands.length - 1] = command;
            desc.setBuildSpec( newCommands );
            project.setDescription( desc, null );
        }

    }

    /**
     * Removes RET Builder from the given project
     * 
     * @param project
     * @throws CoreException
     */
    public static void removeRETBuild( final IProject project ) throws CoreException {

        final IProjectDescription description = project.getDescription();
        final ICommand[] commands = description.getBuildSpec();
        ICommand[] newCommands = new ICommand[commands.length - 1];
        for( int i = 0; i < commands.length; ++i ) {
            if( commands[i].getBuilderName().equals( ReqM2InputBuilder.BUILDER_ID ) ) {
                newCommands = removeBuild( commands, i );
                description.setBuildSpec( newCommands );
                project.setDescription( description, null );
                break;
            }
        }
    }

    /**
     * Checks if the command array is having RET Builder in it.
     * 
     * @param commands
     * @return true if RETNature is present
     */
    private static boolean hasRETBuilder( final ICommand[] commands ) {
        boolean isRETNature = false;
        for( int i = 0; i < commands.length; ++i ) {
            if( commands[i].getBuilderName().equals( ReqM2InputBuilder.BUILDER_ID ) ) {
                isRETNature = true;
            }
        }
        return isRETNature;
    }

    /**
     * removes the build command element at position i
     * 
     * @param commands
     * @param pos
     * @return updated command array
     */
    private static ICommand[] removeBuild( final ICommand[] commands, final int pos ) {
        final ICommand[] newCommands = new ICommand[commands.length - 1];
        System.arraycopy( commands, 0, newCommands, 0, pos );
        System.arraycopy( commands, pos + 1, newCommands, pos, commands.length - pos - 1 );
        return newCommands;

    }

}