package eb.ret.core.model.data;

import eb.ret.core.model.SpecObjectResourceManager;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

/**
 * Data class to provide singleton access to ResourceSet for the SpecObject resources.
 * 
 * @author tintobaby
 * 
 */
public final class SpecObjectModelData {

    /**
     * Singleton instance of SpecObjectModelData.
     */
    private static SpecObjectModelData modelData;
    /**
     * ResourceSet holds all .reqm resources.
     */
    public static ResourceSetImpl resourceSet;

    /**
     * Private constructor.
     */
    private SpecObjectModelData() {
    }

    /**
     * To get access to instance of SpecObjectModelData.
     * 
     * @return instance of SpecObjectModelData.
     */
    public static SpecObjectModelData getInstance() {
        synchronized (SpecObjectResourceManager.class) {
            if( modelData == null ) {
                modelData = new SpecObjectModelData();
            }
        }
        return modelData;
    }

    /**
     * To get the ResourceSet holds the resources for all .reqm files.
     * 
     * @return Instance of ResourceSetImpl.
     */
    public ResourceSetImpl getSpecObjectResourceSet() {
        synchronized (ResourceSetImpl.class) {
            if( resourceSet == null ) {
                resourceSet = new ResourceSetImpl();
            }
        }
        return resourceSet;
    }

    /**
     * To get the Resource corresponding to the given URI.
     * 
     * @param resourceUri
     * @return Instance of Resource.
     */
    public Resource getSpectObjectResource( final URI resourceUri ) {
        Resource modelResource = null;
        if( null != resourceSet ) {
            modelResource = resourceSet.getResource( resourceUri, false );
        }
        return modelResource;
    }

    /**
     * To add a Resource to the ResourceSet.
     * 
     * @param modelResource
     */
    public void addSpecObjectResource( final Resource modelResource ) {
        if( null != resourceSet ) {
            resourceSet.getResources().add( modelResource );
        }
    }

    /**
     * To remove the given Resource from the ResourceSet.
     * 
     * @param modelResource
     */
    public void removeSpecObjectResource( final Resource modelResource ) {
        if( null != resourceSet ) {
            resourceSet.getResources().remove( modelResource );
        }
    }
}
