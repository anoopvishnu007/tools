package eb.ret.core.reqm2.builder;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.reqm2.ReqM2Manager;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.runtime.CoreException;

/**
 * @author Kiren SK
 * @version 1.0
 * @created 17-Aug-2012 5:18:22 PM
 */
public class RETDeltaVisitor implements IResourceDeltaVisitor {

    /*
     * (non-Javadoc)
     * @see org.eclipse.core.resources.IResourceDeltaVisitor#visit(org.eclipse.core.resources.IResourceDelta)
     * The deltas are processed depends on the Kind of change.
     * ReqM2Manager is invoked to process the corresponding resource.
     * 
     */

    @Override
    public boolean visit( final IResourceDelta delta ) throws CoreException {

        final int deltaKind = delta.getKind();
        final ReqM2Manager manager = ReqM2Manager.getInstance();
        final IResource resource = delta.getResource();

        if( resource.getType() == IResource.FILE ) {
            if( manager.isRETDirectory( resource ) ) {
                visitRETFile( (IFile)resource, deltaKind );
            } else if( manager.isReqM2OutputFile( (IFile)resource ) ) {
                visitReqM2File( (IFile)resource, deltaKind );
            }
        }
        return true;
    }

    /*
     * !LINKSTO eclipse.ret.req.SpecObjectModelSync,1
     */
    /**
     * process the reqm2 file given as the input.
     * 
     * @param reqmFile
     * @param deltaKind
     */
    private void visitReqM2File( final IFile reqmFile, final int deltaKind ) {

        if( deltaKind == IResourceDelta.REMOVED ) {
            SpecObjectResourceManager.getInstance().removeSpecObjectResource( reqmFile );
        } else {
            SpecObjectResourceManager.getInstance().loadSpecObjectResource( reqmFile );
        }
    }

    /**
     * process the RET file with in the RET input directory
     * 
     * @param retFile
     * @param deltaKind
     */
    private void visitRETFile( final IFile retFile, final int deltaKind ) {

        if( deltaKind == IResourceDelta.ADDED || deltaKind == IResourceDelta.CHANGED ) {
            ReqM2Manager.getInstance().processReqM2File( retFile );
        } else if( deltaKind == IResourceDelta.REMOVED ) {
            ReqM2Manager.getInstance().removeReqM2File( retFile );
        }
    }

}