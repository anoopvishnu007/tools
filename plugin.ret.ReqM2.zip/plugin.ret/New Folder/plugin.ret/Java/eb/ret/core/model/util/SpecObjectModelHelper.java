package eb.ret.core.model.util;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.model.specobject.SpecobjectsType;
import eb.ret.model.specobject.impl.DocumentRootImpl;
import eb.ret.model.specobject.impl.SpecobjectsTypeImpl;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.compare.diff.metamodel.DiffElement;
import org.eclipse.emf.compare.diff.metamodel.DiffModel;
import org.eclipse.emf.compare.diff.metamodel.MoveModelElement;
import org.eclipse.emf.compare.diff.service.DiffService;
import org.eclipse.emf.compare.match.metamodel.MatchModel;
import org.eclipse.emf.compare.match.service.MatchService;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.transaction.RecordingCommand;
import org.eclipse.emf.transaction.TransactionalEditingDomain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Helper class for SpecObjectModel. The class provides functionality for compare and update existing resource with new
 * resource
 * 
 * @author kirensk
 * 
 */
public class SpecObjectModelHelper {
    /**
     * Error message for exceptions while matching the specobject.
     */
    private static final String ERR_SPEC_MATCH = "Exception while doing content matching in specobject";
    /**
     * Static constant for 0.
     */
    private static final int FIRST_CONTENT = 0;

    /**
     * Editing domain handling the transactions in specobject data model.
     */
    private transient final TransactionalEditingDomain editingDomain;

    /**
     * Constructor for Helper. Helper works on a given editingDomain
     * 
     * @param editingDomain
     */
    public SpecObjectModelHelper( final TransactionalEditingDomain editingDomain ) {
        this.editingDomain = editingDomain;
    }

    /*
     * !LINKSTO    eclipse.ret.req.ChangedSpecObjectById,1,
     * !           eclipse.ret.req.SpecObjectChangeType,1,
     * !           eclipse.ret.req.SpecObjectModification,1
     */

    /**
     * Update an existing Resource with the changes in new Resource.
     * 
     * @param existingResource Existing resource.
     * @param newResource temporary resource with the new changes.
     */
    public void compareAndUpdateExistingResource( final Resource existingResource, final Resource newResource ) {

        final List<SpecobjectType> newSpecObjList = getSpecObjectList( newResource );
        //removedSObjs traces the specObjects which are removed
        final List<SpecobjectType> removedSObjs = new ArrayList<SpecobjectType>();
        removedSObjs.addAll( getSpecObjectList( existingResource ) );

        for( SpecobjectType newSpecObj : newSpecObjList ) {
            final String specObjId = newSpecObj.getId();
            final SpecobjectType existingSpecObj = SpecObjectResourceManager.getInstance()
                                                                            .getSpecObjectData()
                                                                            .getSpecObject( specObjId );
            if( existingSpecObj == null ) {
                //A specObject with the id doesnt exists. Add it to the resource
                addSpecObject( existingResource, newSpecObj );
            } else {
                //A specObject with the id exists. Compare it with the new specObject. If changed reset it.Remove it from removedList
                if( isDifferrent( existingSpecObj, newSpecObj ) ) {
                    setSpecObject( existingSpecObj, newSpecObj );
                }
                removedSObjs.remove( existingSpecObj );
            }
        }
        //Remove the specObjects which are removed
        if( !removedSObjs.isEmpty() ) {
            removeSpecObjects( removedSObjs );
        }
    }

    /**
     * get the specObjectType list with in a Resource
     * 
     * @param resource
     * @return list of specobjectType
     */
    private static List<SpecobjectType> getSpecObjectList( final Resource resource ) {
        final List<SpecobjectType> specObjList = new ArrayList<SpecobjectType>();
        if( resource != null && resource.getContents() != null && !resource.getContents().isEmpty() ) {
            final EObject docRoot = resource.getContents().get( FIRST_CONTENT );
            final EList<SpecobjectsType> specObjectsList = ((DocumentRootImpl)docRoot).getSpecdocument()
                                                                                      .getSpecobjects();
            for( SpecobjectsType specobjects : specObjectsList ) {
                specObjList.addAll( specobjects.getSpecobject() );
            }

        }
        return specObjList;
    }

    /**
     * add the specObject to the Resource
     * 
     * @param resource
     * @param specObject
     */
    private void addSpecObject( final Resource resource, final SpecobjectType specObject ) {
        final EObject existingDocRoot = resource.getContents().get( FIRST_CONTENT );
        final EList<SpecobjectsType> specObjectsList = ((DocumentRootImpl)existingDocRoot).getSpecdocument()
                                                                                          .getSpecobjects();
        final SpecobjectsTypeImpl newSpecObjs = (SpecobjectsTypeImpl)specObject.eContainer();
        // get the docType for the new specObject
        final String newDocType = newSpecObjs.getDoctype();
        if( newDocType != null ) {
            //add the new specObject to the existing specObjects of the docType
            for( final SpecobjectsType specobjects : specObjectsList ) {
                if( newDocType.equals( specobjects.getDoctype() ) ) {
                    editingDomain.getCommandStack().execute( new RecordingCommand( editingDomain ) {//NOPMD command stack created for each specobject.Object initiliazation for each specObject
                        @Override
                        protected void doExecute() {
                            specobjects.getSpecobject().add( specObject );
                        }
                    } );

                    return;
                }
            }
        }
        //newDocType doesnt exist in the current specObjects. Add it to the docRoot of the existing resource
        editingDomain.getCommandStack().execute( new RecordingCommand( editingDomain ) {//NOPMD command stack created for each specobject.Object initiliazation for each specObject
            @Override
            protected void doExecute() {
                ((DocumentRootImpl)existingDocRoot).getSpecdocument().getSpecobjects().add( newSpecObjs );
            }
        } );
    }

    /**
     * Retrieves the container for the existingSpecObject and set the newSpecObject to the existingSpecObject
     * 
     * @param existingSpecObj
     * @param newSpecObj
     */
    private void setSpecObject( final SpecobjectType existingSpecObj, final SpecobjectType newSpecObj ) {
        final SpecobjectsTypeImpl exstgSpecObjs = (SpecobjectsTypeImpl)existingSpecObj.eContainer();
        final int index = exstgSpecObjs.getSpecobject().indexOf( existingSpecObj );
        editingDomain.getCommandStack().execute( new RecordingCommand( editingDomain ) {
            @Override
            protected void doExecute() {
                exstgSpecObjs.getSpecobject().set( index, newSpecObj );
            }
        } );
    }

    /**
     * remove the SpecobjectType from their corresponding containers
     * 
     * @param removeSpecObjList
     */
    private void removeSpecObjects( final List<SpecobjectType> removeSpecObjList ) {
        for( final SpecobjectType specobjectType : removeSpecObjList ) {
            final SpecobjectsTypeImpl exstgSpecObjs = (SpecobjectsTypeImpl)specobjectType.eContainer();

            editingDomain.getCommandStack().execute( new RecordingCommand( editingDomain ) { //NOPMD command stack created for each specobject.Object initiliazation for each specObject
                @Override
                protected void doExecute() {
                    exstgSpecObjs.getSpecobject().remove( specobjectType );
                }
            } );
        }
    }

    /**
     * Compares two given SpecobjectType and returns a flag indicating its different or not
     * 
     * @param existingSpecObj
     * @param newSpecObj
     * @return boolean
     */
    public static boolean isDifferrent( final SpecobjectType existingSpecObj, final SpecobjectType newSpecObj ) {

        MatchModel match = null;
        boolean isDiff = false;
        try {
            match = MatchService.doContentMatch( existingSpecObj, newSpecObj, Collections.<String, Object> emptyMap() );
        } catch( InterruptedException e ) {
            ErrorLogger.logError( ERR_SPEC_MATCH, e );
        }
        //Differencing models
        final DiffModel diff = DiffService.doDiff( match );
        final Iterator<DiffElement> changeItr = diff.getDifferences().iterator();
        while (changeItr.hasNext()) {
            final DiffElement changedElement = changeItr.next();
            // MoveModelElement represents the difference in the object. Ignore MoveModelElement difference
            if( !(changedElement instanceof MoveModelElement) ) {
                isDiff = true;
            }
        }
        return isDiff;
    }
}
