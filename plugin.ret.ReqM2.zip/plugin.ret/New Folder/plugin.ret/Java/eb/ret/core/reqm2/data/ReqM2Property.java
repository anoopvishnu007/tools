package eb.ret.core.reqm2.data;

import eb.ret.core.reqm2.processor.ErrorLogger;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.StringTokenizer;

/**
 * Used for data handing for ReqM2 property. This will represent the data from Eclipse RET Property page.
 * 
 * @author tintobaby
 * 
 */
public class ReqM2Property {
    /**
     * Delimiter for directories
     */
    private static final String DIR_DELIMITER = "|";

    /**
     * Delimiter for directory elements
     */
    private static final String ELEMENT_DELIMITER = ",";

    /**
     * List of input directory paths
     */
    private List<String> directoryPaths;

    /**
     * List of input ret-directories
     */
    private List<RETDirectory> directories;

    /**
     * For storing the user entered docTypes
     */
    private List<String> docTypes;

    /**
     * Flag to indicate the property page is cancelled
     */
    private boolean cancelFlag = false;

    /**
     * Constant used for providing in docType column if "docbook" or "fastdocbook" is selected in Importer column.
     */
    public static final String NOT_APPLICABLE = "n/a";

    /**
     * Constructor. Initialize the inputDirecty paths
     */
    public ReqM2Property( final List<RETDirectory> inputDirs ) {
        this.directories = inputDirs;
        final List<String> paths = new ArrayList<String>();
        for( final RETDirectory dir : inputDirs ) {
            paths.add( dir.getPath() );
        }
        directoryPaths = paths;
    }

    /**
     * Constructor initializes the directories using directory list string
     * 
     * @param dirListString
     */
    public ReqM2Property( final String dirListString, final String docTypePrefString ) {
        setDirectoryFromString( dirListString );
        createDocTypeFromPreference( docTypePrefString );
    }

    /**
     * Default constructor
     */
    public ReqM2Property() {
        /*
         * Default constructor to provide usage of ReqM2Property with non
         * directory properties.
         */
    }

    /**
     * gets the input directory list
     * 
     * @return the input directory list
     */
    public List<RETDirectory> getInputDirectories() {
        return directories;
    }

    /**
     * Returns the doctype list
     * 
     * @return
     */
    public List<String> getDocTypes() {
        return docTypes;
    }

    /**
     * To add directory details to the "directories"(instance variable) list. Also adds the directory paths to the
     * "directoryPaths"(instance variable) list
     * 
     * @param directory
     */
    public final void setDirectories( final List<RETDirectory> inputDirs ) {
        this.directories = inputDirs;
        final List<String> paths = new ArrayList<String>();
        for( final RETDirectory dir : directories ) {
            paths.add( dir.getPath() );
        }
        directoryPaths = paths;
    }

    /**
     * Sets the docTypes(instance variable) list with the passed list
     * 
     * @param list
     */
    public final void setDocTypes( final List<String> list ) {
        this.docTypes = list;
    }

    /**
     * gets the input directory paths as single string
     * 
     * @return the input directory paths
     */
    public List<String> getInputDirectoryPaths() {
        return directoryPaths;
    }

    /**
     * Gets the string representation of directories with delimiter
     * 
     * @return the string representation of directories with delimiter
     */
    public String getDirectoryListString() {
        final StringBuilder builder = new StringBuilder();
        if( directories != null ) {
            for( final RETDirectory inputDir : directories ) {
                builder.append( inputDir.getPath() ).append( ELEMENT_DELIMITER );
                builder.append( inputDir.getImporter().name() ).append( ELEMENT_DELIMITER );
                builder.append( inputDir.getDocType() );
                builder.append( DIR_DELIMITER );
            }
        }
        return builder.toString();
    }

    /**
     * Returns the String representation of docTypes with delimiter for storing to preference store
     * 
     * @return
     */
    public String getDocTypePreferenceString() {
        final StringBuilder builder = new StringBuilder();
        if( docTypes != null ) {
            for( final String doctype : docTypes ) {
                builder.append( doctype ).append( ELEMENT_DELIMITER );
            }
        }
        return builder.toString();
    }

    /**
     * returns flag indicating the page is cancelled or not
     * 
     * @return cancelFlag
     */
    public boolean isCancelled() {
        return cancelFlag;
    }

    /**
     * Sets the cancelFlag indicating the page is cancelled or not
     * 
     * @param cancelFlag
     */
    public void setCancelled( final boolean cancelFlag ) {
        this.cancelFlag = cancelFlag;
    }

    /**
     * Sets the input directory list elements from the string read from preference
     * 
     * @param dirListString directory list string with delimiter
     */
    private void setDirectoryFromString( final String dirListString ) {
        if( dirListString != null ) {
            setInputDirectories( dirListString );
        }
    }

    /**
     * Sets the input directory list elements from the string read from preference. This method is for the compatibility
     * with the input directory path stored using RET 0.1 version.
     * 
     * @param dirListString
     */
    private void setInputDirectories( final String dirListString ) {

        final StringTokenizer dirTokenizer = new StringTokenizer( dirListString, DIR_DELIMITER );
        final List<RETDirectory> inputDirs = new ArrayList<RETDirectory>();
        while (dirTokenizer.hasMoreTokens()) {
            final String dirToken = dirTokenizer.nextToken();
            inputDirs.add( createDirectories( dirToken ) );

        }
        setDirectories( inputDirs );
    }

    /**
     * creates RETDirectory from the directoryString. The values for directory path, importerType and the docTypes are
     * extracted. The default values for importer is docbook and docType is n/a
     * 
     * @param dirToken
     * @return
     */
    private RETDirectory createDirectories( final String dirToken ) {
        final StringTokenizer elementTokens = new StringTokenizer( dirToken, ELEMENT_DELIMITER );
        final RETDirectory directory = new RETDirectory();
        // To support the directory path stored using RET-0.1 
        // a default importer and docType values are set 
        directory.setImporter( ImporterType.DOCBOOK );
        directory.setDocType( NOT_APPLICABLE );

        if( elementTokens.hasMoreTokens() ) {
            directory.setPath( elementTokens.nextToken() );
        }
        if( elementTokens.hasMoreTokens() ) {
            try {
                directory.setImporter( ImporterType.valueOf( elementTokens.nextToken() ) );
            } catch( final Exception ex ) {
                ErrorLogger.logError( "Exception while retrieving importer type", ex );
            }
        }
        if( elementTokens.hasMoreTokens() ) {
            directory.setDocType( elementTokens.nextToken() );
        }

        return directory;
    }

    /**
     * Creates the docTypes from the stored preference string and sets it to the docTypes list
     * 
     * @param docTypePrefString
     */
    private void createDocTypeFromPreference( final String docTypePrefString ) {
        if( docTypePrefString != null ) {
            final Stack<String> docTypes = new Stack<String>();
            final StringTokenizer doctypeTokenizer = new StringTokenizer( docTypePrefString, ELEMENT_DELIMITER );
            while (doctypeTokenizer.hasMoreTokens()) {
                final String docType = doctypeTokenizer.nextToken();
                docTypes.add( docType );
            }
            setDocTypes( docTypes );
        }
    }

    /**
     * Gets the string representation of directories paths with delimiter
     * 
     * @return the string representation of directories path with delimiter
     */
    public String getDirectoryPathsAsString() {
        final StringBuilder builder = new StringBuilder();
        if( directories != null && !directories.isEmpty() ) {
            for( final RETDirectory inputDir : directories ) {
                builder.append( inputDir.getPath() ).append( DIR_DELIMITER );
            }
        }
        return builder.toString();
    }

}