package eb.ret.core.reqm2.processor;

import eb.ret.plugin.RETPlugin;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

/**
 * ErrorLogger used to submit the IStatus depends on the Log level.
 * 
 * @author kirensk
 * 
 */
public final class ErrorLogger {

    /**
     * Private constructor.
     */
    private ErrorLogger() {

    }

    /*
     * !LINKSTO eclipse.ret.req.RETErrorHandling,1
     */
    /**
     * To log error to the Eclipse errorlog view.
     * 
     * @param status
     */
    private static void log( final IStatus status ) {
        RETPlugin.getDefault().getLog().log( status );
    }

    /**
     * To create an IStatus instance.
     * 
     * @param severity
     * @param code
     * @param message
     * @param exception
     * @return
     */
    private static IStatus createStatus( final int severity,
                                         final int code,
                                         final String message,
                                         final Throwable exception ) {
        return new Status( severity, RETPlugin.PLUGIN_ID, code, message, exception );

    }

    /**
     * To log info.
     * 
     * @param message
     * @param exception
     */
    public static void logInfo( final String message, final Throwable exception ) {
        log( createStatus( IStatus.INFO, 0, message, exception ) );
    }

    /**
     * To Log warning.
     * 
     * @param message
     * @param exception
     */
    public static void logWarning( final String message, final Throwable exception ) {
        log( createStatus( IStatus.WARNING, 0, message, exception ) );
    }

    /**
     * To log error.
     * 
     * @param message
     * @param exception
     */
    public static void logError( final String message, final Throwable exception ) {
        log( createStatus( IStatus.ERROR, 0, message, exception ) );
    }
}
