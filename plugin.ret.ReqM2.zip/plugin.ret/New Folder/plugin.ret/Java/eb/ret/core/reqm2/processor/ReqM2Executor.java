package eb.ret.core.reqm2.processor;

import eb.ret.core.reqm2.data.ImporterType;
import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.plugin.RETPlugin;

import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.IConsoleConstants;
import org.eclipse.ui.console.IConsoleManager;
import org.eclipse.ui.console.MessageConsole;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to execute REQM2 tool.
 * 
 * @author tintobaby
 * 
 */
public final class ReqM2Executor {

    /**
     * importer option used for REQM2 process arguments
     */
    private static final String ARG_IMPORTER = "-i";
    /**
     * transformer option used for REQM2 process arguments
     * 
     */
    private static final String ARG_TRANSFORMER = "-x";
    /**
     * outdir option used for REQM2 process arguments
     * 
     */
    private static final String ARG_OUTDIR = "-O";
    /**
     * outfile option used for REQM2 process arguments
     * 
     */
    private static final String ARGS_OUTFILE = "-o";

    /**
     * Process argument to select the tracing unit
     */
    private static final String ARGS_TRACE = "-t";
    /**
     * parameter string option used for REQM2 importer process arguments
     */
    private static final String ARG_PARAM = "-p";

    /**
     * param string used for java input files for importer
     */
    private static final String PARAM_STRING = "\"doctype=%s;status=approved;version=unversioned\"";

    /**
     * Extension constant for File Processing.
     */
    public static final String EXTN_CHAR = ".";
    /**
     * ReqM2 extension constant for File Processing.
     */
    public static final String REQM_EXTN = "reqm";
    /**
     * Process arguments to selects the exporter unit.
     */
    private static final String ARGS_EXPORT = "-r";
    /**
     * Name of exporter unit.
     */
    private static final String HTML_EXPORTER = "ReqM2_HtmlExporter";
    /**
     * java file extension
     * 
     */
    public static final String JAVA_EXTN = "java";

    /**
     * This is a configuration FLAG to stop printing the output of the process to console Can be changed to a
     * configuration input. Set this to true if the result of the PERL process needs to be printed to console.
     */
    private static final boolean IS_PRINT_CONSOLE = true;
    /**
     * Warning message status for ReqM2
     * 
     */
    private static final String STATUS_WARNING = "WARNING";
    /**
     * Error message status for ReqM2
     * 
     */
    private static final String STATUS_ERROR = "ERROR";

    /**
     * Error message to update user for exception while writing reqm2 engine outputs.
     */
    private static final String MSG_ERR_OUTPUT = "Error in writing process output";

    /**
     * Default constructor
     * 
     */
    private ReqM2Executor() {
    }

    /**
     * To execute reqM2 importer with a file. Process will be started with arguments given and updates will be
     * redirected to Console.
     * 
     * @param inputFileName File name for the input file
     * @param inputFilePath Directory of input file
     * @param outputPath Desired output directory for the generated reqm2 file
     * @param inputDir input directory object
     */

    public static void executeReqM2FileImporter( final String inputFileName,
                                                 final String inputFilePath,
                                                 final String outputPath,
                                                 final RETDirectory inputDir ) {

        final String reqM2Path = ReqM2InputData.getRETData().getReqM2Location();
        final String perlPath = ReqM2InputData.getRETData().getPerlLocation();

        final List<String> builderCommand = new ArrayList<String>();
        builderCommand.add( perlPath );
        builderCommand.add( reqM2Path );
        builderCommand.add( ARG_IMPORTER );
        builderCommand.add( ARG_TRANSFORMER );

        builderCommand.add( getImporterType( inputDir, inputFileName ) );

        if( (inputDir != null && inputDir.getImporter() == ImporterType.GENERIC) || isJavaFile( inputFileName ) ) {
            builderCommand.add( ARG_PARAM );
            builderCommand.add( String.format( PARAM_STRING, inputDir.getDocType() ) );
        }
        builderCommand.add( ARG_OUTDIR );
        builderCommand.add( outputPath );
        builderCommand.add( ARGS_OUTFILE );
        builderCommand.add( getOutputFileName( inputFileName ) );
        builderCommand.add( inputFilePath );

        // Invoke ReqM2 tool with the command for running ReqM2 importer unit.
        invokeReqM2Process( builderCommand );
    }

    private static String getImporterType( final RETDirectory inputDir, final String inputFileName ) {

        // if the input file is .java process with generic importer
        if( isJavaFile( inputFileName ) ) {
            return ImporterType.GENERIC.getName();
        }
        if( inputDir != null && inputDir.getImporter() != null ) {
            return inputDir.getImporter().getName();
        }

        return ImporterType.DOCBOOK.getName();
    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2TracingEngine,1, !
     * eclipse.ret.req.ReqM2TracingScope,1, !
     * eclipse.ret.req.ReqM2TracingOutputLocation,1
     */
    /**
     * Execute ReqM2 tracing engine with a list of .reqm files generated by ReqM2 Importer.
     * 
     * @param outPutFileName tracing.oreqm
     * @param outPutPath Path used to store "tracing.oreqm" file.
     * @param cmdListAll List of .reqm files.
     */
    public static void executeReqM2Tracing( final String outPutFileName,
                                            final String outPutPath,
                                            final List<String> cmdListAll ) {

        final String reqM2Path = ReqM2InputData.getRETData().getReqM2Location();
        final String perlPath = ReqM2InputData.getRETData().getPerlLocation();

        final List<String> builderCommand = new ArrayList<String>();
        builderCommand.add( perlPath );
        builderCommand.add( reqM2Path );
        builderCommand.add( ARGS_TRACE );
        builderCommand.add( ARG_OUTDIR );
        builderCommand.add( outPutPath );
        builderCommand.add( ARGS_OUTFILE );
        builderCommand.add( outPutFileName );
        builderCommand.addAll( cmdListAll );

        // Invoke ReqM2 tool with the command for running ReqM2 tracing unit.
        invokeReqM2Process( builderCommand );
    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2OutputEngineExecution,1, !
     * eclipse.ret.req.InputOfReqM2OutputEngine,1, !
     * eclipse.ret.req.ReqM2HTMLOutputLocation,1
     */
    /**
     * Execute ReqM2_HtmlExporter with the .oreqm file generated by ReqM2 tracing engine.
     * 
     * @param outPutFileName ReqM2report.html
     * @param outPutPath Path used to store "ReqM2report.html" file.
     * @param tracingInput .oreqm file.
     */
    public static void executeReqM2HTMLExport( final String outPutFileName,
                                               final String outPutPath,
                                               final String tracingInput ) {

        final String reqM2Path = ReqM2InputData.getRETData().getReqM2Location();
        final String perlPath = ReqM2InputData.getRETData().getPerlLocation();

        final List<String> builderCommand = new ArrayList<String>();
        builderCommand.add( perlPath );
        builderCommand.add( reqM2Path );
        builderCommand.add( ARGS_EXPORT );
        builderCommand.add( ARG_TRANSFORMER );
        builderCommand.add( HTML_EXPORTER );
        builderCommand.add( ARG_OUTDIR );
        builderCommand.add( outPutPath );
        builderCommand.add( ARGS_OUTFILE );
        builderCommand.add( outPutFileName );
        builderCommand.add( tracingInput );

        // Invoke ReqM2 tool with the command for running ReqM2 HTML exporter
        // unit.
        invokeReqM2Process( builderCommand );
    }

    /**
     * Output file name is created from the input file name. Extension is changed to .reqm eg : if inputFileName is
     * requirements.xml outputFileName is created as requirements.reqm
     * 
     * @param inputFileName
     * @return String outputFileName
     */
    public static String getOutputFileName( final String inputFileName ) {
        final StringBuilder outFileBuilder = new StringBuilder( inputFileName );
        final int extInd = outFileBuilder.lastIndexOf( EXTN_CHAR );
        if( extInd > 0 ) {
            outFileBuilder.delete( extInd + 1, outFileBuilder.length() );
        } else {
            outFileBuilder.append( EXTN_CHAR );
        }
        outFileBuilder.append( REQM_EXTN );
        return outFileBuilder.toString();
    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2ErrorLogging,1, !
     * eclipse.ret.req.ReqM2ErrorLogView,1, !
     */
    /**
     * Creates output for the process and prints the output to console.
     * 
     * @param process
     * @param builderCommand
     */
    private static void writeProcessOutput( final Process process, final List<String> builderCommand ) {

        final InputStreamReader tempReader = new InputStreamReader(
            new BufferedInputStream( process.getInputStream() ) );
        final BufferedReader reader = new BufferedReader( tempReader );

        String line = null;
        try {
            do {

                line = reader.readLine();
                if( line != null ) {
                    if( line.indexOf( STATUS_ERROR ) > 0 ) {
                        ErrorLogger.logError( createErrorMessage( line, builderCommand ), null );
                    } else if( line.indexOf( STATUS_WARNING ) > 0 ) {
                        ErrorLogger.logWarning( line, null );
                    } else {
                        writeConsole( line );
                    }
                }

            } while (line != null);
        } catch( final IOException e ) {
            ErrorLogger.logError( MSG_ERR_OUTPUT, e );
        }

    }

    /**
     * Method to direct the information to the Console
     * 
     * @param info
     */
    private static void writeConsole( final String info ) {

        if( info == null ) {
            return;
        }
        final IConsoleManager consoleManager = ConsolePlugin.getDefault().getConsoleManager();
        final IConsole[] consoles = consoleManager.getConsoles();
        MessageConsole msgConsole = null;
        // Retrieve existing Message Console
        for( final IConsole console : consoles ) {
            if( console.getType() == IConsoleConstants.MESSAGE_CONSOLE_TYPE ) {
                msgConsole = (MessageConsole)console;
            }

        }
        // If Message Console is not present, create a console specific for RET
        // Plugin
        if( msgConsole == null ) {
            final IConsole[] msgConsoles = new MessageConsole[1];
            msgConsole = new MessageConsole( RETPlugin.PLUGIN_ID, null );
            msgConsoles[0] = msgConsole;
            consoleManager.addConsoles( msgConsoles );
        }

        msgConsole.newMessageStream().print( info );
    }

    /**
     * Invoke ReqM2 tool with the given command.
     * 
     * @param builderCommand Command string with necessary ReqM2 arguments.
     */
    private static void invokeReqM2Process( final List<String> builderCommand ) {
        try {
            // ProcessBuilder to invoke an external process.
            final ProcessBuilder pBuilder = new ProcessBuilder( builderCommand );
            pBuilder.redirectErrorStream( true );
            final Process process = pBuilder.start();

            // Trigger a separate thread to print output stream. This is will
            // prevent the dead lock between 'process.waitFor' and 'readLine'
            final Thread outputThread = new Thread( new Runnable() {
                @Override
                public void run() {
                    if( IS_PRINT_CONSOLE ) {
                        writeProcessOutput( process, builderCommand );
                    }
                }
            } );
            outputThread.start();

            // Wait for the process to complete. Interrupt can come when user
            // request cancellation.
            try {
                process.waitFor();
            } catch( final InterruptedException ex ) {
                process.destroy();
                outputThread.interrupt();
            }

        } catch( final IOException ex ) {
            ErrorLogger.logError( ex.getMessage(), ex );
        } catch( final Exception ex ) {
            ErrorLogger.logError( ex.getMessage(), ex );
        }
    }

    /**
     * Creates the error message with command line
     * 
     * @param msg error message
     * @param builderCommand list of command line arguments
     * @return message string
     */
    private static String createErrorMessage( final String msg, final List<String> builderCommand ) {
        final StringBuilder cmdBuilder = new StringBuilder( msg );
        cmdBuilder.append( "\n" );
        cmdBuilder.append( "Command Line : " );
        for( final String string : builderCommand ) {

            cmdBuilder.append( string );
            cmdBuilder.append( " " );
        }
        return cmdBuilder.toString();
    }

    /**
     * isJavaFile method checks the extension of the given fileName
     * 
     * @param fileName
     * @return true if fileName has java extension
     */
    private static boolean isJavaFile( final String fileName ) {
        boolean isJava = false;
        if( fileName != null ) {
            final int index = fileName.lastIndexOf( EXTN_CHAR );
            if( index != -1 && JAVA_EXTN.equalsIgnoreCase( fileName.substring( index + 1 ) ) ) {
                isJava = true;
            }
        }
        return isJava;

    }

}