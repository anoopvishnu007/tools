package eb.ret.core.model.data;

import eb.ret.core.model.util.SpecObjectModelHelper;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.util.SpecObjectResourceFactoryImpl;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.transaction.RecordingCommand;
import org.eclipse.emf.transaction.ResourceSetListener;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.emf.workspace.WorkspaceEditingDomainFactory;

import java.io.IOException;

/**
 * This class handles the creation and modification of specobject memory model. It holds the default editingDomain and
 * specObjectFactoryImpl for specObject resource in RET
 * 
 * @author tintobaby
 * 
 */
public class SpecObjectModel implements ISpecObjectModel {

    /**
     * Editing domain handling the transactions in specobject data model.
     */
    private static TransactionalEditingDomain editingDomain;

    /**
     * Factory class to create specobject resources.
     */
    private static SpecObjectResourceFactoryImpl specObjectFactory = new SpecObjectResourceFactoryImpl();
    /**
     * SpecObjectModelData instance to access ResourceSet for specObject resources.
     */
    private transient final SpecObjectModelData modelData;

    /**
     * Error message for exceptions while updating existing resource,
     */
    private static final String ERR_UPD_RESOURCE = "Error in updating new resource";
    /**
     * Error message for exceptions while loading the resource.
     */
    private static final String ERR_LOAD_RES = "Unable to load the resource";

    /**
     * Constructor to initialize the model states
     */
    public SpecObjectModel() {
        super();
        modelData = SpecObjectModelData.getInstance();
        setEditingDomain();
        setSpecObjectFactory();
    }

    /*
     * retrieves the global resourceset for the workspace
     */
    @Override
    public ResourceSet getSpecObjectResourceSet() {
        return modelData.getSpecObjectResourceSet();
    }

    /*
     * load the resource for the corresponding uri
     * 
     */
    @Override
    public void loadSpecObjectResource( final URI modelUri ) {

        if( null == modelData.getSpecObjectResourceSet().getResource( modelUri, false ) ) {
            final Resource resource = specObjectFactory.createResource( modelUri );
            editingDomain.getCommandStack().execute( new RecordingCommand( editingDomain ) {
                @Override
                protected void doExecute() {
                    modelData.addSpecObjectResource( resource );
                    try {
                        resource.load( SpecObjectModelData.getInstance().getSpecObjectResourceSet().getLoadOptions() );
                    } catch( IOException ex ) {
                        ErrorLogger.logError( ERR_LOAD_RES + " " + resource.getURI(), ex );
                    }
                }
            } );

        } else {
            try {
                final Resource existingResource = getSpecObjectResourceSet().getResource( modelUri, false );
                final Resource tempResource = createAndLoadTempResource( modelUri );
                new SpecObjectModelHelper( editingDomain ).compareAndUpdateExistingResource( existingResource,
                                                                                             tempResource );
                //Unload the temporary resource.
                tempResource.unload();
            } catch( Exception e ) {
                ErrorLogger.logError( ERR_UPD_RESOURCE + " " + modelUri, e );
            }
        }
    }

    /*
     * Removes the corresponding reqm resource from the data
     */
    @Override
    public void removeSpecObjectResource( final URI reqmURI ) {
        final Resource modelResource = modelData.getSpectObjectResource( reqmURI );

        editingDomain.getCommandStack().execute( new RecordingCommand( editingDomain ) {
            @Override
            protected void doExecute() {
                if( modelResource.isLoaded() ) {
                    modelResource.unload();
                }
                modelData.removeSpecObjectResource( modelResource );
            }
        } );
    }

    /**
     * Create and load temporary resource for changed .reqm file.
     * 
     * @param modelUri
     * @return Resource corresponding to the changed .reqm file.
     */
    private Resource createAndLoadTempResource( final URI modelUri ) {
        final Resource tempRes = specObjectFactory.createResource( modelUri );
        loadResource( tempRes );
        return tempRes;
    }

    /*
     * !LINKSTO eclipse.ret.req.NotificationMechanism,1
     */
    @Override
    public void addResourceChangeListener( final ResourceSetListener listener ) {
        //Add ResourceSetListener to the associated editing domain.
        editingDomain.addResourceSetListener( listener );
    }

    /**
     * set the default editingDomain. Create the default editingDomain if it is null. This will be the global
     * editingDomain for the specObjects
     */
    public final void setEditingDomain() {

        if( editingDomain == null ) {
            editingDomain = WorkspaceEditingDomainFactory.INSTANCE.createEditingDomain( modelData.getSpecObjectResourceSet() );
        }

    }

    /**
     * set the default specObjectFactory. Create the default specObjectFactory if it is null. It will be the global
     * specObjectFactory for the specObjects
     */

    public final void setSpecObjectFactory() {
        if( specObjectFactory == null ) {
            specObjectFactory = new SpecObjectResourceFactoryImpl();
        }
    }

    /**
     * To load the given resource.
     * 
     * @param resource
     */
    public void loadResource( final Resource resource ) {
        editingDomain.getCommandStack().execute( new RecordingCommand( editingDomain ) {
            @Override
            protected void doExecute() {
                try {
                    resource.load( SpecObjectModelData.getInstance().getSpecObjectResourceSet().getLoadOptions() );
                } catch( IOException ex ) {
                    ErrorLogger.logError( ERR_LOAD_RES + " " + resource.getURI(), ex );
                }
            }
        } );
    }
}
