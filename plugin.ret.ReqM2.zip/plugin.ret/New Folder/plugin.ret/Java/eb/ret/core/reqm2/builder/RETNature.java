package eb.ret.core.reqm2.builder;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;

/**
 * @author Kiren SK
 * @version 1.0
 * 
 *          RETNature implements IProjectNature for RET Nature behavior. It configures the build when RETNature is
 *          configured and removes it when its disabled.
 */
public class RETNature implements IProjectNature {

    /**
     * natureid for RETNature
     */
    public static final String NATURE_ID = "eb.ret.plugin.reqm2nature";

    /**
     * working project for the RETNature
     */
    private IProject project;

    /**
     * Invokes when a RETNature is enabled for a project
     */
    @Override
    public void configure() throws CoreException {

        RETNatureController.addRETBuild( project );
    }

    /**
     * @see org.eclipse.core.resources.IProjectNature#deconfigure() Invokes when a RETNature is disabled for a project
     *      Invokes when a RETNature is disabled for a project
     */
    @Override
    public void deconfigure() throws CoreException {

        RETNatureController.removeRETBuild( project );

    }

    /**
     * Set the project for the Nature.
     */
    @Override
    public void setProject( final IProject project ) {
        this.project = project;

    }

    /**
     * returns the Project for the nature.
     */
    @Override
    public IProject getProject() {
        return project;
    }
}