package eb.ret.core.reqm2.data;

import org.eclipse.core.resources.IProject;

import java.util.List;

/**
 * Interface to provide RET preferences and properties
 * 
 * @author nikhilcr
 */
public interface IRETData {
    /**
     * Returns the RET browser selection option chosen by user
     * 
     * @return String
     */
    String getBrowserSelection();

    /**
     * Returns the list of path of input directories of current project
     * 
     * @return List of paths
     */
    List<String> getDirectoriesPath( IProject project );

    /**
     * Returns the list of input directories of current project
     * 
     * @return List of RETDirectory
     */
    List<RETDirectory> getRETInputDirectories( IProject project );

    /**
     * Returns the list of docTypes of current project
     * 
     * @param project
     * @return
     */
    List<String> getDocTypes( IProject project );

    /**
     * Returns the perl executable location
     * 
     * @return String
     */
    String getPerlLocation();

    /**
     * Returns the ReqM2 executable location
     * 
     * @return String
     */
    String getReqM2Location();

    /**
     * Returns true if RET preferences are set, else will return false
     * 
     * @return true or false
     */
    boolean isRETPreferencesSet();

    /**
     * To check whether the Eclipse RET property is set for the given project
     * 
     * @param project the project to check
     * @return true if ReqM2 property is set else false
     */
    boolean isRETPropertiesSet( final IProject project );
}