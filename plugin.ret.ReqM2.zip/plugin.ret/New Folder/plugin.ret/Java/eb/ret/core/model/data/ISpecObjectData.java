package eb.ret.core.model.data;

import eb.ret.model.specobject.SpecobjectType;

import java.util.List;

/**
 * Interface to provide the data from the model.
 * 
 * @author tintobaby
 * 
 */
public interface ISpecObjectData {

    /**
     * Searches the specobjects from the model according to the search parameters and return a list of specobjects that
     * matches the search criteria
     * 
     * @param params search criteria parameters
     * @return List of specobjects
     */
    public List<SpecobjectType> getSpecObjectList( SpecObjectSearchParams params );

    /**
     * To get the first instance of SpecobjectType which holds the data corresponding to the specobject id.
     * 
     * @param specObjectId
     * @return first SpecobjectType corresponding to the given specobject id.
     */
    public SpecobjectType getSpecObject( String specObjectId );

    /**
     * To get the List of SpecobjectType which holds the data corresponding to the specobject id.
     * 
     * @param specObjectId
     * @return List of SpecobjectType in the Memory model corresponding to the given specobject id.
     */
    public List<SpecobjectType> getSpecObjectList( String specObjectId );

    /**
     * To get the List of Referenced Specobjects. The reference can be either LinksTo or links tag to the given specobject id
     * 
     * @param specObjectId
     * @return List of SpecobjectType in the Memory model linked to the given specobject id.
     */
    public List<SpecobjectType> getLinkedSpecObjects( String specObjectId );
}
