package eb.ret.core.model.data;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.FeatureMap.ValueListIterator;
import org.eclipse.emf.ecore.xml.type.impl.AnyTypeImpl;
import org.eclipse.emf.query.conditions.eobjects.EObjectCondition;
import org.eclipse.emf.query.conditions.eobjects.structuralfeatures.EStructuralFeatureValueGetter;
import org.eclipse.emf.query.conditions.eobjects.structuralfeatures.IEStructuralFeatureValueGetter;

import java.util.ArrayList;
import java.util.List;

/**
 * Value getter class for AnyTypeImpl type
 * 
 * @author anoopvn
 * 
 */
public class AnyTypeValueGetter implements IEStructuralFeatureValueGetter {

    @Override
    public List<EObject> eContents( final EObject eObject, final EObjectCondition filterCondition ) {
        return EStructuralFeatureValueGetter.getInstance().eContents( eObject, filterCondition );
    }

    @Override
    public Object eGet( final EObject eObject, final EStructuralFeature eFeature, final boolean resolve ) {

        if( eObject instanceof AnyTypeImpl ) {
            final List<String> list = new ArrayList<String>();

            final FeatureMap map = (((AnyTypeImpl)eObject).getMixed());
            for( final ValueListIterator<Object> iterator = map.valueListIterator(); iterator.hasNext(); ) {
                final Object entry = iterator.next();
                if( entry instanceof String ) {
                    list.add( (String)entry );
                }
            }
            return list;
        }

        return null;
    }

    @Override
    public EObject resolve( final EObject eObject ) {
        return EStructuralFeatureValueGetter.getInstance().resolve( eObject );
    }

}
