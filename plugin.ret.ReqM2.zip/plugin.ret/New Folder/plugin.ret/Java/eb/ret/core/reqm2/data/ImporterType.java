package eb.ret.core.reqm2.data;

/**
 * Enum for importer types used in ReqM2 importer engine
 * 
 * @author nikhilcr
 * 
 */
public enum ImporterType {
    GENERIC( "ReqM2_GenericImporter", 0 ),
    DOCBOOK( "ReqM2_DocBookImporter", 1 ),
    FASTDOCBOOK( "ReqM2_FastDocBookImporter", 2 );

    /**
     * name used for the enum
     */
    private final String name;
    /**
     * integer value representing the enum
     */
    private final int value;

    /**
     * getter for the name of the enum
     * 
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * getter for the integer value of the enum
     * 
     * @return
     */
    public int getValue() {
        return value;
    }

    /**
     * Constructor for the enum
     * 
     * @param name
     * @param value
     */
    private ImporterType( final String name, final int value ) {
        this.name = name;
        this.value = value;
    }

    /**
     * get the corresponding enum for the given integer value By default returns docbook importer if there is not
     * matching importer value
     * 
     * @param value
     * @return
     */
    public static ImporterType get( final int value ) {
        for( final ImporterType importer : ImporterType.values() ) {
            if( importer.getValue() == value ) {
                return importer;
            }
        }
        return DOCBOOK;
    }

    /**
     * get the corresponding enum for the given enum name. By default returns docbook importer if there is no matching
     * importer name
     * 
     * @param name
     * @return
     */
    public static ImporterType parse( final String name ) {
        for( final ImporterType importer : ImporterType.values() ) {
            if( importer.getName().equals( name ) ) {
                return importer;
            }
        }
        return DOCBOOK;
    }

}
