package eb.ret.core.reqm2.builder;

import eb.ret.core.reqm2.ReqM2Manager;
import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.ui.helper.ProcessMonitorTimerTask;
import eb.ret.ui.views.specobjects.SpecObjectsView;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.jobs.IJobManager;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbenchPart;

import java.util.Map;
import java.util.Timer;

/**
 * RET Builder is invoked for RETNature Project. This verifies each delta resource and process reqM2 if its a RET
 * resource
 * 
 * @author Kiren SK
 * @version 1.0
 */
public class ReqM2InputBuilder extends IncrementalProjectBuilder {

    /**
     * Builder id representing RET Builder.
     * 
     * @since 1.0
     */
    public static final String BUILDER_ID = "eb.ret.plugin.reqm2build";

    /**
     * Message to be displayed if RET Preferences are not set.
     * 
     * @since 1.0
     */
    private static final String MSG_RET_PREF = "RET Preferences are not set.RET Build will not be invoked";

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.core.resources.IncrementalProjectBuilder#build(int,
     * java.util.Map, org.eclipse.core.runtime.IProgressMonitor) Implementation
     * for RETBuild. Redirects to full build in case of a full build and invokes
     * incremental build for incremental type
     */

    @Override
    protected IProject[] build( final int kind, final Map<String, String> args, final IProgressMonitor monitor )
        throws CoreException {
        final IProject[] iProject = new IProject[0];

        // Return the flow if preferences are not set.
        if( !ReqM2InputData.getRETData().isRETPreferencesSet() ) {
            ErrorLogger.logError( MSG_RET_PREF, null );
            return iProject;
        }
        final IJobManager jobManager = Job.getJobManager();
        final IFolder reqMFolder = ReqM2Manager.getInstance().getReqM2ImpOutputFolder( getProject() );
        final ISchedulingRule reqM2Rule = reqMFolder;
        //Timer to monitor the progress monitor cancel event.
        final Timer timer = new Timer();
        //Schedule the timer with the timer task.
        timer.schedule( new ProcessMonitorTimerTask( monitor ), 500, 500 );
        try {
            jobManager.beginRule( reqM2Rule, monitor );
            if( kind == FULL_BUILD ) {
                fullBuild( monitor );
            } else {
                final IResourceDelta delta = getDelta( getProject() );
                if( delta == null ) {
                    fullBuild( monitor );
                } else {
                    incrementalBuild( delta, monitor );
                }
            }

        } finally {
            //Cancel the timer.
            timer.cancel();
            //End the rule for the reqm2
            jobManager.endRule( reqM2Rule );
        }
        // Refresh the reqM2 output folder to get the latest .reqm files generated from perl process
        ReqM2Manager.getInstance().refreshReqM2OutputFolder( getProject() );

        // For refreshing the specobject view if its active
        final IWorkbenchPart viewPart = WorkspaceUtils.getViewPart( SpecObjectsView.class );
        if( viewPart != null ) {
            Display.getDefault().asyncExec( new Runnable() {
                @Override
                public void run() {
                    if( viewPart instanceof SpecObjectsView ) {
                        ((SpecObjectsView)viewPart).refresh();
                    }
                }
            } );
        }

        // Return an empty project list. RET build doesn't require dependency
        // Projects
        return iProject;
    }

    /**
     * Invokes ReqM2Manager to clean the reqm2 output resources
     */
    @Override
    protected void clean( final IProgressMonitor monitor ) throws CoreException {
        ReqM2Manager.getInstance().clearReqM2Output( getProject(), monitor );
    }

    /**
     * RETDeltaVisitor is configured for processing the deltas
     * 
     * @param delta
     * @param monitor
     * @throws CoreException
     */
    protected void incrementalBuild( final IResourceDelta delta, final IProgressMonitor monitor )
        throws CoreException {

        delta.accept( new RETDeltaVisitor(), IContainer.INCLUDE_HIDDEN );

    }

    /**
     * RETResourceVisitor is configured for processing the project resources.
     * 
     * @param monitor
     * @throws CoreException
     */
    protected void fullBuild( final IProgressMonitor monitor ) throws CoreException {

        getProject().accept( new RETResourceVisitor(), IResource.DEPTH_INFINITE, IContainer.INCLUDE_HIDDEN );

    }

}