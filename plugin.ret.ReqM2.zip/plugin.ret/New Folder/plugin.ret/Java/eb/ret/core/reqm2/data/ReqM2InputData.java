package eb.ret.core.reqm2.data;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.plugin.RETPlugin;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ProjectScope;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IPreferencesService;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.osgi.service.prefs.BackingStoreException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This singleton class will hold the ReqM2 preferences and property details for internal RET usage.
 * 
 * @author tintobaby
 * 
 */
public final class ReqM2InputData implements IRETProperty, IRETData {

    /**
     * Enum for output browser selection
     * 
     */
    public enum BrowserType {
        ECLIPSE, SYSTEM
    }

    /**
     * To make ReqM2 properties input directory key
     */
    public static final String INPUT_DIR_KEY = "input_directories";

    /**
     * To make ReqM2 properties docTypes key
     */
    public static final String DOCTYPES_KEY = "docTypes";

    /**
     * To make specobject column preference key
     */
    public static final String SPEC_COL_KEY = "specobject_view";

    /**
     * key for storing ReqM2 tool executable location
     */
    public static final String KEY_REQM2_TOOL = "ReqM2_Tool_Path";

    /**
     * key for storing perl executable location
     */
    public static final String KEY_REQM2_PERL = "ReqM2_Perl_Path";

    /**
     * key for storing browser selection
     */
    public static final String KEY_REQM2_BROWSER = "ReqM2_Browser_Choice";

    /**
     * Constant for project settings folder
     */
    private static final String PROJ_SETTINGS = ".settings";

    /**
     * Static instance of the class
     */
    private static ReqM2InputData retInputData;

    /**
     * private constructor for achieving singleton
     */
    private ReqM2InputData() {

    }

    /**
     * Provides the instance of this class. This method has to be invoked to get the instance of this class.
     * 
     * @return the singleton instance
     */
    private static ReqM2InputData getInstance() {

        synchronized (ReqM2InputData.class) {
            if( retInputData == null ) {
                retInputData = new ReqM2InputData();
            }
        }

        return retInputData;
    }

    /**
     * Return the instance as IRETProperty
     * 
     * @return IRETProperty the ReqM2InputData object of type IRETProperty
     */
    public static IRETProperty getRETProperty() {
        return getInstance();
    }

    /**
     * Return the instance as IRETData
     * 
     * @return IRETData
     */
    public static IRETData getRETData() {
        return getInstance();
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * eb.ret.core.reqm2.data.IRETProperty#setReqM2Property(org.eclipse.core
     * .resources.IProject, eb.ret.core.reqm2.data.ReqM2Property)
     */
    @Override
    public void setReqM2Property( final IProject project, final ReqM2Property property ) {

        final Map<String, String> propMap = new HashMap<String, String>();
        // set the input directories only if propertypage is not cancelled
        if( !property.isCancelled() ) {
            propMap.put( INPUT_DIR_KEY, property.getDirectoryListString() );
        }
        propMap.put( DOCTYPES_KEY, property.getDocTypePreferenceString() );
        saveRETProperty( project, propMap );
    }

    /**
     * Returns IEclipsePreferences of the project
     * 
     * @param project the project
     * @return IEclipsePreferences IEclipsePreferences of project
     */
    private IEclipsePreferences getRETProjectPreference( final IProject project ) {
        final ProjectScope projectSope = new ProjectScope( project );
        return projectSope.getNode( RETPlugin.PLUGIN_ID );
    }

    /**
     * Returns the ReqM2Property of corresponding project
     * 
     * @param project the project which properties to get
     * @return ReqM2Property
     */
    private ReqM2Property getReqM2Property( final IProject project ) {
        final IEclipsePreferences prefs = getRETProjectPreference( project );
        final String propertyString = prefs.get( INPUT_DIR_KEY, "" );
        final String docTypeString = prefs.get( DOCTYPES_KEY, "" );
        return new ReqM2Property( propertyString, docTypeString );
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * eb.ret.core.reqm2.data.IRETData#isReqM2PropertiesSet(org.eclipse.core
     * .resources.IProject)
     */
    @Override
    public boolean isRETPropertiesSet( final IProject project ) {
        final List<String> reqM2Property = getRETData().getDirectoriesPath( project );

        if( reqM2Property == null || (reqM2Property != null && reqM2Property.isEmpty()) ) {
            return false;
        }
        return true;
    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2PreferencePage,1
     */
    /**
     * Return the interface into the preference mechanism
     * 
     * @return IPreferencesService
     */
    private IPreferencesService getPreferenceService() {
        return Platform.getPreferencesService();
    }

    @Override
    public List<String> getDirectoriesPath( final IProject project ) {
        return getReqM2Property( project ).getInputDirectoryPaths();
    }

    @Override
    public List<RETDirectory> getRETInputDirectories( final IProject project ) {
        return getReqM2Property( project ).getInputDirectories();
    }

    @Override
    public List<String> getDocTypes( final IProject project ) {
        return getReqM2Property( project ).getDocTypes();
    }

    @Override
    public String getBrowserSelection() {
        return getPreferenceService().getString( RETPlugin.PLUGIN_ID,
                                                 KEY_REQM2_BROWSER,
                                                 BrowserType.ECLIPSE.toString(),
                                                 null );
    }

    @Override
    public String getPerlLocation() {
        return getPreferenceService().getString( RETPlugin.PLUGIN_ID, KEY_REQM2_PERL, null, null );
    }

    @Override
    public String getReqM2Location() {
        return getPreferenceService().getString( RETPlugin.PLUGIN_ID, KEY_REQM2_TOOL, null, null );
    }

    @Override
    public boolean isRETPreferencesSet() {
        boolean hasPreference = false;
        if( getBrowserSelection() != null && getPerlLocation() != null && getReqM2Location() != null ) {
            hasPreference = true;
        }

        return hasPreference;
    }

    @Override
    public String getSpecObjColumnProperty() {
        final IEclipsePreferences prefs = InstanceScope.INSTANCE.getNode( RETPlugin.PLUGIN_ID );
        return prefs.get( SPEC_COL_KEY, "" );
    }

    @Override
    public void setSpecObjColumnProperty( final String columnString ) {
        final IEclipsePreferences prefs = InstanceScope.INSTANCE.getNode( RETPlugin.PLUGIN_ID );
        prefs.put( SPEC_COL_KEY, columnString );
    }

    /**
     * helper method to save the properties given in propMap to the project's preference store
     * 
     * @param project
     * @param propMap
     */

    private void saveRETProperty( final IProject project, final Map<String, String> propMap ) {
        final IEclipsePreferences prefs = getRETProjectPreference( project );
        String errorKey = null;
        for( final String key : propMap.keySet() ) {
            errorKey = key;
            prefs.put( key, propMap.get( key ) );
        }

        try {
            prefs.flush();
        } catch( final BackingStoreException e ) {
            /*
             * In the scenario of preference files getting updated externally
             * Retry after refresh the settings folder for the project
             */
            try {
                project.findMember( PROJ_SETTINGS )
                       .refreshLocal( IResource.DEPTH_INFINITE, new NullProgressMonitor() );
                prefs.flush();
            } catch( final Exception e1 ) {
                ErrorLogger.logError( "Error while saving " + errorKey + " properties", e );
            }

        }

    }

}