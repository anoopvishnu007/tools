package eb.ret.core.model;

import eb.ret.core.model.data.ISpecObjectData;
import eb.ret.core.model.data.ISpecObjectModel;
import eb.ret.core.model.data.SpecObjectData;
import eb.ret.core.model.data.SpecObjectModel;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;

/**
 * This class handles the creation and modification of specobject memory model.
 * 
 * @author tintobaby
 * 
 */
public final class SpecObjectResourceManager {

    /**
     * Private instance for the singleton class
     */
    private static SpecObjectResourceManager manager;

    /**
     * Singleton instance of SpecObjectData
     */
    private static ISpecObjectData specObjectData = null;

    /**
     * Singleton instance of SpecObjectModel
     */
    private static ISpecObjectModel specObjectModel = null;

    /**
     * private constructor declaring SpecObjectResourceManager as singleton.
     */
    private SpecObjectResourceManager() {
    }

    /**
     * To get access to instance of SpecObjectResourceManager.
     * 
     * @return SpecObjectResourceManager singleton instance.
     */
    public static SpecObjectResourceManager getInstance() {

        synchronized (SpecObjectResourceManager.class) {
            if( manager == null ) {
                manager = new SpecObjectResourceManager();
            }
        }
        return manager;
    }

    /**
     * To get access to instance of SpecObjectData.
     * 
     * @return SpecObjectData singleton instance.
     */
    public ISpecObjectData getSpecObjectData() {
        synchronized (SpecObjectData.class) {
            if( specObjectData == null ) {
                specObjectData = new SpecObjectData();
            }
        }
        return specObjectData;
    }

    /**
     * To get access to instance of SpecObjectModel.
     * 
     * @return SpecObjectModel singleton instance.
     */
    public ISpecObjectModel getSpecObjectModel() {
        synchronized (SpecObjectModel.class) {
            if( specObjectModel == null ) {
                specObjectModel = new SpecObjectModel();
            }
        }
        return specObjectModel;
    }

    /**
     * Remove Resource corresponding to the given IFile from ResourceSet.
     * 
     * @param resFile file associated with the resource.
     */
    public void removeSpecObjectResource( final IFile resFile ) {
        final URI modelUri = getFileUri( resFile );
        getSpecObjectModel().removeSpecObjectResource( modelUri );
    }

    /*
     * !LINKSTO eclipse.ret.req.UniqueSpecObjectModel,1
     */
    /**
     * Load a resource corresponding to the given IFile.
     * 
     * @param resFile resource file.
     */
    public void loadSpecObjectResource( final IFile resFile ) {
        final URI modelUri = getFileUri( resFile );
        getSpecObjectModel().loadSpecObjectResource( modelUri );
    }

    /**
     * create PlatformResourceURI for the given IFile.
     * 
     * @param file
     * @return Platform URI for the given IFile.
     */
    private URI getFileUri( final IFile file ) {
        final IPath filePth = Path.fromOSString( file.getFullPath().toString() );
        return URI.createPlatformResourceURI( filePth.toString(), true );
    }
}
