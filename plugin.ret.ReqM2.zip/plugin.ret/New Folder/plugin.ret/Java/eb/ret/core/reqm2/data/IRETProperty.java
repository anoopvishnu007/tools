package eb.ret.core.reqm2.data;

import org.eclipse.core.resources.IProject;

/**
 * Interface for setting RET properties
 * 
 * @author nikhilcr
 */
public interface IRETProperty {

    /**
     * Setting the ReqM2 property of a project
     * 
     * @param project the project to set the ReqM2 property
     * @param property the ReqM2 property to set
     */
    void setReqM2Property( IProject project, ReqM2Property property );

    /**
     * For setting the specobject view's column preference to the worspace's preference store
     * 
     * @param project
     * @param columnString
     */
    void setSpecObjColumnProperty( String columnString );

    /**
     * For getting the specobject view's column preference from the worspace's preference store
     * 
     * @param project the project for which the property has to be stored
     * @return
     */
    String getSpecObjColumnProperty();

}