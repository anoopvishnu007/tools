/**
 * 
 */
package eb.ret.core.model.data;

import eb.ret.model.specobject.impl.FormattedtextTImpl;
import eb.ret.model.specobject.impl.SpecobjectTypeImpl;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.FeatureMap.ValueListIterator;
import org.eclipse.emf.query.conditions.eobjects.EObjectCondition;
import org.eclipse.emf.query.conditions.eobjects.structuralfeatures.EStructuralFeatureValueGetter;
import org.eclipse.emf.query.conditions.eobjects.structuralfeatures.IEStructuralFeatureValueGetter;

import java.util.ArrayList;
import java.util.List;

/**
 * Value getter class for FormattedTextImpl type
 * 
 * @author anoopvn
 * 
 */
public class FormattedTextValueGetter implements IEStructuralFeatureValueGetter {

    /* (non-Javadoc)
     * @see org.eclipse.emf.query.conditions.eobjects.structuralfeatures.IEStructuralFeatureValueGetter#eContents(org.eclipse.emf.ecore.EObject, org.eclipse.emf.query.conditions.eobjects.EObjectCondition)
     */
    @Override
    public List<EObject> eContents( final EObject eObject, final EObjectCondition filterCondition ) {
        return EStructuralFeatureValueGetter.getInstance().eContents( eObject, filterCondition );
    }

    /* (non-Javadoc)
     * @see org.eclipse.emf.query.conditions.eobjects.structuralfeatures.IEStructuralFeatureValueGetter#eGet(org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EStructuralFeature, boolean)
     */
    @Override
    public Object eGet( final EObject eObject, final EStructuralFeature eFeature, final boolean resolve ) {
        if( eObject instanceof SpecobjectTypeImpl ) {
            return (((SpecobjectTypeImpl)eObject).getDescription().getPre().get( 0 ));
        }
        if( eObject instanceof FormattedtextTImpl ) {
            final List<String> list = new ArrayList<String>();
            final FeatureMap map = (((FormattedtextTImpl)eObject).getMixed());
            for( final ValueListIterator<Object> iterator = map.valueListIterator(); iterator.hasNext(); ) {
                final Object entry = iterator.next();
                if( entry instanceof String ) {
                    list.add( (String)entry );
                }
            }
            return list;
        }

        return null;
    }

    /* (non-Javadoc)
     * @see org.eclipse.emf.query.conditions.eobjects.structuralfeatures.IEStructuralFeatureValueGetter#resolve(org.eclipse.emf.ecore.EObject)
     */
    @Override
    public EObject resolve( final EObject eObject ) {
        return EStructuralFeatureValueGetter.getInstance().resolve( eObject );
    }

}
