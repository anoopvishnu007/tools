package eb.ret.core.model.data;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.util.PatternConstructor;

import org.eclipse.emf.query.statements.SELECT;
import org.eclipse.search.core.text.TextSearchScope;
import org.eclipse.search.ui.text.FileTextSearchScope;

import java.util.regex.Pattern;

/**
 * Parameter value object for model search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchParams {

    /**
     * Stores the value of search is case sensitive or not
     */
    private boolean caseSensitive;
    /**
     * Stores the value of search is a regular expression or not
     */
    private boolean regExSearch;
    /**
     * Stores the search string
     */
    private String searchString;
    /**
     * Stores the specobject id search limitto type
     */
    private LimitToType limitToType;
    /**
     * Stores the search type
     */
    private SearchForType searchFor;
    /**
     * Stores the search pattern
     */
    private Pattern searchPattern;
    /**
     * Stores the search scope
     */
    private FileTextSearchScope scope;
    /**
     * specifying whether search is a whole word search
     */
    private boolean wholeWordSearch;
    /**
     * Stores the result size
     */
    private int resultSize = SELECT.UNBOUNDED;

    /**
     * Constructor
     * 
     * @param caseSensitive
     * @param regExSearch
     * @param searchString
     * @param limitToType
     * @param searchFor
     */
    public SpecObjectSearchParams( final boolean caseSensitive,
                                   final boolean regExSearch,
                                   final String searchString,
                                   final LimitToType limitToType,
                                   final SearchForType searchFor ) {

        this( caseSensitive, regExSearch, true, searchString, limitToType, searchFor, null, null );

    }

    /**
     * Constructor
     * 
     * @param caseSensitive
     * @param regExSearch
     * @param wholeWordSearch
     * @param searchString
     * @param limitToType
     * @param searchFor
     * @param searchPattern
     * @param scope
     */
    public SpecObjectSearchParams( final boolean caseSensitive,
                                   final boolean regExSearch,
                                   final boolean wholeWordSearch,
                                   final String searchString,
                                   final LimitToType limitToType,
                                   final SearchForType searchFor,
                                   final Pattern searchPattern,
                                   final TextSearchScope scope ) {
        super();
        this.caseSensitive = caseSensitive;
        this.regExSearch = regExSearch;
        this.searchString = searchString;
        this.limitToType = limitToType;
        this.searchFor = searchFor;
        this.searchPattern = searchPattern;
        this.scope = (FileTextSearchScope)scope;
        this.wholeWordSearch = wholeWordSearch;
    }

    /**
     * Model search parameter enum for limit to type
     * 
     * @author anoopvn
     * 
     */
    public enum LimitToType {
        ALL( "All", 0 ), DECLARATIONS( "Declarations", 1 ), REFERENCES( "References", 2 );
        private final String name;
        private final int value;

        public String getName() {
            return name;
        }

        public int getValue() {
            return value;
        }

        private LimitToType( final String name, final int value ) {
            this.name = name;
            this.value = value;
        }

        public static LimitToType get( final int value ) {
            for( final LimitToType limitTo : LimitToType.values() ) {
                if( limitTo.getValue() == value ) {
                    return limitTo;
                }
            }
            return ALL;
        }
    }

    /**
     * Model search parameter enum for search for
     * 
     * @author anoopvn
     * 
     */
    public enum SearchForType {
        ID( "Id", 0 ), DESCRIPTION( "Description", 1 ), COMMENTS( "Comments", 2 );
        private final String name;
        private final int value;

        public String getName() {
            return name;
        }

        public int getValue() {
            return value;
        }

        private SearchForType( final String name, final int value ) {
            this.name = name;
            this.value = value;
        }

        public static SearchForType get( final int value ) {
            for( final SearchForType searchFor : SearchForType.values() ) {
                if( searchFor.getValue() == value ) {
                    return searchFor;
                }
            }
            return ID;
        }

    }

    /**
     * Returns the search is case sensitive or not
     * 
     * @return
     */
    public boolean isCaseSensitive() {
        return caseSensitive;
    }

    /**
     * Sets the search is case sensitive or not
     * 
     * @param isCaseSensitive
     */
    public void setCaseSensitive( final boolean isCaseSensitive ) {
        this.caseSensitive = isCaseSensitive;
    }

    /**
     * Returns the search string is regular expression or not
     * 
     * @return
     */
    public boolean isRegExSearch() {
        return regExSearch;
    }

    /**
     * Sets the search string is regular expression or not
     * 
     * @param isRegExSearch
     */
    public void setRegExSearch( final boolean isRegExSearch ) {
        this.regExSearch = isRegExSearch;
    }

    /**
     * Returns the search string
     * 
     * @return
     */
    public String getSearchString() {
        return searchString;
    }

    /**
     * Sets the search string
     * 
     * @param textPattern search string
     */
    public void setSearchString( final String textPattern ) {
        this.searchString = textPattern;
    }

    /**
     * Gets the search limit to type
     * 
     * @return
     */
    public LimitToType getLimitToType() {
        return limitToType;
    }

    /**
     * Sets the search limit to type
     * 
     * @param limitToType
     */
    public void setLimitToType( final LimitToType limitToType ) {
        this.limitToType = limitToType;
    }

    /**
     * Gets the search for type
     * 
     * @return
     */
    public SearchForType getSearchFor() {
        return searchFor;
    }

    /**
     * Sets the search for type of search
     * 
     * @param searchFor
     */
    public void setSearchFor( final SearchForType searchFor ) {
        this.searchFor = searchFor;
    }

    /**
     * Gets the search pattern
     * 
     * @return
     */
    public Pattern getSearchPattern() {

        if( searchPattern == null && searchString != null ) {
            try {
                return PatternConstructor.createPattern( searchString,
                                                         isCaseSensitive(),
                                                         isRegExSearch(),
                                                         isWholeWordSearch() );
            } catch( final Exception e ) {
                ErrorLogger.logError( "Error while getting search Pattern ", e );
            }
        }
        return searchPattern;
    }

    /**
     * Gets the search pattern
     * 
     * @param searchPattern
     */
    public void setSearchPattern( final Pattern searchPattern ) {
        this.searchPattern = searchPattern;
    }

    /**
     * Gets the search scope
     * 
     * @return the scope
     */
    public FileTextSearchScope getScope() {
        return scope;
    }

    /**
     * Sets the search scope
     * 
     * @param scope
     */
    public void setScope( final FileTextSearchScope scope ) {
        this.scope = scope;
    }

    /**
     * Gets the search result size
     * 
     * @return
     */
    public int getResultSize() {
        return resultSize;
    }

    /**
     * Sets the search result size
     * 
     * @param resultSize
     */
    public void setResultSize( final int resultSize ) {
        this.resultSize = resultSize;
    }

    /**
     * Gets the whole word search parameter
     * 
     * @return the wholeWordSearch
     */
    public boolean isWholeWordSearch() {
        return wholeWordSearch;
    }

    public void setWholeWordSearch( final boolean wholeWordSearch ) {
        this.wholeWordSearch = wholeWordSearch;
    }

}
