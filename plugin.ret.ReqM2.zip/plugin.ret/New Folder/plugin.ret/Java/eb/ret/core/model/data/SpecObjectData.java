package eb.ret.core.model.data;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecObjectPackage;
import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;
import org.eclipse.emf.query.conditions.eobjects.EObjectCondition;
import org.eclipse.emf.query.conditions.eobjects.EObjectTypeRelationCondition;
import org.eclipse.emf.query.conditions.eobjects.structuralfeatures.EObjectAttributeValueCondition;
import org.eclipse.emf.query.conditions.eobjects.structuralfeatures.EObjectReferenceValueCondition;
import org.eclipse.emf.query.conditions.strings.StringAdapter;
import org.eclipse.emf.query.conditions.strings.StringRegularExpressionValue;
import org.eclipse.emf.query.conditions.strings.StringValue;
import org.eclipse.emf.query.statements.FROM;
import org.eclipse.emf.query.statements.IQueryResult;
import org.eclipse.emf.query.statements.SELECT;
import org.eclipse.emf.query.statements.WHERE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Provides necessary data from Specobject model.
 * 
 * @author tintobaby
 * 
 */
public final class SpecObjectData implements ISpecObjectData

{
    /**
     * Warning message for multiple specobject with same id
     */
    private static final String MSG_MUL_SPECOBJ = "More than one specobject exist with the id ";
    /**
     * First index used to get the Object from the List
     */
    private static final int FIRST_INDEX = 0;

    /*
     * !LINKSTO eclipse.ret.req.SpecObjectModelById,1
     */
    /**
     * {@link ISpecObjectData}
     * 
     * Returns the first occurrence of specobject with the given specObjectId
     */
    @Override
    public SpecobjectType getSpecObject( final String specObjectId ) {
        final List<SpecobjectType> specobjList = getSpecObjectList( specObjectId );
        SpecobjectType specobject = null;
        if( !specobjList.isEmpty() ) {
            if( specobjList.size() > 1 ) {
                ErrorLogger.logWarning( MSG_MUL_SPECOBJ + specObjectId, null );
            }
            specobject = specobjList.get( FIRST_INDEX );
        }
        return specobject;
    }

    /**
     * {@link ISpecObjectData}
     * 
     * Implements ModelQuery for querying SpecObject Resource with the given specObjectId.
     */
    @Override
    public List<SpecobjectType> getSpecObjectList( final String specObjectId ) {
        final EObjectCondition condition = new EObjectAttributeValueCondition(
            SpecObjectPackage.eINSTANCE.getSpecobjectType_Id(),
            new StringValue( specObjectId ) );

        final SELECT selectStatement = new SELECT( new FROM( getResourceContents() ), new WHERE( condition ) );

        List<SpecobjectType> specobjectList = new ArrayList<SpecobjectType>();
        // Execute query
        final IQueryResult result = selectStatement.execute(); //NOPMD - ModelQuery ResultSet need not be closed.
        if( !result.isEmpty() ) {
            final SpecobjectType[] specObjeArray = new SpecobjectType[result.getEObjects().size()];
            specobjectList = Arrays.asList( result.getEObjects().toArray( specObjeArray ) );

        }
        return specobjectList;
    }

    @Override
    public List<SpecobjectType> getSpecObjectList( final SpecObjectSearchParams params ) {
        List<SpecobjectType> specobjectList = new ArrayList<SpecobjectType>();
        //build the select statement query
        final SELECT selectStmt = getStatement( params );
        // Execute query
        final IQueryResult result = selectStmt.execute(); //NOPMD - ModelQuery ResultSet need not be closed.
        if( !result.isEmpty() ) {
            final SpecobjectType[] specObjeArray = new SpecobjectType[result.getEObjects().size()];
            specobjectList = Arrays.asList( result.getEObjects().toArray( specObjeArray ) );

        }
        return specobjectList;

    }

    /**
     * Gets the select statement for querying in the model
     * 
     * @param params search parameters
     * @return SELECT statement with parameter conditions
     */
    private SELECT getStatement( final SpecObjectSearchParams params ) {
        int resultSize = SELECT.UNBOUNDED;
        if( params.getResultSize() > 0 ) {
            resultSize = params.getResultSize();
        }
        return new SELECT( resultSize, new FROM( getResourceContents() ), new WHERE( getCondition( params ) ) );
    }

    /**
     * Gets the condition for the select statement
     * 
     * @param params search parameters
     * @return the condition
     */
    private EObjectCondition getCondition( final SpecObjectSearchParams params ) {
        EObjectCondition condition = null;
        //description and the comments are formatted text type and id is an attribute
        switch (params.getSearchFor()) {
            case COMMENTS:
                condition = getFormattedTextCondition( params, SpecObjectPackage.Literals.SPECOBJECT_TYPE__COMMENT );
                break;

            case DESCRIPTION:
                condition = getFormattedTextCondition( params,
                                                       SpecObjectPackage.Literals.SPECOBJECT_TYPE__DESCRIPTION );
                break;
            case ID:
            default:
                condition = getSpecObjectIdCondition( params );
                break;
        }

        return condition;
    }

    /**
     * gets the specobject id condition according to the limitto types
     * 
     * @param params search parameters
     * @return the condition
     */
    private EObjectCondition getSpecObjectIdCondition( final SpecObjectSearchParams params ) {

        EObjectCondition condition = null;
        switch (params.getLimitToType()) {
            case REFERENCES:
                condition = getReferencesCondition( params );
                break;
            case DECLARATIONS:
                condition = getDeclarationCondition( params );
                break;
            case ALL:
                condition = getReferencesCondition( params ).OR( getDeclarationCondition( params ) );
                break;
            default:
                break;
        }

        return condition;

    }

    /**
     * Gets specobject declaration condition
     * 
     * @param params search parameters
     * @return the condition
     */
    private EObjectCondition getDeclarationCondition( final SpecObjectSearchParams params ) {
        //searches the pattern in the id field of specobjects 
        final EObjectCondition condition = new EObjectAttributeValueCondition(
            SpecObjectPackage.eINSTANCE.getSpecobjectType_Id(),
            new StringRegularExpressionValue(
                params.getSearchPattern().pattern(),
                params.isCaseSensitive(),
                StringAdapter.DEFAULT ) );

        return condition;

    }

    /**
     * 
     * Gets the specobject references condition
     * 
     * @param params search parameters
     * @return the condition
     */
    private EObjectCondition getReferencesCondition( final SpecObjectSearchParams params ) {
        //searches the specobject id references in the provides coverage section or in the links section
        final EObjectCondition provCovCondition = getProvidesCoverageCondition( params );
        final EObjectCondition linksCondition = getLinksCondition( params );
        return provCovCondition.OR( linksCondition );

    }

    /**
     * Gets the specobject references using Links element condition
     * 
     * @param params search parameters
     * @return the condition
     */
    private EObjectCondition getLinksCondition( final SpecObjectSearchParams params ) {
        //searches pattern in the links field
        final EObjectCondition attrCondition = new EObjectAttributeValueCondition(
            XMLTypePackage.eINSTANCE.getAnyType_Mixed(),
            new StringRegularExpressionValue(
                params.getSearchPattern().pattern(),
                params.isCaseSensitive(),
                StringAdapter.DEFAULT ), new AnyTypeValueGetter() );
        //taking the reference object of link type target field
        final EObjectCondition targetCondition = new EObjectReferenceValueCondition(
            SpecObjectPackage.Literals.LINK_TYPE__TARGET,
            attrCondition );
        //taking the reference object of link type field
        final EObjectCondition linkTypeCondition = new EObjectReferenceValueCondition(
            SpecObjectPackage.Literals.LINKS_TYPE__LINK,
            targetCondition );
        //taking the reference object of specobject link type field
        final EObjectCondition linksCondition = new EObjectReferenceValueCondition(
            SpecObjectPackage.Literals.SPECOBJECT_TYPE__LINKS,
            linkTypeCondition );
        return linksCondition;
    }

    /**
     * Gets the specobject references using provides coverage element condition
     * 
     * @param params search parameters
     * @return the condition
     */
    private EObjectCondition getProvidesCoverageCondition( final SpecObjectSearchParams params ) {
        //taking the reference object of provides coverage link type field
        final EObjectCondition linkstoCondition = new EObjectReferenceValueCondition(
            SpecObjectPackage.Literals.PROVIDESCOVERAGE_TYPE__PROVCOV,
            new EObjectAttributeValueCondition(
                SpecObjectPackage.Literals.PROVCOV_TYPE__LINKSTO,
                new StringRegularExpressionValue(
                    params.getSearchPattern().pattern(),
                    params.isCaseSensitive(),
                    StringAdapter.DEFAULT ) ) );
        //taking the reference object of specobject provides coverage type field
        final EObjectCondition provCovCondition = new EObjectReferenceValueCondition(
            new EObjectTypeRelationCondition( SpecObjectPackage.Literals.SPECOBJECT_TYPE ),
            SpecObjectPackage.Literals.SPECOBJECT_TYPE__PROVIDESCOVERAGE,
            linkstoCondition );
        return provCovCondition;
    }

    /**
     * Gets the condition to obtain the EReference value which is of type FormattedTextType
     * 
     * @param params search parameters
     * @param reference EReference object
     * @return the condition
     */
    private EObjectCondition getFormattedTextCondition( final SpecObjectSearchParams params,
                                                        final EReference reference ) {

        final EObjectCondition attrCondition = new EObjectAttributeValueCondition(
            SpecObjectPackage.eINSTANCE.getFormattedtextT_Mixed(),
            new StringRegularExpressionValue(
                params.getSearchPattern().pattern(),
                params.isCaseSensitive(),
                StringAdapter.DEFAULT ), new FormattedTextValueGetter() );

        return new EObjectReferenceValueCondition( reference, attrCondition );

    }

    /**
     * Gets all the EObjects present in the model
     * 
     * @return list of EObjects
     */
    private static EList<EObject> getResourceContents() {
        final EList<EObject> contentList = new BasicEList<EObject>();
        final ResourceSet resSet = SpecObjectResourceManager.getInstance()
                                                            .getSpecObjectModel()
                                                            .getSpecObjectResourceSet();
        final EList<Resource> resList = resSet.getResources();
        for( final Resource resource : resList ) {
            contentList.addAll( resource.getContents() );
        }

        return contentList;
    }

    @Override
    public List<SpecobjectType> getLinkedSpecObjects( final String specObjectId ) {

        final SpecObjectSearchParams refParams = new SpecObjectSearchParams(
            true,
            false,
            specObjectId,
            LimitToType.REFERENCES,
            SearchForType.ID );

        return getSpecObjectList( refParams );
    }

}
