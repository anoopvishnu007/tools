package eb.ret.core.reqm2.data;

/**
 * Represents the input directory for the reqm2 tool
 * 
 */
public class RETDirectory {
    /**
     * Stores the complete path of the directory
     */
    private String path;
    /**
     * Stores the importer type associated with the directory
     */
    private ImporterType importer = ImporterType.DOCBOOK;
    /**
     * Stores docType associated with the directory
     */
    private String docType;

    /**
     * Returns the complete path of the directory
     * 
     * @return String
     */
    public String getPath() {
        return path;
    }

    /**
     * Sets the complete path of the directory
     * 
     * @param path
     */
    public void setPath( final String path ) {
        this.path = path;
    }

    /**
     * Returns the importer type of the directory
     * 
     * @return String
     */
    public ImporterType getImporter() {
        return importer;
    }

    /**
     * Sets the importer type to the directory
     * 
     * @param importer
     */
    public void setImporter( final ImporterType importer ) {
        this.importer = importer;
    }

    /**
     * Returns the docType of the directory
     * 
     * @return String
     */
    public String getDocType() {
        return docType;
    }

    /**
     * Sets the docType to the directory
     * 
     * @param docType
     */
    public void setDocType( final String docType ) {
        this.docType = docType;
    }

    /**
     * determines whether the docType is editable for the directory. DocType shall be editable only for generic
     * importers
     * 
     * @return
     */
    public boolean isDocTypeEditable() {
        if( importer == ImporterType.GENERIC ) {
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return 31 * path.hashCode() * importer.hashCode() * docType.hashCode();
    }

    @Override
    public boolean equals( final Object obj ) {
        if( obj == null ) {
            return false;
        }
        if( obj == this ) {
            return true;
        }
        if( obj.getClass() != getClass() ) {
            return false;
        }
        final RETDirectory dir = (RETDirectory)obj;
        if( this.getPath() != dir.getPath()
            || this.getImporter() != dir.getImporter()
            || this.getDocType() != dir.getDocType() ) {
            return false;
        }
        return true;
    }

}
