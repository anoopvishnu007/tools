package eb.ret.core.reqm2.builder;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.reqm2.ReqM2Manager;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;

/**
 * @author Kiren SK
 * @version 1.0
 * @created 17-Aug-2012 5:18:30 PM
 * 
 *          RETResourceVisitor handles each of the RET Files for a RET full build.
 * 
 */
public class RETResourceVisitor implements IResourceVisitor {

    /*
     * (non-Javadoc)
     * @see org.eclipse.core.resources.IResourceVisitor#visit(org.eclipse.core.resources.IResource)
     * Implementation for visiting a resource in RET Full build.
     */

    @Override
    public boolean visit( final IResource resource ) throws CoreException {
        final ReqM2Manager manager = ReqM2Manager.getInstance();

        if( resource.getType() == IResource.FILE ) {
            if( manager.isRETDirectory( resource ) ) {
                manager.processReqM2File( (IFile)resource );
            } else if( manager.isReqM2OutputFile( (IFile)resource ) ) {
                //!LINKSTO eclipse.ret.req.SpecObjectModelSync,1
                SpecObjectResourceManager.getInstance().loadSpecObjectResource( (IFile)resource );
            }
        }
        return true;
    }
}