package eb.ret.text.refactoring.rename;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.model.data.ISpecObjectData;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.helper.SpecObjectEditorUtil;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.ltk.core.refactoring.Change;
import org.eclipse.ltk.core.refactoring.CompositeChange;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.ltk.core.refactoring.TextFileChange;
import org.eclipse.ltk.core.refactoring.participants.CheckConditionsContext;
import org.eclipse.ltk.core.refactoring.participants.RefactoringParticipant;
import org.eclipse.ltk.core.refactoring.participants.RefactoringProcessor;
import org.eclipse.ltk.core.refactoring.participants.SharableParticipants;
import org.eclipse.ltk.core.refactoring.participants.ValidateEditChecker;
import org.eclipse.text.edits.MalformedTreeException;
import org.eclipse.text.edits.MultiTextEdit;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Processor class for renaming a specobject
 * 
 * @author kirensk
 * 
 */
public class SpecObjectRenameProcessor extends RefactoringProcessor {

    /**
     * Message shown if the entered text came as null
     */
    private static final String MSG_NULL_TEXT = "Cannot Replace with a null text";
    /**
     * The processor name for the specobject rename
     */
    private static final String PROCESSOR_NAME = "SpecObjectRenameProcessor";
    /**
     * The rename details which should come from user input
     */
    private final RenameData renameData;
    /**
     * Private instance of the specobject for which rename is triggered
     */
    private SpecobjectType specObject;
    /**
     * The list of referenced specobjects to the specObject instance
     */
    private List<SpecobjectType> referencedList;
    /**
     * A map file to store a single change corresponding for a file's IPath
     */
    private Map<IPath, TextFileChange> changeMap = new HashMap<IPath, TextFileChange>();

    /**
     * Constructor with user input data
     * 
     * @param data
     */
    public SpecObjectRenameProcessor( final RenameData data ) {
        super();
        this.renameData = data;
    }

    @Override
    public Object[] getElements() {
        return new Object[]{specObject};
    }

    @Override
    public String getIdentifier() {
        return renameData.getSpecObject().getId();
    }

    @Override
    public String getProcessorName() {

        return PROCESSOR_NAME;
    }

    @Override
    public boolean isApplicable() throws CoreException {
        if( renameData.getSpecObject() != null ) {
            return true;
        }
        return false;
    }

    @Override
    public RefactoringStatus checkInitialConditions( final IProgressMonitor monitor )
        throws CoreException,
        OperationCanceledException {
        final RefactoringStatus status = new RefactoringStatus();
        if( renameData.getSpecObject() == null ) {
            status.addFatalError( MSG_NULL_TEXT );
        }
        return status;
    }

    @Override
    public RefactoringStatus checkFinalConditions( final IProgressMonitor monitor,
                                                   final CheckConditionsContext context )
        throws CoreException,
        OperationCanceledException {

        final RefactoringStatus status = new RefactoringStatus();

        if( renameData.getSpecObject() == null || renameData.getNewText() == null ) {
            status.addFatalError( MSG_NULL_TEXT );
            return status;
        }

        RenameEditDetector.checkIdConditions( renameData, status, monitor );

        if( status.hasFatalError() ) {
            return status;
        }

        try {
            final ValidateEditChecker checker = (ValidateEditChecker)context.getChecker( ValidateEditChecker.class );

            setSourceFile( checker );
            collectReferencedSourceFiles( checker );
            status.merge( checker.check( monitor ) );
        } catch( final Exception e ) {
            status.addFatalError( "Exception while collecting files" + e.getMessage() );
        }
        return status;
    }

    @Override
    public Change createChange( final IProgressMonitor monitor ) throws CoreException, OperationCanceledException {

        //initialize fresh change map
        changeMap = new HashMap<IPath, TextFileChange>();

        //create a composite change to hold the specobject changesS
        final CompositeChange rootChange = new CompositeChange( getIdentifier() );
        rootChange.markAsSynthetic();

        //determine and collect the changes in changeMap
        try {
            determineDeclarationChange( monitor );
            determineReferenceChanges( monitor );
            final Collection<TextFileChange> changes = changeMap.values();
            if( !changes.isEmpty() ) {
                rootChange.addAll( changes.toArray( new Change[changes.size()] ) );
            }

        } catch( final MalformedTreeException e ) {
            ErrorLogger.logError( e.getMessage(), e );
        } catch( final IOException e ) {
            ErrorLogger.logError( e.getMessage(), e );
        } catch( final BadLocationException e ) {
            ErrorLogger.logError( e.getMessage(), e );
        }

        return rootChange;
    }

    /**
     * Collects the specobjects in the resource referring the renamed specObject. Reference can be either through
     * linksto or links element
     * 
     * @param editChecker
     */
    private void collectReferencedSourceFiles( final ValidateEditChecker editChecker ) {
        final ISpecObjectData data = SpecObjectResourceManager.getInstance().getSpecObjectData();
        referencedList = data.getLinkedSpecObjects( specObject.getId() );

        if( editChecker != null ) {
            for( final SpecobjectType specObject : referencedList ) {
                final IFile file = SpecObjectEditorUtil.getSourceFile( specObject );
                editChecker.addFile( file );
            }
        }

    }

    /**
     * Determines the sourcefile of the renamed specobject. This is added to the editChecker also
     * 
     * @param editChecker
     */
    private void setSourceFile( final ValidateEditChecker editChecker ) {
        specObject = renameData.getSpecObject();
        final IFile file = SpecObjectEditorUtil.getSourceFile( specObject );
        if( editChecker != null ) {
            editChecker.addFile( file );
        }

    }

    /**
     * If updateReference is checked by the user, determine the changes for referenced specobjects
     * 
     * @param monitor
     * @throws MalformedTreeException
     * @throws CoreException
     * @throws IOException
     * @throws BadLocationException
     */
    private void determineReferenceChanges( final IProgressMonitor monitor )
        throws MalformedTreeException,
        CoreException,
        IOException,
        BadLocationException {
        if( renameData.isUpdateReferences() ) {
            for( final SpecobjectType refSpecObject : referencedList ) {
                final TextFileChange fileChange = (TextFileChange)getFileChange( refSpecObject );
                RenameEditDetector.setReferenceRenameEdits( fileChange, renameData, refSpecObject, monitor );
            }
        }
    }

    /**
     * Determines the changes in the declared specobject
     * 
     * @param monitor
     * @throws MalformedTreeException
     * @throws CoreException
     * @throws IOException
     * @throws BadLocationException
     */

    private void determineDeclarationChange( final IProgressMonitor monitor )
        throws MalformedTreeException,
        CoreException,
        IOException,
        BadLocationException {

        final TextFileChange fileChange = (TextFileChange)getFileChange( specObject );
        RenameEditDetector.setDeclarationRenameEdits( fileChange, renameData, monitor );

    }

    /**
     * Determines the TextFileChange for a specific specObject
     * 
     * @param specObject
     * @return
     * @throws MalformedTreeException
     * @throws CoreException
     * @throws IOException
     * @throws BadLocationException
     */
    private Change getFileChange( final SpecobjectType specObject )
        throws MalformedTreeException,
        CoreException,
        IOException,
        BadLocationException {

        final IFile file = SpecObjectEditorUtil.getSourceFile( specObject );
        Change fileChange = changeMap.get( file.getFullPath() );
        if( fileChange == null ) {
            fileChange = getTextFileChange( file );
        }

        return fileChange;
    }

    /**
     * Checks the changeMap for the change corresponding for a file. If not exists create and store a fresh change for
     * the file
     * 
     * @param file
     * @return
     */
    private Change getTextFileChange( final IFile file ) {
        final TextFileChange change = new TextFileChange( file.getName(), file );
        //Set the root edit to contain multiple changes
        final MultiTextEdit rootEdit = new MultiTextEdit();
        change.setEdit( rootEdit );
        //store the change for a corresponding file
        changeMap.put( file.getFullPath(), change );

        return change;
    }

    @Override
    public RefactoringParticipant[] loadParticipants( final RefactoringStatus status,
                                                      final SharableParticipants sharedPart ) throws CoreException {
        return null;
    }

}
