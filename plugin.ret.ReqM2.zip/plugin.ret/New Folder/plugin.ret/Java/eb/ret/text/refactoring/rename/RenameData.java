package eb.ret.text.refactoring.rename;

import eb.ret.model.specobject.SpecobjectType;

/**
 * Data class to hold the information for specobject rename re-factoring
 * 
 * @author kirensk
 * 
 */
public class RenameData {
    /**
     * specobject for which rename operation is performed
     */
    private final SpecobjectType specObject;
    /**
     * flag to update the specobjects references
     */
    private boolean updateReferences;
    /**
     * new text with which the rename process will happen
     */
    private String newText;
    /**
     * idPrefix declared in the source file of the specObject
     */
    private String idPrefix;

    /**
     * Constructor with specobject as the input
     * 
     * @param specObject
     */
    public RenameData( final SpecobjectType specObject ) {
        super();
        this.specObject = specObject;
    }

    /**
     * constructor with specobject, updateReferences flag and newText entered
     * 
     * @param specObject
     * @param updateReference
     * @param newText
     */
    public RenameData( final SpecobjectType specObject, final boolean updateReferences, final String newText ) {
        super();
        this.specObject = specObject;
        this.updateReferences = updateReferences;
        this.newText = newText;
    }

    /**
     * sets the {@link #updateReferences} flag
     * 
     * @param updateReference
     */
    public void setUpdateReference( final boolean updateReference ) {
        this.updateReferences = updateReference;
    }

    /**
     * sets the {@link #newText} flag
     * 
     * @param newText
     */
    public void setNewText( final String newText ) {
        this.newText = newText;
    }

    /**
     * get the specobject for which rename is triggered
     * 
     * @return
     */
    public SpecobjectType getSpecObject() {
        return specObject;
    }

    /**
     * is the updateReferences flag checked or not
     * 
     * @return
     */
    public boolean isUpdateReferences() {
        return updateReferences;
    }

    /**
     * get the newText entered from the gui
     * 
     * @return
     */
    public String getNewText() {

        return newText;
    }

    /**
     * get the newText for replacing id after considering the idPrefix for the rename data
     * 
     * @return
     */
    public String getNewIdText() {
        if( newText != null && idPrefix != null ) {
            final int index = newText.indexOf( idPrefix );
            if( index == 0 ) {
                return newText.substring( idPrefix.length() );
            }
        }
        return getNewText();
    }

    /**
     * get the idPrefix for the rename data
     * 
     * @return
     */
    public String getIdPrefix() {
        return idPrefix;
    }

    /**
     * set the idPrefix for the rename data
     * 
     * @param idPrefix
     */
    public void setIdPrefix( final String idPrefix ) {
        this.idPrefix = idPrefix;
    }

    /**
     * get the existing text after considering the idPrefix if it exists in the rename data
     * 
     * @return
     */

    public String getExistingIdText() {
        String declarationId = specObject.getId();
        if( idPrefix != null ) {
            final int index = declarationId.indexOf( idPrefix );
            if( index > -1 ) {
                declarationId = declarationId.substring( idPrefix.length() );
            }
        }
        return declarationId;
    }
}
