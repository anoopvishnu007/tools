package eb.ret.text.refactoring.rename;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.model.data.ISpecObjectData;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.helper.SpecObjectEditorUtil;
import eb.ret.ui.text.specobject.AbstractSpecObjectRegion;
import eb.ret.util.PatternHelper;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.filebuffers.FileBuffers;
import org.eclipse.core.filebuffers.ITextFileBuffer;
import org.eclipse.core.filebuffers.ITextFileBufferManager;
import org.eclipse.core.filebuffers.LocationKind;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.ltk.core.refactoring.Change;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.ltk.core.refactoring.TextChange;
import org.eclipse.ltk.core.refactoring.TextEditChangeGroup;
import org.eclipse.text.edits.ReplaceEdit;
import org.eclipse.text.edits.TextEditGroup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The class detects the changes required for a specobject rename process
 * 
 * @author kirensk
 * 
 */
public final class RenameEditDetector {
    /**
     * message for new id in idprefix warning
     */
    private static final String MSG_NEW_ID = "\" and the new ID will be : \"";
    /**
     * message for existing id in idprefix warning
     */
    private static final String MSG_PREFIX = " The specobject contains idprefix : \"";
    /**
     * message for duplicate specobject id
     */
    private static final String MSG_DUPL_ID = "specobject already exists with the name ";
    /**
     * message for renaming an auto generated specobject where id is not defined
     */
    private static final String MSG_ID_FIELD = "Cannot rename this specobject as ID field is not defined";
    /**
     * Word boundary character pattern used to set the specobject search as a whole word
     */
    private static final String WORD_BOUNDARY = "\\b";

    /**
     * Non word boundary character pattern used to set the specobject search as a whole word
     */
    private static final String NONWORD_BOUNDARY = "\\B";

    /**
     * private constructor. This class is not to be instantiated
     */
    private RenameEditDetector() {

    }

    /**
     * Identifies the edits required for the rename of declaration of the given specobject and set them to the change
     * 
     * @param change
     * @param data
     * @param monitor
     * @return
     * @throws CoreException
     * @throws IOException
     * @throws BadLocationException
     */
    public static void setDeclarationRenameEdits( final Change change,
                                                  final RenameData data,
                                                  final IProgressMonitor monitor )
        throws CoreException,
        IOException,
        BadLocationException {
        final List<ReplaceEdit> editList = new ArrayList<ReplaceEdit>();
        final SpecobjectType specObject = data.getSpecObject();
        final IFile file = SpecObjectEditorUtil.getSourceFile( specObject );
        final IDocument document = RenameEditDetector.getDocument( file, monitor );
        final AbstractSpecObjectRegion specRegion = WorkspaceUtils.getSpecObjectRegion( specObject, file, document );

        //identify the edits in the declaration
        final IRegion replaceRegion = specRegion.getIdRegion();
        if( replaceRegion != null ) {
            editList.addAll( findEdits( document, replaceRegion, data.getExistingIdText(), data.getNewIdText() ) );
        }

        for( final ReplaceEdit replaceEdit : editList ) {
            final String editGroupName = "Declaration of " + specObject.getId();
            addEditGroup( change, replaceEdit, editGroupName );
        }

    }

    /**
     * Identifies the edits required for the references of the specobject and add them to the change
     * 
     * @param change
     * @param data
     * @param refSpecObject
     * @param monitor
     * @throws CoreException
     * @throws BadLocationException
     * @throws IOException
     */
    public static void setReferenceRenameEdits( final Change change,
                                                final RenameData data,
                                                final SpecobjectType refSpecObject,
                                                final IProgressMonitor monitor )
        throws CoreException,
        BadLocationException,
        IOException {

        final List<ReplaceEdit> editList = new ArrayList<ReplaceEdit>();

        final IFile file = SpecObjectEditorUtil.getSourceFile( refSpecObject );
        final IDocument document = RenameEditDetector.getDocument( file, monitor );
        final AbstractSpecObjectRegion specRegion = WorkspaceUtils.getSpecObjectRegion( refSpecObject, file, document );
        final SpecobjectType specObject = data.getSpecObject();

        //identifies the edits with in a LINKSTO region
        IRegion replaceRegion = specRegion.getLinksToRegion();
        if( replaceRegion != null ) {
            editList.addAll( findEdits( document, replaceRegion, specObject.getId(), data.getNewText() ) );
        }

        //identifies the edits with in a LINKS region
        replaceRegion = specRegion.getLinksRegion();
        if( replaceRegion != null ) {
            editList.addAll( findEdits( document, replaceRegion, specObject.getId(), data.getNewText() ) );
        }

        //convert all the edits identified to a change group. This will enable the edits to be listed below the filechange
        for( final ReplaceEdit replaceEdit : editList ) {
            final String editGroupName = "Reference of " + specObject.getId();
            addEditGroup( change, replaceEdit, editGroupName );
        }

    }

    /**
     * Converts an edit to a text edit group for its change. This will enable grouping edits in the preview file change
     * 
     * @param change
     * @param replaceEdit
     * @param editGroupName
     */
    private static void addEditGroup( final Change change, final ReplaceEdit replaceEdit, final String editGroupName ) {
        ((TextChange)change).addEdit( replaceEdit );
        final TextEditGroup group = new TextEditGroup( editGroupName, replaceEdit );
        final TextEditChangeGroup editChangeGroup = new TextEditChangeGroup( (TextChange)change, group );
        ((TextChange)change).addTextEditChangeGroup( editChangeGroup );
    }

    /**
     * Finds the replace edits for changing existingText in the with the replaceRegion to be replaced with replacingText
     * 
     * @param document
     * @param replaceRegion
     * @param existingText
     * @param replacingText
     * @throws BadLocationException
     */
    private static List<ReplaceEdit> findEdits( final IDocument document,
                                                final IRegion replaceRegion,
                                                final String existingText,
                                                final String replacingText ) throws BadLocationException {

        final List<ReplaceEdit> editList = new ArrayList<ReplaceEdit>();

        final String renamePatternText = getRenamePatternText( existingText );
        final Pattern idPattern = Pattern.compile( renamePatternText );
        final Matcher match = idPattern.matcher( document.get() );
        int searchStart = replaceRegion.getOffset();

        while (match.find( searchStart )) {
            final int charStart = match.start();
            final int charEnd = match.end();
            searchStart = charEnd;
            final int length = charEnd - charStart;
            if( charStart < (replaceRegion.getOffset() + replaceRegion.getLength()) ) {
                editList.add( getReplaceEdit( replacingText, match, length ) );
            }

        }
        return editList;
    }

    /**
     * Gets the rename pattern string with boundary characters added
     * 
     * @param existingText existing id text
     * @return rename pattern string to bulid the pattern
     */
    private static String getRenamePatternText( final String existingText ) {
        final StringBuffer buffer = new StringBuffer();
        //if meta characters entered in the completion id mark it as characters only
        String renamePatternText = existingText;
        renamePatternText = PatternHelper.escapeMetaCharacters( renamePatternText );
        PatternHelper.appendAsRegEx( renamePatternText, buffer );

        final String startCharString = renamePatternText.substring( 0, 1 );
        final String endCharString = renamePatternText.substring( renamePatternText.length() - 1 );
        buffer.insert( 0, getBoundaryString( startCharString ) );
        buffer.append( getBoundaryString( endCharString ) );
        renamePatternText = buffer.toString();
        return renamePatternText;
    }

    /**
     * Gets the boundary character class string to build the pattern string
     * 
     * @param charString the boundary character as string
     * @return boundary character class string
     */
    private static String getBoundaryString( final String charString ) {
        if( charString.matches( "\\w" ) ) {
            return WORD_BOUNDARY;
        }
        return NONWORD_BOUNDARY;

    }

    /**
     * Creates a replace edit with the input params
     * 
     * @param replacingText
     * @param match
     * @param length
     * @return the created edit
     */
    private static ReplaceEdit getReplaceEdit( final String replacingText, final Matcher match, final int length ) {
        return new ReplaceEdit( match.start(), length, replacingText );
    }

    /**
     * Retrieves the document for a corresponding file
     * 
     * @param file
     * @param monitor
     * @return
     * @throws CoreException
     */
    public static IDocument getDocument( final IFile file, final IProgressMonitor monitor ) throws CoreException {
        final ITextFileBufferManager manager = FileBuffers.getTextFileBufferManager();
        try {
            manager.connect( file.getFullPath(), LocationKind.IFILE, monitor );
            final ITextFileBuffer textFileBuffer = manager.getTextFileBuffer( file.getFullPath(), LocationKind.IFILE );
            return textFileBuffer.getDocument();
        } finally {
            manager.disconnect( file.getFullPath(), LocationKind.IFILE, monitor );
        }
    }

    /**
     * Checks for id conditions of the existing specobject. Fatal error is added if id region is not present in the
     * specobject or a specobject already exists with the same id. If the user entered text doesn't starts with the
     * existing idPrefix of the source file then a warning is added to the status
     * 
     * @param status
     * @param monitor
     * @throws CoreException
     */

    public static void checkIdConditions( final RenameData renameData,
                                          final RefactoringStatus status,
                                          final IProgressMonitor monitor ) throws CoreException {

        final IFile file = SpecObjectEditorUtil.getSourceFile( renameData.getSpecObject() );
        final IDocument document = RenameEditDetector.getDocument( file, monitor );

        final AbstractSpecObjectRegion specRegion = WorkspaceUtils.getSpecObjectRegion( renameData.getSpecObject(),
                                                                                        file,
                                                                                        document );

        if( specRegion.getIdRegion() == null ) {
            status.addFatalError( MSG_ID_FIELD );

            return;
        }

        final ISpecObjectData data = SpecObjectResourceManager.getInstance().getSpecObjectData();
        final SpecobjectType duplicate = data.getSpecObject( renameData.getNewText() );
        if( duplicate != null ) {
            status.addFatalError( MSG_DUPL_ID + renameData.getNewText() );
            return;
        }

        final String idPrefix = SpecObjectEditorUtil.getIDPrefixFromDoc( document );
        if( idPrefix != null && idPrefix.length() > 0 ) {

            renameData.setIdPrefix( idPrefix );
            if( renameData.getNewText().indexOf( idPrefix ) != 0 ) {
                status.addWarning( MSG_PREFIX + idPrefix + MSG_NEW_ID + idPrefix + renameData.getNewIdText() + '\"' );
            }

        }
    }

}
