package eb.ret.ui.editor.texthover;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.NeedscoverageType;
import eb.ret.model.specobject.ProvcovType;
import eb.ret.model.specobject.ProvidescoverageType;
import eb.ret.model.specobject.ReleasesType;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.model.specobject.SpecobjectsType;
import eb.ret.plugin.RETPlugin;
import eb.ret.ui.helper.HTMLDisplayHelper;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.osgi.framework.Bundle;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * This class provides the input for the browser to display the specobject hover control.
 * 
 * @author tintobaby
 * 
 */
public final class TextHoverDisplayHelper {

    /**
     * label for Version
     */
    private static final String LABEL_VERSION = "Version : ";
    /**
     * label for Status
     */
    private static final String LABEL_STATUS = "Status : ";
    /**
     * label for providescoverage
     */
    private static final String LABEL_PROVCOV = "ProvidesCoverage : ";
    /**
     * label for needscoverage
     */
    private static final String LABEL_NEEDSCOV = "NeedsCoverage : ";
    /**
     * label for releases
     */
    private static final String LABEL_REL = "Releases : ";
    /**
     * label for doctype
     */
    private static final String LABEL_DOCTYPE = "DocType : ";
    /**
     * label for description
     */
    private static final String LABEL_DESC = "Description : ";
    /**
     * font tag begin with size and font name
     */
    private static final String TAG_FONT_BEGIN = "<font size=\"2\" face=\"sans-serif\">";;
    /**
     * font tag end
     */
    private static final String TAG_FONT_END = "</font>";
    /**
     * element image gif filename
     */
    private static final String ELEM_OBJ_IMG = "/icons/elements_obj.gif";

    /**
     * Private constructor.
     */
    private TextHoverDisplayHelper() {
    }

    /**
     * To add the title information for the hover control browser input.
     * 
     * @param specObject
     * 
     * @param buffer StringBuffer for browser input.
     */
    private static void addSpecobjectHoverTitle( final SpecobjectType specObject, final StringBuffer buffer ) {

        buffer.append( "<table><tr><td nowrap>" );
        HTMLDisplayHelper.addImage( buffer, getHoverControlImageLocation( ELEM_OBJ_IMG ), "25", "20" );
        buffer.append( "</td><td width=\"50%\" nowrap>" );
        addFontToText( buffer, specObject.getId() );
        buffer.append( "</td><td width=\"30%\" nowrap>" );
        addBoldFontToText( buffer, LABEL_STATUS );
        addFontToText( buffer, specObject.getStatus().getLiteral() );
        buffer.append( "</td><td width=\"20%\" nowrap>" );
        addBoldFontToText( buffer, LABEL_VERSION );
        addFontToText( buffer, specObject.getVersion() );
        buffer.append( "</td></tr></table>" );
    }

    /**
     * returns the input for the browser as string.
     * 
     * @param specObject TODO
     * 
     * @return HTML string
     */
    public static String getHoverInfo( final SpecobjectType specObject ) {

        final StringBuffer buffer = new StringBuffer();
        if( specObject != null ) {
            addSpecobjectHoverTitle( specObject, buffer );
            HTMLDisplayHelper.addLine( buffer );

            buffer.append( TAG_FONT_BEGIN );

            HTMLDisplayHelper.addBoldString( buffer, LABEL_DESC );

            final FeatureMap descVal = specObject.getDescription().getMixed();

            if( !descVal.isEmpty() ) {
                buffer.append( (String)descVal.getValue( 0 ) );
            }

            HTMLDisplayHelper.addBoldParagraph( buffer, LABEL_DOCTYPE );
            buffer.append( ((SpecobjectsType)specObject.eContainer()).getDoctype() );

            final ReleasesType releases = specObject.getReleases();
            if( releases != null ) {
                HTMLDisplayHelper.addBoldParagraph( buffer, LABEL_REL );
                HTMLDisplayHelper.addBullettedList( buffer, releases.getRelease() );
            }

            final NeedscoverageType needsCov = specObject.getNeedscoverage();
            if( needsCov != null ) {
                HTMLDisplayHelper.addBoldParagraph( buffer, LABEL_NEEDSCOV );
                HTMLDisplayHelper.addBullettedList( buffer, needsCov.getNeedsobj() );
            }

            final ProvidescoverageType providesCov = specObject.getProvidescoverage();
            if( providesCov != null ) {
                HTMLDisplayHelper.addBoldParagraph( buffer, LABEL_PROVCOV );

                final EList<ProvcovType> provCoveList = providesCov.getProvcov();
                final List<String> targetList = new ArrayList<String>();
                for( final ProvcovType provcovType : provCoveList ) {
                    final String destVersion = provcovType.getDstversion();
                    final EList<String> liksToList = provcovType.getLinksto();

                    for( final String item : liksToList ) {
                        targetList.add( item + "," + destVersion );
                    }
                }
                HTMLDisplayHelper.addBullettedList( buffer, targetList );
            }

            buffer.append( TAG_FONT_END );

            if( buffer.length() > 0 ) {
                HTMLDisplayHelper.applyDefaultBrowserColors( buffer, 0 );
            } else {
                return null;
            }
        }
        return buffer.toString();
    }

    /**
     * To get the specobject hover control title image location.
     * 
     * @param relativeImgPath
     * @return Path of the image.
     */
    private static String getHoverControlImageLocation( final String relativeImgPath ) {
        final Bundle bundle = Platform.getBundle( RETPlugin.PLUGIN_ID );
        final URL locationUrl = FileLocator.find( bundle, new Path( relativeImgPath ), null );
        URL fileUrl = null;
        String imgPath;
        try {
            fileUrl = FileLocator.toFileURL( locationUrl );
        } catch( final IOException ex ) {
            ErrorLogger.logError( ex.getMessage(), ex );
        }
        imgPath = fileUrl.getFile();
        imgPath = imgPath.substring( 1, imgPath.length() );
        return imgPath;

    }

    /**
     * To add a string with the font.
     * 
     * @param buffer
     * @param paragraph
     */
    private static void addFontToText( final StringBuffer buffer, final String text ) {
        if( text != null ) {
            buffer.append( TAG_FONT_BEGIN );
            buffer.append( text );
            buffer.append( TAG_FONT_END );
        }
    }

    /**
     * To add a bold string with the font.
     * 
     * @param buffer
     * @param paragraph
     */
    private static void addBoldFontToText( final StringBuffer buffer, final String text ) {
        if( text != null ) {
            buffer.append( TAG_FONT_BEGIN );
            buffer.append( "<b>" );
            buffer.append( text );
            buffer.append( "</b>" );
            buffer.append( TAG_FONT_END );
        }
    }
}
