package eb.ret.ui.helper;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.model.data.ISpecObjectData;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;

public final class SpecObjectUtils {

    /**
     * Message to show when source file not found in workspace
     */
    private static final String FILE_NOT_FOUND = "Source file not found for the requirement id ";

    /**
     * Default constructor
     */
    private SpecObjectUtils() {
        //private constructor
    }

    /**
     * Finds the specObject for the provided specObject-id and open its definition containing file in the editor
     * 
     * @param specObject
     */
    public static void openSpecObjInEditor( final String specObjectId ) {
        final IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
        try {
            final ISpecObjectData specObjData = SpecObjectResourceManager.getInstance().getSpecObjectData();
            final SpecobjectType specObject = specObjData.getSpecObject( specObjectId );
            final IFile fileToOpen = SpecObjectEditorUtil.getSourceFile( specObject );

            if( fileToOpen == null ) {
                ErrorLogger.logError( FILE_NOT_FOUND + "\"" + specObjectId + "\"", null );
            } else {
                final IEditorPart editorPart = IDE.openEditor( page, fileToOpen );
                SpecObjectEditorUtil.revealInEditor( editorPart, specObject );
            }
        } catch( final PartInitException ex ) {
            ErrorLogger.logError( ex.getMessage(), ex );
        } catch( BadLocationException e ) {
            ErrorLogger.logError( e.getMessage(), e );
        }

    }

}
