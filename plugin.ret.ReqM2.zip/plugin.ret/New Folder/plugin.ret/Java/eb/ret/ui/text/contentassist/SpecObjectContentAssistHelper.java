package eb.ret.ui.text.contentassist;

import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.helper.SpecObjectEditorUtil;
import eb.ret.ui.helper.SpecObjectEditorUtil.SpecObjectMatch;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Region;

/**
 * This class contains helper methods to show specobject id auto completion
 * 
 * @author anoopvn
 * 
 */
public final class SpecObjectContentAssistHelper {

    /**
     * Constructor
     */
    private SpecObjectContentAssistHelper() {
    }

    /**
     * Gets the specobject id String region which user clicked for autocompletion
     * 
     * @param document the document
     * @param curserOffset cursor offset
     * @return region of the id string
     * @throws BadLocationException
     */
    private static IRegion getAutoCompletionPrefixRegion( final IDocument document, final int curserOffset )
        throws BadLocationException {
        int offset = curserOffset;
        if( document == null
            || offset > document.getLength()
            || !SpecObjectEditorUtil.isValidSpecObjectId( document, offset, true ) ) {
            return null;
        }
        int length = 0;
        while (--offset >= 0) {
            final char chr = document.getChar( offset );
            if( Character.isWhitespace( chr ) || (chr == ',') ) {
                break;
            }
            length++;
        }
        return new Region( offset + 1, length );
    }

    /**
     * Gets completion proposal object of a specobject
     * 
     * @param offset cursor offset
     * @param typedContent typed id string
     * @param specObject specobject which has id starts with the typedContent
     * @return SpecObjectIdCompletionProposal
     */
    public static SpecObjectIdCompletionProposal getCompletionProposal( final int offset,
                                                                        final String typedContent,
                                                                        final SpecobjectType specObject ) {
        SpecObjectIdCompletionProposal proposal = null;
        final int replacementOffset = offset - typedContent.length();
        final int replacementLength = typedContent.length();

        final String idWithVersion = specObject.getId() + "," + specObject.getVersion();
        final int cursorPosition = idWithVersion.length();
        final String displayString = idWithVersion;
        if( idWithVersion != null && replacementOffset >= 0 && replacementLength >= 0 && cursorPosition >= 0 ) {
            proposal = new SpecObjectIdCompletionProposal(
                idWithVersion,
                replacementOffset,
                replacementLength,
                cursorPosition,
                displayString,
                specObject );
        }

        return proposal;
    }

    /**
     * Gets the specobject match object of the auto completion specobject id string
     * 
     * @param document the document
     * @param curserOffset cursor offset
     * @return SpecObjectMatch object
     * @throws BadLocationException
     */
    public static SpecObjectMatch getAutoCompletionIdMatch( final IDocument document, final int curserOffset )
        throws BadLocationException {
        SpecObjectMatch specObjectMatch = null;
        final IRegion prefixRegion = getAutoCompletionPrefixRegion( document, curserOffset );
        if( prefixRegion != null ) {
            final String prefix = document.get( prefixRegion.getOffset(), prefixRegion.getLength() );
            specObjectMatch = new SpecObjectMatch( prefix, prefixRegion );
        }
        return specObjectMatch;
    }
}
