package eb.ret.ui.search.query;

import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.search.result.view.SpecObjectFileMatch;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.Match;

import java.util.ArrayList;
import java.util.List;

/**
 * Result collector class for specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchResultCollector {

    /**
     * search result object
     */
    private final AbstractTextSearchResult searchResult;

    /**
     * list of current search matches
     */
    private List<SpecObjectFileMatch> cachedMatches;

    /**
     * constructor
     * 
     * @param result search result class
     */
    public SpecObjectSearchResultCollector( final AbstractTextSearchResult result ) {
        super();
        searchResult = result;
    }

    public boolean acceptPatternMatch( final IFile file,
                                       final int matchOffset,
                                       final int length,
                                       final CharSequence content,
                                       final SpecobjectType specObject ) throws CoreException {

        final SpecObjectFileMatch fileMatch = new SpecObjectFileMatch( file, matchOffset, length, specObject );
        cachedMatches.add( fileMatch );
        return true;
    }

    public void beginReporting() {
        cachedMatches = new ArrayList<SpecObjectFileMatch>();
    }

    public void endReporting() {
        flushMatches();
        cachedMatches = null;
    }

    /**
     * flush the cached matches in to the search result
     */
    private void flushMatches() {
        if( !cachedMatches.isEmpty() ) {
            searchResult.addMatches( cachedMatches.toArray( new Match[cachedMatches.size()] ) );
            cachedMatches.clear();
        }
    }

}
