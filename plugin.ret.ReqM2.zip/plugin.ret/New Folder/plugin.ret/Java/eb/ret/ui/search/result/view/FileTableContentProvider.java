/**
 * 
 */
package eb.ret.ui.search.result.view;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.AbstractTextSearchViewPage;

/**
 * @author anoopvn
 * 
 */
public class FileTableContentProvider implements IStructuredContentProvider, IFileSearchContentProvider {
    /**
     * Array of input element
     */
    private final Object[] EMPTY_ARR = new Object[0];
    /**
     * Search result page
     */
    private final SpecObjectSearchResultPage searchResultPage;
    /**
     * Search result
     */
    private AbstractTextSearchResult searchResult;

    /**
     * Constructor
     * 
     * @param page
     */
    public FileTableContentProvider( final AbstractTextSearchViewPage page ) {
        searchResultPage = (SpecObjectSearchResultPage)page;
    }

    @Override
    public void dispose() {
        // nothing to do
    }

    @Override
    public Object[] getElements( final Object inputElement ) {
        if( inputElement instanceof SpecObjectSearchResult ) {
            final int elementLimit = getElementLimit();
            final Object[] elements = ((SpecObjectSearchResult)inputElement).getElements();
            if( elementLimit != -1 && elements.length > elementLimit ) {
                final Object[] shownElements = new Object[elementLimit];
                System.arraycopy( elements, 0, shownElements, 0, elementLimit );
                return shownElements;
            }
            return elements;
        }
        return EMPTY_ARR;
    }

    @Override
    public void inputChanged( final Viewer viewer, final Object oldInput, final Object newInput ) {
        if( newInput instanceof SpecObjectSearchResult ) {
            searchResult = (SpecObjectSearchResult)newInput;
        }
    }

    @Override
    public void elementsChanged( final Object[] updatedElements ) {
        final TableViewer viewer = getViewer();
        final int elementLimit = getElementLimit();
        for( int index = 0; index < updatedElements.length; index++ ) {
            if( searchResult.getMatchCount( updatedElements[index] ) > 0 ) {
                if( viewer.testFindItem( updatedElements[index] ) == null ) {
                    if( !(elementLimit != -1) || viewer.getTable().getItemCount() < elementLimit ) {
                        viewer.add( updatedElements[index] );
                    }
                } else {
                    viewer.update( updatedElements[index], null );
                }
            } else {
                viewer.remove( updatedElements[index] );
            }
        }
    }

    /**
     * Gets the element limit
     * 
     * @return
     */
    private int getElementLimit() {
        return searchResultPage.getElementLimit().intValue();
    }

    /**
     * Gets the table viewer
     * 
     * @return
     */
    private TableViewer getViewer() {
        return (TableViewer)searchResultPage.getViewer();
    }

    @Override
    public void clear() {
        getViewer().refresh();
    }
}