/**
 * 
 */
package eb.ret.ui.specobjects.search.result.view;

import org.eclipse.core.resources.IResource;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.Match;

import java.util.ArrayList;
import java.util.List;

/**
 * Line element representation of an offset in a document
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectElement {
    /**
     * Line element parent resource which contains the line
     */
    private final IResource parentResource;
    /**
     * Line number line
     */
    private final int lineNumber;
    /**
     * Line star offset
     */
    private final int lineStartOffset;
    /**
     * line content string
     */
    private final String lineContents;

    /**
     * Constructor
     * 
     * @param parent parent file
     * @param line line number
     * @param startOffset line start offset
     * @param contentString line content
     */
    public SpecObjectElement( final IResource parent, final int line, final int startOffset, final String contentString ) {
        parentResource = parent;
        lineNumber = line;
        lineStartOffset = startOffset;
        lineContents = contentString;
    }

    /**
     * Gets the parent resource
     * 
     * @return
     */
    public IResource getParent() {
        return parentResource;
    }

    /**
     * Gets the line number
     * 
     * @return
     */
    public int getLine() {
        return lineNumber;
    }

    /**
     * Gets the line contents
     * 
     * @return
     */
    public String getContents() {
        return lineContents;
    }

    /**
     * Gets the start offset
     * 
     * @return
     */
    public int getOffset() {
        return lineStartOffset;
    }

    /**
     * Checks the passed offset contains in the current line
     * 
     * @param offset offset
     * @return true if passed offset contains with in the line else false
     */
    public boolean contains( final int offset ) {
        return lineStartOffset <= offset && offset < lineStartOffset + lineContents.length();
    }

    /**
     * Gets the line content length
     * 
     * @return
     */
    public int getLength() {
        return lineContents.length();
    }

    /**
     * Gets the matches of the current line element
     * 
     * @param result the search result
     * @return array of matches in the current line
     */
    public SpecObjectFileMatch[] getMatches( final AbstractTextSearchResult result ) {
        final List<SpecObjectFileMatch> res = new ArrayList<SpecObjectFileMatch>();
        final Match[] matches = result.getMatches( parentResource );
        for( int index = 0; index < matches.length; index++ ) {
            final SpecObjectFileMatch currentMatch = (SpecObjectFileMatch)matches[index];
            if( currentMatch.getSpecObjectElement() == this ) {
                res.add( currentMatch );
            }
        }
        return res.toArray( new SpecObjectFileMatch[res.size()] );
    }

    /**
     * Gets the number of matches in the current line
     * 
     * @param result the search result
     * @return number of matches
     */
    public int getNumberOfMatches( final AbstractTextSearchResult result ) {
        int count = 0;
        final Match[] matches = result.getMatches( parentResource );
        for( int index = 0; index < matches.length; index++ ) {
            final SpecObjectFileMatch currentMatches = (SpecObjectFileMatch)matches[index];
            if( currentMatches.getSpecObjectElement() == this ) {
                count++;
            }
        }
        return count;
    }

}
