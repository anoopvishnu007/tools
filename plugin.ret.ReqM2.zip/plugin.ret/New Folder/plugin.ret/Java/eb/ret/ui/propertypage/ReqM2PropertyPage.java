package eb.ret.ui.propertypage;

import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.core.reqm2.data.ReqM2Property;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.ui.propertypage.helper.InputDirectoryContentCreator;
import eb.ret.ui.propertypage.helper.ReqM2PropertyDataHandler;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Table;
import org.eclipse.ui.dialogs.PropertyPage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * holds the user interface implementation for ReqM2 property page.
 * 
 * @author tintobaby
 * 
 */
public class ReqM2PropertyPage extends PropertyPage {

    /**
     * Maximum number of docType values that needs to be persisted for the RET Property Page
     */
    private static final int DOC_TYPE_LIMIT = 6;

    /**
     * Message for invalid directory
     */
    private static final String INVALID_DIR_MSG = " is an invalid path.";

    /**
     * Stores all the input directories
     */
    private List<RETDirectory> inputDirs;

    /**
     * For storing the user inserted data in docType column drop-down
     */
    private List<String> docTypeCache;

    /**
     * InputDirectoryViewBuilder object
     */
    private final InputDirectoryContentCreator dirContentCreator;

    /**
     * Constructor
     */
    public ReqM2PropertyPage() {
        super();
        this.dirContentCreator = new InputDirectoryContentCreator( this );

    }

    /**
     * Perform all the operations while pressing OK button.
     */
    @Override
    public boolean performOk() {

        boolean success = true;
        final IProject currentProject = getCurrentProject();
        if( inputDirs != null && currentProject != null && currentProject.isOpen() ) {
            if( !checkForError() ) {
                return false;
            }
            try {
                // saving the input directories and the user entered docTypes in
                // the preference store. If any error comes, method will throw
                // an exception
                new ReqM2PropertyDataHandler( this ).saveReqM2Properties( inputDirs );

            } catch( final CoreException ex ) {
                ErrorLogger.logError( ex.getMessage(), ex );
                success = false;
            } catch( final Exception ex ) {
                ErrorLogger.logError( ex.getMessage(), ex );
                success = false;
            }
        }

        return success;
    }

    @Override
    public boolean performCancel() {
        final IProject currentProject = getCurrentProject();
        // checks the current project is open or not
        if( currentProject != null && currentProject.isOpen() && inputDirs != null ) {
            final ReqM2Property property = new ReqM2Property();
            property.setCancelled( true );
            property.setDocTypes( getDocTypeCache() );
            ReqM2InputData.getRETProperty().setReqM2Property( getCurrentProject(), property );
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.eclipse.jface.preference.PreferencePage#createContents(org.eclipse
     * .swt.widgets.Composite)
     * 
     * @since 1.0
     */
    @Override
    protected Control createContents( final Composite parent ) {

        if( inputDirs == null ) {
            inputDirs = ReqM2InputData.getRETData().getRETInputDirectories( getCurrentProject() );
        }
        // parent composite for property page
        return dirContentCreator.createContents( parent );
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.jface.preference.PreferencePage#performDefaults()
     * 
     * @since 1.0
     */
    @Override
    protected void performDefaults() {
        super.performDefaults();
        final IProject currentProject = getCurrentProject();
        if( currentProject != null
            && currentProject.isOpen()
            && dirContentCreator.getViewer() != null
            && dirContentCreator.getViewer().getTable() != null ) {
            dirContentCreator.getViewer().getTable().clearAll();
            inputDirs.clear();
            dirContentCreator.getViewer().setInput( inputDirs );
            dirContentCreator.getRemoveButton().setEnabled( false );
            checkState();
        }
    }

    /*
     * !LINKSTO eclipse.ret.req.RETInputDirectoryNotFound,1
     */
    /**
     * This method checks the validity of directory paths in the tree viewer and display corresponding message in the
     * property page
     * 
     */
    public void checkState() {
        if( inputDirs != null ) {
            for( final RETDirectory dir : inputDirs ) {
                checkState( dir.getPath() );
            }
        }
    }

    /**
     * This method checks the validity of the provided directory path and display corresponding message in the property
     * page
     * 
     * @param path
     */
    public void checkState( final String path ) {
        final IFolder element = getCurrentProject().getFolder( WorkspaceUtils.getIPath( path ) );
        if( !element.exists() ) {
            setErrorMessageForPage( path + INVALID_DIR_MSG );
            return;
        }
    }

    /**
     * Sets the error message in the property page
     * 
     * @param message
     */
    public void setErrorMessageForPage( final String message ) {
        if( message == null ) {
            setValid( true );
            setErrorMessage( null );

        } else {
            setValid( false );
            setErrorMessage( message );
        }
    }

    /**
     * Returns an unmodifiable list of input directories.
     * 
     * @return inputDirs the instance variable inputDirs
     */
    public List<RETDirectory> getInputDirs() {
        if( inputDirs == null ) {
            inputDirs = new ArrayList<RETDirectory>();
        }
        return Collections.unmodifiableList( inputDirs );
    }

    /**
     * Adds the provided input-directory to the input-directory list
     * 
     * @param directory
     */
    public void addInputDirectory( final RETDirectory directory ) {
        inputDirs.add( directory );

        // for selecting the added row in the table
        getViewer().refresh();
        final Table table = getViewer().getTable();
        if( table.getItemCount() >= 1 ) {
            table.setSelection( table.getItemCount() - 1 );
        }
    }

    /**
     * Removes the provided directory from the input-directory list
     * 
     * @param directory
     */
    public void removeInputDirectory( final RETDirectory directory ) {
        inputDirs.remove( directory );
    }

    /**
     * Returns an unmodifiable list of stored docType. The stored docTypes are stored per project
     * 
     * @return List of string
     */
    public List<String> getDocTypeCache() {
        return Collections.unmodifiableList( docTypeCache );
    }

    /**
     * Adds the provided docType to the top of the docType list. Also limits the docType cache to the last
     * {@link #DOC_TYPE_LIMIT} values
     * 
     * @param docType
     */
    public void addDocTypeCache( final String docType ) {
        if( docTypeCache != null ) {
            docTypeCache.add( 0, docType );
            for( int i = DOC_TYPE_LIMIT; i < docTypeCache.size(); i++ ) {
                docTypeCache.remove( i );
            }
        }

    }

    /**
     * Sets the docType to the stored cache
     * 
     * @param docType
     */
    public void setDocTypeCache( final List<String> docType ) {
        this.docTypeCache = docType;
    }

    /**
     * Gets the table viewer of RET property page
     * 
     * @return TableViewer
     */
    public TableViewer getViewer() {
        return dirContentCreator.getViewer();
    }

    /**
     * gets the currently shown property page's project
     * 
     * @return the currentProject
     */
    public IProject getCurrentProject() {
        return (IProject)getElement().getAdapter( IResource.class );
    }

    /**
     * Checks if doctypes are provided for all input directory. If not provided an error message will be shown
     * 
     * @return
     */
    public boolean checkForError() {
        for( final RETDirectory directory : inputDirs ) {
            // To check if the doctype is not provided
            if( directory.getDocType() == null || directory.getDocType().isEmpty() ) {
                setErrorMessageForPage( String.format( "DocType is empty for %s input directory", directory.getPath() ) );
                return false;
            }
        }
        setErrorMessageForPage( null );
        //check the state of the directories 
        checkState();
        return true;
    }
}