package eb.ret.ui.search.page.control;

import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.ui.search.page.SpecObjectSearchDialogPage;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;

/**
 * This class represents the limit to controls in the specobject search page
 * 
 * @author anoopvn
 * 
 */
public class LimitToControl extends AbstractSearchPageControl {

    /**
     * LimitTo radio buttons
     */
    private Button limitToButtons[];

    /**
     * LimitTo group label
     */
    public static final String LIMIT_TO = "Limit To";

    /**
     * Constructor
     * 
     * @param parentPage
     * @param searchDialogPage
     */
    public LimitToControl( final Composite parentPage, final SpecObjectSearchDialogPage searchDialogPage ) {
        super( parentPage, searchDialogPage );
    }

    @Override
    public void createControl() {
        createLimitTo( parentPage );
    }

    /**
     * Creates limit to group control
     * 
     * @param parent
     */
    private void createLimitTo( final Composite parent ) {
        pageElements.setLimitToGroup( new Group( parent, 0 ) );
        pageElements.getLimitToGroup().setText( LIMIT_TO );
        pageElements.getLimitToGroup().setLayout( new GridLayout( 2, false ) );
        fillLimitToGroup();
        pageElements.getLimitToGroup().setLayoutData( new GridData( SWT.FILL, SWT.FILL, true, false, 1, 1 ) );

    }

    /**
     * Creates the limit to options radio buttons
     * 
     */
    private void fillLimitToGroup() {

        final int searchFor = pageElements.getSearchForSelection();

        createLimitToButton();

        if( searchFor == SearchForType.ID.getValue() ) {
            enableGroup( pageElements.getLimitToGroup(), true );
        } else {
            enableGroup( pageElements.getLimitToGroup(), false );
        }

        final SelectionAdapter listener = new SelectionAdapter() {

            @Override
            public void widgetSelected( final SelectionEvent event ) {
                performLimitToSelectionChanged( (Button)event.widget );
            }

        };
        for( final Button limitToButton : limitToButtons ) {
            limitToButton.addSelectionListener( listener );
        }

        Dialog.applyDialogFont( pageElements.getLimitToGroup() );
        pageElements.getLimitToGroup().layout();
    }

    private final void performLimitToSelectionChanged( final Button button ) {
        if( button.getSelection() ) {
            pageElements.setLimitToSelection( ((Integer)button.getData()).intValue() );
        }
    }

    /**
     * Creates limit to buttons corresponding to the limit to types
     * 
     * @return array of buttons
     */
    private void createLimitToButton() {
        final LimitToType[] limitToTypes = LimitToType.values();
        limitToButtons = new Button[limitToTypes.length];
        int count = 0;
        for( final LimitToType limitToType : limitToTypes ) {
            limitToButtons[count++] = createButton( pageElements.getLimitToGroup(),
                                                    SWT.RADIO,
                                                    limitToType.getName(),
                                                    limitToType.getValue(),
                                                    false );
        }
        final int selIndex = pageElements.getLimitToSelection();
        limitToButtons[selIndex].setSelection( true );
    }

    /**
     * getter method for accessing limitTo buttons created
     * 
     * @return
     */
    public Button[] getLimitToButtons() {
        return limitToButtons;
    }

}
