/**
 * 
 */
package eb.ret.ui.specobjects.search.result.view;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.text.Region;
import org.eclipse.search.ui.text.Match;

/**
 * Match class for specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectFileMatch extends Match {
    /**
     * Line element object of corresponding match
     */
    private final SpecObjectElement specObjectElement;
    /**
     * Original region of the match
     */
    private Region matchRegion;

    /**
     * Constructor
     * 
     * @param element matched file
     */
    public SpecObjectFileMatch( final IFile element ) {
        super( element, -1, -1 );
        specObjectElement = null;
        matchRegion = null;
    }

    /**
     * Constructor
     * 
     * @param element matched file
     * @param offset matched offset
     * @param length matched region length
     * @param lineElement matched line element
     */
    public SpecObjectFileMatch( final IFile element,
                                final int offset,
                                final int length,
                                final SpecObjectElement lineElement ) {
        super( element, offset, length );
        if( lineElement == null ) {
            specObjectElement = null;
        } else {
            specObjectElement = lineElement;
        }
    }

    @Override
    public void setOffset( final int offset ) {
        if( matchRegion == null ) {
            // remember the original location before changing it
            matchRegion = new Region( getOffset(), getLength() );
        }
        super.setOffset( offset );
    }

    @Override
    public void setLength( final int length ) {
        if( matchRegion == null ) {
            // remember the original location before changing it
            matchRegion = new Region( getOffset(), getLength() );
        }
        super.setLength( length );
    }

    /**
     * Gets the original offset of the match
     * 
     * @return
     */
    public int getOriginalOffset() {
        if( matchRegion != null ) {
            return matchRegion.getOffset();
        }
        return getOffset();
    }

    /**
     * Gets the original length
     * 
     * @return length
     */
    public int getOriginalLength() {
        if( matchRegion != null ) {
            return matchRegion.getLength();
        }
        return getLength();
    }

    /**
     * gets the line element of specobject
     * 
     * @return line element
     */
    public SpecObjectElement getSpecObjectElement() {
        return specObjectElement;
    }

}
