package eb.ret.ui.text.specobject;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.FindReplaceDocumentAdapter;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Region;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * XML implementation for region identification in xml files
 * 
 * @author kirensk
 * 
 */
public class XMLSpecObjectRegion extends AbstractSpecObjectRegion {

    /**
     * Tag used for links element
     */
    private static final String TAG_LINKS = "links";
    /**
     * Tag used for comment element
     */
    private static final String TAG_COMMENT = "comment";
    /**
     * Tag used for linksto elements
     */
    private static final String TAG_LINKSTO = "providescoverage";
    /**
     * Tag used for id element
     */
    private static final String TAG_ID = "id";
    /**
     * Tag used for description element
     */
    private static final String TAG_DESC = "description";
    /**
     * character used for closing tag start
     */
    private static final String TAG_CLOSE_CHAR = "</";
    /**
     * character used for tag end
     */
    private static final String TAG_END_CHAR = ">";
    /**
     * character used for begin tag start
     */
    private static final String TAG_START_CHAR = "<";

    /**
     * Constructor with input as specobject and document
     * 
     * @param specObject
     * @param document
     */
    public XMLSpecObjectRegion( final SpecobjectType specObject, final IDocument document ) {
        super( specObject, document );
    }

    /**
     * Constructor with input as specobject
     * 
     * @param specObject
     * @throws IOException
     */
    public XMLSpecObjectRegion( final SpecobjectType specObject ) throws IOException {
        super( specObject );
    }

    @Override
    public IRegion getSpecObjectRegion() {
        int startOffset = 0;
        int length = 0;
        try {
            final int lineNumber = Integer.parseInt( specObject.getSourceline() );
            final IRegion specObjStartReg = document.getLineInformation( lineNumber - 1 );
            startOffset = specObjStartReg.getOffset();
            final FindReplaceDocumentAdapter findAdapter = new FindReplaceDocumentAdapter( document );
            final IRegion specObjEndRegion = findAdapter.find( startOffset, "</specobject>", true, true, false, true );
            length = (specObjEndRegion.getOffset() + specObjEndRegion.getLength()) - startOffset;
        } catch( final BadLocationException be ) {
            ErrorLogger.logError( MSG_BAD_LOC + specObject.getId(), be );
        } catch( final NumberFormatException ne ) {
            ErrorLogger.logError( MSG_INVLD_LINE + specObject.getSourceline(), ne );
        } catch( final Exception e ) {
            ErrorLogger.logError( MSG_EXCPTN, e );
        }
        return new Region( startOffset, length );
    }

    @Override
    public IRegion getRegion( final String region ) {
        return getRegionUsingTagName( region );
    }

    @Override
    public IRegion getDescriptionRegion() {
        return getRegionUsingTagName( TAG_DESC );
    }

    @Override
    public IRegion getIdRegion() {
        return getRegionUsingTagName( TAG_ID );
    }

    @Override
    public IRegion getLinksToRegion() {
        return getRegionUsingTagName( TAG_LINKSTO );
    }

    @Override
    public IRegion getCommentsRegion() {
        return getRegionUsingTagName( TAG_COMMENT );
    }

    @Override
    public IRegion getLinksRegion() {
        return getRegionUsingTagName( TAG_LINKS );
    }

    /**
     * finds the region for the given tagName.
     * 
     * This will identify the region with in <tagName> and </tagName>
     * 
     * @param tagName
     * @return the region corresponding to the tagName with in the specobject
     */
    private IRegion getRegionUsingTagName( final String tagName ) {

        IRegion matchRegion = null;
        int startOffset = 0, endOffset = 0;
        int length = 0;

        final String searchString = getStartTag( tagName );
        final int regexOptions = getRegExOptions( false );
        specObjectRegion = getSpecObjectRegion();
        final int specObjEndOffset = specObjectRegion.getOffset() + specObjectRegion.getLength();
        final Matcher matcher = Pattern.compile( searchString, regexOptions ).matcher( document.get() );
        final Matcher endMatcher = Pattern.compile( getEndTag( tagName ), regexOptions ).matcher( document.get() );

        if( matcher.find( specObjectRegion.getOffset() ) ) {
            startOffset = matcher.start();
            if( startOffset < specObjEndOffset && endMatcher.find( startOffset ) ) {
                endOffset = endMatcher.end();
            }

            if( endOffset > specObjEndOffset ) {
                endOffset = specObjEndOffset;
            }
        }

        if( endOffset > startOffset ) {
            length = endOffset - startOffset;
            matchRegion = new Region( startOffset, length );
        }

        return matchRegion;
    }

    /**
     * get the xml start tag for the tagName
     * 
     * @param tagName
     * @return the xml tag for the given tagName
     */

    private String getStartTag( final String tagName ) {

        return TAG_START_CHAR + tagName + TAG_END_CHAR;

    }

    /**
     * get the xml end tag for the tagName
     * 
     * @param tagName
     * @return the xml tag for the given tagName
     */
    private String getEndTag( final String tagName ) {
        return TAG_CLOSE_CHAR + tagName + TAG_END_CHAR;
    }

}
