package eb.ret.ui.editor.texthover;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.helper.SpecObjectEditorUtil;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.text.IInformationControl;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;

/**
 * Action to open the the corresponding source file which contains the selected specobject.
 * 
 * @author tintobaby
 * 
 */
final class OpenDeclarationAction extends Action {

    /**
     * Relative location of the specobject hover image.
     */
    private static final String IMG_REL_LOC = "../../../../../icons/goto_obj.gif";
    /**
     * Open Declaration action tooltip.
     */
    private static final String OPEN_DCLR = "Open Declaration";
    /**
     * Error message for the exceptions while getting the source line information from the specobject.
     */
    private static final String ERR_SRC_FILE = "Source file information not available for the specobject ";

    /**
     * Selected specobject.
     */
    private SpecobjectType specObject;
    /**
     * IInformationControl to display the specobject details.
     */
    private final IInformationControl hoverInfoCtrl;

    @Override
    public void run() {
        final IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
        IFile fileToOpen;
        try {
            fileToOpen = SpecObjectEditorUtil.getSourceFile( getSpecObject() );

            if( fileToOpen == null ) {
                ErrorLogger.logError( ERR_SRC_FILE + getSpecObject().getId(), null );
            } else {
                final IEditorPart editorPart = IDE.openEditor( page, fileToOpen );
                SpecObjectEditorUtil.revealInEditor( editorPart, getSpecObject() );
            }
            hoverInfoCtrl.dispose();
        } catch( final Exception ex ) {
            ErrorLogger.logError( ex.getMessage(), ex );
        }

    }

    /**
     * Constructor with specobject and information control as the inputs
     * 
     * @param specObject
     * @param infoControl
     */
    public OpenDeclarationAction( final SpecobjectType specObject, final IInformationControl infoControl ) {
        super();
        this.setSpecObject( specObject );
        hoverInfoCtrl = infoControl;
        final ImageDescriptor imgDesc = ImageDescriptor.createFromFile( this.getClass(), IMG_REL_LOC );
        setImageDescriptor( imgDesc );
        setToolTipText( OPEN_DCLR );
    }

    /**
     * get specobject instance of the open declaration
     * 
     * @return
     */
    public SpecobjectType getSpecObject() {
        return specObject;
    }

    /**
     * set the specobject to the open declaration
     * 
     * @param specObject
     */
    public void setSpecObject( final SpecobjectType specObject ) {
        this.specObject = specObject;
    }
}