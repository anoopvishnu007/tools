package eb.ret.ui.editor.texthover;

import org.eclipse.jface.text.AbstractReusableInformationControlCreator;
import org.eclipse.jface.text.DefaultInformationControl;
import org.eclipse.jface.text.IInformationControl;
import org.eclipse.jface.text.IInformationControlCreator;
import org.eclipse.jface.text.IInformationControlExtension4;
import org.eclipse.swt.widgets.Shell;

/**
 * Reusable information control creator to provide the control creator for creating linksTo element hover control.
 * 
 * @author tintobaby
 * 
 */
public final class SpecobjectHoverControlCreator extends AbstractReusableInformationControlCreator {

    /**
     * Hover control toolbar status message.
     */
    private String statusBarText = "Press F2 for focus";
    /**
     * Information control creator to create the hover control
     */
    private final IInformationControlCreator prstrCtrlCreator;

    /**
     * Constructor.
     * 
     * @param ctrlCreator Information control creator.
     */
    public SpecobjectHoverControlCreator( final IInformationControlCreator ctrlCreator ) {
        super();
        prstrCtrlCreator = ctrlCreator;
    }

    @Override
    public IInformationControl doCreateInformationControl( final Shell parent ) {

        //Check whether the browser input is available or not.
        if( SpecobjectToolTipBrowserControl.isBrowserAvailable( parent ) ) {

            //Creating the instance of information control.
            final SpecobjectToolTipBrowserControl infoControl = new SpecobjectToolTipBrowserControl( parent,
                                                                                                     getStatusBarText() ) {
                @Override
                public IInformationControlCreator getInformationPresenterControlCreator() {
                    return prstrCtrlCreator;
                }
            };
            return infoControl;
        } else {
            //Return the instance of DefaultInformationControl, if the SWT browser widget is not available with  SpecobjectToolTipBrowserControl.
            return new DefaultInformationControl( parent, getStatusBarText() );
        }
    }

    @Override
    public boolean canReuse( final IInformationControl control ) {
        if( !super.canReuse( control ) ) {
            return false;
        }
        if( control instanceof IInformationControlExtension4 ) {
            ((IInformationControlExtension4)control).setStatusText( getStatusBarText() );
        }
        return true;
    }

    /**
     * Gets the status bar text for hover control
     * 
     * @return
     */
    public String getStatusBarText() {
        return statusBarText;
    }

    /**
     * Sets the status bar text for hover control
     * 
     * @param statusBarText
     */
    public void setStatusBarText( final String statusBarText ) {
        this.statusBarText = statusBarText;
    }
}