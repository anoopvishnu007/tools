package eb.ret.ui.helper;

import eb.ret.core.reqm2.ReqM2TracingManager;
import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.core.reqm2.processor.ErrorLogger;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

/*
 * !LINKSTO eclipse.ret.req.ReqM2Button,1,
 *          eclipse.ret.req.ReqM2ButtonVisibility,1
 */
/**
 * This class handles the execution of Eclipse RET Trace button click event.
 * 
 * @author tintobaby
 * 
 */
public class RETTracingCommandHandler extends AbstractHandler {

    /**
     * Message box title.
     */
    private static final String LABEL_TITLE = "Eclipse RET";
    /**
     * Error message to inform the absence of Eclipse RET preferences to user while pressing ReqM2 trace button.
     */
    private static final String MSG_PREF_NOT_SET = "Eclipse RET preferences not set";

    /*
     * !LINKSTO  eclipse.ret.req.RETPreRequisitesNotSet,1,
     * !         eclipse.ret.req.ReqM2ButtonVisibility,1
     */
    @Override
    public Object execute( final ExecutionEvent event ) throws ExecutionException {
        //Check whether the Eclipse RET preference is set or not.
        //!LINKSTO  eclipse.ret.req.RETPreRequisitesNotSet,1
        if( ReqM2InputData.getRETData().isRETPreferencesSet() ) {
            //Perform ReqM2 tracing and reporting.
            ReqM2TracingManager.getInstance().performReqM2TracingAndReporting();

        } else {
            ErrorLogger.logError( MSG_PREF_NOT_SET, null );
            final Shell shell = new Shell( Display.getDefault() );
            final MessageBox mBox = new MessageBox( shell );
            mBox.setMessage( MSG_PREF_NOT_SET );
            mBox.setText( LABEL_TITLE );
            mBox.open();
        }
        return event;
    }
}
