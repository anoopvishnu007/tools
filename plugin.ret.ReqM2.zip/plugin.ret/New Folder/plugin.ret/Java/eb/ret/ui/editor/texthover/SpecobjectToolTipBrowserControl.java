package eb.ret.ui.editor.texthover;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.core.runtime.ListenerList;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.text.AbstractInformationControl;
import org.eclipse.jface.text.IInformationControlExtension2;
import org.eclipse.jface.text.IInputChangedListener;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.LocationAdapter;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;

/**
 * This class helps to display an HTML information in an SWT browser.
 * 
 * @author tintobaby
 * 
 */
public class SpecobjectToolTipBrowserControl extends AbstractInformationControl implements
        IInformationControlExtension2 {

    /**
     * Error message to update the user for the errors while displaying specobject hover control.
     */
    private static final String HOVER_DIS_ERROR = "Unable to display the hover control. Input for the hover control may contain incorrect values";

    /**
     * Flag to identify the browse is available or not.
     */
    private static boolean isBsrAvailable = false;

    /**
     * List to keep InputChangedListeneres
     */
    private final ListenerList listenerList = new ListenerList( ListenerList.IDENTITY );

    /**
     * SWT browser to display the Input HTML string.
     */
    private Browser htmlBrowser;

    /**
     * Flag to check the whether the browser has content or not.
     */
    private boolean hasBrowserContent;

    /**
     * Constructor.
     * 
     * @param parent
     * @param toolBarManager ToolBarManager to display the tool bar.
     */
    public SpecobjectToolTipBrowserControl( final Shell parent, final ToolBarManager toolBarManager ) {
        super( parent, toolBarManager );
        //Calling the super class method.
        create();
    }

    /**
     * Constructor.
     * 
     * @param parent
     * @param toolBarStatusMsg Status message to display in the tool bar.
     */
    public SpecobjectToolTipBrowserControl( final Shell parent, final String toolBarStatusMsg ) {
        super( parent, toolBarStatusMsg );
        create();
    }

    /**
     * This method is to check whether the SWT browser widget is available with the given parent.
     * 
     * @param parent
     * @return true if the browser is available. Otherwise false.
     */
    public static boolean isBrowserAvailable( final Composite parent ) {

        try {
            //Creating the Browser instance to verify the availability of the SWT browser widget.
            final Browser browser = new Browser( parent, SWT.NONE );
            browser.dispose();
            isBsrAvailable = true;
        } catch( final SWTError er ) {
            isBsrAvailable = false;
        }
        return isBsrAvailable;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.AbstractInformationControl#createContent(org.eclipse.swt.widgets.Composite)
     */
    @Override
    protected void createContent( final Composite parent ) {
        htmlBrowser = new Browser( parent, SWT.NONE );
        htmlBrowser.setJavascriptEnabled( false );

        final Display display = getShell().getDisplay();
        htmlBrowser.setForeground( display.getSystemColor( SWT.COLOR_INFO_FOREGROUND ) );
        htmlBrowser.setBackground( display.getSystemColor( SWT.COLOR_INFO_BACKGROUND ) );

        htmlBrowser.addLocationListener( new LocationAdapter() {
            @Override
            public void changing( final org.eclipse.swt.browser.LocationEvent event ) {
                //s final SpecobjectType location = event.;

            };
        } );
        // Remove browser's default context menu.
        htmlBrowser.setMenu( new Menu( getShell(), SWT.NONE ) );
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.IInformationControlExtension2#setInput(java.lang.Object)
     */
    @Override
    public void setInput( final Object input ) {

        if( (input instanceof SpecobjectType) ) {

            String htmlInput = TextHoverDisplayHelper.getHoverInfo( (SpecobjectType)input );//(String)input;

            if( htmlInput.length() > 0 ) {
                hasBrowserContent = true;
                String scrollStyle = null;
                //Initially scroll bar was hidden and when the presentation control initializes the scroll appears
                if( isResizable() ) {
                    scrollStyle = "overflow:scroll;";
                } else {
                    scrollStyle = "overflow:hidden;";
                }
                final StringBuffer buffer = new StringBuffer( htmlInput );
                final StringBuffer styleBuf = new StringBuffer();
                styleBuf.append( " style=\"" );
                styleBuf.append( scrollStyle );
                styleBuf.append( '"' );
                final int index = buffer.indexOf( "<body " );
                if( index != -1 ) {
                    buffer.insert( index + 5, styleBuf );
                }
                htmlInput = buffer.toString();
                htmlBrowser.setText( htmlInput );
                htmlBrowser.redraw();

                final Object[] listeners = listenerList.getListeners();
                //Firing all input changed listeners.
                for( int listnerIndex = 0; listnerIndex < listeners.length; listnerIndex++ ) {
                    ((IInputChangedListener)listeners[listnerIndex]).inputChanged( input );
                }

            }
        } else {
            ErrorLogger.logError( HOVER_DIS_ERROR, null );
        }
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.AbstractInformationControl#setVisible(boolean)
     */
    @Override
    public void setVisible( final boolean visible ) {
        super.setVisible( visible );
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.AbstractInformationControl#handleDispose()
     */
    @Override
    protected void handleDispose() {
        htmlBrowser = null;
        super.handleDispose();
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.AbstractInformationControl#computeSizeHint()
     */
    @Override
    public Point computeSizeHint() {
        //Tooltip control width and height is fixed. If the input has more information, the user can use scroll bars to view the full details.
        //Control also have the resizing capability.
        return new Point( 700, 300 );
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.IInformationControlExtension#hasContents()
     */
    @Override
    public boolean hasContents() {
        return hasBrowserContent;
    }

    /**
     * add the listener to the input change listener list
     * 
     * @param listener
     */
    public void addInputChangeListener( final IInputChangedListener listener ) {
        listenerList.add( listener );
    }

    /**
     * removes the listener from the input change listener list
     * 
     * @param listener
     */
    public void removeInputChangeListener( final IInputChangedListener listener ) {
        listenerList.remove( listener );
    }

}