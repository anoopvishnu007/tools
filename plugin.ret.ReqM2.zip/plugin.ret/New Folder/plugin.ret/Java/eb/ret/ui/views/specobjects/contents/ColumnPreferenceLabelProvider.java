package eb.ret.ui.views.specobjects.contents;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.TableColumn;

/**
 * Label provider for Column Preference of specobject view
 * 
 * @author nikhilcr
 * 
 */
public class ColumnPreferenceLabelProvider extends LabelProvider {

    /**
     * Default constructor
     */
    public ColumnPreferenceLabelProvider() {
        super();
    }

    @Override
    public String getText( final Object element ) {
        if( element instanceof TableColumn ) {
            return ((TableColumn)element).getText();
        }
        return null;
    }

    @Override
    public Image getImage( final Object element ) {
        return null;
    }

}
