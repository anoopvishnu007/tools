package eb.ret.ui.helper;

import org.eclipse.swt.graphics.RGB;

import java.util.List;

/**
 * This class helps to apply different styles and format in an HTML string.
 * 
 * @author tintobaby
 * 
 */
public final class HTMLDisplayHelper {

    /**
     * Background colour.
     */
    private static final RGB BGND_COLOR = new RGB( 255, 255, 225 );
    /**
     * Foreground colour.
     */
    private static final RGB FGND_COLOR = new RGB( 0, 0, 0 );

    /**
     * Private constructor.
     */
    private HTMLDisplayHelper() {
    }

    /**
     * To Append different colours available with the given Foreground RGB and the Background RGB in the given HTML
     * string.
     * 
     * @param htmlString StringBuffer for browser input.
     * @param fgCLR Foreground colour.
     * @param bgCLR Background colour.
     */
    private static void appendColors( final StringBuffer htmlString, final RGB fgCLR, final RGB bgCLR ) {
        htmlString.append( "<body text=\"" );
        appendColor( htmlString, fgCLR );
        htmlString.append( "\" bgcolor=\"" );
        appendColor( htmlString, bgCLR );
        htmlString.append( "\">" );
    }

    /**
     * To Append different colours available with the given RGB in the given HTML string.
     * 
     * @param htmlString StringBuffer for browser input.
     * @param rgb RGB for colour input.
     */
    private static void appendColor( final StringBuffer htmlString, final RGB rgb ) {
        htmlString.append( '#' );
        appendAsHexString( htmlString, rgb.red );
        appendAsHexString( htmlString, rgb.green );
        appendAsHexString( htmlString, rgb.blue );
    }

    /**
     * To Append the hex string for the given colour in the given HTML string.
     * 
     * @param htmlString StringBuffer for browser input.
     * @param intValue Hex string for the given colour.
     */
    private static void appendAsHexString( final StringBuffer htmlString, final int intValue ) {
        final String hexValue = Integer.toHexString( intValue );
        if( hexValue.length() == 1 ) {
            htmlString.append( '0' );
        }
        htmlString.append( hexValue );
    }

    /**
     * To add a paragraph in the given HTML string.
     * 
     * @param htmlString StringBuffer for browser input.
     * @param paragraph
     */
    public static void addParagraph( final StringBuffer htmlString, final String paragraph ) {
        if( paragraph != null ) {
            htmlString.append( "<p>" );
            htmlString.append( paragraph );
        }
    }

    /**
     * To insert the default colour for the browser in the given HTML string.
     * 
     * @param htmlString StringBuffer for browser input.
     * @param position
     */
    public static void applyDefaultBrowserColors( final StringBuffer htmlString, final int position ) {
        final StringBuffer pageProlog = new StringBuffer( 60 );
        appendColors( pageProlog, FGND_COLOR, BGND_COLOR );
        htmlString.insert( position, pageProlog.toString() );
    }

    /**
     * To insert an image to display in the browser.
     * 
     * @param buffer StringBuffer for browser input.
     * @param imgPath Full path of the image.
     * @param width Width of the image.
     * @param height Height of the image.
     */
    public static void addImage( final StringBuffer buffer,
                                 final String imgPath,
                                 final String width,
                                 final String height ) {

        buffer.append( "<img src= \'" );
        buffer.append( imgPath );
        buffer.append( "\' width=" );
        buffer.append( width );
        buffer.append( " height=\'" );
        buffer.append( height );
        buffer.append( "\'>" );
    }

    /**
     * To add a bold string in the given HTML string.
     * 
     * @param buffer StringBuffer for browser input.
     * @param string
     */
    public static void addBoldString( final StringBuffer buffer, final String string ) {
        buffer.append( "<b>" );
        buffer.append( string );
        buffer.append( "</b>" );
    }

    /**
     * To add a Line.
     * 
     * @param buffer
     */
    public static void addLine( final StringBuffer buffer ) {
        buffer.append( "<hr>" );
    }

    /**
     * To add a bold paragraph with bold characters.
     * 
     * @param buffer
     * @param paragraph
     */
    public static void addBoldParagraph( final StringBuffer buffer, final String paragraph ) {
        if( paragraph != null ) {
            buffer.append( "<b>" );
            HTMLDisplayHelper.addParagraph( buffer, paragraph );
            buffer.append( "</b>" );
        }
    }

    /**
     * To add an ordered list with bullets.
     * 
     * @param buffer
     * @param listItems
     */
    public static void addBullettedList( final StringBuffer buffer, final List<String> listItems ) {
        buffer.append( "<ul>" );
        for( String item : listItems ) {
            buffer.append( "<li>" );
            buffer.append( item );
            buffer.append( "</li>" );
        }
        buffer.append( "</ul>" );
    }
}
