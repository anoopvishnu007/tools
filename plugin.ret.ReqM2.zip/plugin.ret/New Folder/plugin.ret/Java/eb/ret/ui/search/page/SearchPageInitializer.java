package eb.ret.ui.search.page;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.text.FindReplaceDocumentAdapter;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.PlatformUI;

/**
 * This class initializes the search page with default values
 * 
 * @author anoopvn
 * 
 */
public class SearchPageInitializer {
    /**
     * Escape character
     */
    public static final char ESCAPE_CHAR = '\\';
    /**
     * Meta character star
     */
    public static final String META_CHAR_STAR = "*";
    /**
     * Instance of search dialog page
     */
    private final SpecObjectSearchDialogPage searchDialog;
    /**
     * Instance of search dialog page elements
     */
    private final SpecObjectSearchPageElements pageElements;

    /**
     * Constructor
     * 
     * @param searchDialog
     */
    public SearchPageInitializer( final SpecObjectSearchDialogPage searchDialog ) {

        this.searchDialog = searchDialog;
        pageElements = searchDialog.getPageElements();
    }

    /**
     * Initializing the search page
     */
    public void initialize() {

        if( pageElements.getSearchPattern() != null ) {
            if( pageElements.isFirstTime() ) {
                pageElements.setFirstTime( false );
                initializeValues();
            }
            pageElements.getSearchPattern().setFocus();
        }
        searchDialog.getSpecObjectutil().updateOKStatus();

        final IEditorInput editorInput = pageElements.getPageContainer().getActiveEditorInput();
        pageElements.getPageContainer().setActiveEditorCanProvideScopeSelection( editorInput != null
            && editorInput.getAdapter( IFile.class ) != null );

    }

    /**
     * Initialize default values in search page elements
     */
    private void initializeValues() {
        // Set item and text here to prevent page from resizing
        pageElements.getSearchPattern().setItems( getPreviousSearchPatterns() );
        pageElements.getExtensions().setItems( searchDialog.getPrevExtensions() );
        if( !initializePatternControl() ) {
            pageElements.getSearchPattern().select( 0 );
            pageElements.getExtensions().setText( META_CHAR_STAR );
            searchDialog.handleWidgetSelected();
        }
    }

    /**
     * Gets the previous search patterns
     * 
     * @return array of previous search patterns
     */
    private String[] getPreviousSearchPatterns() {
        final int size = pageElements.getPrevSearchPattns().size();
        final String[] patterns = new String[size];
        for( int i = 0; i < size; i++ ) {
            patterns[i] = pageElements.getPrevSearchPattns().get( i ).getTextPattern();

        }
        return patterns;
    }

    /**
     * Initialize the search pattern combo value with selected text in the editor if any text selected
     * 
     * @return true when initialized with selected text else false
     */
    private boolean initializePatternControl() {
        final ISelection selection = pageElements.getPageContainer().getSelection();
        if( selection instanceof ITextSelection
            && !selection.isEmpty()
            && ((ITextSelection)selection).getLength() > 0 ) {
            final String text = ((ITextSelection)selection).getText();
            if( text != null ) {
                if( pageElements.isRegularExpressionSearch() ) {
                    pageElements.getSearchPattern()
                                .setText( FindReplaceDocumentAdapter.escapeForRegExPattern( text ) );
                } else {
                    pageElements.getSearchPattern().setText( insertEscapeChars( text ) );
                }

                if( searchDialog.getPrevExtensions().length > 0 ) {
                    pageElements.getExtensions().setText( searchDialog.getPrevExtensions()[0] );
                } else {
                    final String extension = getExtensionFromEditor();
                    if( extension == null ) {
                        pageElements.getExtensions().setText( META_CHAR_STAR );
                    } else {
                        pageElements.getExtensions().setText( extension );
                    }
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Inserts escape character in the given string
     * 
     * @param text
     * @return the string with escape characters
     */
    private String insertEscapeChars( final String text ) {
        if( text == null || text.equals( "" ) ) {
            return "";
        }
        final StringBuffer sbIn = new StringBuffer( text );
        final int lengthOfFirstLine = text.length();
        final StringBuffer sbOut = new StringBuffer( lengthOfFirstLine + 5 );
        int index = 0;
        while (index < lengthOfFirstLine) {
            final char character = sbIn.charAt( index );
            if( character == '*' || character == '?' || character == ESCAPE_CHAR ) {
                sbOut.append( ESCAPE_CHAR );
            }
            sbOut.append( character );
            index++;
        }
        return sbOut.toString();
    }

    /**
     * Gets the currently opened file extension
     * 
     * @return the currently opened file extension
     */
    private String getExtensionFromEditor() {
        final IEditorPart ePart = PlatformUI.getWorkbench()
                                            .getActiveWorkbenchWindow()
                                            .getActivePage()
                                            .getActiveEditor();
        if( ePart != null ) {
            final Object elem = ePart.getEditorInput();
            if( elem instanceof IFileEditorInput ) {
                final String extension = ((IFileEditorInput)elem).getFile().getFileExtension();
                if( extension == null ) {
                    return ((IFileEditorInput)elem).getFile().getName();
                }
                return "*." + extension;
            }
        }
        return null;
    }

}
