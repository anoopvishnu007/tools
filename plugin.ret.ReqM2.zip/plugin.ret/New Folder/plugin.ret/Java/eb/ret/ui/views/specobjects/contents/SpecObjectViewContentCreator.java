package eb.ret.ui.views.specobjects.contents;

import eb.ret.model.specobject.FormattedtextT;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.model.specobject.impl.SpecobjectTypeImpl;
import eb.ret.ui.views.specobjects.SpecObjectsView;
import eb.ret.ui.views.specobjects.helper.SelectionDialogUtil;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.FeatureMap.Entry;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.TableColumn;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class SpecObjectViewContentCreator {

    private static final List<String> DEFAULT_LIST = Arrays.asList( new String[]{"ID", "Version", "Status"} );
    /**
     * Constant for the column width
     */
    private static final int COL_WIDTH = 100;
    /**
     * Constant for links column usage
     */
    private static final String COL_LINKS = "Links";
    /**
     * Constant for ProvidesCoverage column usage
     */
    private static final String COL_PROVIDES_COV = "ProvidesCoverage";
    /**
     * column index
     */
    private int index = 0;
    /**
     * SpecObjectsView instance for the content creator
     */
    private final SpecObjectsView specObjectsView;

    /**
     * Default constructor
     */
    public SpecObjectViewContentCreator( final SpecObjectsView view ) {
        this.specObjectsView = view;
    }

    /**
     * Creates all the table columns
     */
    public void createColumns() {
        List<String> columnPrefList = SelectionDialogUtil.getColumnPreferences();
        if( columnPrefList == null ) {
            columnPrefList = DEFAULT_LIST;
        }
        createColumnsData();
        SelectionDialogUtil.ckeckForVisibility( specObjectsView, columnPrefList );
    }

    /**
     * Creates columns and its data-type for specobject view
     * 
     * @param column
     * @param columnList
     * @return
     */
    private void createColumnsData() {
        index = 0;

        TableViewerColumn col = null;

        addAttributeColumns();

        final Map<String, Integer> textColMap = ColumnConfig.getTextColMap();
        for( final String key : textColMap.keySet() ) {
            final int featureId = textColMap.get( key );
            col = createTableViewerColumn( key, COL_WIDTH );
            addFormattedTextLabelProvider( col, featureId );
        }

        final Map<String, Integer> nameColMap = ColumnConfig.getNameColMap();
        for( final String key : nameColMap.keySet() ) {

            final int featureId = nameColMap.get( key );
            col = createTableViewerColumn( key, COL_WIDTH );
            addNameLabelProvider( col, featureId );
        }

        final Map<String, Integer[]> multiValueColMap = ColumnConfig.getMultiValueColMap();
        for( final String key : multiValueColMap.keySet() ) {

            final Integer[] features = multiValueColMap.get( key );
            col = createTableViewerColumn( key, COL_WIDTH );
            addMultiLabelProvider( col, features );
        }

        addCustomizedColumns();

    }

    /**
     * add all the attribute columns specified in the attrColMap. The ID field is configured always as the first column
     */
    private void addAttributeColumns() {
        final Map<String, Integer> attrColMap = ColumnConfig.getAttributeColMap();
        final int idfeatureId = attrColMap.get( "ID" );
        TableViewerColumn col = createTableViewerColumn( "ID", COL_WIDTH );
        addAttributeLabelProvider( col, idfeatureId );

        for( final String key : attrColMap.keySet() ) {

            if( "ID".equals( key ) ) {
                continue;
            }

            final int featureId = attrColMap.get( key );
            col = createTableViewerColumn( key, COL_WIDTH );
            addAttributeLabelProvider( col, featureId );
        }
    }

    /**
     * adds the customized columns with specific formatting in label display
     * 
     * @return
     */
    private void addCustomizedColumns() {
        TableViewerColumn col = createTableViewerColumn( COL_LINKS, COL_WIDTH );
        final LinksColumnLabelProvider linLabelProvider = new LinksColumnLabelProvider( col );
        col.setLabelProvider( linLabelProvider );

        col = createTableViewerColumn( COL_PROVIDES_COV, COL_WIDTH );
        final ProvidesCoverageColumnLabelProvider pclLabelProvider = new ProvidesCoverageColumnLabelProvider( col );
        col.setLabelProvider( pclLabelProvider );
    }

    /**
     * Adds the label provider for the features given. The first feature (features[0]) will be retrieved on
     * SpecobjectType and the second on (features[1]) on the retrieved object
     * 
     * @param col
     * @param features
     */
    private void addMultiLabelProvider( final TableViewerColumn col, final Integer[] features ) {
        col.setLabelProvider( new ColumnLabelProvider() {

            @Override
            public String getText( final Object element ) {
                String textValue = "";
                final EObject object = (EObject)((SpecobjectTypeImpl)element).eGet( features[0], true, false );
                if( object != null ) {

                    final Object listObject = object.eGet( object.eClass().getEStructuralFeature( features[1] ) );
                    if( listObject instanceof EList<?> ) {
                        textValue = getListString( listObject );
                    }
                }
                col.getColumn().setData( ((SpecobjectType)element).getId(), textValue );
                return textValue;
            }

            private String getListString( final Object listObject ) {
                final EList<?> list = (EList<?>)listObject;
                if( list != null ) {
                    final StringBuilder builder = new StringBuilder();
                    for( final Object listElement : list ) {
                        if( builder.length() > 0 ) {
                            builder.append( "," );
                        }
                        builder.append( listElement );

                    }
                    return builder.toString();
                }

                return "";
            }
        }

        );
    }

    /**
     * adds the label provider for the feature. The feature is expected to be an {@link Enumerator}
     * 
     * @param col
     * @param featureId
     */
    private void addNameLabelProvider( final TableViewerColumn col, final int featureId ) {
        col.setLabelProvider( new ColumnLabelProvider() {
            @Override
            public String getText( final Object element ) {
                String textValue = "";
                final Enumerator type = (Enumerator)((SpecobjectTypeImpl)element).eGet( featureId, true, false );
                if( type != null ) {
                    textValue = type.getName();
                }
                col.getColumn().setData( ((SpecobjectType)element).getId(), textValue );
                return textValue;
            }
        } );

    }

    /**
     * adds the label provider for the feature. The feature is expected to be an {@link FormattedtextT}
     * 
     * @param col
     * @param featureId
     */
    private void addFormattedTextLabelProvider( final TableViewerColumn col, final int featureId ) {
        col.setLabelProvider( new ColumnLabelProvider() {
            @Override
            public String getText( final Object element ) {
                String textValue = "";
                final FormattedtextT text = (FormattedtextT)((SpecobjectTypeImpl)element).eGet( featureId, true, true );
                if( text != null ) {
                    final List<Entry> descriptions = text.getMixed();
                    if( descriptions != null ) {
                        final StringBuilder builder = new StringBuilder();
                        for( final Entry description : descriptions ) {
                            builder.append( description.getValue() );
                        }
                        textValue = builder.toString();
                    }
                }
                col.getColumn().setData( ((SpecobjectType)element).getId(), textValue );
                return textValue;
            }
        } );

    }

    /**
     * adds the label provider for the feature. The feature is expected to be of type {@link String}
     * 
     * @param col
     * @param featureId
     */
    public final void addAttributeLabelProvider( final TableViewerColumn col, final int featureId ) {
        col.setLabelProvider( new ColumnLabelProvider() {
            @Override
            public String getText( final Object element ) {
                String textValue = "";
                textValue = (String)((SpecobjectTypeImpl)element).eGet( featureId, true, true );
                col.getColumn().setData( ((SpecobjectType)element).getId(), textValue );
                return textValue;
            }
        } );
    }

    /**
     * Creates a table column and sets it properties
     * 
     * @param title
     * @param width
     * @return
     */
    private TableViewerColumn createTableViewerColumn( final String title, final int width ) {
        final int pos = index++;
        final TableViewerColumn viewerColumn = new TableViewerColumn( specObjectsView.getViewer(), SWT.NONE, pos );
        final TableColumn column = viewerColumn.getColumn();
        column.setText( title );
        column.setWidth( width );
        column.setResizable( true );
        column.setMoveable( true );
        column.addSelectionListener( getSelectionAdapter( viewerColumn ) );

        return viewerColumn;
    }

    /**
     * Selection adapter for sorting of specobject view columns
     * 
     * @param viewerColumn
     * @param index
     * @return
     */
    private SelectionAdapter getSelectionAdapter( final TableViewerColumn viewerColumn ) {
        final SelectionAdapter selectionAdapter = new SelectionAdapter() {
            @Override
            public void widgetSelected( final SelectionEvent event ) {
                specObjectsView.getComparator().setSortColumn( viewerColumn );
                final int direction = specObjectsView.getComparator().getDirection();
                specObjectsView.getViewer().getTable().setSortDirection( direction );
                specObjectsView.getViewer().getTable().setSortColumn( viewerColumn.getColumn() );
                specObjectsView.getViewer().refresh();
            }
        };
        return selectionAdapter;
    }

}
