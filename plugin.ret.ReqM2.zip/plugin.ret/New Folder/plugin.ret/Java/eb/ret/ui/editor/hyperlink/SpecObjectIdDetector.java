package eb.ret.ui.editor.hyperlink;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.ui.helper.SpecObjectEditorUtil;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.hyperlink.AbstractHyperlinkDetector;
import org.eclipse.jface.text.hyperlink.IHyperlink;

/**
 * This class detects the specobject ids present under the mouse clicked position as hyperlinks when clicking Ctrl+mouse
 * click in the Java editor
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectIdDetector extends AbstractHyperlinkDetector {

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.hyperlink.IHyperlinkDetector#detectHyperlinks(org.eclipse.jface.text.ITextViewer, org.eclipse.jface.text.IRegion, boolean)
     */
    @Override
    public IHyperlink[] detectHyperlinks( final ITextViewer textViewer,
                                          final IRegion region,
                                          final boolean canShowMultilinks ) {

        IHyperlink[] specObjectLinks = null;

        if( region != null ) {

            final IDocument document = textViewer.getDocument();
            final int offset = region.getOffset();

            try {
                specObjectLinks = SpecObjectEditorUtil.getSpecObjectLinks( document, offset );
            } catch( BadLocationException ex ) {
                ErrorLogger.logError( ex.getMessage(), ex );
            }
        }
        return specObjectLinks;
    }

}
