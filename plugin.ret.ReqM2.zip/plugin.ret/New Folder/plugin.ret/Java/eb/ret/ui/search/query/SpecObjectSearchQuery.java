/**
 * 
 */
package eb.ret.ui.search.query;

import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.ui.MessageFormatter;
import eb.ret.ui.RETPluginMessages;
import eb.ret.ui.search.result.view.SpecObjectSearchResult;
import eb.ret.util.PatternConstructor;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.ISearchResult;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.FileTextSearchScope;

import java.util.regex.Pattern;

/**
 * This class is the search query class for specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchQuery implements ISearchQuery {

    /**
     * specobject search result collector
     */
    private static SpecObjectSearchResultCollector collector;
    /**
     * search scope
     */
    private final FileTextSearchScope scope;
    /**
     * search string
     */
    private final String searchText;
    /**
     * specifying whether search is a regular expression search
     */
    private final boolean isRegEx;
    /**
     * specifying whether search is a case sensitive search
     */
    private final boolean isCaseSenstve;
    /**
     * search limit to type
     */
    private final LimitToType limitToType;
    /**
     * search for type
     */
    private final SearchForType searchFor;
    /**
     * search result object
     */
    private SpecObjectSearchResult result;
    /**
     * specifying whether search is a whole word search
     */
    private final boolean wholeWordSearch;

    /**
     * Constructor
     * 
     * @param searchString search string
     * @param searchForType search for type
     * @param limitTo search limit to type
     * @param isRegularEx search is regular expression search or not
     * @param isCaseSens search is case sensitive search or not
     * @param wholeWordSearch specify whether the search is a complete string match search
     * @param selScope search scope
     */
    public SpecObjectSearchQuery( final String searchString,
                                  final SearchForType searchForType,
                                  final LimitToType limitTo,
                                  final boolean isRegularEx,
                                  final boolean isCaseSens,
                                  final boolean wholeWordSearch,
                                  final FileTextSearchScope selScope ) {
        this.searchText = searchString;
        this.isRegEx = isRegularEx;
        this.isCaseSenstve = isCaseSens;
        this.scope = selScope;
        this.limitToType = limitTo;
        this.searchFor = searchForType;
        this.wholeWordSearch = wholeWordSearch;
    }

    /* (non-Javadoc)
     * @see org.eclipse.search.ui.ISearchQuery#run(org.eclipse.core.runtime.IProgressMonitor)
     */
    @Override
    public IStatus run( final IProgressMonitor monitor ) throws OperationCanceledException {
        final AbstractTextSearchResult textResult = (AbstractTextSearchResult)getSearchResult();
        textResult.removeAll();
        //creating the result collector object 
        collector = new SpecObjectSearchResultCollector( textResult );
        final SpecObjectSearchParams searchData = new SpecObjectSearchParams(
            isCaseSenstve,
            isRegEx,
            wholeWordSearch,
            searchText,
            limitToType,
            searchFor,
            getSearchPattern(),
            scope );
        //gets the specobject model search engine
        final SpecObjectModelSearchEngine specObjModelSE = new SpecObjectModelSearchEngine( collector, searchData );
        return specObjModelSE.search( monitor );
    }

    /**
     * Gets the search pattern of the search string
     * 
     * @return search pattern
     */
    public Pattern getSearchPattern() {
        return PatternConstructor.createPattern( searchText, isCaseSenstve, isRegEx, wholeWordSearch );
    }

    /**
     * Checks the scope is for all file types
     * 
     * @return true for if scope is for all file types else false
     */
    private boolean isFileNameScopeIsAllFileTypes() {
        boolean isScopeForAll = false;
        final String[] fileNamePatterns = scope.getFileNamePatterns();
        if( fileNamePatterns == null ) {
            isScopeForAll = true;
        } else {
            for( int i = 0; i < fileNamePatterns.length; i++ ) {
                if( "*".equals( fileNamePatterns[i] ) ) {
                    isScopeForAll = true;
                }
            }
        }
        return isScopeForAll;
    }

    /* (non-Javadoc)
     * @see org.eclipse.search.ui.ISearchQuery#getLabel()
     */
    @Override
    public String getLabel() {
        return RETPluginMessages.SpecObjectSearchQuery_label;
    }

    /* (non-Javadoc)
     * @see org.eclipse.search.ui.ISearchQuery#canRerun()
     */
    @Override
    public boolean canRerun() {
        return true;
    }

    /* (non-Javadoc)
     * @see org.eclipse.search.ui.ISearchQuery#canRunInBackground()
     */
    @Override
    public boolean canRunInBackground() {
        return true;
    }

    /* (non-Javadoc)
     * @see org.eclipse.search.ui.ISearchQuery#getSearchResult()
     */
    @Override
    public ISearchResult getSearchResult() {
        if( result == null ) {
            result = new SpecObjectSearchResult( this );
        }
        return result;
    }

    /**
     * Gets the result label string
     * 
     * @param nMatches number of matches
     * @return label string
     */
    public String getResultLabel( final int nMatches ) {
        final String searchString = searchText;
        // search with all file scopes
        if( isFileNameScopeIsAllFileTypes() ) {
            return getGlobalScopeResultLabel( nMatches, searchString );
        }
        // search  with selected file extensions
        if( nMatches == 1 ) {
            final Object[] args = {searchString, scope.getDescription(), scope.getFilterDescription()};
            return MessageFormatter.format( RETPluginMessages.SpecObjectSearchQuery_singularPatternWithFileExt, args );
        }
        final Object[] args = {
            searchString,
            Integer.valueOf( nMatches ),
            scope.getDescription(),
            scope.getFilterDescription()};
        return MessageFormatter.format( RETPluginMessages.SpecObjectSearchQuery_pluralPatternWithFileExt, args );
    }

    /**
     * gets the result label string for global scope search
     * 
     * @param nMatches number of matches
     * @param searchString search string
     * @return label string
     */
    private String getGlobalScopeResultLabel( final int nMatches, final String searchString ) {
        // search all file extensions
        if( nMatches == 1 ) {
            final Object[] args = {searchString, scope.getDescription()};
            return MessageFormatter.format( RETPluginMessages.SpecObjectSearchQuery_singularLabel, args );
        }
        final Object[] args = {searchString, Integer.valueOf( nMatches ), scope.getDescription()};
        return MessageFormatter.format( RETPluginMessages.SpecObjectSearchQuery_pluralPattern, args );
    }

}
