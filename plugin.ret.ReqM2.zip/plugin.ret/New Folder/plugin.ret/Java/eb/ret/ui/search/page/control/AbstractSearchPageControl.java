package eb.ret.ui.search.page.control;

import eb.ret.ui.search.page.SpecObjectSearchDialogPage;
import eb.ret.ui.search.page.SpecObjectSearchPageElements;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;

/**
 * Abstract base class for all controls in the specobject search page
 * 
 * @author anoopvn
 * 
 */
public abstract class AbstractSearchPageControl {

    /**
     * parent composite of the control
     */
    protected final Composite parentPage;
    /**
     * specobject search dialog page
     */
    protected final SpecObjectSearchDialogPage searchDialogPage;
    /**
     * specobject page elements
     */
    protected final SpecObjectSearchPageElements pageElements;

    /**
     * Contructor
     * 
     * @param parentPage
     * @param searchDialogPage
     */

    public AbstractSearchPageControl( final Composite parentPage, final SpecObjectSearchDialogPage searchDialogPage ) {
        this.parentPage = parentPage;
        this.searchDialogPage = searchDialogPage;
        this.pageElements = searchDialogPage.getPageElements();

    }

    /**
     * Creates button control according to the given parameter styles
     * 
     * @param parent parent composite
     * @param style button style
     * @param text button label text
     * @param data button data
     * @param isSelected true or false for the default selection
     * @return Button object
     */
    public Button createButton( final Composite parent,
                                final int style,
                                final String text,
                                final int data,
                                final boolean isSelected ) {
        final Button button = new Button( parent, style );
        button.setText( text );
        button.setData( Integer.valueOf( data ) );
        button.setLayoutData( new GridData( SWT.FILL, SWT.CENTER, false, false ) );
        button.setSelection( isSelected );
        return button;
    }

    /**
     * Abstract method to create the control
     */
    public abstract void createControl();

    /**
     * enable or disable a given group and its children depends on the enabled flag
     * 
     * @param group
     * @param enabled
     */
    protected void enableGroup( final Group group, final boolean enabled ) {

        final Control children[] = group.getChildren();
        for( int i = 0; i < children.length; i++ ) {
            children[i].setEnabled( enabled );
        }
        group.setEnabled( enabled );
    }

}
