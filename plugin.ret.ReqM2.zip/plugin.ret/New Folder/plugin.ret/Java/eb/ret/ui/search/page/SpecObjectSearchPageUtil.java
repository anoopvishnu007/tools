package eb.ret.ui.search.page;

import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.plugin.RETPlugin;
import eb.ret.ui.RETPluginMessages;
import eb.ret.ui.search.query.SpecObjectSearchQuery;
import eb.ret.ui.search.result.view.SpecObjectFileMatch;
import eb.ret.util.PatternConstructor;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.resource.JFaceColors;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.search.ui.ISearchPageContainer;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.text.FileTextSearchScope;
import org.eclipse.ui.IWorkingSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.PatternSyntaxException;

/**
 * This class contains utility methods for specobject search page
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchPageUtil {

    /**
     * Dialog store page
     */
    public static final String PAGE_NAME = "RETSearchPage";
    /**
     * Dialog store constant to store case sensitive check value
     */
    public static final String STORE_CASE_SENS = "CASE_SENSITIVE";
    /**
     * Dialog store constant to store regular expression check value
     */
    public static final String STORE_REGEXSEARCH = "REG_EX_SEARCH";
    /**
     * Dialog store constant to store searchFor value
     */
    private static final String STORE_SEARCHFOR = "SEARCH_FOR_VAL";
    /**
     * Dialog store constant to store limitTo value
     */
    private static final String STORE_LIMITTO = "LIMIT_TO_VAL";
    /**
     * Dialog store constant to maintain history
     */
    public static final String STORE_HISTORY = "HISTORY";
    /**
     * Dialog store constant to maintain history size
     */
    public static final String STORE_HIST_SIZE = "HISTORY_SIZE";
    /**
     * History size value for extension storage
     */
    public static final int STORE_EXTN_SIZE = 12;
    /**
     * Section name for the stored file extensions.
     * 
     */
    private static final String STORE_EXTENSIONS = "EXTENSIONS";
    /**
     * Search dialog page
     */
    private final SpecObjectSearchDialogPage searchDialog;
    /**
     * Search dialog page elements
     */
    public SpecObjectSearchPageElements pageElements;

    /**
     * Constructor
     * 
     * @param searchDialog
     */
    public SpecObjectSearchPageUtil( final SpecObjectSearchDialogPage searchDialog ) {
        this.searchDialog = searchDialog;
        pageElements = searchDialog.getPageElements();
    }

    /**
     * Created a file text search scope according to the given integer value
     * 
     * @param scope selected scope value
     * @return an object of FileTextSearchScope
     */
    public FileTextSearchScope createTextSearchScope( final int scope ) {
        // Setup search scope
        switch (scope) {
            case ISearchPageContainer.WORKSPACE_SCOPE:
                return FileTextSearchScope.newWorkspaceScope( pageElements.getExtensionStrings(), false );
            case ISearchPageContainer.SELECTION_SCOPE:
                return getSelectedResourcesScope();
            case ISearchPageContainer.SELECTED_PROJECTS_SCOPE:
                return getEnclosingProjectScope();
            case ISearchPageContainer.WORKING_SET_SCOPE:
                final IWorkingSet[] workingSets = pageElements.getPageContainer().getSelectedWorkingSets();
                return FileTextSearchScope.newSearchScope( workingSets, pageElements.getExtensionStrings(), false );
            default:
                // unknown scope
                return FileTextSearchScope.newWorkspaceScope( pageElements.getExtensionStrings(), false );
        }
    }

    /**
     * gets the selected resources scope
     * 
     * @return the selected resources scope
     */
    public FileTextSearchScope getSelectedResourcesScope() {
        final HashSet<IResource> resources = new HashSet<IResource>();
        final ISelection sel = pageElements.getPageContainer().getSelection();
        if( sel instanceof IStructuredSelection && !sel.isEmpty() ) {
            final Iterator<?> iter = ((IStructuredSelection)sel).iterator();
            while (iter.hasNext()) {
                final Object curr = iter.next();
                addResourcesInScope( resources, curr );
            }
        } else if( pageElements.getPageContainer().getActiveEditorInput() != null ) {
            resources.add( (IResource)pageElements.getPageContainer().getActiveEditorInput().getAdapter( IFile.class ) );
        }
        final IResource[] arr = resources.toArray( new IResource[resources.size()] );
        return FileTextSearchScope.newSearchScope( arr, pageElements.getExtensionStrings(), false );
    }

    /**
     * Adds the resources in the selected scope to the passed set
     * 
     * @param resources object of resources set
     * @param scope selected scope
     */
    private void addResourcesInScope( final Set<IResource> resources, final Object scope ) {
        if( scope instanceof IWorkingSet ) {
            final IWorkingSet workingSet = (IWorkingSet)scope;
            addWorkingSetResources( resources, workingSet );
        } else if( scope instanceof SpecObjectFileMatch ) {
            final IResource resource = ((SpecObjectFileMatch)scope).getParent();
            if( resource != null && resource.isAccessible() ) {
                resources.add( resource );
            }
        } else if( scope instanceof IAdaptable ) {
            final IResource resource = (IResource)((IAdaptable)scope).getAdapter( IResource.class );
            if( resource != null && resource.isAccessible() ) {
                resources.add( resource );
            }
        }
    }

    /**
     * Adds the resources in the selected working set to the passed set
     * 
     * @param resources object of resources set
     * @param workingSet
     */
    private void addWorkingSetResources( final Set<IResource> resources, final IWorkingSet workingSet ) {
        if( !workingSet.isAggregateWorkingSet() && !workingSet.isEmpty() ) {

            final IAdaptable[] elements = workingSet.getElements();
            for( int i = 0; i < elements.length; i++ ) {
                final IResource resource = (IResource)elements[i].getAdapter( IResource.class );
                if( resource != null && resource.isAccessible() ) {
                    resources.add( resource );
                }
            }
        }
    }

    /**
     * Gets the enclosing project scope
     * 
     * @return the enclosing project scope
     */
    public FileTextSearchScope getEnclosingProjectScope() {
        final String[] enclosProjectName = pageElements.getPageContainer().getSelectedProjectNames();
        if( enclosProjectName == null ) {
            return FileTextSearchScope.newWorkspaceScope( pageElements.getExtensionStrings(), false );
        }

        final IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        final IResource[] res = new IResource[enclosProjectName.length];
        for( int i = 0; i < res.length; i++ ) {
            res[i] = root.getProject( enclosProjectName[i] );
        }

        return FileTextSearchScope.newSearchScope( res, pageElements.getExtensionStrings(), false );
    }

    public SearchPatternData findInPrevious( final String pattern ) {
        for( final Iterator<SearchPatternData> iter = pageElements.getPrevSearchPattns().iterator(); iter.hasNext(); ) {
            final SearchPatternData element = iter.next();
            if( pattern.equals( element.getTextPattern() ) ) {
                return element;
            }
        }
        return null;
    }

    /**
     * Returns the page settings for this specobject search page.
     * 
     * @return the page settings to be used
     */
    public IDialogSettings getDialogSettings() {
        return RETPlugin.getDefault().getDialogSettingsSection( PAGE_NAME );
    }

    /**
     * Stores it current configuration in the dialog store.
     */
    public void writeConfiguration() {
        final IDialogSettings dialogSettings = getDialogSettings();
        dialogSettings.put( STORE_CASE_SENS, pageElements.isCaseSensitive() );
        dialogSettings.put( STORE_REGEXSEARCH, pageElements.isRegularExpressionSearch() );
        dialogSettings.put( STORE_LIMITTO, pageElements.getLimitToSelection() );
        dialogSettings.put( STORE_SEARCHFOR, pageElements.getSearchForSelection() );

        final int historySize = Math.min( pageElements.getPrevSearchPattns().size(), STORE_EXTN_SIZE );
        dialogSettings.put( STORE_HIST_SIZE, historySize );
        for( int i = 0; i < historySize; i++ ) {
            final IDialogSettings histSettings = dialogSettings.addNewSection( STORE_HISTORY + i );
            final SearchPatternData data = (pageElements.getPrevSearchPattns().get( i ));
            data.store( histSettings );
        }

        final IDialogSettings extensionsSettngs = dialogSettings.addNewSection( STORE_EXTENSIONS );
        extensionsSettngs.put( Integer.toString( 0 ), pageElements.getExtensions().getText() );
        final Set<String> extensionMap = new HashSet<String>( STORE_EXTN_SIZE );
        extensionMap.add( pageElements.getExtensions().getText() );
        final int length = Math.min( pageElements.getExtensions().getItemCount(), STORE_EXTN_SIZE - 1 );
        int index = 1;
        for( int i = 0; i < length; i++ ) {
            final String extension = pageElements.getExtensions().getItem( i );
            if( extensionMap.add( extension ) ) {
                extensionsSettngs.put( Integer.toString( index++ ), extension );
            }
        }

    }

    /**
     * Initializes itself from the stored page settings.
     */
    public void readConfiguration() {
        try {
            final IDialogSettings settings = getDialogSettings();
            pageElements.setCaseSensitiveFlag( settings.getBoolean( STORE_CASE_SENS ) );
            pageElements.setRegExSearch( settings.getBoolean( STORE_REGEXSEARCH ) );
            if( settings.get( STORE_LIMITTO ) != null ) {
                pageElements.setLimitToSelection( settings.getInt( STORE_LIMITTO ) );
            }
            if( settings.get( STORE_SEARCHFOR ) != null ) {
                pageElements.setSearchForSelection( settings.getInt( STORE_SEARCHFOR ) );
            }
            readHistoryConfiguration( settings );

            final Set<String> previousExtens = new LinkedHashSet<String>( STORE_EXTN_SIZE );
            final IDialogSettings extensionSettngs = settings.getSection( STORE_EXTENSIONS );
            if( extensionSettngs == null ) {
                searchDialog.setPrevExtensions( getPreviousExtensionsOldStyle() );
            } else {
                for( int i = 0; i < STORE_EXTN_SIZE; i++ ) {
                    final String extension = extensionSettngs.get( Integer.toString( i ) );
                    if( extension == null ) {
                        break;
                    }
                    previousExtens.add( extension );
                }
                searchDialog.setPrevExtensions( new String[previousExtens.size()] );
                previousExtens.toArray( searchDialog.getPrevExtensions() );
            }

        } catch( final NumberFormatException ex ) {
            //ignore the NumberFormatException for the first time of history reading
            if( !pageElements.isFirstTime() ) {
                ErrorLogger.logError( ex.getMessage(), ex );
            }
        }

    }

    /**
     * helper method to read history stored in the settings
     * 
     * @param settings
     */
    private void readHistoryConfiguration( final IDialogSettings settings ) {
        if( settings.get( STORE_HIST_SIZE ) != null ) {
            final int historySize = settings.getInt( STORE_HIST_SIZE );
            for( int i = 0; i < historySize; i++ ) {
                final IDialogSettings histSettings = settings.getSection( STORE_HISTORY + i );
                if( histSettings != null ) {
                    final SearchPatternData data = SearchPatternData.create( histSettings );
                    if( data != null ) {
                        pageElements.getPrevSearchPattns().add( data );
                    }
                }
            }
        }
    }

    public String[] getPreviousExtensionsOldStyle() {
        final List<String> extensions = new ArrayList<String>( pageElements.getPrevSearchPattns().size() );
        final int size = pageElements.getPrevSearchPattns().size();
        for( int i = 0; i < size; i++ ) {
            final SearchPatternData data = pageElements.getPrevSearchPattns().get( i );
            final String text = SpecObjectFileTypeEditor.typesToString( data.getFileNamePatterns() );
            if( !extensions.contains( text ) ) {
                extensions.add( text );
            }
        }
        return extensions.toArray( new String[extensions.size()] );
    }

    /**
     * Return search pattern data and update previous searches. An existing entry will be updated.
     * 
     * @return the search pattern data
     */
    public SearchPatternData getPatternData() {
        SearchPatternData match = findInPrevious( pageElements.getSearchPattern().getText() );
        if( match != null ) {
            pageElements.getPrevSearchPattns().remove( match );
        }
        match = new SearchPatternData(
            pageElements.getSearchPattern().getText(),
            pageElements.getSearchForSelection(),
            pageElements.getLimitToSelection(),
            pageElements.isCaseSensitive(),
            pageElements.isRegularExpressionSearch(),
            pageElements.getExtensionStrings(),
            pageElements.getPageContainer().getSelectedScope(),
            pageElements.getPageContainer().getSelectedWorkingSets() );

        pageElements.getPrevSearchPattns().add( 0, match );
        return match;
    }

    /**
     * Creates a new specobject query
     * 
     * @return specobject query
     * @throws CoreException
     */
    public ISearchQuery getSpecObjectSearchQuery() throws CoreException {
        final SearchPatternData data = getPatternData();
        final FileTextSearchScope scope = createTextSearchScope( pageElements.getPageContainer().getSelectedScope() );
        final String text = data.getTextPattern();
        final boolean regEx = data.isRegExSearch();
        final boolean caseSensitive = data.isCaseSensitive();
        final SearchForType searchFor = data.getSearchFor();
        final LimitToType limitTo = data.getLimitToType();
        return new SpecObjectSearchQuery( text, searchFor, limitTo, regEx, caseSensitive, false, scope );

    }

    /**
     * Updates the status of the search page according to the search validations
     */
    public void updateOKStatus() {
        boolean regexStatus = true;
        boolean hasTextPattern = false;
        final String searchPattern = pageElements.getSearchPattern().getText();
        if( searchPattern != null && !searchPattern.trim().isEmpty() ) {
            hasTextPattern = true;
            regexStatus = validateRegex( pageElements.getSearchPattern().getText() );
        }
        final boolean hasFilePattern = pageElements.getExtensions() != null
            && pageElements.getExtensions().getText().length() > 0;
        pageElements.getPageContainer().setPerformActionEnabled( regexStatus && hasFilePattern && hasTextPattern );
    }

    /**
     * Validates the given string is a regular expression or not if the check box regular expression is checked
     * 
     * @param patternText the string to check
     * @return return true if the given string is a valid regular expression else false
     */
    private boolean validateRegex( final String patternText ) {
        if( pageElements.isRegularExpressionSearch() ) {
            try {

                PatternConstructor.createPattern( patternText,
                                                  pageElements.isCaseSensitive(),
                                                  pageElements.isRegularExpressionSearch(),
                                                  false );
            } catch( final PatternSyntaxException e ) {
                final String locMessage = e.getLocalizedMessage();
                int msgIndex = 0;
                while (msgIndex < locMessage.length() && "\n\r".indexOf( locMessage.charAt( msgIndex ) ) == -1) {
                    msgIndex++;
                }
                setStatusMessage( true, locMessage.substring( 0, msgIndex ) ); // only take first line
                return false;
            }
            setStatusMessage( false, "" );
        } else {
            setStatusMessage( false, RETPluginMessages.SpecobjectSearchPage_containingText_hint );
        }
        return true;
    }

    /**
     * Sets the search string status message
     * 
     * @param error true when set an error status else false
     * @param message message
     */
    private void setStatusMessage( final boolean error, final String message ) {
        pageElements.getStatusLabel().setText( message );
        if( error ) {
            pageElements.getStatusLabel().setForeground( JFaceColors.getErrorText( pageElements.getStatusLabel()
                                                                                               .getDisplay() ) );
        } else {
            pageElements.getStatusLabel().setForeground( null );
        }
    }

}
