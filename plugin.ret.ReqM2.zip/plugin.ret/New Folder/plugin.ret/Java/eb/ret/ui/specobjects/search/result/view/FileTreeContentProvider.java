/**
 * 
 */
package eb.ret.ui.specobjects.search.result.view;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.viewers.AbstractTreeViewer;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.AbstractTextSearchViewPage;
import org.eclipse.search.ui.text.Match;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Content provider class for specobject search result view page
 * 
 * @author anoopvn
 * 
 */
public class FileTreeContentProvider implements ITreeContentProvider, IFileSearchContentProvider {

    /**
     * Array of input elements
     */
    private final Object[] EMPTY_ARR = new Object[0];
    /**
     * Search result
     */
    private AbstractTextSearchResult searchResult;
    /**
     * Search result page
     */
    private final SpecObjectSearchResultPage resultPage;
    /**
     * The tree viewer
     */
    private final AbstractTreeViewer treeViewer;
    /**
     * Children map to store match element and its child line element
     */
    private Map<Object, Set<Object>> childrenMap;

    /**
     * Constructor
     * 
     * @param page search result page
     * @param viewer tree viewer
     */
    FileTreeContentProvider( final AbstractTextSearchViewPage page, final AbstractTreeViewer viewer ) {
        resultPage = (SpecObjectSearchResultPage)page;
        treeViewer = viewer;
    }

    @Override
    public Object[] getElements( final Object inputElement ) {
        final Object[] children = getChildren( inputElement );
        final int elementLimit = resultPage.getElementLimit().intValue();
        if( elementLimit != -1 && elementLimit < children.length ) {
            final Object[] limitedChildren = new Object[elementLimit];
            System.arraycopy( children, 0, limitedChildren, 0, elementLimit );
            return limitedChildren;
        }
        return children;
    }

    @Override
    public void dispose() {
        // nothing to do
    }

    @Override
    public void inputChanged( final Viewer viewer, final Object oldInput, final Object newInput ) {
        if( newInput instanceof SpecObjectSearchResult ) {
            initialize( (SpecObjectSearchResult)newInput );
        }
    }

    /**
     * Initializes a search result match
     * 
     * @param result
     */
    private synchronized void initialize( final AbstractTextSearchResult result ) {
        searchResult = result;
        childrenMap = new HashMap<Object, Set<Object>>();

        if( result != null ) {
            final Object[] elements = result.getElements();
            for( int elemIndex = 0; elemIndex < elements.length; elemIndex++ ) {
                final Match[] matches = result.getMatches( elements[elemIndex] );
                for( int matchIndex = 0; matchIndex < matches.length; matchIndex++ ) {
                    insert( ((SpecObjectFileMatch)matches[matchIndex]).getSpecObjectElement(), false );
                }

            }
        }
    }

    /**
     * Insert a child element
     * 
     * @param childElm child element
     * @param refreshViewer whether to refresh the viewer or not
     */
    private void insert( final Object childElm, final boolean refreshViewer ) {
        Object child = childElm;
        Object parent = getParent( child );
        while (parent != null) {
            if( SearchResultProviderUtils.insertChild( parent, child, childrenMap ) ) {
                if( refreshViewer ) {
                    treeViewer.add( parent, child );
                }
            } else {
                if( refreshViewer ) {
                    treeViewer.refresh( parent );
                }
                return;
            }
            child = parent;
            parent = getParent( child );
        }
        if( SearchResultProviderUtils.insertChild( searchResult, child, childrenMap ) && refreshViewer ) {

            treeViewer.add( searchResult, child );

        }
    }

    /**
     * Remove the element from the viewer
     * 
     * @param element element to remove
     * @param refreshViewer tree viewer
     */
    private void remove( final Object element, final boolean refreshViewer ) {

        if( hasChildren( element ) ) {
            if( refreshViewer ) {
                treeViewer.refresh( element );
            }
        } else {
            if( SearchResultProviderUtils.hasMatches( element, searchResult ) ) {
                if( refreshViewer ) {
                    treeViewer.refresh( element );
                }

            } else {
                childrenMap.remove( element );
                final Object parent = getParent( element );
                if( parent == null ) {
                    SearchResultProviderUtils.removeFromSiblings( element, searchResult, childrenMap );
                    if( refreshViewer ) {
                        treeViewer.refresh();
                    }

                } else {
                    SearchResultProviderUtils.removeFromSiblings( element, parent, childrenMap );
                    remove( parent, refreshViewer );
                }
            }
        }
    }

    @Override
    public Object[] getChildren( final Object parentElement ) {
        final Set<?> children = childrenMap.get( parentElement );
        if( children == null ) {
            return EMPTY_ARR;
        }
        return children.toArray();
    }

    @Override
    public boolean hasChildren( final Object element ) {
        return getChildren( element ).length > 0;
    }

    /*
     * (non-Javadoc)
     * @see org.eclipse.search.internal.ui.text.IFileSearchContentProvider#elementsChanged(java.lang.Object[])
     */
    @Override
    public synchronized void elementsChanged( final Object[] updatedElements ) {
        for( int elemIndex = 0; elemIndex < updatedElements.length; elemIndex++ ) {
            if( (updatedElements[elemIndex] instanceof SpecObjectElement) ) {
                // change events to line elements are reported in text search
                final SpecObjectElement lineElement = (SpecObjectElement)updatedElements[elemIndex];
                final int nMatches = lineElement.getNumberOfMatches( searchResult );
                if( nMatches > 0 ) {
                    if( SearchResultProviderUtils.hasChild( lineElement.getParent(), lineElement, childrenMap ) ) {
                        treeViewer.update( SearchResultProviderUtils.getObject( lineElement ), null );
                    } else {
                        insert( lineElement, true );
                    }
                } else {
                    remove( lineElement, true );
                }

            } else {
                // change events to elements are reported in file search
                if( searchResult.getMatchCount( updatedElements[elemIndex] ) > 0 ) {
                    insert( updatedElements[elemIndex], true );
                } else {
                    remove( updatedElements[elemIndex], true );
                }
            }
        }
    }

    @Override
    public void clear() {
        initialize( searchResult );
        treeViewer.refresh();
    }

    @Override
    public Object getParent( final Object element ) {
        if( element instanceof IProject ) {
            return null;
        }
        if( element instanceof IResource ) {
            final IResource resource = (IResource)element;
            return resource.getParent();
        }
        if( element instanceof SpecObjectElement ) {
            return ((SpecObjectElement)element).getParent();
        }

        if( element instanceof SpecObjectFileMatch ) {
            final SpecObjectFileMatch match = (SpecObjectFileMatch)element;
            return match.getSpecObjectElement();
        }
        return null;
    }
}
