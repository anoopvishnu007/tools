/**
 * 
 */
package eb.ret.ui.specobjects.search.result.view;

import eb.ret.ui.MessageFormatter;
import eb.ret.ui.RETPluginImages;
import eb.ret.ui.RETPluginMessages;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.viewers.DelegatingStyledCellLabelProvider.IStyledLabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StyledString;
import org.eclipse.jface.viewers.StyledString.Styler;
import org.eclipse.osgi.util.TextProcessor;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.AbstractTextSearchViewPage;
import org.eclipse.search.ui.text.Match;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import java.util.Arrays;
import java.util.Comparator;

/**
 * @author anoopvn
 * 
 */
public class FileLabelProvider extends LabelProvider implements IStyledLabelProvider {

    /**
     * match high light background color name
     */
    private static final String BG_COLOR_NAME = "org.eclipse.search.ui.match.highlight";
    /**
     * Styler for label
     */
    public static final Styler HIGHLIGHT_STYLE = StyledString.createColorRegistryStyler( null, BG_COLOR_NAME );
    /**
     * Show label constant
     */
    public static final int SHOW_LABEL = 1;
    /**
     * Show label path constant
     */
    public static final int SHOW_LABEL_PATH = 2;

    /**
     * Separator format for label
     */
    private static final String FGSEPERATORFORMAT = "{0} - {1}";
    /**
     * Label string
     */
    private static final String FGELLIPSES = " ... ";
    /**
     * label provider object
     */
    private final WorkbenchLabelProvider labelProvider;
    /**
     * Text search view page
     */
    private final AbstractTextSearchViewPage specObjSearchPage;
    /**
     * comparator class object for label
     */
    private final Comparator<Object> matchComparator;
    /**
     * Line match image
     */
    private final Image lineMatchImage;

    /**
     * minimal number of characters shown after and before a match
     */
    private static final int MIN_MATCH_CONTEXT = 10;

    /**
     * Constructor
     * 
     * @param page search view page
     * @param orderFlag order
     */
    public FileLabelProvider( final AbstractTextSearchViewPage page ) {
        super();
        labelProvider = new WorkbenchLabelProvider();
        specObjSearchPage = page;
        lineMatchImage = RETPluginImages.get( RETPluginImages.IMGOBJ_TEXT_LINE );
        matchComparator = new Comparator<Object>() {
            @Override
            public int compare( final Object obj1, final Object obj2 ) {
                return ((SpecObjectFileMatch)obj1).getOriginalOffset()
                    - ((SpecObjectFileMatch)obj2).getOriginalOffset();
            }
        };
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.viewers.LabelProvider#getText(java.lang.Object)
     */
    @Override
    public String getText( final Object object ) {
        return getStyledText( object ).getString();
    }

    @Override
    public StyledString getStyledText( final Object element ) {
        if( element instanceof SpecObjectElement ) {
            return getLineElementLabel( (SpecObjectElement)element );
        }

        if( !(element instanceof IResource) ) {
            return new StyledString();
        }

        final IResource resource = (IResource)element;
        if( !resource.exists() ) {
            new StyledString( RETPluginMessages.FileLabelProvider_removed_resource_label );
        }
        final String name = getResourceName( resource );
        return getColoredLabelWithCounts( resource, new StyledString( name ) );
    }

    /**
     * Gets the line element label string
     * 
     * @param lineElement the line element
     * @return styled label string
     */
    private StyledString getLineElementLabel( final SpecObjectElement lineElement ) {
        final int lineNumber = lineElement.getLine();
        final String lineNumberString = MessageFormatter.format( RETPluginMessages.FileLabelProvider_line_number,
                                                                 Integer.valueOf( lineNumber ) );

        final StyledString str = new StyledString( lineNumberString, StyledString.QUALIFIER_STYLER );

        final Match[] matches = lineElement.getMatches( specObjSearchPage.getInput() );
        Arrays.sort( matches, matchComparator );

        final String content = lineElement.getContents();

        int pos = getLineStart( matches, content, lineElement.getOffset() );

        final int length = content.length();

        int charsToCut = getCharsToCut( length, matches ); // number of characters to leave away if the line is too long
        for( int i = 0; i < matches.length; i++ ) {
            final SpecObjectFileMatch match = (SpecObjectFileMatch)matches[i];
            final int start = Math.max( match.getOriginalOffset() - lineElement.getOffset(), 0 );
            // append gap between last match and the new one
            if( pos < start ) {
                if( charsToCut > 0 ) {
                    charsToCut = appendShortenedGap( content, pos, start, charsToCut, i == 0, str );
                } else {
                    str.append( content.substring( pos, start ) );
                }
            }
            // append match
            final int end = Math.min( match.getOriginalOffset() + match.getOriginalLength() - lineElement.getOffset(),
                                      lineElement.getLength() );
            str.append( content.substring( start, end ), HIGHLIGHT_STYLE );
            pos = end;
        }
        // append rest of the line
        if( charsToCut > 0 ) {
            appendShortenedGap( content, pos, length, charsToCut, false, str );
        } else {
            str.append( content.substring( pos ) );
        }
        return str;
    }

    /**
     * Append a gap to show minimal number of characters shown after and before a match
     * 
     * @param content string content of match
     * @param start start offset
     * @param end end offset
     * @param charsToCut chars to cut
     * @param isFirst is first match
     * @param str styled label string
     * @return number of gap characters
     */
    private int appendShortenedGap( final String content,
                                    final int start,
                                    final int end,
                                    final int charsToCut,
                                    final boolean isFirst,
                                    final StyledString str ) {
        int gapLength = end - start;
        if( !isFirst ) {
            gapLength -= MIN_MATCH_CONTEXT;
        }
        if( end < content.length() ) {
            gapLength -= MIN_MATCH_CONTEXT;
        }
        if( gapLength < MIN_MATCH_CONTEXT ) { // don't cut, gap is too small
            str.append( content.substring( start, end ) );
            return charsToCut;
        }

        int context = MIN_MATCH_CONTEXT;
        if( gapLength > charsToCut ) {
            context += gapLength - charsToCut;
        }

        if( !isFirst ) {
            str.append( content.substring( start, start + context ) ); // give all extra context to the right side of a match
            context = MIN_MATCH_CONTEXT;
        }

        str.append( FGELLIPSES, StyledString.QUALIFIER_STYLER );

        if( end < content.length() ) {
            str.append( content.substring( end - context, end ) );
        }
        return charsToCut - gapLength + FGELLIPSES.length();
    }

    /**
     * gets the characters to cut
     * 
     * @param contentLength content length
     * @param matches array of matches
     * @return number of characters to cut
     */
    private int getCharsToCut( final int contentLength, final Match[] matches ) {
        if( contentLength <= 256 || !"win32".equals( SWT.getPlatform() ) || matches.length == 0 ) {
            return 0;
        }
        return contentLength - 256 + Math.max( matches.length * FGELLIPSES.length(), 100 );
    }

    /**
     * Evaluates the line start position of match
     * 
     * @param matches array of matches
     * @param lineContent line content
     * @param lineOffset line offset
     * @return line start position
     */
    private int getLineStart( final Match[] matches, final String lineContent, final int lineOffset ) {
        int max = lineContent.length();
        if( matches.length > 0 ) {
            final SpecObjectFileMatch match = (SpecObjectFileMatch)matches[0];
            max = match.getOriginalOffset() - lineOffset;
            if( max < 0 ) {
                return 0;
            }
        }
        for( int i = 0; i < max; i++ ) {
            final char chr = lineContent.charAt( i );
            if( !Character.isWhitespace( chr ) || chr == '\n' || chr == '\r' ) {
                return i;
            }
        }
        return max;
    }

    /**
     * Gets the colored label with match counts
     * 
     * @param element the element to get the match count for *
     * @param coloredName styled label string
     * @return styled label string
     */
    private StyledString getColoredLabelWithCounts( final Object element, final StyledString coloredName ) {
        final AbstractTextSearchResult result = specObjSearchPage.getInput();
        if( result == null ) {
            return coloredName;
        }

        final int matchCount = result.getMatchCount( element );
        if( matchCount <= 1 ) {
            return coloredName;
        }

        final String countInfo = MessageFormatter.format( RETPluginMessages.FileLabelProvider_count_format,
                                                          Integer.valueOf( matchCount ) );
        coloredName.append( ' ' ).append( countInfo, StyledString.COUNTER_STYLER );
        return coloredName;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.viewers.LabelProvider#getImage(java.lang.Object)
     */
    @Override
    public Image getImage( final Object element ) {
        if( element instanceof SpecObjectElement ) {
            return lineMatchImage;
        }
        if( !(element instanceof IResource) ) {
            return null;
        }

        final IResource resource = (IResource)element;
        return labelProvider.getImage( resource );
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.viewers.BaseLabelProvider#dispose()
     */
    @Override
    public void dispose() {
        super.dispose();
        labelProvider.dispose();
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.viewers.BaseLabelProvider#isLabelProperty(java.lang.Object, java.lang.String)
     */
    @Override
    public boolean isLabelProperty( final Object element, final String property ) {
        return labelProvider.isLabelProperty( element, property );
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.viewers.BaseLabelProvider#removeListener(org.eclipse.jface.viewers.ILabelProviderListener)
     */
    @Override
    public void removeListener( final ILabelProviderListener listener ) {
        super.removeListener( listener );
        labelProvider.removeListener( listener );
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.viewers.BaseLabelProvider#addListener(org.eclipse.jface.viewers.ILabelProviderListener)
     */
    @Override
    public void addListener( final ILabelProviderListener listener ) {
        super.addListener( listener );
        labelProvider.addListener( listener );
    }

    /**
     * Adds special marks so that that the given string is readable in a BIDI environment.
     * 
     * @param string the string
     * @param delimiters the additional delimiters
     * @return the processed styled string
     */
    private static String processPathString( final String string, final String delimiters ) {
        return TextProcessor.process( string, delimiters );
    }

    /**
     * Returns the label of a path.
     * 
     * @param path the path
     * @param isOSPath if true, the path represents an OS path, if false it is a workspace path.
     * @return the label of the path to be used in the UI.
     */
    public static String getPathLabel( final IPath path, final boolean isOSPath ) {
        String label;
        if( isOSPath ) {
            label = path.toOSString();
        } else {
            label = path.makeRelative().toString();
        }
        return processPathString( label, "/\\:." );
    }

    /**
     * Returns a label for a resource name.
     * 
     * @param resource the resource
     * @return the label of the resource name.
     */
    public static String getResourceName( final IResource resource ) {
        return processPathString( resource.getName(), ":." );
    }
}
