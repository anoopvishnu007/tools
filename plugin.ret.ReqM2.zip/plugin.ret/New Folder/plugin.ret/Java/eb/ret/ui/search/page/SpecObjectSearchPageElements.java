package eb.ret.ui.search.page;

import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;

import org.eclipse.search.ui.ISearchPageContainer;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.fieldassist.ContentAssistCommandAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * This class holds the controls in the specobject search page
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchPageElements {

    /**
     * integer value representing the limitTo selection. By default ALL has to be selected
     */
    private int limitToSel = LimitToType.ALL.getValue();
    /**
     * integer value representing the searchFor selection. By default ID has to be selected
     */
    private int searchForSel = SearchForType.ID.getValue();
    /**
     * search text pattern combo
     */
    private Combo searchPattern;

    /**
     * Limit to group control
     */
    private Group limitToGroup;
    /**
     * search page container object
     */
    private ISearchPageContainer pageContainer;
    /**
     * List to hold previous search patterns
     */
    private final List<SearchPatternData> prevSearchPattns = new ArrayList<SearchPatternData>();
    /**
     * File type editor control functionalities
     */
    private SpecObjectFileTypeEditor fileTypeEditor;
    /**
     * File extensions combo control
     */
    private Combo extensions;
    /**
     * Label for the search pattern control
     */
    private Label statusLabel;
    /**
     * Regular expression flag
     */
    private boolean regExSearch;
    /**
     * Case sensitive flag
     */
    private boolean caseSensitiveFlag;
    /**
     * Page is loading first time flag
     */
    private boolean firstTime = true;
    /**
     * search pattern content assist for regular expression search
     */
    private ContentAssistCommandAdapter patternContAssist;
    /**
     * case sensitive check box
     */
    private Button caseSensitive;
    /**
     * regular expression check box
     */
    private Button regularExpression;

    /**
     * gets the search pattern combo control
     * 
     * @return search pattern combo control
     */
    public Combo getSearchPattern() {
        return searchPattern;
    }

    /**
     * Sets the search pattern combo control
     * 
     * @param searchPattern search pattern combo control
     */
    public void setSearchPattern( final Combo searchPattern ) {
        this.searchPattern = searchPattern;
    }

    /**
     * 
     * @return the limitTo selection in the pageElements
     */
    public int getLimitToSelection() {
        return limitToSel;
    }

    /**
     * sets the limitTo selection from the user
     * 
     * @param limitToSelection
     */
    public void setLimitToSelection( final int limitToSelection ) {
        this.limitToSel = limitToSelection;
    }

    /**
     * 
     * @return the searchFor selection in the pageElements
     */
    public int getSearchForSelection() {
        return searchForSel;
    }

    /**
     * sets the searchFor selection from the user
     * 
     * @param limitToSelection
     */
    public void setSearchForSelection( final int searchForSel ) {
        this.searchForSel = searchForSel;
    }

    /**
     * Gets the limit to group
     * 
     * @return
     */
    public Group getLimitToGroup() {
        return limitToGroup;
    }

    /**
     * Sets the limit to group
     * 
     * @param limitToGroup
     */
    public void setLimitToGroup( final Group limitToGroup ) {
        this.limitToGroup = limitToGroup;
    }

    /**
     * Gets the page container
     * 
     * @return
     */
    public ISearchPageContainer getPageContainer() {
        return pageContainer;
    }

    /**
     * Sets the page container
     * 
     * @param pageContainer
     */
    public void setPageContainer( final ISearchPageContainer pageContainer ) {
        this.pageContainer = pageContainer;
    }

    /**
     * Gets the file type editor
     * 
     * @return
     */
    public SpecObjectFileTypeEditor getFileTypeEditor() {
        return fileTypeEditor;
    }

    /**
     * Sets the file type editor
     * 
     * @param fileTypeEditor
     */
    public void setFileTypeEditor( final SpecObjectFileTypeEditor fileTypeEditor ) {
        this.fileTypeEditor = fileTypeEditor;
    }

    /**
     * Gets the file type extensions
     * 
     * @return
     */
    public String[] getExtensionStrings() {
        return fileTypeEditor.getFileTypes();
    }

    /**
     * Gets the extension combo control
     * 
     * @return
     */
    public Combo getExtensions() {
        return extensions;
    }

    /**
     * Sets the file type extensions
     * 
     * @param extensions
     */
    public void setExtensions( final Combo extensions ) {
        this.extensions = extensions;
    }

    /**
     * gets the status label
     * 
     * @return
     */
    public Label getStatusLabel() {
        return statusLabel;
    }

    /**
     * Sets the status label
     * 
     * @param statusLabel
     */
    public void setStatusLabel( final Label statusLabel ) {
        this.statusLabel = statusLabel;
    }

    /**
     * Gets the case sensitive flag
     * 
     * @return
     */
    public boolean isCaseSensitive() {
        return caseSensitiveFlag;
    }

    /**
     * Gets the regular expression flag
     * 
     * @return
     */
    public boolean isRegularExpressionSearch() {
        return regExSearch;
    }

    /**
     * Sets the regular expression search flag
     * 
     * @param isRegularExSearch
     */
    public void setRegularExSearch( final boolean isRegularExSearch ) {
        this.regExSearch = isRegularExSearch;
    }

    /**
     * Gets the first time flag
     * 
     * @return
     */
    public boolean isFirstTime() {
        return firstTime;
    }

    /**
     * Sets the first time flag
     * 
     * @param firstTime
     */
    public void setFirstTime( final boolean firstTime ) {
        this.firstTime = firstTime;
    }

    /**
     * Gets the previous search pattern list
     * 
     * @return
     */
    public List<SearchPatternData> getPrevSearchPattns() {
        return prevSearchPattns;
    }

    /**
     * Gets the case sensitive button
     * 
     * @return
     */
    public Button getCaseSensitive() {
        return caseSensitive;
    }

    /**
     * Sets the case sensitive button
     * 
     * @param caseSensitive
     */
    public void setCaseSensitive( final Button caseSensitive ) {
        this.caseSensitive = caseSensitive;
    }

    /**
     * Gets the regular expression button
     * 
     * @return
     */
    public Button getRegularExpression() {
        return regularExpression;
    }

    /**
     * Sets the regular expression button
     * 
     * @param regularExpression
     */
    public void setRegularExpression( final Button regularExpression ) {
        this.regularExpression = regularExpression;
    }

    /**
     * Returns the regular expression search value
     * 
     * @return
     */
    public boolean isRegExSearch() {
        return regExSearch;
    }

    /**
     * Sets the regular expression search value
     * 
     * @param regExSearch
     */
    public void setRegExSearch( final boolean regExSearch ) {
        this.regExSearch = regExSearch;
    }

    /**
     * Returns the case sensitive flag value
     * 
     * @return
     */
    public boolean isCaseSensitiveFlag() {
        return caseSensitiveFlag;
    }

    /**
     * Sets the case sensitive flag
     * 
     * @param caseSensitiveFlag
     */
    public void setCaseSensitiveFlag( final boolean caseSensitiveFlag ) {
        this.caseSensitiveFlag = caseSensitiveFlag;
    }

    /**
     * Returns the pattern content assist control
     * 
     * @return
     */
    public ContentAssistCommandAdapter getPatternContAssist() {
        return patternContAssist;
    }

    /**
     * Sets the pattern content assist control
     * 
     * @param patternContAssist
     */
    public void setPatternContAssist( final ContentAssistCommandAdapter patternContAssist ) {
        this.patternContAssist = patternContAssist;
    }

}
