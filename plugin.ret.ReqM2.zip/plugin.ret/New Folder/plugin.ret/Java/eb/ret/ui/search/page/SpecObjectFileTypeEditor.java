package eb.ret.ui.search.page;

import eb.ret.ui.RETPluginMessages;

import org.eclipse.jface.window.Window;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.dialogs.TypeFilteringDialog;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

/**
 * This class does the functionalities of file type selection control
 * 
 * @author anoopvn
 * 
 */

public class SpecObjectFileTypeEditor extends SelectionAdapter implements DisposeListener {

    /**
     * File extension control
     */
    private Combo fileTypeTextField;
    /**
     * Browse button to select file extensions
     */
    private Button typeBrowseButton;
    /**
     * Type delimiter message
     */
    private final static String TYPE_DELIMITER = RETPluginMessages.FileTypeEditor_typeDelimiter;
    /**
     * File extension pattern negation character
     */
    public final static String FILE_PATRN_NEGATR = "!";
    /**
     * File extension pattern star character
     */
    public static final String STAR_CHAR = "*";

    /**
     * File extension type comparator
     */
    private static final Comparator<Object> FILE_TYPES_CMPTR = new Comparator<Object>() {
        @Override
        public int compare( final Object obj1, final Object obj2 ) {
            return compare( (String)obj1, (String)obj2 );
        }

        public int compare( final String obj1, final String obj2 ) {
            final boolean isNegative1 = obj1.startsWith( FILE_PATRN_NEGATR );
            final boolean isNegative2 = obj2.startsWith( FILE_PATRN_NEGATR );
            if( isNegative1 != isNegative2 ) {
                return isNegative1 ? 1 : -1;
            }
            return obj1.compareTo( obj2 );
        }
    };

    /**
     * Constructor
     * 
     * @param textField combo box control
     * @param browseButton button control
     */
    public SpecObjectFileTypeEditor( final Combo textField, final Button browseButton ) {
        super();
        fileTypeTextField = textField;
        typeBrowseButton = browseButton;

        fileTypeTextField.addDisposeListener( this );
        typeBrowseButton.addDisposeListener( this );
        typeBrowseButton.addSelectionListener( this );
    }

    @Override
    public void widgetDisposed( final DisposeEvent event ) {
        final Widget widget = event.widget;
        if( widget.equals( fileTypeTextField ) ) {
            fileTypeTextField = null;
        } else if( widget.equals( typeBrowseButton ) ) {
            typeBrowseButton = null;
        }
    }

    @Override
    public void widgetSelected( final SelectionEvent event ) {
        if( event.widget.equals( typeBrowseButton ) ) {
            handleBrowseButton();
        }
    }

    /**
     * Gets the file extensions selected in the text field
     * 
     * @return array file types
     */
    public String[] getFileTypes() {
        final Set<String> result = new HashSet<String>();
        final StringTokenizer tokenizer = new StringTokenizer( fileTypeTextField.getText(), TYPE_DELIMITER );

        while (tokenizer.hasMoreTokens()) {
            final String currentExtension = tokenizer.nextToken().trim();
            result.add( currentExtension );
        }
        return result.toArray( new String[result.size()] );
    }

    /**
     * Sets the given types to text field in correct format
     * 
     * @param types array of file types
     */
    public void setFileTypes( final String[] types ) {
        fileTypeTextField.setText( typesToString( types ) );
    }

    /**
     * Method to handle browse button
     */
    protected void handleBrowseButton() {
        final TypeFilteringDialog dialog = new TypeFilteringDialog(
            fileTypeTextField.getShell(),
            Arrays.asList( getFileTypes() ) );
        if( dialog.open() == Window.OK ) {
            final Object[] result = dialog.getResult();
            final HashSet<String> patterns = new HashSet<String>();
            boolean starIncluded = false;
            for( final Object resultObj : result ) {
                final String fileNameSelection = resultObj.toString();
                if( STAR_CHAR.equals( fileNameSelection ) ) {
                    starIncluded = true;
                } else {
                    patterns.add( "*." + fileNameSelection );
                }
            }
            if( patterns.isEmpty() && starIncluded ) { // remove star when other file extensions active
                patterns.add( STAR_CHAR );
            }
            final String[] filePatterns = patterns.toArray( new String[patterns.size()] );
            Arrays.sort( filePatterns );
            setFileTypes( filePatterns );
        }
    }

    /**
     * Formats the given types to correct file name search format
     * 
     * @param types array of file types
     * @return formatted type string
     */
    public static String typesToString( final String[] types ) {
        Arrays.sort( types, FILE_TYPES_CMPTR );
        final StringBuffer result = new StringBuffer();
        for( int index = 0; index < types.length; index++ ) {
            if( index > 0 ) {
                result.append( TYPE_DELIMITER );
                result.append( ' ' );
            }
            result.append( types[index] );
        }
        return result.toString();
    }
}
