package eb.ret.ui.search.result.view;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.search.query.FileUtils;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Region;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.Match;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Match class for specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectFileMatch extends Match {
    /**
     * Specobject element of corresponding match
     */
    private final SpecobjectType specObject;
    /**
     * Original region of the match
     */
    private Region matchRegion;
    /**
     * Line element parent resource which contains the line
     */
    private final IResource parentResource;
    /**
     * Line number line
     */
    private int lineNumber;
    /**
     * Line start offset
     */
    private int lineStartOffset;
    /**
     * Line end offset
     */
    private int lineEndOffset;
    /**
     * line content string
     */
    private String lineContents;

    /**
     * Constructor
     * 
     * @param element matched file
     */
    public SpecObjectFileMatch( final IFile element ) {
        super( element, -1, -1 );
        specObject = null;
        matchRegion = null;
        parentResource = null;
    }

    /**
     * Constructor
     * 
     * @param element matched file
     * @param offset matched offset
     * @param length matched region length
     * @param lineElement matched line element
     */
    public SpecObjectFileMatch( final IFile element,
                                final int offset,
                                final int length,
                                final SpecobjectType specObject ) {
        super( element, offset, length );

        this.specObject = specObject;
        parentResource = element;
        setMatchLineDetails( offset, parentResource );
    }

    @Override
    public void setOffset( final int offset ) {
        if( matchRegion == null ) {
            // remember the original location before changing it
            matchRegion = new Region( getOffset(), getLength() );
        }
        super.setOffset( offset );
    }

    @Override
    public void setLength( final int length ) {
        if( matchRegion == null ) {
            // remember the original location before changing it
            matchRegion = new Region( getOffset(), getLength() );
        }
        super.setLength( length );
    }

    /**
     * Gets the original offset of the match
     * 
     * @return
     */
    public int getOriginalOffset() {
        if( matchRegion != null ) {
            return matchRegion.getOffset();
        }
        return getOffset();
    }

    /**
     * Gets the original length
     * 
     * @return length
     */
    public int getOriginalLength() {
        if( matchRegion != null ) {
            return matchRegion.getLength();
        }
        return getLength();
    }

    /**
     * gets the line element of specobject
     * 
     * @return line element
     */
    public SpecobjectType getSpecObjectElement() {
        return specObject;
    }

    /**
     * Gets the parent resource
     * 
     * @return
     */
    public IResource getParent() {
        return parentResource;
    }

    /**
     * Gets the line number
     * 
     * @return
     */
    public int getLine() {
        return lineNumber;
    }

    /**
     * Gets the line contents
     * 
     * @return
     */
    public String getContents() {
        return lineContents;
    }

    /**
     * Gets the start offset
     * 
     * @return
     */
    public int getLineStartOffset() {
        return lineStartOffset;
    }

    /**
     * Checks the passed offset contains in the current line
     * 
     * @param offset offset
     * @return true if passed offset contains with in the line else false
     */
    public boolean contains( final int offset ) {
        return lineStartOffset <= offset && offset < lineStartOffset + lineContents.length();
    }

    /**
     * Gets the line content length
     * 
     * @return
     */
    public int getLineContentLength() {
        return lineContents.length();
    }

    /**
     * Gets the matches of the current line element
     * 
     * @param result the search result
     * @return array of matches in the current line
     */
    public SpecObjectFileMatch[] getMatches( final AbstractTextSearchResult result ) {
        final List<SpecObjectFileMatch> res = new ArrayList<SpecObjectFileMatch>();
        final Match[] matches = result.getMatches( parentResource );
        for( int index = 0; index < matches.length; index++ ) {
            final SpecObjectFileMatch currentMatch = (SpecObjectFileMatch)matches[index];
            if( currentMatch.getSpecObjectElement() == this.specObject ) {
                res.add( currentMatch );
            }
        }
        return res.toArray( new SpecObjectFileMatch[res.size()] );
    }

    /**
     * Gets the number of matches in the current line
     * 
     * @param result the search result
     * @return number of matches
     */
    public int getNumberOfMatches( final AbstractTextSearchResult result ) {
        int count = 0;
        final Match[] matches = result.getMatches( parentResource );
        for( int index = 0; index < matches.length; index++ ) {
            final SpecObjectFileMatch currentMatches = (SpecObjectFileMatch)matches[index];
            if( currentMatches.getSpecObjectElement() == this.specObject ) {
                count++;
            }
        }
        return count;
    }

    /**
     * Gets the line element information object of the offset
     * 
     * @param offset matched offset
     * @param matchRequestor match requester object
     * @return the line element of the offset
     */
    private void setMatchLineDetails( final int offset, final IResource parent ) {

        IRegion lineStart = null;
        try {
            lineNumber = FileUtils.getLineNumber( (IFile)parent, offset );
            lineStart = FileUtils.getLineInformation( (IFile)parent, offset );
        } catch( final IOException e ) {
            ErrorLogger.logError( e.getMessage(), e );
        }
        IDocument document = null;
        if( lineStart != null ) {
            try {
                document = FileUtils.getDocument( (IFile)parent );
                if( document != null ) {
                    lineStartOffset = lineStart.getOffset();
                    lineEndOffset = lineStart.getOffset() + lineStart.getLength();
                    lineContents = document.get( lineStartOffset, lineStart.getLength() ).trim();
                }
            } catch( final IOException e ) {
                ErrorLogger.logError( e.getMessage(), e );
            } catch( final BadLocationException e ) {
                ErrorLogger.logError( e.getMessage(), e );
            }

        }

    }

    /**
     * @return the lineEndOffset
     */
    public int getLineMatchEndOffset() {
        return lineEndOffset;
    }

}
