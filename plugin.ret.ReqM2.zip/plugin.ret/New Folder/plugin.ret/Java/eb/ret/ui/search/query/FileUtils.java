/**
 * 
 */
package eb.ret.ui.search.query;

import eb.ret.core.reqm2.processor.ErrorLogger;

import org.eclipse.core.filebuffers.FileBuffers;
import org.eclipse.core.filebuffers.ITextFileBuffer;
import org.eclipse.core.filebuffers.ITextFileBufferManager;
import org.eclipse.core.filebuffers.LocationKind;
import org.eclipse.core.resources.IFile;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.texteditor.ITextEditor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * This class contains the utility methods for file operations
 * 
 * @author anoopvn
 * 
 */
public final class FileUtils {

    /**
     * Constructor
     */
    private FileUtils() {

    }

    /**
     * Evaluates the text editors opened and add it to the map
     * 
     * @param fileDocumentMap map contains IFile as key and corresponding document as value
     * @param ePart editor part
     */
    public static void evaluateTextEditor( final Map<IFile, IDocument> fileDocumentMap, final IEditorPart ePart ) {
        final IEditorInput input = ePart.getEditorInput();
        if( input instanceof IFileEditorInput ) {
            final IFile file = ((IFileEditorInput)input).getFile();
            if( !fileDocumentMap.containsKey( file ) ) { // take the first editor found
                final ITextFileBufferManager bufferManager = FileBuffers.getTextFileBufferManager();
                final ITextFileBuffer textFileBuffer = bufferManager.getTextFileBuffer( file.getFullPath(),
                                                                                        LocationKind.IFILE );
                if( textFileBuffer == null ) {
                    // use document provider
                    final IDocument document = ((ITextEditor)ePart).getDocumentProvider().getDocument( input );
                    fileDocumentMap.put( file, document );

                } else {
                    // file buffer has precedence
                    fileDocumentMap.put( file, textFileBuffer.getDocument() );
                }
            }
        }
    }

    /**
     * Evaluates the non file buffer documents
     * 
     * @return returns a map from IFile to IDocument for all open, dirty editors
     */
    public static Map<IFile, IDocument> evalNonFileBufferDocuments() {
        Map<IFile, IDocument> result = new HashMap<IFile, IDocument>();
        final IWorkbench workbench = PlatformUI.getWorkbench();
        final IWorkbenchWindow[] windows = workbench.getWorkbenchWindows();
        for( int winIndex = 0; winIndex < windows.length; winIndex++ ) {
            final IWorkbenchPage[] pages = windows[winIndex].getPages();
            for( int pageIndex = 0; pageIndex < pages.length; pageIndex++ ) {
                final IEditorReference[] editorRefs = pages[pageIndex].getEditorReferences();
                for( int editorIndex = 0; editorIndex < editorRefs.length; editorIndex++ ) {
                    final IEditorPart epart = editorRefs[editorIndex].getEditor( false );
                    if( epart instanceof ITextEditor && epart.isDirty() ) { // only dirty editors
                        evaluateTextEditor( result, epart );
                    }
                }
            }
        }
        if( !PlatformUI.isWorkbenchRunning() ) {
            result = Collections.emptyMap();
        }
        return result;
    }

    /**
     * Load a text file contents as a string.
     * 
     * @param file The input file
     * @return The file contents as a String
     * @exception IOException IO Error
     */
    public static String readFile( final File file ) throws IOException {

        final BufferedReader reader = new BufferedReader( new FileReader( file ) );
        String line = null;
        final StringBuilder stringBuilder = new StringBuilder();
        final String lineSep = System.getProperty( "line.separator" );
        try {
            line = reader.readLine();
            while (line != null) {
                stringBuilder.append( line );
                stringBuilder.append( lineSep );
                line = reader.readLine();
            }
        } finally {
            reader.close();
        }
        return stringBuilder.toString();
    }

    /**
     * Gets the document of the file
     * 
     * @param file the file
     * @param docsInEditors documents currently opened in editors
     * @return IDocument corresponding to the file
     * @throws IOException
     */
    public static IDocument getDocument( final IFile file, final Map<?, ?> docsInEditors ) throws IOException {
        IDocument document = getOpenDocument( file, docsInEditors );
        if( document == null ) {
            document = getDocument( file );
        }
        return document;
    }

    /**
     * Gets the document of the IFile object
     * 
     * @param file the file
     * @return IDocument
     * @throws IOException
     */
    public static IDocument getDocument( final IFile file ) throws IOException {
        IDocument document;
        String buffer = "";
        buffer = readFile( file.getLocation().toFile() );
        document = new Document( buffer );
        return document;
    }

    /**
     * Gets the line information of the offset from the file
     * 
     * @param file the file object
     * @param offset offset of the line
     * @return IRegion region of the line containing the offset
     * @throws IOException
     */
    public static IRegion getLineInformation( final IFile file, final int offset ) throws IOException {
        IRegion lineRegion = null;
        final IDocument document = getDocument( file );
        try {
            final int lineNumber = document.getLineOfOffset( offset );
            lineRegion = document.getLineInformation( lineNumber );
        } catch( final BadLocationException e ) {
            ErrorLogger.logError( e.getMessage(), e );
        }

        return lineRegion;
    }

    /**
     * Gets the line number of the offset in the file
     * 
     * @param file the file object
     * @param offset offset of the line
     * @return line number of the offset
     * @throws IOException
     */
    public static int getLineNumber( final IFile file, final int offset ) throws IOException {

        int editorLineNumber = 0;
        try {
            final IDocument document = getDocument( file );
            final int lineNumber = document.getLineOfOffset( offset );
            //document line number starts with 0. So for getting the editor line number we need to add 1 to it
            editorLineNumber = lineNumber + 1;
        } catch( final BadLocationException e ) {
            ErrorLogger.logError( e.getMessage(), e );
        }
        return editorLineNumber;
    }

    /**
     * Gets the document object of the corresponding file
     * 
     * @param file the file
     * @param docsInEditors documents currently opened in editors
     * @return IDocument
     */
    public static IDocument getOpenDocument( final IFile file, final Map<?, ?> docsInEditors ) {
        IDocument document = (IDocument)docsInEditors.get( file );
        if( document == null ) {
            final ITextFileBufferManager bufferManager = FileBuffers.getTextFileBufferManager();
            final ITextFileBuffer textFileBuffer = bufferManager.getTextFileBuffer( file.getFullPath(),
                                                                                    LocationKind.IFILE );
            if( textFileBuffer != null ) {
                document = textFileBuffer.getDocument();
            }
        }
        return document;
    }
}
