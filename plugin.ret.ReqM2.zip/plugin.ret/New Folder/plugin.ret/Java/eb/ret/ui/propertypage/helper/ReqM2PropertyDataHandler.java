package eb.ret.ui.propertypage.helper;

import eb.ret.core.reqm2.ReqM2Manager;
import eb.ret.core.reqm2.builder.RETNatureController;
import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.core.reqm2.data.ReqM2Property;
import eb.ret.ui.propertypage.ReqM2PropertyPage;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * This class does the data handling functionalities of ReqM2 property page
 * 
 * @author anoopvn
 */
/*
 * !LINKSTO eclipse.ret.req.InputDirectorySelection,1
 */
public class ReqM2PropertyDataHandler {

    /**
     * The current selected project
     */
    private final IProject project;

    private final ReqM2PropertyPage propertyPage;

    /**
     * constructor
     * 
     * @param project the project which properties shown
     */
    public ReqM2PropertyDataHandler( final ReqM2PropertyPage propertyPage ) {
        this.propertyPage = propertyPage;
        this.project = propertyPage.getCurrentProject();
    }

    /*
     * !LINKSTO eclipse.ret.req.InputFileSettings,1
     */
    /**
     * Saving the input directory paths.
     * 
     * @param latestIDirs latest input directories
     * @throws CoreException
     */
    public void saveReqM2Properties( final List<RETDirectory> latestIDirs ) throws CoreException {

        final IProject currentProject = project;
        if( currentProject != null ) {
            final List<RETDirectory> existingDirs = ReqM2InputData.getRETData()
                                                                  .getRETInputDirectories( currentProject );
            // handling directory resources
            handleDirectories( latestIDirs, existingDirs );

            handleProjectNature( latestIDirs );

        }
    }

    /**
     * handles the directory resources
     * 
     * @param latestDirs list of latest selected directory paths
     * @param existingDirs list of existing(previously selected) directory paths
     * @throws CoreException
     */
    private void handleDirectories( final List<RETDirectory> latestDirs, final List<RETDirectory> existingDirs )
        throws CoreException {
        // for handling the removed directories
        final List<RETDirectory> removedDirs = new ArrayList<RETDirectory>();
        // temporary list for finding newly added directories
        final List<RETDirectory> addedDirs = new ArrayList<RETDirectory>( latestDirs.size() );
        addedDirs.addAll( latestDirs );
        if( existingDirs != null && !existingDirs.isEmpty() ) {
            for( final RETDirectory dir : existingDirs ) {
                // if a directory in the existing directory list is present in
                // the latest directory list then remove from newly added
                // directories.The rest of the directories are freshly added
                // thus need to handle addition process
                if( latestDirs.contains( dir ) ) {
                    addedDirs.remove( dir );
                } else {
                    // if not present then add it removed list for cleaning up
                    // the
                    // ReqM2 output files
                    removedDirs.add( dir );
                }
            }
        }
        refreshProperty( latestDirs );
        touchDirectories( addedDirs );
        cleanUpReqM2Resource( removedDirs );

    }

    /**
     * Removes the associated ReqM2 output of the paths present in the removed list
     * 
     * @param removedList list of paths removed
     */
    private void cleanUpReqM2Resource( final List<RETDirectory> removedDirs ) {
        for( final RETDirectory removedDir : removedDirs ) {
            final IPath path = WorkspaceUtils.getIPath( removedDir.getPath() );
            final IFolder remFolder = project.getFolder( path );
            ReqM2Manager.getInstance().removeReqM2Directory( remFolder );
        }
    }

    /*
     * !LINKSTO eclipse.ret.req.InputFileSettings,1, !
     * eclipse.ret.req.ImportProjectProperties,1, !
     * eclipse.ret.req.ReopeningProjectWithProperties,1,
     */
    /**
     * Refreshing the property store with new input directory list
     * 
     * @param latestDirs latest input directories
     */
    private void refreshProperty( final List<RETDirectory> latestDirs ) {
        final ReqM2Property property = new ReqM2Property( latestDirs );
        property.setDocTypes( propertyPage.getDocTypeCache() );
        ReqM2InputData.getRETProperty().setReqM2Property( project, property );
    }

    /**
     * Touch the newly added directories to bring the resource delta to the build
     * 
     * @param addedDir list of newly added directories
     * @throws CoreException
     */
    private void touchDirectories( final List<RETDirectory> addedDir ) throws CoreException {
        final IProject currentProject = project;
        for( final Iterator<RETDirectory> iterator = addedDir.iterator(); iterator.hasNext(); ) {
            final RETDirectory dir = iterator.next();
            // Touch the folder to bring the resource delta to the build.
            if( currentProject.exists( WorkspaceUtils.getIPath( dir.getPath() ) ) ) {
                final IFolder folder = currentProject.getFolder( dir.getPath() );
                touchDirectory( folder );
            }
        }

    }

    /**
     * Touch the folder to bring the resource delta to the build The child files needs to be touched to bring delta for
     * all resources to the RET Build
     * 
     * @param folder the folder to touch
     * @throws CoreException
     */
    private void touchDirectory( final IFolder folder ) throws CoreException {
        final IProgressMonitor monitor = new NullProgressMonitor();
        folder.touch( monitor );
        for( final IResource child : folder.members() ) {
            if( child.getType() == IResource.FOLDER ) {
                touchDirectory( (IFolder)child );
            } else if( child.getType() == IResource.FILE ) {
                child.touch( monitor );
            }
        }
    }

    /**
     * set the RETNature if the project is not RETNature. disable the RETBuild if the directory list is null ebable the
     * RETBuild if directory is not null and RETBuild is not present
     * 
     * 
     * @param inputDirectList
     * @throws CoreException
     */
    private void handleProjectNature( final java.util.List<RETDirectory> inputDirectList ) throws CoreException {

        final IProject currentProject = project;

        if( inputDirectList == null || inputDirectList.isEmpty() ) {
            return;
        }

        if( !RETNatureController.isRETProject( currentProject ) ) {
            RETNatureController.activateRETNature( currentProject );
        }
    }
}
