package eb.ret.ui.editor.texthover;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.model.data.ISpecObjectData;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.helper.SpecObjectEditorUtil;
import eb.ret.ui.helper.SpecObjectEditorUtil.SpecObjectMatch;

import org.eclipse.jdt.ui.text.java.hover.IJavaEditorTextHover;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IInformationControlCreator;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextHoverExtension;
import org.eclipse.jface.text.ITextHoverExtension2;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.ui.IEditorPart;

public class LinksToElementTextHover implements IJavaEditorTextHover, ITextHoverExtension, ITextHoverExtension2 {

    /**
     * To create an IInformationControl to display the specobject tooltip.
     */
    private IInformationControlCreator hoverCtrlCreator;
    /**
     * To create an IInformationControl to display the specobject hover control.
     */
    private IInformationControlCreator pstrCtrlCreator;
    /**
     * private instance of specObject selected
     */
    private SpecobjectType specObject;

    @Override
    public String getHoverInfo( final ITextViewer textViewer, final IRegion hoverRegion ) {
        return null;
    }

    @Override
    public IRegion getHoverRegion( final ITextViewer textViewer, final int offset ) {
        final IDocument document = textViewer.getDocument();
        IRegion region = null;
        try {
            final SpecObjectMatch specObjectMatch = SpecObjectEditorUtil.getSpecObjectMatch( document, offset );
            if( specObjectMatch != null ) {
                region = specObjectMatch.getRegion();
            }
        } catch( final BadLocationException ex ) {
            ErrorLogger.logError( ex.getMessage(), ex );
        }
        return region;
    }

    @Override
    public void setEditor( final IEditorPart arg0 ) {
        // No use. 
    }

    @Override
    public Object getHoverInfo2( final ITextViewer textViewer, final IRegion hoverRegion ) {

        if( hoverRegion != null ) {
            final IDocument document = textViewer.getDocument();
            final int offset = hoverRegion.getOffset();

            specObject = getSpecObject( document, offset );
            if( specObject != null ) {
                return specObject;
            }
        }
        return null;
    }

    @Override
    public IInformationControlCreator getHoverControlCreator() {
        if( hoverCtrlCreator == null ) {
            hoverCtrlCreator = new SpecobjectHoverControlCreator( getInformationPresenterControlCreator() );
        }
        return hoverCtrlCreator;
    }

    /**
     * To create an information control to display the specobject hover tooltip.
     * 
     * @return
     */
    public IInformationControlCreator getInformationPresenterControlCreator() {
        if( pstrCtrlCreator == null ) {
            pstrCtrlCreator = new SpecobjectPresenterControlCreator( specObject );
        }
        return pstrCtrlCreator;
    }

    /**
     * To get the selected specobject.
     * 
     * @param document
     * @param offset
     * @return specobject.
     */
    private static SpecobjectType getSpecObject( final IDocument document, final int offset ) {
        SpecobjectType specObject = null;
        try {
            final SpecObjectMatch specObjectMatch = SpecObjectEditorUtil.getSpecObjectMatch( document, offset );
            if( specObjectMatch != null ) {
                final ISpecObjectData specObjData = SpecObjectResourceManager.getInstance().getSpecObjectData();
                specObject = specObjData.getSpecObject( specObjectMatch.getId() );
            }
        } catch( final BadLocationException ex ) {
            ErrorLogger.logError( ex.getMessage(), ex );
        }
        return specObject;
    }
}
