/**
 * 
 */
package eb.ret.ui.search.query;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.model.data.ISpecObjectData;
import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.text.specobject.AbstractSpecObjectRegion;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This class contains the utility methods of specobject search engine class
 * 
 * @author anoopvn
 * 
 */
public final class SpecObjectSearchEngineUtils {

    private SpecObjectSearchEngineUtils() {
        super();
    }

    /**
     * gets the workspace relative path of the given path
     * 
     * @param path path of the directory
     * @return the workspace relative path
     */

    public static String getWorkSpaceRelativePath( final IPath path ) {
        String actualPath = null;
        if( path != null ) {
            actualPath = path.toOSString();
            final IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
            final IContainer container = root.getContainerForLocation( path );
            if( container == null ) {
                actualPath = path.toOSString();
            } else {
                actualPath = container.getFullPath().toOSString();
            }
        }
        return actualPath;

    }

    /**
     * Gets the specobjects corresponding to the search parameters
     * 
     * @param params search parameters
     * @return list of specobjects
     */
    public static List<SpecobjectType> getSpecobjects( final SpecObjectSearchParams params ) {
        final ISpecObjectData specObjectData = SpecObjectResourceManager.getInstance().getSpecObjectData();
        return specObjectData.getSpecObjectList( params );

    }

    /**
     * Add the specobjects present in the files, which are in scope to a map as file as the key and list of specobjects
     * present in that file as value
     * 
     * @param fileList list of specobject files or empty file list
     * @param filesInScopeList list of files present inside the scope selected
     * @param specObjects list of specobjects
     * @param specObjSearchMap map containing files and specobjects or empty map
     */
    public static void addSpecObjects( final List<IFile> fileList,
                                       final List<IFile> filesInScopeList,
                                       final List<SpecobjectType> specObjects,
                                       final Map<IFile, List<SpecobjectType>> specObjSearchMap ) {
        for( final SpecobjectType specObject : specObjects ) {
            if( specObject.eResource().getURI().isPlatformResource() ) {
                addToSpecObjectMap( fileList, filesInScopeList, specObject, specObjSearchMap );
            }

        }
    }

    /**
     * Add the specobject present in the files, which are in scope to a map as file as the key and list of specobjects
     * present in that file as value
     * 
     * @param fileList list of specobject files or empty file list
     * @param filesInScopeList list of files present inside the scope selected
     * @param specObject the adding specobject
     * @param specObjSearchMap map containing files and specobjects or empty map
     */
    public static void addToSpecObjectMap( final List<IFile> fileList,
                                           final List<IFile> filesInScopeList,
                                           final SpecobjectType specObject,
                                           final Map<IFile, List<SpecobjectType>> specObjSearchMap ) {

        List<SpecobjectType> specObjectList = null;
        final IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        final String sourceFileLoc = specObject.getSourcefile();
        final IPath path = WorkspaceUtils.getIPath( sourceFileLoc );
        final IPath sourcePath = WorkspaceUtils.getIPath( SpecObjectSearchEngineUtils.getWorkSpaceRelativePath( path ) );
        final IFile sourceFile = root.getFile( sourcePath );
        if( filesInScopeList.contains( sourceFile ) ) {
            if( !fileList.contains( sourceFile ) ) {
                fileList.add( sourceFile );
            }
            if( specObjSearchMap.containsKey( sourceFile ) ) {
                specObjectList = specObjSearchMap.get( sourceFile );
                if( !specObjectList.contains( specObject ) ) {
                    specObjectList.add( specObject );
                    specObjSearchMap.put( sourceFile, specObjectList );
                }

            } else {
                specObjectList = new ArrayList<SpecobjectType>();
                specObjectList.add( specObject );
                specObjSearchMap.put( sourceFile, specObjectList );

            }
        }

    }

    /**
     * 
     * identifies the search regions depends on the search parameters and the specobject
     * 
     * @param file
     * @param specobject
     * @param document
     * @param searchParams
     * @return list of regions to be searched for the search string
     */

    public static List<IRegion> getSearchRegionList( final IFile file,
                                                     final SpecobjectType specobject,
                                                     final IDocument document,
                                                     final SpecObjectSearchParams searchParams ) {

        final AbstractSpecObjectRegion specObjectRegion = WorkspaceUtils.getSpecObjectRegion( specobject,
                                                                                                    file,
                                                                                                    document );

        final List<IRegion> regionList = new ArrayList<IRegion>();
        if( SearchForType.ID.equals( searchParams.getSearchFor() ) ) {
            if( LimitToType.DECLARATIONS.equals( searchParams.getLimitToType() ) ) {
                addToRegionList( specObjectRegion.getIdRegion(), regionList );
            } else if( LimitToType.REFERENCES.equals( searchParams.getLimitToType() ) ) {
                addToRegionList( specObjectRegion.getLinksRegion(), regionList );
                addToRegionList( specObjectRegion.getLinksToRegion(), regionList );
            } else if( LimitToType.ALL.equals( searchParams.getLimitToType() ) ) {
                addToRegionList( specObjectRegion.getIdRegion(), regionList );
                addToRegionList( specObjectRegion.getLinksRegion(), regionList );
                addToRegionList( specObjectRegion.getLinksToRegion(), regionList );
            }

        } else if( SearchForType.DESCRIPTION.equals( searchParams.getSearchFor() ) ) {
            regionList.add( specObjectRegion.getDescriptionRegion() );

        } else if( SearchForType.COMMENTS.equals( searchParams.getSearchFor() ) ) {
            regionList.add( specObjectRegion.getCommentsRegion() );
        }

        return regionList;

    }

    /**
     * Adds the region to the region list
     * 
     * @param region region to add
     * @param regionList list of regions
     */
    private static void addToRegionList( final IRegion region, final List<IRegion> regionList ) {
        if( region != null && regionList != null ) {
            regionList.add( region );
        }
    }

}
