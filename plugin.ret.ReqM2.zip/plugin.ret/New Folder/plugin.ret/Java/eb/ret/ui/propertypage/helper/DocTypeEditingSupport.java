package eb.ret.ui.propertypage.helper;

import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.ui.propertypage.ReqM2PropertyPage;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ComboBoxViewerCellEditor;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;

import java.util.ArrayList;
import java.util.List;

public class DocTypeEditingSupport extends EditingSupport {
    /**
     * For storing RET input directory table details
     */
    private final TableViewer viewer;
    /**
     * propertyPage instance to access the page variables
     */
    private final ReqM2PropertyPage propertyPage;
    /**
     * Cell Editor used for DocType column in RET Property page
     */
    private ComboBoxViewerCellEditor cellEditor;

    /**
     * Constructor
     * 
     * @param viewer tableviewer
     */
    public DocTypeEditingSupport( final ReqM2PropertyPage propertyPage ) {
        super( propertyPage.getViewer() );
        this.propertyPage = propertyPage;
        this.viewer = propertyPage.getViewer();
    }

    @Override
    protected CellEditor getCellEditor( final Object element ) {
        if( propertyPage.getDocTypeCache() == null ) {
            final List<String> data = new ArrayList<String>( 6 );
            if( element.getClass().isAssignableFrom( RETDirectory.class ) ) {
                data.add( ((RETDirectory)element).getDocType() );
            }
            propertyPage.setDocTypeCache( data );
        }
        cellEditor = new ComboBoxViewerCellEditor( viewer.getTable(), SWT.NONE );
        for( final String docTypeCache : propertyPage.getDocTypeCache() ) {
            cellEditor.getViewer().add( docTypeCache );
        }
        return cellEditor;
    }

    @Override
    protected boolean canEdit( final Object element ) {
        final RETDirectory directory = (RETDirectory)element;
        return directory.isDocTypeEditable();
    }

    @Override
    protected Object getValue( final Object element ) {
        final RETDirectory directory = (RETDirectory)element;

        return directory.getDocType();
    }

    @Override
    protected void setValue( final Object element, final Object value ) {
        final RETDirectory directory = (RETDirectory)element;
        String text = (String)value;
        if( value == null ) {
            text = ((CCombo)cellEditor.getControl()).getText();
            if( text == null || text.length() == 0 ) {
                propertyPage.checkForError();
                return;
            }

        }
        directory.setDocType( text );
        if( !text.trim().isEmpty() && !propertyPage.getDocTypeCache().contains( text ) ) {
            propertyPage.addDocTypeCache( text );
        }
        propertyPage.checkForError();
        viewer.update( element, null );

    }

}