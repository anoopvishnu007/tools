/**
 * 
 */
package eb.ret.ui.search.result.view;

/**
 * File search content provider interface
 * 
 * @author anoopvn
 * 
 */
public interface IFileSearchContentProvider {

    /**
     * Update the elements which are changed
     * 
     * @param updatedElements changed elements
     */
    public abstract void elementsChanged( Object[] updatedElements );

    /**
     * Clear the input of the content provider
     */
    public abstract void clear();

}
