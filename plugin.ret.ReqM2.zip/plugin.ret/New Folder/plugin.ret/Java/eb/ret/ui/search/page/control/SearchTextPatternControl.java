package eb.ret.ui.search.page.control;

import eb.ret.ui.RETPluginMessages;
import eb.ret.ui.search.page.SpecObjectSearchDialogPage;

import org.eclipse.jface.fieldassist.ComboContentAdapter;
import org.eclipse.jface.text.FindReplaceDocumentAdapterContentProposalProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.fieldassist.ContentAssistCommandAdapter;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;

/**
 * This class represents the search string pattern control in search page
 * 
 * @author anoopvn
 * 
 */
public class SearchTextPatternControl extends AbstractSearchPageControl {

    /**
     * Constructor
     * 
     * @param parentPage
     * @param searchDialogPage
     */
    public SearchTextPatternControl( final Composite parentPage, final SpecObjectSearchDialogPage searchDialogPage ) {
        super( parentPage, searchDialogPage );
    }

    @Override
    public void createControl() {
        // grid layout with 2 columns Info text
        final Composite group = new Composite( parentPage, 0 );
        final GridLayout layout = new GridLayout( 2, false );
        layout.marginWidth = 0;
        layout.marginHeight = 0;
        group.setLayout( layout );
        // Text line which explains the special characters
        createSearchStringLabel( group );
        createSearchPatternCombo( group );
        createCaseSensitiveCheckBox( group );
        createSeparator( group );
        createRegularExpressionCheckBox( group );
        group.setLayoutData( new GridData( GridData.FILL, GridData.CENTER, false, false, 2, 1 ) );
    }

    /**
     * Creates separator control
     * 
     * @param parent parent
     */
    private void createSeparator( final Composite parent ) {
        final Label separator = new Label( parent, SWT.NONE );
        separator.setVisible( false );
        final GridData gdData = new GridData( GridData.FILL, GridData.FILL, true, false, 1, 1 );
        gdData.heightHint = searchDialogPage.convertHeightInCharsToPixels( 1 ) / 3;
        separator.setLayoutData( gdData );
    }

    /**
     * Creates regular expression check box
     * 
     * @param parent
     */
    private void createRegularExpressionCheckBox( final Composite parent ) {
        // RegEx checkbox
        final Button btnRegEx = new Button( parent, SWT.CHECK );
        btnRegEx.setText( RETPluginMessages.SpecObjectSearchPage_regularExpression );
        btnRegEx.setSelection( pageElements.isRegularExpressionSearch() );

        btnRegEx.addSelectionListener( new SelectionAdapter() {
            @Override
            public void widgetSelected( final SelectionEvent event ) {
                pageElements.setRegExSearch( btnRegEx.getSelection() );
                searchDialogPage.getSpecObjectutil().updateOKStatus();
                searchDialogPage.getSpecObjectutil().writeConfiguration();
                pageElements.getPatternContAssist().setEnabled( pageElements.isRegExSearch() );
            }
        } );
        btnRegEx.setLayoutData( new GridData( GridData.FILL, GridData.FILL, false, false, 1, 1 ) );
        btnRegEx.setFont( parent.getFont() );
        pageElements.setRegularExpression( btnRegEx );
    }

    /**
     * Creates case sensitive check box
     * 
     * @param parent
     */
    private void createCaseSensitiveCheckBox( final Composite parent ) {
        final Button btnCaseSensitive = new Button( parent, SWT.CHECK );
        btnCaseSensitive.setText( RETPluginMessages.SpecObjectSearchPage_caseSensitive );
        btnCaseSensitive.setSelection( pageElements.isCaseSensitive() );
        btnCaseSensitive.setLayoutData( new GridData( GridData.FILL, GridData.FILL, false, false, 1, 1 ) );
        btnCaseSensitive.setFont( parent.getFont() );

        btnCaseSensitive.addSelectionListener( new SelectionAdapter() {
            @Override
            public void widgetSelected( final SelectionEvent event ) {
                pageElements.setCaseSensitiveFlag( btnCaseSensitive.getSelection() );
            }
        } );

        pageElements.setCaseSensitive( btnCaseSensitive );

    }

    /**
     * Creates search pattern combo box
     * 
     * @param parent
     */
    private void createSearchPatternCombo( final Composite parent ) {

        parent.setLayoutData( new GridData( SWT.FILL, SWT.CENTER, false, false, 1, 1 ) );
        //search pattern combo box
        final Combo searchPattern = new Combo( parent, SWT.SINGLE | SWT.BORDER );
        searchPattern.addSelectionListener( new SelectionAdapter() {
            @Override
            public void widgetSelected( final SelectionEvent event ) {
                searchDialogPage.handleWidgetSelected();
                searchDialogPage.getSpecObjectutil().updateOKStatus();
            }
        } );
        // adding listeners for regex syntax checking
        searchPattern.addModifyListener( new ModifyListener() {
            @Override
            public void modifyText( final ModifyEvent event ) {
                searchDialogPage.getSpecObjectutil().updateOKStatus();
            }
        } );
        final GridData data = new GridData( GridData.FILL, GridData.FILL, true, false, 1, 1 );
        data.widthHint = searchDialogPage.convertWidthInCharsToPixels( 50 );
        searchPattern.setLayoutData( data );
        pageElements.setSearchPattern( searchPattern );
        //Adding content assist for the pattern combo box, enables only when regular expression check box is checked
        final ComboContentAdapter contentAdapter = new ComboContentAdapter();
        final FindReplaceDocumentAdapterContentProposalProvider findProposer = new FindReplaceDocumentAdapterContentProposalProvider(
            true );
        final ContentAssistCommandAdapter patternContAssist = new ContentAssistCommandAdapter(
            searchPattern,
            contentAdapter,
            findProposer,
            ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS,
            new char[0],
            true );
        pageElements.setPatternContAssist( patternContAssist );
        pageElements.getPatternContAssist().setEnabled( pageElements.isRegularExpressionSearch() );

    }

    /**
     * Creates search string label
     * 
     * @param parent
     */
    private void createSearchStringLabel( final Composite parent ) {
        final Label statusLabel = new Label( parent, SWT.LEAD );
        statusLabel.setLayoutData( new GridData( SWT.FILL, SWT.CENTER, false, false, 2, 1 ) );
        statusLabel.setFont( parent.getFont() );
        statusLabel.setAlignment( SWT.LEFT );
        statusLabel.setText( RETPluginMessages.SpecobjectSearchPage_containingText_hint );

        pageElements.setStatusLabel( statusLabel );
    }
}
