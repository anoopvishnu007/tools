package eb.ret.ui.editor.hyperlink;

import eb.ret.ui.helper.SpecObjectUtils;

import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.hyperlink.IHyperlink;

/**
 * This class represents the specobject id hyperlink
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectHyperLink implements IHyperlink {

    /**
     * Label for the specobject id hyperlink
     */
    private static final String OPEN_REQUIREMENT = "Open Requirement";
    /**
     * Region to show as hyperlink
     */
    private final IRegion linkRegion;
    /**
     * Selected requirement id
     */
    private final String specObjectId;

    /**
     * constructor
     * 
     * @param specObjIdRegion region to show as hyperlink
     * @param specObjId the specobject id
     * @param file file containing the specobject id
     */
    public SpecObjectHyperLink( final IRegion specObjIdRegion, final String specObjectId ) {
        linkRegion = specObjIdRegion;
        this.specObjectId = specObjectId;
    }

    /*
     * @see org.eclipse.jdt.internal.ui.javaeditor.IHyperlink#getHyperlinkRegion()
     * @since 3.1
     */
    @Override
    public IRegion getHyperlinkRegion() {
        return linkRegion;
    }

    /*
     * @see org.eclipse.jdt.internal.ui.javaeditor.IHyperlink#open()
     * @since 3.1
     */
    @Override
    public void open() {
        SpecObjectUtils.openSpecObjInEditor( specObjectId );
    }

    /*
    * @see org.eclipse.jdt.internal.ui.javaeditor.IHyperlink#getTypeLabel()
    * @since 3.1
    */
    @Override
    public String getTypeLabel() {
        return OPEN_REQUIREMENT;
    }

    /*
     * @see org.eclipse.jdt.internal.ui.javaeditor.IHyperlink#getHyperlinkText()
     * @since 3.1
     */
    @Override
    public String getHyperlinkText() {
        return OPEN_REQUIREMENT;
    }
}