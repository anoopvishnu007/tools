package eb.ret.ui.specobjects.search.result.view;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.plugin.RETPlugin;
import eb.ret.ui.MessageFormatter;
import eb.ret.ui.RETPluginMessages;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.OpenEvent;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.Match;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;

import java.util.Set;

/**
 * Search result view page for specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchResultPage extends SpecObjectSearchResultParentPage {
    /**
     * Key to store the limit value to show the results in the result view
     */
    private static final String KEY_LIMIT = "eb.ret.ui.search.resultpage.limit";
    /**
     * Limit to show the results in the result view
     */
    private static final int DFAULT_ELEM_LIMIT = 1000;

    /**
     * Constructor
     */
    public SpecObjectSearchResultPage() {
        super();
        setElementLimit( Integer.valueOf( DFAULT_ELEM_LIMIT ) );

    }

    @Override
    public final void setElementLimit( final Integer elementLimit ) {
        super.setElementLimit( elementLimit );
        final int limit = elementLimit.intValue();
        RETPlugin.getDefault().getDialogSettings().put( KEY_LIMIT, limit );
    }

    @Override
    public StructuredViewer getViewer() {
        return super.getViewer();
    }

    @Override
    protected void showMatch( final Match match, final int offset, final int length, final boolean activate )
        throws PartInitException {
        final IFile file = (IFile)match.getElement();
        final IWorkbenchPage page = getSite().getPage();
        if( offset >= 0 && length != 0 ) {
            openAndSelect( page, file, offset, length, activate );
        } else {
            open( page, file, activate );
        }
    }

    @Override
    protected void handleOpen( final OpenEvent event ) {
        if( showLineMatches() ) {
            final Object firstElement = ((IStructuredSelection)event.getSelection()).getFirstElement();
            if( firstElement instanceof IFile && getDisplayedMatchCount( firstElement ) == 0 ) {
                try {
                    open( getSite().getPage(), (IFile)firstElement, false );
                } catch( final PartInitException e ) {
                    ErrorDialog.openError( getSite().getShell(),
                                           RETPluginMessages.SpecObjectSearchPage_open_file_dialog_title,
                                           RETPluginMessages.SpecObjectSearchPage_open_file_failed,
                                           e.getStatus() );
                }
                return;
            }
        }
        super.handleOpen( event );
    }

    @Override
    public void dispose() {
        super.dispose();
    }

    @Override
    public void restoreState( final IMemento memento ) {
        super.restoreState( memento );

        int elementLimit = DFAULT_ELEM_LIMIT;
        try {
            elementLimit = RETPlugin.getDefault().getDialogSettings().getInt( KEY_LIMIT );
        } catch( final NumberFormatException ex ) {
            ErrorLogger.logError( ex.getMessage(), ex );
        }
        if( memento != null ) {

            final Integer value = memento.getInteger( KEY_LIMIT );
            if( value != null ) {
                elementLimit = value.intValue();
            }
        }
        setElementLimit( Integer.valueOf( elementLimit ) );
    }

    @Override
    public void saveState( final IMemento memento ) {
        super.saveState( memento );
        memento.putInteger( KEY_LIMIT, getElementLimit().intValue() );
    }

    @Override
    public String getLabel() {
        final String label = super.getLabel();
        final StructuredViewer viewer = getViewer();
        if( viewer instanceof TableViewer ) {
            final TableViewer tabViwer = (TableViewer)viewer;

            final AbstractTextSearchResult result = getInput();
            if( result != null ) {
                final int itemCount = ((IStructuredContentProvider)tabViwer.getContentProvider()).getElements( getInput() ).length;
                if( showLineMatches() ) {
                    final int matchCount = getInput().getMatchCount();
                    if( itemCount < matchCount ) {
                        return MessageFormatter.format( RETPluginMessages.SpecObjectSearchPage_limited_format_matches,
                                                        new Object[]{
                                                            label,
                                                            Integer.valueOf( itemCount ),
                                                            Integer.valueOf( matchCount )} );
                    }
                } else {
                    final int fileCount = getInput().getElements().length;
                    if( itemCount < fileCount ) {
                        return MessageFormatter.format( RETPluginMessages.SpecObjectSearchPage_limited_format_files,
                                                        new Object[]{
                                                            label,
                                                            Integer.valueOf( itemCount ),
                                                            Integer.valueOf( fileCount )} );
                    }
                }
            }
        }
        return label;
    }

    @Override
    public int getDisplayedMatchCount( final Object element ) {
        if( showLineMatches() ) {
            if( element instanceof SpecObjectElement ) {
                final SpecObjectElement lineEntry = (SpecObjectElement)element;
                return lineEntry.getNumberOfMatches( getInput() );
            }
            return 0;
        }
        return super.getDisplayedMatchCount( element );
    }

    @Override
    public Match[] getDisplayedMatches( final Object element ) {
        if( showLineMatches() ) {
            if( element instanceof SpecObjectElement ) {
                final SpecObjectElement lineEntry = (SpecObjectElement)element;
                return lineEntry.getMatches( getInput() );
            }
            return new Match[0];
        }
        return super.getDisplayedMatches( element );
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Override
    protected void evaluateChangedElements( final Match[] matches, final Set changedElements ) {
        if( showLineMatches() ) {
            for( int index = 0; index < matches.length; index++ ) {
                changedElements.add( ((SpecObjectFileMatch)matches[index]).getSpecObjectElement() );
            }
        } else {
            super.evaluateChangedElements( matches, changedElements );
        }
    }

    /**
     * Determines whether to show line matches or not
     * 
     * @return true if need to show the line matches else false
     */
    private boolean showLineMatches() {
        final AbstractTextSearchResult input = getInput();
        return getLayout() == FLAG_LAYOUT_TREE && input != null;
    }

}
