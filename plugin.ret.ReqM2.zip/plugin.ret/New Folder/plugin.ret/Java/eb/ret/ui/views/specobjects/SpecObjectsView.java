package eb.ret.ui.views.specobjects;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.model.data.ISpecObjectData;
import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.search.query.SpecObjectSearchEngineUtils;
import eb.ret.ui.views.specobjects.contents.SpecObjectFilter;
import eb.ret.ui.views.specobjects.contents.SpecObjectViewContentCreator;
import eb.ret.ui.views.specobjects.helper.SpecObjectViewComparator;
import eb.ret.ui.views.specobjects.helper.SpecObjectViewMouseListener;

import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import java.util.List;

/**
 * Class for creating the specobjects view
 * 
 * @author nikhilcr
 * 
 */
public class SpecObjectsView extends ViewPart {

    /**
     * The ID of the view as specified by the extension.
     */
    public static final String VIEW_ID = "eb.ret.ui.views.specobjects.SpecObjectsView";

    /**
     * Constant for representing the text for specobject view filter
     */
    private static final String COL_ID_FILTER = "Id Filter: ";

    /**
     * The table viewer for specobject view
     */
    private TableViewer viewer;

    /**
     * Comparator for sorting of specobject view table
     */
    private SpecObjectViewComparator comparator;

    /**
     * SpecObjectFilter instance for specobject view table filtering
     */
    private SpecObjectFilter filter;

    /**
     * List of SpecobjectType for specobject view table
     */
    private List<SpecobjectType> speobjects;

    @Override
    public void createPartControl( final Composite parent ) {
        final GridLayout layout = new GridLayout( 2, false );
        parent.setLayout( layout );

        final Text searchText = createFilter( parent );
        viewer = new TableViewer( parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.FULL_SELECTION | SWT.BORDER );

        addFilter( searchText );
        createViewerContents();
        addViewerComponents();
    }

    /**
     * Adds components of the viewer
     */
    private void addViewerComponents() {
        // Adding double-click functionality
        final SpecObjectViewMouseListener mouseListener = new SpecObjectViewMouseListener( this );
        viewer.getTable().addMouseListener( mouseListener );

        //Adding right-click menu functionality
        final MenuManager menuManager = new MenuManager();
        final Menu menu = menuManager.createContextMenu( viewer.getTable() );
        viewer.getTable().setMenu( menu );

        getSite().registerContextMenu( menuManager, viewer );
        // Make the selection available
        getSite().setSelectionProvider( viewer );
    }

    /**
     * create contents of the viewer
     */
    private void createViewerContents() {
        final SpecObjectViewContentCreator contentCreator = new SpecObjectViewContentCreator( this );
        contentCreator.createColumns();

        final Table table = viewer.getTable();
        table.setHeaderVisible( true );
        table.setLinesVisible( true );
        viewer.setContentProvider( new ArrayContentProvider() );
        final ISpecObjectData specObjectData = SpecObjectResourceManager.getInstance().getSpecObjectData();
        speobjects = specObjectData.getSpecObjectList( new SpecObjectSearchParams(
            false,
            false,
            "*",
            LimitToType.DECLARATIONS,
            SearchForType.ID ) );
        viewer.setInput( speobjects );

        final GridData gridData = new GridData();
        gridData.verticalAlignment = GridData.FILL;
        gridData.horizontalSpan = 2;
        gridData.grabExcessHorizontalSpace = true;
        gridData.grabExcessVerticalSpace = true;
        gridData.horizontalAlignment = GridData.FILL;
        viewer.getControl().setLayoutData( gridData );
        comparator = new SpecObjectViewComparator();
        viewer.setComparator( comparator );
    }

    /**
     * add filter for the viewer
     * 
     * @param searchText
     */
    private void addFilter( final Text searchText ) {
        filter = new SpecObjectFilter();
        viewer.addFilter( filter );
        searchText.addKeyListener( new KeyAdapter() {
            @Override
            public void keyReleased( final KeyEvent keyEvent ) {
                filter.setSearchText( searchText.getText() );
                viewer.refresh();
            }
        } );
    }

    /**
     * create the filter for the specobject viewer
     * 
     * @param parent
     * @return
     */
    private Text createFilter( final Composite parent ) {
        final Label searchLabel = new Label( parent, SWT.NONE );
        searchLabel.setText( COL_ID_FILTER );
        final Text searchText = new Text( parent, SWT.BORDER | SWT.SEARCH );
        searchText.setLayoutData( new GridData( GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_FILL ) );
        searchText.setMessage( "type id filter" );
        return searchText;
    }

    @Override
    public void setFocus() {
        viewer.getControl().setFocus();
    }

    /**
     * Refreshes the specobject view with the current data
     */
    public void refresh() {
        speobjects = SpecObjectSearchEngineUtils.getSpecobjects( new SpecObjectSearchParams(
            false,
            false,
            "*",
            LimitToType.DECLARATIONS,
            SearchForType.ID ) );
        viewer.setInput( speobjects );
        viewer.refresh();
    }

    /**
     * Returns the TableViewer of the specobject view
     * 
     * @return
     */
    public TableViewer getViewer() {
        return viewer;
    }

    /**
     * Returns the SpecObjectViewComparator of the specobject view
     * 
     * @return
     */
    public SpecObjectViewComparator getComparator() {
        return comparator;
    }

}
