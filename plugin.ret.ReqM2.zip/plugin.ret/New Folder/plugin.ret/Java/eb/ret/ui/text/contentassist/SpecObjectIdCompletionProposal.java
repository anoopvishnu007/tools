package eb.ret.ui.text.contentassist;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.editor.texthover.SpecobjectHoverControlCreator;
import eb.ret.ui.editor.texthover.SpecobjectPresenterControlCreator;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IInformationControlCreator;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.ICompletionProposalExtension3;
import org.eclipse.jface.text.contentassist.ICompletionProposalExtension5;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;

/**
 * This class represents the specobject id completion proposal
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectIdCompletionProposal implements ICompletionProposal, ICompletionProposalExtension3,
        ICompletionProposalExtension5 {
    /**
     * Status bar text for proposal hover control
     */
    private static final String CNTRL_STATUS_TEXT = "Press 'Tab' from proposal table or click for focus";
    /**
     * The string to be displayed in the completion proposal popup.
     */
    private final String displayString;
    /**
     * The replacement string.
     */
    private final String replacementString;
    /**
     * The replacement offset.
     */
    private final int replacementOffset;
    /**
     * The replacement length.
     */
    private final int replacementLength;
    /**
     * The cursor position after this proposal has been applied.
     */
    private final int cursorPosition;
    /**
     * The specobject of corresponding proposal
     */
    private final SpecobjectType specObject;

    /**
     * Creates a new completion proposal. All fields are initialized based on the provided information.
     * 
     * @param replacementString the actual string to be inserted into the document
     * @param replacementOffset the offset of the text to be replaced
     * @param replacementLength the length of the text to be replaced
     * @param cursorPosition the position of the cursor following the insert relative to replacementOffset
     * @param displayString the string to be displayed for the proposal
     * @param specObject the specobject corresponds to the proposal
     */
    public SpecObjectIdCompletionProposal( final String replacementString,
                                           final int replacementOffset,
                                           final int replacementLength,
                                           final int cursorPosition,
                                           final String displayString,
                                           final SpecobjectType specObject ) {

        this.replacementString = replacementString;
        this.replacementOffset = replacementOffset;
        this.replacementLength = replacementLength;
        this.cursorPosition = cursorPosition;
        this.displayString = displayString;
        this.specObject = specObject;

    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposalExtension3#getInformationControlCreator()
     */
    @Override
    public IInformationControlCreator getInformationControlCreator() {
        final SpecobjectPresenterControlCreator pesentCtrlCreator = new SpecobjectPresenterControlCreator( specObject );
        final SpecobjectHoverControlCreator hoverCtrl = new SpecobjectHoverControlCreator( pesentCtrlCreator );
        hoverCtrl.setStatusBarText( CNTRL_STATUS_TEXT );
        return hoverCtrl;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposalExtension3#getPrefixCompletionText(org.eclipse.jface.text.IDocument, int)
     */
    @Override
    public CharSequence getPrefixCompletionText( final IDocument document, final int completionOffset ) {
        return replacementString;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposalExtension3#getPrefixCompletionStart(org.eclipse.jface.text.IDocument, int)
     */
    @Override
    public int getPrefixCompletionStart( final IDocument document, final int completionOffset ) {
        return 0;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposal#apply(org.eclipse.jface.text.IDocument)
     */
    @Override
    public void apply( final IDocument document ) {
        try {
            document.replace( replacementOffset, replacementLength, replacementString );
        } catch( final BadLocationException x ) {
            ErrorLogger.logError( x.getMessage(), x );
        }

    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposal#getSelection(org.eclipse.jface.text.IDocument)
     */
    @Override
    public Point getSelection( final IDocument document ) {
        return new Point( replacementOffset + cursorPosition, 0 );
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposal#getAdditionalProposalInfo()
     */
    @Override
    public String getAdditionalProposalInfo() {
        return null;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposal#getDisplayString()
     */
    @Override
    public String getDisplayString() {
        return displayString;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposal#getImage()
     */
    @Override
    public Image getImage() {
        return null;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.text.contentassist.ICompletionProposal#getContextInformation()
     */
    @Override
    public IContextInformation getContextInformation() {
        return null;
    }

    @Override
    public Object getAdditionalProposalInfo( final IProgressMonitor monitor ) {
        return specObject;
    }

}
