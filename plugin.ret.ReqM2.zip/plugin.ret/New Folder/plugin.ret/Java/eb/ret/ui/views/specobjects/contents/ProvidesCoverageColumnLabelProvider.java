package eb.ret.ui.views.specobjects.contents;

import eb.ret.model.specobject.ProvcovType;
import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewerColumn;

import java.util.List;

/**
 * Label provider for providescoverage column in specobject viewer
 * 
 * @author nikhilcr
 * 
 */
public class ProvidesCoverageColumnLabelProvider extends ColumnLabelProvider {
    /**
     * Constant for representing linksto
     */
    private static final String LINKSTO = "linksto";
    /**
     * Column for which the label provider is created
     */
    private final TableViewerColumn col;

    /**
     * Default constructor
     * 
     * @param col
     */
    public ProvidesCoverageColumnLabelProvider( final TableViewerColumn col ) {
        super();
        this.col = col;
    }

    @Override
    public String getText( final Object element ) {
        String textValue = "";
        if( ((SpecobjectType)element).getProvidescoverage() != null ) {
            final List<ProvcovType> providesCoverages = ((SpecobjectType)element).getProvidescoverage().getProvcov();
            if( providesCoverages != null ) {
                final StringBuilder builder = new StringBuilder();
                for( final ProvcovType provCov : providesCoverages ) {
                    builder.append( LINKSTO + " :" );
                    builder.append( getLinksto( provCov ) );
                    builder.append( provCov.getDstversion() ).append( "\n" );
                }
                textValue = builder.toString();
            }
        }
        col.getColumn().setData( ((SpecobjectType)element).getId(), textValue );
        return textValue;
    }

    /**
     * Gets the linksto as a single string
     * 
     * @param provCov
     * @return
     */
    private String getLinksto( final ProvcovType provCov ) {
        final StringBuilder builder = new StringBuilder();
        if( provCov.getLinksto() != null ) {
            for( final String linksTo : provCov.getLinksto() ) {
                builder.append( linksTo ).append( "," );
            }
        }
        return builder.toString();
    }

}
