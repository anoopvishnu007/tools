package eb.ret.ui.search.page;

import eb.ret.ui.RETPluginMessages;
import eb.ret.ui.search.page.control.FileTypeControl;
import eb.ret.ui.search.page.control.LimitToControl;
import eb.ret.ui.search.page.control.SearchForControl;
import eb.ret.ui.search.page.control.SearchTextPatternControl;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.DialogPage;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.search.ui.ISearchPage;
import org.eclipse.search.ui.ISearchPageContainer;
import org.eclipse.search.ui.NewSearchUI;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

/**
 * The search page implementation of specobject search functionality
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchDialogPage extends DialogPage implements ISearchPage {

    /**
     * Search page utility class object
     */
    private SpecObjectSearchPageUtil specObjectutil;
    /**
     * The previous file extensions.
     */
    private String[] prevExtensions;
    /**
     * Page elements object which contains the page controls
     */
    private final SpecObjectSearchPageElements pageElements = new SpecObjectSearchPageElements();

    /**
     * Gets the SpecObjectSearchPageElements object corresponding to the search page
     * 
     * @return SpecObjectSearchPageElements
     */
    public SpecObjectSearchPageElements getPageElements() {
        return pageElements;
    }

    @Override
    public void createControl( final Composite parent ) {

        initializeDialogUnits( parent );
        specObjectutil = new SpecObjectSearchPageUtil( this );
        specObjectutil.readConfiguration();

        //Initialize the main window with parentDialog
        final Composite parentDialog = new Composite( parent, SWT.NONE );
        parentDialog.setFont( parent.getFont() );
        final GridLayout layout = new GridLayout( 2, true );
        parentDialog.setLayout( layout );

        //Add Search Text Pattern control to the parentDialog
        new SearchTextPatternControl( parentDialog, this ).createControl();

        createSeparator( parentDialog );

        new SearchForControl( parentDialog, this ).createControl();

        new LimitToControl( parentDialog, this ).createControl();

        new FileTypeControl( parentDialog, this ).createControl();
        setControl( parentDialog );

        Dialog.applyDialogFont( parentDialog );
    }

    /**
     * creates an empty separator label
     * 
     * @param parentDialog
     */
    private void createSeparator( final Composite parentDialog ) {
        final Label separator = new Label( parentDialog, 0 );
        separator.setVisible( true );
        final GridData data = new GridData( SWT.FILL, SWT.FILL, false, false, 2, 1 );
        data.heightHint = convertHeightInCharsToPixels( 1 ) / 3;
        separator.setLayoutData( data );
    }

    /*
     * Overrides method from IDialogPage to make public
     */
    @Override
    public int convertWidthInCharsToPixels( final int chars ) {
        return super.convertWidthInCharsToPixels( chars );
    }

    /*
     * Overrides method from IDialogPage to make public
     */
    @Override
    public int convertHeightInCharsToPixels( final int chars ) {
        return super.convertHeightInCharsToPixels( chars );
    }

    @Override
    public boolean performAction() {
        try {
            NewSearchUI.runQueryInBackground( specObjectutil.getSpecObjectSearchQuery() );
        } catch( final CoreException e ) {

            ErrorDialog.openError( getShell(),
                                   "Specobject Search",
                                   RETPluginMessages.SpecObjectSearchPage_searchproblems_message,
                                   e.getStatus() );

            return false;
        }
        return true;
    }

    @Override
    public void setContainer( final ISearchPageContainer container ) {
        pageElements.setPageContainer( container );
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.dialogs.DialogPage#dispose()
     */
    @Override
    public void dispose() {
        specObjectutil.writeConfiguration();
        super.dispose();
    }

    /*
     * Implements method from IDialogPage
     */
    @Override
    public void setVisible( final boolean visible ) {
        if( visible ) {
            new SearchPageInitializer( this ).initialize();
        }
        super.setVisible( visible );
    }

    /**
     * Handling the widget selected event in the search pattern combo
     */
    public void handleWidgetSelected() {
        final int selectionIndex = pageElements.getSearchPattern().getSelectionIndex();
        if( selectionIndex < 0 || selectionIndex >= pageElements.getPrevSearchPattns().size() ) {
            return;
        }

        final SearchPatternData patternData = pageElements.getPrevSearchPattns().get( selectionIndex );
        if( !pageElements.getSearchPattern().getText().equals( patternData.getTextPattern() ) ) {
            return;
        }
        pageElements.getCaseSensitive().setSelection( patternData.isCaseSensitive() );
        pageElements.setRegularExSearch( patternData.isRegExSearch() );
        pageElements.getRegularExpression().setSelection( pageElements.isRegularExpressionSearch() );
        pageElements.getSearchPattern().setText( patternData.getTextPattern() );
        pageElements.getPatternContAssist().setEnabled( pageElements.isRegularExpressionSearch() );
        pageElements.getFileTypeEditor().setFileTypes( patternData.getFileNamePatterns() );
        if( patternData.getWorkingSets() == null ) {
            pageElements.getPageContainer().setSelectedScope( patternData.getScope() );
        } else {
            pageElements.getPageContainer().setSelectedWorkingSets( patternData.getWorkingSets() );
        }
    }

    /**
     * Gets the specobjectutil object of the page
     * 
     * @return
     */
    public SpecObjectSearchPageUtil getSpecObjectutil() {
        return specObjectutil;
    }

    /**
     * Gets the previous file extensions array
     * 
     * @return
     */
    public String[] getPrevExtensions() {
        return prevExtensions;
    }

    /**
     * Sets the extensions to the previous file extensions array
     * 
     * @param prevExtensions
     */
    public void setPrevExtensions( final String[] prevExtensions ) {
        this.prevExtensions = prevExtensions;
    }

}
