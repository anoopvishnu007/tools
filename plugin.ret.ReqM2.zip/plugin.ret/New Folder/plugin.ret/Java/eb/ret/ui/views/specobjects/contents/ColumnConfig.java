package eb.ret.ui.views.specobjects.contents;

import eb.ret.model.specobject.SpecObjectPackage;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * A configuration class for specobject view's column mapping to its data
 * 
 * @author kirensk
 * 
 */
public final class ColumnConfig {

    /**
     * Private constructor
     */
    private ColumnConfig() {

    }

    /**
     * configuration map to contain the mapping of a column and an attribute EStructuralFeature value of SpecobjectType
     */
    private static Map<String, Integer> attrColMap = new HashMap<String, Integer>();

    /**
     * configuration map to contain the mapping of a column and a FormattedTextT typed EStructuralFeature value of
     * SpecobjectType
     */
    private static Map<String, Integer> textColMap = new HashMap<String, Integer>();
    /**
     * configuration map to contain the mapping of a column and an Enumeration typed EStructuralFeature value of
     * SpecobjectType
     */
    private static Map<String, Integer> nameColMap = new HashMap<String, Integer>();
    /**
     * configuration map to contain the mapping of a column and an EStructuralFeature value of EReferences and its inner
     * feature in SpecobjectType
     */
    private static Map<String, Integer[]> multiValueColMap = new HashMap<String, Integer[]>();

    /**
     * static initialization of configuration maps
     */
    static {

        attrColMap.put( "ID", SpecObjectPackage.SPECOBJECT_TYPE__ID );
        attrColMap.put( "Version", SpecObjectPackage.SPECOBJECT_TYPE__VERSION );
        attrColMap.put( "ShortDesc", SpecObjectPackage.SPECOBJECT_TYPE__SHORTDESC );
        attrColMap.put( "SourceFile", SpecObjectPackage.SPECOBJECT_TYPE__SOURCEFILE );
        attrColMap.put( "SourceLine", SpecObjectPackage.SPECOBJECT_TYPE__SOURCELINE );
        attrColMap.put( "CreationDate", SpecObjectPackage.SPECOBJECT_TYPE__CREATIONDATE );
        attrColMap.put( "Priority", SpecObjectPackage.SPECOBJECT_TYPE__PRIORITY );
        attrColMap.put( "Usecase", SpecObjectPackage.SPECOBJECT_TYPE__USECASE );
        attrColMap.put( "FurtherInfo", SpecObjectPackage.SPECOBJECT_TYPE__FURTHERINFO );
        attrColMap.put( "SafetyRationale", SpecObjectPackage.SPECOBJECT_TYPE__SAFETYRATIONALE );
        attrColMap.put( "VerifyCrit", SpecObjectPackage.SPECOBJECT_TYPE__VERIFYCRIT );
        attrColMap.put( "Testin", SpecObjectPackage.SPECOBJECT_TYPE__TESTIN );
        attrColMap.put( "Testexec", SpecObjectPackage.SPECOBJECT_TYPE__TESTEXEC );
        attrColMap.put( "Testout", SpecObjectPackage.SPECOBJECT_TYPE__TESTOUT );
        attrColMap.put( "TestpassCrit", SpecObjectPackage.SPECOBJECT_TYPE__TESTPASSCRIT );

        textColMap.put( "Source", SpecObjectPackage.SPECOBJECT_TYPE__SOURCE );
        textColMap.put( "Description", SpecObjectPackage.SPECOBJECT_TYPE__DESCRIPTION );
        textColMap.put( "Rationale", SpecObjectPackage.SPECOBJECT_TYPE__RATIONALE );
        textColMap.put( "Comments", SpecObjectPackage.SPECOBJECT_TYPE__COMMENT );

        nameColMap.put( "Safety", SpecObjectPackage.SPECOBJECT_TYPE__SAFETYCLASS );
        nameColMap.put( "Status", SpecObjectPackage.SPECOBJECT_TYPE__STATUS );

        multiValueColMap.put( "Releases", new Integer[]{
            SpecObjectPackage.SPECOBJECT_TYPE__RELEASES,
            SpecObjectPackage.RELEASES_TYPE__RELEASE} );
        multiValueColMap.put( "Dependencies", new Integer[]{
            SpecObjectPackage.SPECOBJECT_TYPE__RELEASES,
            SpecObjectPackage.RELEASES_TYPE__RELEASE} );
        multiValueColMap.put( "Conflicts", new Integer[]{
            SpecObjectPackage.SPECOBJECT_TYPE__CONFLICTS,
            SpecObjectPackage.CONFLICTS_TYPE__CONFLICTSWITH} );
        multiValueColMap.put( "NeedsCoverage", new Integer[]{
            SpecObjectPackage.SPECOBJECT_TYPE__NEEDSCOVERAGE,
            SpecObjectPackage.NEEDSCOVERAGE_TYPE__NEEDSOBJ} );
    }

    /**
     * @return the attrColMap
     */
    public static Map<String, Integer> getAttributeColMap() {
        return Collections.unmodifiableMap( attrColMap );
    }

    /**
     * @return the textColMap
     */
    public static Map<String, Integer> getTextColMap() {
        return Collections.unmodifiableMap( textColMap );
    }

    /**
     * @return the nameColMap
     */
    public static Map<String, Integer> getNameColMap() {
        return Collections.unmodifiableMap( nameColMap );
    }

    /**
     * @return the multiValueColMap
     */
    public static Map<String, Integer[]> getMultiValueColMap() {
        return Collections.unmodifiableMap( multiValueColMap );
    }
}
