package eb.ret.ui;

import org.eclipse.osgi.util.NLS;

/**
 * This class contains the messages used in the RET plug-in
 * 
 * @author anoopvn
 * 
 */
@SuppressWarnings("PMD")
//Need clarification regarding the PMD warnings for this class 
public final class RETPluginMessages extends NLS {//NOPMD MessageFormatter needs more than the threshold variables.

    private static final String BUNDLE_NAME = "eb.ret.ui.RETPluginMessages";

    private RETPluginMessages() {
        super();
        // Do not instantiate
    }

    public static String SpecObjectSearchPage_open_file_dialog_title;
    public static String SpecObjectSearchPage_open_file_failed;
    public static String SpecobjectSearchPage_containingText_hint;
    public static String SpecObjectSearchPage_caseSensitive;
    public static String SpecObjectSearchPage_regularExpression;
    public static String SpecObjectSearchPage_browse;
    public static String SpecObjectSearchPage_fileNamePatterns_text;
    public static String SpecObjectSearchPage_fileNamePatterns_hint;
    public static String SpecObjectSearchPage_searchproblems_message;

    public static String SpecObjectModelSearch_statusMessage;
    public static String SpecObjectModelSearch_filesearch_task_label;
    public static String SpecObjectModelSearch_progress_updating_job;
    public static String SpecObjectModelSearch_textsearch_task_label;
    public static String SpecObjectModelSearch_scanning;
    public static String SpecObjectSearch_error;
    public static String SpecObjectModelSearch_canceled;
    public static String PatternConstructor_error_line_delim_position;
    public static String SpecObjectSearchQuery_label;
    public static String SpecObjectSearchQuery_pluralPattern;
    public static String SpecObjectSearchQuery_singularLabel;
    public static String FileTypeEditor_typeDelimiter;
    public static String FileLabelProvider_count_format;
    public static String FileLabelProvider_line_number;
    public static String FileLabelProvider_removed_resource_label;

    public static String SpecObjectSearchPage_limited_format_files;
    public static String SpecObjectSearchPage_limited_format_matches;
    static {
        NLS.initializeMessages( BUNDLE_NAME, RETPluginMessages.class );
    }

    public static String SpecObjectSearchQuery_singularPatternWithFileExt;
    public static String SpecObjectSearchQuery_pluralPatternWithFileExt;
}
