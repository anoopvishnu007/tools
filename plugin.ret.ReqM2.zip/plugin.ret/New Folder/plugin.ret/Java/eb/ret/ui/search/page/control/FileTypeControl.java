package eb.ret.ui.search.page.control;

import eb.ret.ui.RETPluginMessages;
import eb.ret.ui.search.page.SpecObjectFileTypeEditor;
import eb.ret.ui.search.page.SpecObjectSearchDialogPage;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

/**
 * This class represents the file type control in specobject search page
 * 
 * @author anoopvn
 * 
 */
public class FileTypeControl extends AbstractSearchPageControl {

    /**
     * Constructor
     * 
     * @param parentPage
     * @param searchDialogPage
     */
    public FileTypeControl( final Composite parentPage, final SpecObjectSearchDialogPage searchDialogPage ) {
        super( parentPage, searchDialogPage );
    }

    @Override
    public void createControl() {
        addFileNameControls( parentPage );
    }

    /**
     * Creates the file name extension control in the given parent composite
     * 
     * @param parent
     */
    public void addFileNameControls( final Composite parent ) {
        // Line with label, combo and button
        final Composite group = new Composite( parent, 0 );
        // grid layout with 2 columns
        final GridLayout layout = new GridLayout( 2, false );
        layout.marginWidth = 0;
        layout.marginHeight = 0;
        group.setLayout( layout );
        //file pattern text hint
        final Label label = new Label( group, SWT.LEAD );
        label.setText( RETPluginMessages.SpecObjectSearchPage_fileNamePatterns_text );
        label.setLayoutData( new GridData( SWT.FILL, SWT.CENTER, false, false, 2, 1 ) );
        label.setFont( group.getFont() );
        //file name pattern combo
        pageElements.setExtensions( new Combo( group, SWT.SINGLE | SWT.BORDER ) );
        pageElements.getExtensions().addModifyListener( new ModifyListener() {
            @Override
            public void modifyText( final ModifyEvent event ) {
                searchDialogPage.getSpecObjectutil().updateOKStatus();
            }
        } );
        final GridData data = new GridData( GridData.FILL, GridData.FILL, true, false, 1, 1 );
        data.widthHint = searchDialogPage.convertWidthInCharsToPixels( 50 );
        pageElements.getExtensions().setLayoutData( data );
        pageElements.getExtensions().setFont( group.getFont() );
        pageElements.getExtensions().setText( "*" );
        //file name pattern browse button
        final Button button = new Button( group, SWT.PUSH );
        button.setText( RETPluginMessages.SpecObjectSearchPage_browse );
        final GridData gridData = new GridData( SWT.BEGINNING, SWT.CENTER, true, false, 1, 1 );
        button.setLayoutData( gridData );
        button.setFont( group.getFont() );
        //sets the file name pattern functionalities 
        pageElements.setFileTypeEditor( new SpecObjectFileTypeEditor( pageElements.getExtensions(), button ) );
        // Text line which explains the special characters
        final Label description = new Label( group, SWT.LEAD );
        description.setText( RETPluginMessages.SpecObjectSearchPage_fileNamePatterns_hint );
        description.setLayoutData( new GridData( SWT.FILL, SWT.CENTER, false, false, 2, 1 ) );
        description.setFont( group.getFont() );
        group.setLayoutData( new GridData( GridData.FILL, GridData.CENTER, false, false, 2, 1 ) );

    }

}
