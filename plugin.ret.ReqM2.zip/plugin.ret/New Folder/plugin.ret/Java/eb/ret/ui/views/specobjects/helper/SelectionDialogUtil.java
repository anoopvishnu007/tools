package eb.ret.ui.views.specobjects.helper;

import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.ui.views.specobjects.SpecObjectsView;

import org.eclipse.swt.widgets.TableColumn;

import java.util.Arrays;
import java.util.List;

public final class SelectionDialogUtil {

    /**
     * Default constructor
     */
    private SelectionDialogUtil() {
        //default constructor
    }

    /**
     * Checks for the visibility of the provided column, i.e. if the column is selected to be visible in the view
     * 
     * @param col
     * @param columnList
     * @param colText
     */
    public static void ckeckForVisibility( final SpecObjectsView specObjectsView, final List<String> columnPrefList ) {
        final TableColumn[] columns = specObjectsView.getViewer().getTable().getColumns();
        for( final TableColumn column : columns ) {
            if( columnPrefList.contains( column.getText() ) ) {
                column.setResizable( true );
                column.setWidth( 100 );
            } else {
                column.setResizable( false );
                column.setWidth( 0 );
            }

        }
    }

    /**
     * get the column preferences as a list of column names
     * 
     * @return
     */
    public static List<String> getColumnPreferences() {
        final String columnPrefers = ReqM2InputData.getRETProperty().getSpecObjColumnProperty();
        List<String> columnList = null;
        if( columnPrefers != null && !columnPrefers.isEmpty() ) {
            columnList = Arrays.asList( columnPrefers.split( "," ) );
        }
        return columnList;
    }

}
