package eb.ret.ui.renaming;

import eb.ret.text.refactoring.rename.RenameData;

import org.eclipse.ltk.core.refactoring.participants.ProcessorBasedRefactoring;
import org.eclipse.ltk.ui.refactoring.RefactoringWizard;

/**
 * Wizard implementation for renaming specobjects.
 * 
 * @author tintobaby
 * 
 */
public class SpecobjectRenameWizard extends RefactoringWizard {

    /**
     * Rename pages title.
     */
    private static final String RENAME_SPECOBJECT = "Rename specobject";
    /**
     * Contains the details for renaming
     */
    private final RenameData renameData;

    /**
     * Constructor.
     * 
     * @param refactoring
     * @param rnData
     */
    public SpecobjectRenameWizard( final ProcessorBasedRefactoring refactoring, final RenameData rnData ) {

        //Calling super constructor
        super( refactoring, DIALOG_BASED_USER_INTERFACE );
        renameData = rnData;
    }

    @Override
    protected void addUserInputPages() {
        setDefaultPageTitle( RENAME_SPECOBJECT );
        addPage( new SpecobjectRenameInputPage( renameData ) );
    }
}
