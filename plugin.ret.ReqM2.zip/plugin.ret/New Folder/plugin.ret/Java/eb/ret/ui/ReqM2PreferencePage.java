package eb.ret.ui;

import static eb.ret.core.reqm2.data.ReqM2InputData.KEY_REQM2_BROWSER;
import static eb.ret.core.reqm2.data.ReqM2InputData.KEY_REQM2_PERL;
import static eb.ret.core.reqm2.data.ReqM2InputData.KEY_REQM2_TOOL;

import eb.ret.core.reqm2.builder.RETNatureController;
import eb.ret.core.reqm2.builder.ReqM2InputBuilder;
import eb.ret.core.reqm2.data.IRETData;
import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.core.reqm2.data.ReqM2InputData.BrowserType;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.plugin.RETPlugin;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.FileFieldEditor;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import java.util.List;

/**
 * This class creates a preference page for ReqM2 tool setting. These preference settings will be stored in the
 * preference store that belongs to the main plug-in class. That way, preferences can be accessed directly via the
 * preference store.
 * 
 * @author nikhilcr
 * 
 */
public class ReqM2PreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage {
    /**
     * Label for ReqM2 preferences in UI display
     */
    public static final String LABEL_REQM2_PREF = "ReqM2 Preferences";

    /**
     * Label for Perl executable directory in UI display
     */
    public static final String LABEL_PERL_DIR = "&Perl Executable:";

    /**
     * Label for ReqM2 executable in UI display
     */
    public static final String LABEL_REQM2_DIR = "&ReqM2 Tool Executable:";

    /**
     * Label for output browser selection in UI display
     */
    public static final String LABEL_OUT_BROWSER = "Tracing Output Browser";

    /**
     * Label for internal browser in UI display
     */
    public static final String LABEL_INT_BROWSER = "&Eclipse Internal Browser";

    /**
     * Label for system browser in UI display
     */
    public static final String LABEL_SYS_BROWSER = "&System Browser";

    /**
     * Label for group
     */
    public static final String LABEL_EXE_GROUP = "Executable Paths";

    /**
     * Message that will be logged in Eclipse logger if any build error occur
     */
    public static final String MSG_BUILD_ERROR = "Builder Error in preference build invoker";
    /**
     * Job name for triggering Eclipse RET Build
     */
    private static final String BUILD_JOB = "EclipseRET Build";

    /**
     * Default constructor
     */
    public ReqM2PreferencePage() {
        super( GRID );
    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2PreferencePage,1
     */
    /**
     * Creates the field editors. Field editors are abstractions of the common GUI blocks needed to manipulate various
     * types of preferences. Each field editor knows how to save and restore itself.
     */
    @Override
    protected void createFieldEditors() {
        final Group execGroup = new Group( getFieldEditorParent(), SWT.SHADOW_ETCHED_OUT );
        execGroup.setText( LABEL_EXE_GROUP );
        final GridData gridData = new GridData( SWT.FILL, SWT.BEGINNING, true, false );
        gridData.horizontalSpan = 3;
        gridData.verticalIndent = 20;
        execGroup.setLayoutData( gridData );
        execGroup.setLayout( new RowLayout( SWT.VERTICAL ) );

        addField( new FileFieldEditor( KEY_REQM2_PERL, LABEL_PERL_DIR, execGroup ) );
        addField( new FileFieldEditor( KEY_REQM2_TOOL, LABEL_REQM2_DIR, execGroup ) );

        final Composite composite = new Composite( getFieldEditorParent(), SWT.NONE );
        final GridData radioGridData = new GridData( SWT.FILL, SWT.BEGINNING, true, false );
        radioGridData.verticalIndent = 20;
        composite.setLayoutData( radioGridData );
        composite.setLayout( new RowLayout( SWT.VERTICAL ) );

        addField( new RadioGroupFieldEditor( KEY_REQM2_BROWSER, LABEL_OUT_BROWSER, 1, new String[][]{
            {LABEL_INT_BROWSER, BrowserType.ECLIPSE.toString()},
            {LABEL_SYS_BROWSER, BrowserType.SYSTEM.toString()}}, composite ) );
    }

    /*
     * Saves the RET preference data to Eclipse preference store and invokes the RET builder on the open 
     * projects in the workspace if needed
     * 
     * @see org.eclipse.jface.preference.FieldEditorPreferencePage#performOk()
     * 
     * !LINKSTO eclipse.ret.req.ReqM2PreferencePage,1,
     * !        eclipse.ret.req.PerlExecLocation,1,
     * !        eclipse.ret.req.ReqM2ToolLocation,1,
     * !        eclipse.ret.req.HTMLOutputBrowserChoice,1,
     * !        eclipse.ret.req.ReqM2UserPreferences,1
     */
    @Override
    public boolean performOk() {
        final boolean isOk = super.performOk();
        final IRETData retData = ReqM2InputData.getRETData();
        if( retData.isRETPreferencesSet() ) {
            invokeBuilder();
        }

        return isOk;
    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2PreferencePage,1,
     * !        eclipse.ret.req.WorkspaceSwitch,1,
     * !        eclipse.ret.req.ExportReqM2Preferences,1,
     * !        eclipse.ret.req.ImportReqM2Preferences,1
     */
    @Override
    public void init( final IWorkbench workbench ) {
        setPreferenceStore( RETPlugin.getDefault().getPreferenceStore() );
        setDescription( LABEL_REQM2_PREF );
    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2PreferencePage,1
     */
    /**
     * Schedule a background job to invoke the RET builder for all the open projects in the workspace that has RET
     * nature attached and RET property set
     */
    private void invokeBuilder() {

        final Job retBuildJob = new Job( BUILD_JOB ) {
            @Override
            protected IStatus run( final IProgressMonitor monitor ) {
                final List<IProject> projects = WorkspaceUtils.getOpenProjects();
                try {
                    for( IProject project : projects ) {
                        if( RETNatureController.isRETProject( project )
                            && ReqM2InputData.getRETData().isRETPropertiesSet( project ) ) {

                            project.build( IncrementalProjectBuilder.FULL_BUILD,
                                           ReqM2InputBuilder.BUILDER_ID,
                                           null,
                                           monitor );
                        }

                    }
                } catch( CoreException ex ) {
                    ErrorLogger.logError( MSG_BUILD_ERROR, ex );
                }
                return Status.OK_STATUS;
            }
        };
        retBuildJob.schedule();

    }
}