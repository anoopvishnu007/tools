package eb.ret.ui.views.specobjects.handler;

import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.helper.SpecObjectUtils;
import eb.ret.ui.views.specobjects.SpecObjectsView;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.widgets.TableItem;

/**
 * Handler class for opening the declaration of a specobject id
 * 
 * @author nikhilcr
 * 
 */
public class OpenDeclarationHandler extends AbstractHandler {

    @Override
    public Object execute( final ExecutionEvent event ) throws ExecutionException {
        final SpecObjectsView view = (SpecObjectsView)WorkspaceUtils.getViewPart( SpecObjectsView.class );
        final TableItem[] items = view.getViewer().getTable().getSelection();
        for( int i = 0; i < items.length; i++ ) {
            if( items[i] != null && SpecobjectType.class.isAssignableFrom( items[i].getData().getClass() ) ) {
                SpecObjectUtils.openSpecObjInEditor( ((SpecobjectType)items[i].getData()).getId() );
            }
        }

        return null;
    }

}
