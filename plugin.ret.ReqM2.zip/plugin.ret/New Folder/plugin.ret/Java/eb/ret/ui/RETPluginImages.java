/**
 * 
 */
package eb.ret.ui;

import eb.ret.plugin.RETPlugin;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;
import org.osgi.framework.Bundle;

import java.net.URL;

/**
 * This class provides the access to plug-in images
 * 
 * @author anoopvn
 * 
 */
public final class RETPluginImages {
    /**
     * Constructor
     */
    private RETPluginImages() {
        super();
    }

    /**
     * The RET plug-in image registry
     */
    private final static ImageRegistry PLUGIN_REGISTRY = RETPlugin.getDefault().getImageRegistry();
    /**
     * The RET plug-in image icon path
     */
    private static final IPath ICONS_PATH = new Path( "/icons/full" );
    /**
     * The RET plug-in image icon path of 16*16 images
     */
    public static final String T_OBJ = "obj16/";
    /**
     * Name prefix of icons
     */
    private static final String NAME_PREFIX = "eb.ret.ui.";
    /**
     * Name prefix length
     */
    private static final int NAME_PREFIX_LEN = NAME_PREFIX.length();

    /**
     * Default search image
     */
    public static final String IMGOBJ_TSRCH_DPDN = NAME_PREFIX + "tsearch_dpdn_obj.gif";
    /**
     * Line match image to show line element
     */
    public static final String IMGOBJ_TEXT_LINE = NAME_PREFIX + "line_match.gif";
    /**
     * Line match image descriptor
     */
    public static final ImageDescriptor DESC_OBJ_LINE = createImageDescriptor( T_OBJ, IMGOBJ_TEXT_LINE );
    /**
     * Default search image descriptor
     */
    public static final ImageDescriptor DESC_OBJ_DPDN = createImageDescriptor( T_OBJ, IMGOBJ_TSRCH_DPDN );

    /**
     * Gets the image corresponding to the key
     * 
     * @param key registered key of image
     * @return Image
     */
    public static Image get( final String key ) {
        return PLUGIN_REGISTRY.get( key );
    }

    /**
     * Creates an image descriptor
     * 
     * @param prefix image name prefix
     * @param name image name
     * @return an image descriptor
     */
    private static ImageDescriptor createImageDescriptor( final String prefix, final String name ) {
        final ImageDescriptor result = create( prefix, name.substring( NAME_PREFIX_LEN ), true );
        PLUGIN_REGISTRY.put( name, result );
        return result;
    }

    /**
     * Creates an image descriptor for the given prefix and name in the RET plug-in bundle. If no image could be found,
     * useMissingImageDescriptor decides if either the 'missing image descriptor' is returned or null.
     * 
     * 
     * @param prefix image prefix
     * @param name image name
     * @param useMissingImgDesc to determine whether no image found, should return a missing image descriptor
     * @return image descriptor
     */
    private static ImageDescriptor create( final String prefix, final String name, final boolean useMissingImgDesc ) {
        final IPath path = ICONS_PATH.append( prefix ).append( name );
        return createImageDescriptor( RETPlugin.getDefault().getBundle(), path, useMissingImgDesc );
    }

    /**
     * Creates an image descriptor for the given path in a bundle. If no image could be found,useMissingImageDescriptor
     * decides if either the 'missing image descriptor' is returned or null.
     * 
     * 
     * @param bundle the bundle
     * @param path path of the image
     * @param useMissingImgDesc missing image descriptor parameter
     * @return image descriptor
     */
    public static ImageDescriptor createImageDescriptor( final Bundle bundle,
                                                         final IPath path,
                                                         final boolean useMissingImgDesc ) {
        final URL url = FileLocator.find( bundle, path, null );
        if( url != null ) {
            return ImageDescriptor.createFromURL( url );
        }
        if( useMissingImgDesc ) {
            return ImageDescriptor.getMissingImageDescriptor();
        }
        return null;
    }

}
