package eb.ret.ui.helper;

import org.eclipse.core.runtime.IProgressMonitor;

import java.util.TimerTask;

/**
 * Timer task to monitor whether the progress monitor is cancelled or not.
 * 
 * @author tintobaby
 * 
 */
public class ProcessMonitorTimerTask extends TimerTask {
    /**
     * Current progress monitor.
     */
    private IProgressMonitor monitor = null;
    /**
     * Current Thread.
     */
    private Thread thread = null;

    /**
     * Constructor.
     * 
     * @param monitor Current progress monitor.
     */
    public ProcessMonitorTimerTask( final IProgressMonitor monitor ) {
        super();
        this.setMonitor( monitor );
        this.setThread( Thread.currentThread() );
    }

    @Override
    public void run() {
        if( null == this.monitor ) {
            return;
        }
        if( this.monitor.isCanceled() ) {
            //Interrupt the thread, if the progress  monitor is cancelled.
            this.thread.interrupt();
        }
    }

    /**
     * To set the progress monitor.
     * 
     * @param monitor Progress monitor.
     */
    private void setMonitor( final IProgressMonitor monitor ) {
        this.monitor = monitor;
    }

    /**
     * To set the current thread.
     * 
     * @param thread Current Thread.
     */
    private void setThread( final Thread thread ) {
        this.thread = thread;
    }
}
