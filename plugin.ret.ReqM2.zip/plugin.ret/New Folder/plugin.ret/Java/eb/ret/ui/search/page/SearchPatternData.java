/**
 * 
 */
package eb.ret.ui.search.page;

import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;

import org.eclipse.core.runtime.Assert;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.ui.IWorkingSet;
import org.eclipse.ui.IWorkingSetManager;
import org.eclipse.ui.PlatformUI;

/**
 * This class holds Search input data
 * 
 * @author anoopvn
 * 
 */
public class SearchPatternData {

    /**
     * Search working sets constant
     */
    private static final String WORKING_SETS = "workingSets";
    /**
     * Search pattern scope constant
     */
    private static final String SEARCH_SCOPE = "scope";
    /**
     * Search pattern file extensions constant
     */
    private static final String FILE_PATTERNS = "fileNamePatterns";
    /**
     * Search pattern text constant
     */
    private static final String TEXT_PATTERN = "textPattern";
    /**
     * Search pattern regular expression constant
     */
    private static final String IS_REG_EX_SEARCH = "regExSearch";
    /**
     * Search pattern case sensitive constant
     */
    private static final String IGNORE_CASE = "ignoreCase";
    /**
     * Holds the value search pattern is case sensitive or not
     */
    private final boolean caseSensitive;
    /**
     * Holds the value search pattern is regular expression or not
     */
    private final boolean regExSearch;
    /**
     * Holds the value of the pattern text
     */
    private final String textPattern;
    /**
     * Holds the value of file name extensions
     */
    private final String[] fileNamePatterns;
    /**
     * Holds the value of search scope
     */
    private final int scope;
    /**
     * Holds the value of search scope working sets
     */
    private final IWorkingSet[] workingSets;
    /**
     * Holds the value of search limit to entry
     */
    private final LimitToType limitToType;
    /**
     * Holds the value of search for entry
     */
    private final SearchForType searchFor;

    /**
     * Constructor
     * 
     * @param textPattern search string
     * @param searchForType selected search for type
     * @param limitTo selected limit to type
     * @param caseSensitive search is case sensitive or not
     * @param regExSearch search is a regular expression or not
     * @param fileNamePatterns file name extensions to search
     * @param scope search scope
     * @param workingSets working set entry
     */
    public SearchPatternData( final String textPattern,
                              final int searchForType,
                              final int limitTo,
                              final boolean isCaseSensitive,
                              final boolean isRegExSearch,
                              final String[] fileNamePatterns,
                              final int scope,
                              final IWorkingSet[] workingSets ) {
        Assert.isNotNull( fileNamePatterns );
        this.caseSensitive = isCaseSensitive;
        this.regExSearch = isRegExSearch;
        this.textPattern = textPattern;
        this.fileNamePatterns = fileNamePatterns;
        this.scope = scope;
        this.workingSets = workingSets; // can be null
        limitToType = LimitToType.get( limitTo );
        searchFor = SearchForType.get( searchForType );
    }

    /**
     * Store the current search options in the dialog settings
     * 
     * @param settings IDialogSettings
     */
    public void store( final IDialogSettings settings ) {
        settings.put( IGNORE_CASE, !caseSensitive );
        settings.put( IS_REG_EX_SEARCH, regExSearch );
        settings.put( TEXT_PATTERN, textPattern );
        settings.put( FILE_PATTERNS, fileNamePatterns );
        settings.put( SEARCH_SCOPE, scope );
        if( workingSets == null ) {
            settings.put( WORKING_SETS, new String[0] );
        } else {
            final String[] wsIds = new String[workingSets.length];
            for( int i = 0; i < workingSets.length; i++ ) {
                wsIds[i] = workingSets[i].getLabel();
            }
            settings.put( WORKING_SETS, wsIds );
        }

    }

    /**
     * Creates a new SearchPatternData object
     * 
     * @param settings IDialogSettings
     * @return SearchPatternData
     */
    public static SearchPatternData create( final IDialogSettings settings ) {
        final String textPattern = settings.get( TEXT_PATTERN );
        final String[] wsIds = settings.getArray( WORKING_SETS );
        IWorkingSet[] workingSets = null;
        if( wsIds != null && wsIds.length > 0 ) {
            final IWorkingSetManager workingSetManager = PlatformUI.getWorkbench().getWorkingSetManager();
            workingSets = new IWorkingSet[wsIds.length];
            for( int i = 0; workingSets != null && i < wsIds.length; i++ ) {
                workingSets[i] = workingSetManager.getWorkingSet( wsIds[i] );
                if( workingSets[i] == null ) {
                    workingSets = null;
                }
            }
        }
        String[] fileNamePatterns = settings.getArray( FILE_PATTERNS );
        if( fileNamePatterns == null ) {
            fileNamePatterns = new String[0];
        }
        try {
            final int scope = settings.getInt( SEARCH_SCOPE );
            final boolean isRegExSearch = settings.getBoolean( IS_REG_EX_SEARCH );
            final boolean ignoreCase = settings.getBoolean( IGNORE_CASE );

            return new SearchPatternData(
                textPattern,
                0,
                0,
                !ignoreCase,
                isRegExSearch,
                fileNamePatterns,
                scope,
                workingSets );
        } catch( final NumberFormatException e ) {
            return null;
        }
    }

    /**
     * Returns the search is case sensitive or not
     * 
     * @return
     */
    public boolean isCaseSensitive() {
        return caseSensitive;
    }

    /**
     * Returns the search string is a regular expression or not
     * 
     * @return
     */
    public boolean isRegExSearch() {
        return regExSearch;
    }

    /**
     * Gets the search string
     * 
     * @return
     */
    public String getTextPattern() {
        return textPattern;
    }

    /**
     * Gets the file name patterns
     * 
     * @return
     */
    public String[] getFileNamePatterns() {
        return fileNamePatterns;
    }

    /**
     * Gets the search scope
     * 
     * @return
     */
    public int getScope() {
        return scope;
    }

    /**
     * Gets the working sets
     * 
     * @return
     */
    public IWorkingSet[] getWorkingSets() {
        return workingSets;
    }

    /**
     * Gets the id search limit to type
     * 
     * @return
     */
    public LimitToType getLimitToType() {
        return limitToType;
    }

    /**
     * Gets the search type
     * 
     * @return
     */
    public SearchForType getSearchFor() {
        return searchFor;
    }

}
