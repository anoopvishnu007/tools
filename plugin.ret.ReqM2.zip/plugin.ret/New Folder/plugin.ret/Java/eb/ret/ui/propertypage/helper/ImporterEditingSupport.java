package eb.ret.ui.propertypage.helper;

import eb.ret.core.reqm2.data.ImporterType;
import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.core.reqm2.data.ReqM2Property;
import eb.ret.ui.propertypage.ReqM2PropertyPage;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ComboBoxViewerCellEditor;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;

/**
 * This class creates the combo box editing support for importer column
 * 
 * @author nikhilcr
 * 
 */
public class ImporterEditingSupport extends EditingSupport {

    /**
     * For storing RET input directory table details
     */
    private final TableViewer viewer;
    /**
     * Cell Editor used for Importer column in RET Property page
     */
    private ComboBoxViewerCellEditor cellEditor;
    /**
     * propertyPage instance to access the page variables
     */
    private final ReqM2PropertyPage propertyPage;
    /**
     * Temp variable to store the previous value of docType.
     */
    private String docTypeTemp = "";

    /**
     * Constructor
     * 
     * @param viewer
     */
    public ImporterEditingSupport( final ReqM2PropertyPage propertyPage ) {
        super( propertyPage.getViewer() );
        this.propertyPage = propertyPage;
        this.viewer = propertyPage.getViewer();
    }

    @Override
    protected CellEditor getCellEditor( final Object element ) {

        cellEditor = new ComboBoxViewerCellEditor( viewer.getTable(), SWT.READ_ONLY );

        for( final ImporterType importer : ImporterType.values() ) {
            cellEditor.getViewer().add( importer.name() );
        }
        // Selection Listener is added to reset the value of docType as per the importer selection
        cellEditor.getViewer().addSelectionChangedListener( new ISelectionChangedListener() {

            @Override
            public void selectionChanged( final SelectionChangedEvent event ) {
                final RETDirectory directory = (RETDirectory)element;
                if( ImporterType.GENERIC.name()
                                        .equals( ((StructuredSelection)cellEditor.getViewer().getSelection()).getFirstElement() ) ) {
                    directory.setDocType( docTypeTemp );

                } else {

                    directory.setDocType( ReqM2Property.NOT_APPLICABLE );
                }

                viewer.update( element, null );
            }
        } );

        return cellEditor;
    }

    @Override
    protected boolean canEdit( final Object element ) {
        return true;
    }

    @Override
    protected Object getValue( final Object element ) {

        final RETDirectory directory = (RETDirectory)element;
        docTypeTemp = directory.getDocType();
        return directory.getImporter().name();

    }

    @Override
    protected void setValue( final Object element, final Object value ) {
        final RETDirectory directory = (RETDirectory)element;
        directory.setImporter( ImporterType.valueOf( (String)value ) );
        if( directory.getImporter() == ImporterType.GENERIC ) {
            if( directory.getDocType().equals( ReqM2Property.NOT_APPLICABLE ) ) {
                directory.setDocType( "" );
            }
        } else {
            directory.setDocType( ReqM2Property.NOT_APPLICABLE );

        }
        viewer.update( element, null );
        propertyPage.checkForError();
    }
}
