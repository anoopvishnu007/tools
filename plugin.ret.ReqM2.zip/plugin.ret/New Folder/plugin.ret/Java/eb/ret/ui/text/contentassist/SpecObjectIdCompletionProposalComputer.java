/**
 * 
 */
package eb.ret.ui.text.contentassist;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.model.data.ISpecObjectData;
import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.core.model.data.SpecObjectSearchParams.LimitToType;
import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.helper.SpecObjectEditorUtil.SpecObjectMatch;
import eb.ret.util.PatternConstructor;
import eb.ret.util.PatternHelper;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.ui.text.java.ContentAssistInvocationContext;
import org.eclipse.jdt.ui.text.java.IJavaCompletionProposalComputer;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContextInformation;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * This class computes the specobject id completion proposals
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectIdCompletionProposalComputer implements IJavaCompletionProposalComputer {
    /**
     * The empty list of completion proposals
     */
    private static final List<ICompletionProposal> NO_PROPOSALS = new ArrayList<ICompletionProposal>();
    /**
     * The maximum desired number of auto completion proposals
     */
    private static final int RESULTSIZE = 20;

    /* (non-Javadoc)
     * @see org.eclipse.jdt.ui.text.java.IJavaCompletionProposalComputer#computeCompletionProposals(org.eclipse.jdt.ui.text.java.ContentAssistInvocationContext, org.eclipse.core.runtime.IProgressMonitor)
     */
    @Override
    public List<ICompletionProposal> computeCompletionProposals( final ContentAssistInvocationContext context,
                                                                 final IProgressMonitor progressMonitor ) {
        final List<ICompletionProposal> result = new ArrayList<ICompletionProposal>();

        final IDocument document = context.getDocument();
        final int offset = context.getInvocationOffset();

        try {
            //gets the specobject match object at the cursor offset
            final SpecObjectMatch match = SpecObjectContentAssistHelper.getAutoCompletionIdMatch( document, offset );
            if( match != null ) {

                final String content = match.getId();

                final SpecObjectSearchParams params = new SpecObjectSearchParams(
                    false,
                    true,
                    content,
                    LimitToType.DECLARATIONS,
                    SearchForType.ID );
                //if meta characters entered in the completion id mark it as characters only
                PatternHelper.escapeMetaCharacters( content );
                //appending reg ex condition starting with the id string and any String after the id
                final StringBuffer buffer = new StringBuffer( "^" );
                PatternHelper.appendAsRegEx( content, buffer );
                buffer.append( ".*" );

                final Pattern pattern = PatternConstructor.createPattern( buffer.toString(), false );
                params.setSearchPattern( pattern );
                params.setResultSize( RESULTSIZE );

                //querying the model
                final ISpecObjectData specObjectData = SpecObjectResourceManager.getInstance().getSpecObjectData();
                final List<SpecobjectType> specObjects = specObjectData.getSpecObjectList( params );

                for( final SpecobjectType specObject : specObjects ) {
                    final ICompletionProposal proposal = SpecObjectContentAssistHelper.getCompletionProposal( offset,
                                                                                                              match.getId(),
                                                                                                              specObject );
                    if( proposal != null ) {
                        result.add( proposal );
                    }
                }
            }
        } catch( final BadLocationException e ) {
            return NO_PROPOSALS;
        }
        return result;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jdt.ui.text.java.IJavaCompletionProposalComputer#computeContextInformation(org.eclipse.jdt.ui.text.java.ContentAssistInvocationContext, org.eclipse.core.runtime.IProgressMonitor)
     */
    @Override
    public List<IContextInformation> computeContextInformation( final ContentAssistInvocationContext context,
                                                                final IProgressMonitor progressMonitor ) {
        return null;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jdt.ui.text.java.IJavaCompletionProposalComputer#getErrorMessage()
     */
    @Override
    public String getErrorMessage() {
        return null;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jdt.ui.text.java.IJavaCompletionProposalComputer#sessionEnded()
     */
    @Override
    public void sessionEnded() {
        //  nothing to do
    }

    /* (non-Javadoc)
     * @see org.eclipse.jdt.ui.text.java.IJavaCompletionProposalComputer#sessionStarted()
     */
    @Override
    public void sessionStarted() {
        // nothing to do
    }

}
