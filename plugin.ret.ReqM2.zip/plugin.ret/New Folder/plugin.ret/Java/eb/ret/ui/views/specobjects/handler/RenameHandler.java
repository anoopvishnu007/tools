package eb.ret.ui.views.specobjects.handler;

import eb.ret.model.specobject.SpecobjectType;
import eb.ret.text.refactoring.rename.RenameData;
import eb.ret.text.refactoring.rename.SpecObjectRenameProcessor;
import eb.ret.ui.renaming.SpecobjectRenameWizard;
import eb.ret.ui.views.specobjects.SpecObjectsView;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ltk.core.refactoring.participants.ProcessorBasedRefactoring;
import org.eclipse.ltk.ui.refactoring.RefactoringWizardOpenOperation;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.PlatformUI;

/**
 * Handler class for renaming of a specobject id
 * 
 * @author nikhilcr
 * 
 */
public class RenameHandler extends AbstractHandler {
    @Override
    public Object execute( final ExecutionEvent event ) throws ExecutionException {
        final SpecObjectsView view = (SpecObjectsView)WorkspaceUtils.getViewPart( SpecObjectsView.class );
        final TableItem[] items = view.getViewer().getTable().getSelection();
        for( int i = 0; i < items.length; i++ ) {
            if( items[i] != null && SpecobjectType.class.isAssignableFrom( items[i].getData().getClass() ) ) {
                performRename( (SpecobjectType)items[i].getData() );
            }
        }
        return null;
    }

    /**
     * Provides renaming functionality for the provided specobject
     * 
     * @param specObject
     */
    private void performRename( final SpecobjectType specObject ) {
        final RenameData data = new RenameData( specObject );

        final SpecObjectRenameProcessor processor = new SpecObjectRenameProcessor( data );

        final ProcessorBasedRefactoring refactoring = new ProcessorBasedRefactoring( processor );

        final SpecobjectRenameWizard wizard = new SpecobjectRenameWizard( refactoring, data );
        final RefactoringWizardOpenOperation operation = new RefactoringWizardOpenOperation( wizard );
        try {
            final String titleFailedChecks = "";
            operation.run( PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), titleFailedChecks );
        } catch( final InterruptedException irex ) {
            // operation was cancelled
        }
    }

}
