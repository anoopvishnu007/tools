package eb.ret.ui.search.result.view;

import org.eclipse.core.resources.IContainer;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;

/**
 * Specobject search result viewer sorter class to sort the search result
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchResultViewerSorter extends ViewerComparator {
    /**
     * Empty string
     */
    private static final String EMPTY_STRING = "";
    /**
     * The label provider of search result view
     */
    private final ILabelProvider labelProvider;

    /**
     * Constructor
     * 
     * @param labProvider label provider object
     */
    public SpecObjectSearchResultViewerSorter( final ILabelProvider labProvider ) {
        super();
        labelProvider = labProvider;
    }

    /* (non-Javadoc)
     * @see org.eclipse.jface.viewers.ViewerComparator#category(java.lang.Object)
     */
    @Override
    public int category( final Object element ) {
        if( element instanceof IContainer ) {
            return 1;
        }
        return 2;
    }

    @SuppressWarnings("unchecked")
    @Override
    public int compare( final Viewer viewer, final Object obj1, final Object obj2 ) {
        final int cat1 = category( obj1 );
        final int cat2 = category( obj2 );

        if( cat1 != cat2 ) {
            return cat1 - cat2;
        }

        if( obj1 instanceof SpecObjectFileMatch && obj2 instanceof SpecObjectFileMatch ) {
            final SpecObjectFileMatch elem1 = (SpecObjectFileMatch)obj1;
            final SpecObjectFileMatch elem2 = (SpecObjectFileMatch)obj2;
            return elem1.getOffset() - elem2.getOffset();
        }

        String name1 = labelProvider.getText( obj1 );
        String name2 = labelProvider.getText( obj2 );
        if( name1 == null ) {
            name1 = EMPTY_STRING;
        }
        if( name2 == null ) {
            name2 = EMPTY_STRING;
        }
        return getComparator().compare( name1, name2 );
    }
}