package eb.ret.ui.views.specobjects.contents;

import eb.ret.model.specobject.LinkType;
import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.emf.ecore.util.FeatureMap.Entry;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewerColumn;

import java.util.List;

/**
 * Label provider for Links column in specobject viewer
 * 
 * @author nikhilcr
 * 
 */
public class LinksColumnLabelProvider extends ColumnLabelProvider {

    /**
     * Constant for representing target
     */
    private static final String COL_TARGET = "target";

    /**
     * Constant for representing comment
     */
    private static final String COL_COMMENT = "Comment";
    /**
     * Column for which the label provider is created
     */
    private final TableViewerColumn col;

    /**
     * Default constructor
     * 
     * @param col
     */
    public LinksColumnLabelProvider( final TableViewerColumn col ) {
        super();
        this.col = col;
    }

    @Override
    public String getText( final Object element ) {
        String textValue = "";
        if( ((SpecobjectType)element).getLinks() != null ) {
            final List<LinkType> links = ((SpecobjectType)element).getLinks().getLink();
            if( links != null ) {
                final StringBuilder builder = new StringBuilder();
                for( final LinkType link : links ) {
                    builder.append( COL_TARGET + " :" ).append( link.getTarget() ).append( "\n" );
                    builder.append( COL_COMMENT + " :" );
                    builder.append( getComment( link ) );
                }
                textValue = builder.toString();
            }
        }
        col.getColumn().setData( ((SpecobjectType)element).getId(), textValue );
        return textValue;
    }

    /**
     * Gets the comments as a single string
     * 
     * @param link
     * @return
     */
    private String getComment( final LinkType link ) {
        final StringBuilder builder = new StringBuilder();
        if( link.getComment() != null && link.getComment().getMixed() != null ) {
            for( final Entry entry : link.getComment().getMixed() ) {
                builder.append( entry.getValue().toString() ).append( "\n" );
            }
        }
        return builder.toString();
    }

}
