package eb.ret.ui.text.specobject;

import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.search.query.FileUtils;
import eb.ret.ui.search.query.SpecObjectSearchEngineUtils;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;

import java.io.IOException;
import java.util.regex.Pattern;

/**
 * Abstract class for processing specobject region in the corresponding source file
 */
public abstract class AbstractSpecObjectRegion {

    /**
     * document instance of the specobject's source file
     */
    protected IDocument document;
    /**
     * specobject for which the region represents
     */
    protected SpecobjectType specObject;
    /**
     * specobject region in the source file
     */
    protected IRegion specObjectRegion;

    /**
     * Message for exception while determining specobject region
     */
    protected static final String MSG_EXCPTN = "Exception while getting specobject region";

    /**
     * Message for invalid source line in specobject
     */
    protected static final String MSG_INVLD_LINE = "Invalid source line from specobject ";

    /**
     * Message for exception while determining specobject region
     */
    protected static final String MSG_BAD_LOC = "Badlocation calclulated while reading from document for specobject ";

    /**
     * Constructor with input as specobject for which the region is constructed. The document instance is set from the
     * constructor
     * 
     * @param specObject
     * @throws IOException
     */
    public AbstractSpecObjectRegion( final SpecobjectType specObject ) throws IOException {
        this.specObject = specObject;
        setDocument( specObject );
    }

    /**
     * Constructor with input as specobject and its corresponding document instance of the source file
     * 
     * @param specObject
     * @param document
     */
    public AbstractSpecObjectRegion( final SpecobjectType specObject, final IDocument document ) {
        this.specObject = specObject;
        this.document = document;
    }

    /**
     * returns the entire specobject region in the source file
     * 
     * @return IRegion representing the specobject
     */
    public abstract IRegion getSpecObjectRegion();

    /**
     * returns the region for the entered element
     * 
     * @return IRegion representing the region with in the specobject
     */
    public abstract IRegion getRegion( String region );

    /**
     * returns the region for description
     * 
     * @return IRegion representing the description region with in the specobject
     */
    public abstract IRegion getDescriptionRegion();

    /**
     * returns the region for id
     * 
     * @return IRegion representing the id region with in the specobject
     */
    public abstract IRegion getIdRegion();

    /**
     * returns the region for LinksTo
     * 
     * @return IRegion representing the linksto region with in the specobject
     */
    public abstract IRegion getLinksToRegion();

    /**
     * returns the region for Comments
     * 
     * @return IRegion representing the Comments region with in the specobject
     */
    public abstract IRegion getCommentsRegion();

    /**
     * returns the region for Links
     * 
     * @return IRegion representing the links region with in the specobject
     */
    public abstract IRegion getLinksRegion();

    /**
     * initialize the document instance for a corresponding specObject
     * 
     * @param specObject
     * @throws IOException
     */
    public final void setDocument( final SpecobjectType specObject ) throws IOException {
        this.specObject = specObject;
        final IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        final String sourceFileLoc = specObject.getSourcefile();
        final IPath path = WorkspaceUtils.getIPath( sourceFileLoc );
        final IPath sourcePath = WorkspaceUtils.getIPath( SpecObjectSearchEngineUtils.getWorkSpaceRelativePath( path ) );
        final IFile sourceFile = root.getFile( sourcePath );
        this.document = FileUtils.getDocument( sourceFile );

    }

    /**
     * finds the regex option depends on the case sensitivity
     * 
     * @param isCaseSensitive
     * @return regexOptions
     */
    public static int getRegExOptions( final boolean isCaseSensitive ) {
        int regexOptions = Pattern.MULTILINE;
        if( !isCaseSensitive ) {
            regexOptions |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
        }
        return regexOptions;
    }

}
