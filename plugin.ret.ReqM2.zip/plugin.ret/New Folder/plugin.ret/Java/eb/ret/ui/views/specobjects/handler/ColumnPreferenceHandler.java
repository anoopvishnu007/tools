package eb.ret.ui.views.specobjects.handler;

import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.ui.views.specobjects.SpecObjectsView;
import eb.ret.ui.views.specobjects.contents.ColumnPreferenceLabelProvider;
import eb.ret.ui.views.specobjects.helper.SelectionDialogUtil;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.dialogs.ListSelectionDialog;
import org.eclipse.ui.handlers.HandlerUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Handlers for column preference of specobject view
 * 
 * @author nikhilcr
 * 
 */
public class ColumnPreferenceHandler extends AbstractHandler {

    private static final String LABEL_PREF = "Column Preferences";

    /**
     * Default with for the columns selected from preference view
     */
    private static final int COL_WIDTH = 100;

    /**
     * List that stores the columns selected by user
     */
    private List<TableColumn> selections;

    /**
     * Contains all the table-columns in the specobject view table
     */
    private TableColumn[] tableColumns;

    /**
     * Default constructor.
     */
    public ColumnPreferenceHandler() {
        super();
    }

    @Override
    public Object execute( final ExecutionEvent event ) throws ExecutionException {
        setSelection();
        final ListSelectionDialog colSelectDialog = new ListSelectionDialog( HandlerUtil.getActiveWorkbenchWindow( event )
                                                                                        .getShell(),
                                                                             tableColumns,
                                                                             new ArrayContentProvider(),
                                                                             new ColumnPreferenceLabelProvider(),
                                                                             LABEL_PREF ) {
            @Override
            public void create() {
                super.create();

                final CheckboxTableViewer viewer = getViewer();
                final Button okButton = this.getOkButton();
                viewer.addCheckStateListener( new ICheckStateListener() {
                    @Override
                    public void checkStateChanged( final CheckStateChangedEvent event ) {
                        okButton.setEnabled( viewer.getCheckedElements().length > 0 );
                    }
                } );
                final SelectionListener listener = new SelectionAdapter() {
                    @Override
                    public void widgetSelected( final SelectionEvent event ) {
                        okButton.setEnabled( viewer.getCheckedElements().length > 0 );
                    }
                };
                this.getButton( IDialogConstants.SELECT_ALL_ID ).addSelectionListener( listener );
                this.getButton( IDialogConstants.DESELECT_ALL_ID ).addSelectionListener( listener );
            }
        };
        // Setting the selections to the created ListSelectionDialog
        colSelectDialog.setInitialElementSelections( selections );
        colSelectDialog.open();
        final Object[] selectedColumns = colSelectDialog.getResult();
        if( selectedColumns != null && selectedColumns.length > 0 ) {
            selections.clear();
            for( int i = 0; i < tableColumns.length; i++ ) {
                tableColumns[i].setWidth( 0 );
                tableColumns[i].setResizable( false );
            }
            final StringBuilder builder = new StringBuilder();
            // Adding the selected columns to the instance variable "selections",
            // to be set in ListSelectionDialog
            for( int i = 0; i < selectedColumns.length; i++ ) {
                final TableColumn selectedColumn = (TableColumn)selectedColumns[i];
                selections.add( selectedColumn );
                selectedColumn.setWidth( COL_WIDTH );
                selectedColumn.setResizable( true );
                builder.append( selectedColumn.getText() ).append( "," );
            }
            ReqM2InputData.getRETProperty().setSpecObjColumnProperty( builder.toString() );
        }

        return null;
    }

    /**
     * Sets the variable "selections" with the elements to be kept as selected when the selection dialog opens
     */
    private void setSelection() {
        selections = new ArrayList<TableColumn>();
        // Adding the persisted selections in the instance variable "selections", to be set in ListSelectionDialog. 
        // This is done only the first time, i.e. when ListSelectionDialog is created
        final SpecObjectsView view = (SpecObjectsView)WorkspaceUtils.getViewPart( SpecObjectsView.class );
        final List<String> columnList = SelectionDialogUtil.getColumnPreferences();
        final TableViewer viewer = view.getViewer();
        tableColumns = viewer.getTable().getColumns();
        if( columnList == null ) {
            setSelectionDefault();
        } else {
            for( int j = 0; j < tableColumns.length; j++ ) {
                if( tableColumns[j] != null && columnList.contains( tableColumns[j].getText() ) ) {
                    selections.add( tableColumns[j] );
                }
            }
        }
        // end of adding the persisted selections
    }

    /**
     * Sets the variable "selections" with the default elements to be kept as selected
     */
    private void setSelectionDefault() {
        for( int j = 0; j < tableColumns.length; j++ ) {
            if( "ID".equals( tableColumns[j].getText() )
                || "Version".equals( tableColumns[j].getText() )
                || "Status".equals( tableColumns[j].getText() ) ) {
                selections.add( tableColumns[j] );
            }
        }
    }

}
