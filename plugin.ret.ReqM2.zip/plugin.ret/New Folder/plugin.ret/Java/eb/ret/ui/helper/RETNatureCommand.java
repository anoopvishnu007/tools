package eb.ret.ui.helper;

import eb.ret.core.reqm2.builder.RETNatureController;
import eb.ret.core.reqm2.processor.ErrorLogger;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.commands.IElementUpdater;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.ui.menus.UIElement;

import java.util.Iterator;
import java.util.Map;

/**
 * RETNatureCommand is used to give funtionality to Add/Remove RET Nature popup from context menu. This command toggle
 * the nature of the project. It also implements IElementUpdater to dynamically check the build state in the popup.
 * 
 * @author kirensk
 * 
 */
public class RETNatureCommand extends AbstractHandler implements IElementUpdater {

    /**
     * Command Id representing the RETNature Command
     */
    public static final String COMMAND_ID = "eb.ret.retNatureCommand";

    /**
     * Error message to be displayed when Update Element fails for the command element
     */
    private static final String MSG_UPD_ELEM = "Error in updating the Add/Remove RETNature element ";

    /**
     * Error message to be displayed when Toggling of Nature fails
     */
    private static final String MSG_TOGGLENATURE = "Error while getting Project from Selection";

    public RETNatureCommand() {
        super();
    }

    /*
     * invoked when the "Add/Remove RET Nature" is clicked.
     * (non-Javadoc)
     * @see org.eclipse.core.commands.AbstractHandler#execute(org.eclipse.core.commands.ExecutionEvent)
     */
    @Override
    public Object execute( final ExecutionEvent event ) throws ExecutionException {
        final ISelection selection = HandlerUtil.getCurrentSelection( event );

        final IProject project = getProject( selection );
        if( project != null ) {
            try {
                toggleNature( project );
            } catch( CoreException e ) {
                ErrorLogger.logError( MSG_TOGGLENATURE, e );
            }
        }

        return event;
    }

    /**
     * Toggles sample nature on a project
     * 
     * @param project to have sample nature added or removed
     * @throws CoreException
     */
    private void toggleNature( final IProject project ) throws CoreException {

        if( RETNatureController.isRETProject( project ) ) {
            RETNatureController.deactivateRETNature( project );
            return;
        }
        RETNatureController.activateRETNature( project );
    }

    /**
     * Common method to extract project object from current selection.
     * 
     * @param selection
     * @return the project for the selection
     */
    private IProject getProject( final ISelection selection ) {
        IProject project = null;
        if( selection instanceof IStructuredSelection ) {
            for( @SuppressWarnings("rawtypes")
            Iterator it = ((IStructuredSelection)selection).iterator(); it.hasNext(); ) {
                Object element = it.next();
                if( element instanceof IProject ) {
                    project = (IProject)element;
                } else if( element instanceof IAdaptable ) {
                    project = (IProject)((IAdaptable)element).getAdapter( IProject.class );
                }

            }
        }
        return project;
    }

    /*
     * (non-Javadoc)
     * @see org.eclipse.ui.commands.IElementUpdater#updateElement(org.eclipse.ui.menus.UIElement, java.util.Map)
     * 
     * This is invoked each time the command element is picked up. 
     * Used for checking the menu depends on Project is RETNature or not.
     */
    @SuppressWarnings("rawtypes")
    @Override
    public void updateElement( final UIElement element, final Map parameters ) {

        final IWorkbenchWindow workbench = (IWorkbenchWindow)parameters.get( IWorkbenchWindow.class.getName() );
        final ISelection selection = workbench.getSelectionService().getSelection();
        if( selection != null ) {
            final IProject project = getProject( selection );
            try {
                if( project != null && RETNatureController.isRETProject( project ) ) {
                    element.setChecked( true );
                }
            } catch( CoreException e ) {
                ErrorLogger.logError( MSG_UPD_ELEM, e );
            }
        }

    }

}
