package eb.ret.ui.search.query;

import org.eclipse.core.resources.IFile;
import org.eclipse.search.core.text.TextSearchMatchAccess;

/**
 * Match access class to used for searching in the file
 * 
 * @author anoopvn
 * 
 */
public class ReusableMatchAccess extends TextSearchMatchAccess {

    /**
     * Matched region start offset
     */
    private int matchOffset;
    /**
     * Matched region length
     */
    private int matchLength;
    /**
     * Matched file
     */
    private IFile matchedFile;
    /**
     * Matched file content
     */
    private CharSequence fileContent;

    /**
     * Initializes the values
     * 
     * @param file matched file
     * @param offset matched region start offset
     * @param length matched region length
     * @param content matched file content
     */
    public void initialize( final IFile file, final int offset, final int length, final CharSequence content ) {
        matchedFile = file;
        matchOffset = offset;
        matchLength = length;
        fileContent = content;
    }

    @Override
    public IFile getFile() {
        return matchedFile;
    }

    @Override
    public int getMatchOffset() {
        return matchOffset;
    }

    @Override
    public int getMatchLength() {
        return matchLength;
    }

    @Override
    public int getFileContentLength() {
        return fileContent.length();
    }

    @Override
    public char getFileContentChar( final int offset ) {
        return fileContent.charAt( offset );
    }

    @Override
    public String getFileContent( final int offset, final int length ) {
        return fileContent.subSequence( offset, offset + length ).toString(); // must pass a copy!
    }
}