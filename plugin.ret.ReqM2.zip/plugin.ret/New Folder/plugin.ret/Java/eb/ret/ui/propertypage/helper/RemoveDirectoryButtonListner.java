package eb.ret.ui.propertypage.helper;

import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.ui.propertypage.ReqM2PropertyPage;

import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;

/**
 * This class act as a listener for Remove button in the ReqM2 property page
 * 
 * @author anoopvn
 */
public class RemoveDirectoryButtonListner extends SelectionAdapter {
    /**
     * The ReqM2PropertyPage object
     */
    public ReqM2PropertyPage propertyPage;

    /**
     * Constructor
     * 
     * @param reqM2PropertyPage the ReqM2PropertyPage object
     */
    public RemoveDirectoryButtonListner( final ReqM2PropertyPage reqM2PropertyPage ) {
        super();
        this.propertyPage = reqM2PropertyPage;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt
     * .events.SelectionEvent)
     * 
     * @since 1.0
     */
    @Override
    public void widgetSelected( final SelectionEvent event ) {
        super.widgetSelected( event );
        final Button button = (Button)event.getSource();
        if( button.getText().equals( InputDirectoryContentCreator.LABEL_REMOVE ) ) {
            handleRemoveDirectory();
            button.setEnabled( false );
        }
        // checks the directory paths are valid
        propertyPage.checkForError();

    }

    /*
     * !LINKSTO eclipse.ret.req.RemoveInputDirectory,1
     */
    /**
     * Handles remove button functionality. It removes the selected Ret input directory and its path from the internally
     * stored input directory list and input path list.
     * 
     */
    private void handleRemoveDirectory() {
        final Table table = propertyPage.getViewer().getTable();
        final TableItem[] selectedItems = table.getSelection();
        for( int i = 0; i < selectedItems.length; i++ ) {
            final RETDirectory selectedDir = (RETDirectory)selectedItems[i].getData();
            if( propertyPage.getInputDirs().contains( selectedDir ) ) {
                propertyPage.removeInputDirectory( selectedDir );
            }
        }
        propertyPage.getViewer().refresh();
    }

}
