/**
 * 
 */
package eb.ret.ui.search.result.view;

import eb.ret.ui.RETPluginImages;
import eb.ret.ui.search.query.SpecObjectSearchQuery;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.IEditorMatchAdapter;
import org.eclipse.search.ui.text.IFileMatchAdapter;
import org.eclipse.search.ui.text.Match;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;

/**
 * Search result class of specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchResult extends AbstractTextSearchResult implements IEditorMatchAdapter,
        IFileMatchAdapter {

    /**
     * Empty match array
     */
    private final Match[] EMPTY_ARR = new Match[0];

    /**
     * Specobject search query
     */
    private final SpecObjectSearchQuery query;

    /**
     * Constructor
     * 
     * @param query search query
     */
    public SpecObjectSearchResult( final SpecObjectSearchQuery query ) {
        super();
        this.query = query;
    }

    @Override
    public ImageDescriptor getImageDescriptor() {

        return RETPluginImages.DESC_OBJ_DPDN;
    }

    @Override
    public String getLabel() {
        return query.getResultLabel( getMatchCount() );
    }

    @Override
    public String getTooltip() {
        return getLabel();
    }

    @Override
    public Match[] computeContainedMatches( final AbstractTextSearchResult result, final IFile file ) {
        return getMatches( file );
    }

    @Override
    public IFile getFile( final Object element ) {
        if( element instanceof IFile ) {
            return (IFile)element;
        }
        return null;
    }

    @Override
    public boolean isShownInEditor( final Match match, final IEditorPart editor ) {
        final IEditorInput einput = editor.getEditorInput();
        if( einput instanceof IFileEditorInput ) {
            final IFileEditorInput finput = (IFileEditorInput)einput;
            return match.getElement().equals( finput.getFile() );
        }
        return false;
    }

    @Override
    public Match[] computeContainedMatches( final AbstractTextSearchResult result, final IEditorPart editor ) {
        final IEditorInput einput = editor.getEditorInput();
        if( einput instanceof IFileEditorInput ) {
            final IFileEditorInput finput = (IFileEditorInput)einput;
            return getMatches( finput.getFile() );
        }
        return EMPTY_ARR;
    }

    @Override
    public ISearchQuery getQuery() {
        return query;
    }

    @Override
    public IFileMatchAdapter getFileMatchAdapter() {
        return this;
    }

    @Override
    public IEditorMatchAdapter getEditorMatchAdapter() {
        return this;
    }

}
