package eb.ret.ui.helper;

import static eb.ret.core.reqm2.data.ReqM2InputData.KEY_REQM2_BROWSER;

import eb.ret.core.reqm2.data.ReqM2InputData.BrowserType;
import eb.ret.plugin.RETPlugin;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * Initialise default preferences in ReqM2 preference page.
 * 
 * @author tintobaby
 * 
 */
public class DefaultPreferenceInitializer extends AbstractPreferenceInitializer {

    /**
     * To initialise the default preferences.
     */
    @Override
    public void initializeDefaultPreferences() {

        final IPreferenceStore preferenceStore = RETPlugin.getDefault().getPreferenceStore();
        preferenceStore.setDefault( KEY_REQM2_BROWSER, BrowserType.ECLIPSE.toString() );
    }

}