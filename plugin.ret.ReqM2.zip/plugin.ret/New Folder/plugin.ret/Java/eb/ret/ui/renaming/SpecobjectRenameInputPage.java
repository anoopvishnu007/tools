package eb.ret.ui.renaming;

import eb.ret.text.refactoring.rename.RenameData;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.ltk.ui.refactoring.UserInputWizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * User input page(first page) for specobject renaming.
 * 
 * @author tintobaby
 * 
 */
public class SpecobjectRenameInputPage extends UserInputWizardPage {
    /**
     * Label for the text input field
     */
    private static final String LABEL_TXT_FIELD = "New name:";

    /**
     * Label for the update references check box
     */
    private static final String LABEL_UPD_REF = "Update references";

    /**
     * Text box for updating specobject id.
     */
    private Text textField;

    /**
     * Update reference check box.
     */
    private Button updRefCheckBox;

    /**
     * Instance of rename data holds the details for rename operation.
     */
    private final RenameData renameData;

    /**
     * Existing specobject Id.
     */
    private final String previousId;

    /**
     * Constructor.
     * 
     * @param data
     */
    public SpecobjectRenameInputPage( final RenameData data ) {
        super( SpecobjectRenameInputPage.class.getName() );
        renameData = data;
        previousId = data.getSpecObject().getId();
    }

    @Override
    public void createControl( final Composite parent ) {

        //Parent composite.
        final Composite composite = new Composite( parent, SWT.NONE );
        final GridLayout gridLayout = new GridLayout( 2, false );
        gridLayout.marginWidth = 10;
        gridLayout.marginHeight = 10;
        composite.setLayout( gridLayout );
        initializeDialogUnits( composite );
        Dialog.applyDialogFont( composite );

        //Calling Dialog class method.
        setControl( composite );

        final Label lblNewName = new Label( composite, SWT.NONE );
        lblNewName.setText( LABEL_TXT_FIELD );

        //Text box to update the specobject id.
        textField = new Text( composite, SWT.BORDER );
        //Display the existing id.
        textField.setText( previousId );
        textField.setLayoutData( new GridData( GridData.FILL_HORIZONTAL ) );
        textField.selectAll();

        /**
         * listener to update the value to the data object. Also check the input status in the text box.
         */
        textField.addKeyListener( new KeyAdapter() {
            @Override
            public void keyReleased( final KeyEvent exp ) {
                renameData.setNewText( textField.getText() );
                checkStatus();
            }
        } );

        //Update references check box.
        updRefCheckBox = createCheckbox( composite, LABEL_UPD_REF );

        /**
         * listener to update the value to the data object.
         */
        updRefCheckBox.addSelectionListener( new SelectionAdapter() {
            @Override
            public void widgetSelected( final SelectionEvent event ) {
                renameData.setUpdateReference( updRefCheckBox.getSelection() );
            }
        } );

        //For updating button status.
        setPageComplete( false );
    }

    /**
     * Check the input status in the text box.
     */
    private void checkStatus() {
        final String txt = textField.getText();
        setPageComplete( txt.length() > 0 && !txt.equals( previousId ) );
    }

    /**
     * To create a check box
     * 
     * @param composite
     * @param text
     * @return
     */
    private Button createCheckbox( final Composite composite, final String text ) {
        final Button checkUpdateRef = new Button( composite, SWT.CHECK );
        checkUpdateRef.setText( text );

        final GridData gridData = new GridData( GridData.FILL_HORIZONTAL );
        gridData.horizontalSpan = 2;
        checkUpdateRef.setLayoutData( gridData );
        return checkUpdateRef;
    }
}
