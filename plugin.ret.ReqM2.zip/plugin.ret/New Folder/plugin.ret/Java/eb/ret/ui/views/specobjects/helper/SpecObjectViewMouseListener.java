package eb.ret.ui.views.specobjects.helper;

import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.helper.SpecObjectUtils;
import eb.ret.ui.views.specobjects.SpecObjectsView;

import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.widgets.TableItem;

/**
 * MouseListener class for specobject view
 * 
 * @author nikhilcr
 * 
 */
public class SpecObjectViewMouseListener implements MouseListener {
    /**
     * specobject view on which the listener is configured
     */
    private final SpecObjectsView specObjectsView;

    /**
     * constructur with view as the input
     * 
     * @param view
     */
    public SpecObjectViewMouseListener( final SpecObjectsView view ) {
        this.specObjectsView = view;
    }

    @Override
    public void mouseDoubleClick( final MouseEvent event ) {
        final TableItem[] items = specObjectsView.getViewer().getTable().getSelection();
        //        currentSelection.clear();
        //        currentSelection.addAll( Arrays.asList( items ) );
        for( int i = 0; i < items.length; i++ ) {
            SpecObjectUtils.openSpecObjInEditor( ((SpecobjectType)items[i].getData()).getId() );
        }
    }

    @Override
    public void mouseDown( final MouseEvent event ) {
        // functionality not required

    }

    @Override
    public void mouseUp( final MouseEvent event ) {
        // functionality not required

    }

}
