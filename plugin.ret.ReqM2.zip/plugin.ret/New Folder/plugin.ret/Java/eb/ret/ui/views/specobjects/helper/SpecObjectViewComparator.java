package eb.ret.ui.views.specobjects.helper;

import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;

/**
 * Comparator class to compare specobjects based on the selected column. The default comparator of ViewerComparator is
 * used for comparison
 * 
 * @author kirensk
 * 
 */
public class SpecObjectViewComparator extends ViewerComparator {
    /**
     * Constant for default column name
     */
    private static final String DEFAULT_COL_NAME = "ID";
    /**
     * constant for descending sorting order
     */
    private static final int DESCENDING = 1;
    /**
     * For SpecObjec view column name
     */
    private String columnName;
    /**
     * For SpecObjec view column sorting direction
     */
    private int direction = DESCENDING;
    /**
     * column on which the comparator is sorting
     */
    private TableViewerColumn sortColumn;

    /**
     * default constructor
     */
    public SpecObjectViewComparator() {
        super();
        this.columnName = DEFAULT_COL_NAME;
        direction = DESCENDING;
    }

    /**
     * Returns the sorting order
     * 
     * @return
     */
    public int getDirection() {
        return direction == 1 ? SWT.DOWN : SWT.UP;
    }

    /**
     * Sets the column name and sets the order of sorting
     * 
     * @param colName
     */
    public void setColumn( final String colName ) {
        if( colName != null ) {

            if( this.columnName.equals( colName ) ) {
                // Same column as last sort, toggle the direction
                direction = 1 - direction;
            } else {
                // New column; do an ascending sort
                this.columnName = colName;
                direction = DESCENDING;
            }
            columnName = colName;
        }
    }

    /**
     * Sets the column on which sorting will be performed
     * 
     * @param sortColumn
     */
    public void setSortColumn( final TableViewerColumn sortColumn ) {
        if( sortColumn != null ) {
            this.sortColumn = sortColumn;
            setColumn( sortColumn.getColumn().getText() );
        }
    }

    //suppress type check in compare
    @SuppressWarnings("unchecked")
    @Override
    public int compare( final Viewer viewer, final Object specobj_a, final Object specobj_b ) {
        String columnText_a = "";
        String columnText_b = "";
        if( sortColumn != null && sortColumn.getViewer() != null ) {

            columnText_a = (String)sortColumn.getColumn().getData( ((SpecobjectType)specobj_a).getId() );
            columnText_b = (String)sortColumn.getColumn().getData( ((SpecobjectType)specobj_b).getId() );
        }

        if( direction == DESCENDING ) {
            final String tempCol = columnText_a;
            columnText_a = columnText_b;
            columnText_b = tempCol;
        }
		// replace null text with blank string to handle the comparator
        if( columnText_a == null ) {
            columnText_a = "";
        }
        if( columnText_b == null ) {
            columnText_b = "";
        }

        return getComparator().compare( columnText_a, columnText_b );

    }

}
