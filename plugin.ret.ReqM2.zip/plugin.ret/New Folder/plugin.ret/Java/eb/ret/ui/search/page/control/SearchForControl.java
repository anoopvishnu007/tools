package eb.ret.ui.search.page.control;

import eb.ret.core.model.data.SpecObjectSearchParams.SearchForType;
import eb.ret.ui.search.page.SpecObjectSearchDialogPage;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;

/**
 * This class represents the search for control in the search page
 * 
 * @author anoopvn
 * 
 */
public class SearchForControl extends AbstractSearchPageControl {
    /**
     * SearchFor radio buttons
     */
    private Button searchForButtons[];

    /**
     * searchFor group label
     */
    public static final String SEARCH_FOR = "Search For";

    /**
     * Constructor
     * 
     * @param parentPage
     * @param searchDialogPage
     */
    public SearchForControl( final Composite parentPage, final SpecObjectSearchDialogPage searchDialogPage ) {
        super( parentPage, searchDialogPage );
    }

    @Override
    public void createControl() {
        createSearchFor( parentPage );
    }

    /**
     * Creates the search for options in the search page
     * 
     * @param parent
     */
    private void createSearchFor( final Composite parent ) {
        final Group result = new Group( parent, 0 );
        result.setText( SEARCH_FOR );
        result.setLayout( new GridLayout( 2, true ) );
        createSearchForButton( result );
        final Label filler = new Label( result, 0 );
        filler.setVisible( false );
        filler.setLayoutData( new GridData( SWT.FILL, SWT.FILL, false, false, 1, 1 ) );
        result.setLayoutData( new GridData( SWT.FILL, SWT.FILL, true, false, 1, 1 ) );

    }

    /**
     * creates search for option buttons
     * 
     * @param parent parent composite
     * @return array of buttons
     */
    private void createSearchForButton( final Group parent ) {
        final SearchForType[] searchForTypes = SearchForType.values();
        searchForButtons = new Button[searchForTypes.length];
        int count = 0;
        final SelectionAdapter searchForAdapter = getSelectionAdapter();
        for( final SearchForType searchFor : searchForTypes ) {
            final Button searchForbutton = createButton( parent,
                                                         SWT.RADIO,
                                                         searchFor.getName(),
                                                         searchFor.getValue(),
                                                         false );
            searchForbutton.addSelectionListener( searchForAdapter );
            searchForButtons[count++] = searchForbutton;
        }
        final int selIndex = pageElements.getSearchForSelection();
        searchForButtons[selIndex].setSelection( true );
    }

    /**
     * getter for accessing the searchFor buttons created
     * 
     * @return
     */

    public Button[] getSearchForButtons() {
        return searchForButtons;
    }

    /**
     * Gets the selection adapter for searchFor button
     * 
     * @return SelectionAdapter
     */
    private SelectionAdapter getSelectionAdapter() {
        return new SelectionAdapter() {
            @Override
            public void widgetSelected( final SelectionEvent event ) {
                performSearchForSelectionChanged( (Button)event.widget );
            }

        };
    }

    /**
     * Enables or disables the limit to group options in the search page according to the search for value
     * 
     * @param searchForButton
     */
    private final void performSearchForSelectionChanged( final Button searchForButton ) {
        if( searchForButton.getSelection() ) {
            pageElements.setSearchForSelection( ((Integer)searchForButton.getData()).intValue() );
            if( SearchForType.ID.getName().equals( searchForButton.getText() ) ) {
                enableGroup( pageElements.getLimitToGroup(), true );
            } else {
                enableGroup( pageElements.getLimitToGroup(), false );
            }
        }
    }
}
