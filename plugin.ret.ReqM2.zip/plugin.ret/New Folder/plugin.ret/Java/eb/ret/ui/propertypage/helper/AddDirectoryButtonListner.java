package eb.ret.ui.propertypage.helper;

import eb.ret.core.reqm2.data.ImporterType;
import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.core.reqm2.data.ReqM2Property;
import eb.ret.ui.propertypage.ReqM2PropertyPage;
import eb.ret.util.WorkspaceUtils;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.dialogs.CheckedTreeSelectionDialog;
import org.eclipse.ui.model.BaseWorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * This class act as a listener for Add Directory button in the ReqM2 property page
 * 
 * @author anoopvn
 */
public class AddDirectoryButtonListner extends SelectionAdapter {
    /**
     * Constant for selecting input directory message
     */
    private static final String INPUT_DIR_MSG = "Select input directories";

    /**
     * The ReqM2PropertyPage object
     */
    private final ReqM2PropertyPage propertyPage;

    /**
     * Constructor
     * 
     * @param reqM2PropertyPage the ReqM2PropertyPage object
     */
    public AddDirectoryButtonListner( final ReqM2PropertyPage reqM2PropertyPage ) {
        super();
        this.propertyPage = reqM2PropertyPage;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt
     * .events.SelectionEvent)
     * 
     * @since 1.0
     */
    @Override
    public void widgetSelected( final SelectionEvent event ) {
        super.widgetSelected( event );
        final Button button = (Button)event.getSource();
        if( button.getText().equals( InputDirectoryContentCreator.LABEL_ADD_DIR ) ) {
            handleAddDirectory();
        }
        // checks the directory paths are valid
        propertyPage.checkState();

    }

    /*
     * !LINKSTO eclipse.ret.req.AddInputDirectory,1
     */
    /**
     * handling add directory button functionality
     * 
     */
    private void handleAddDirectory() {
        // Opens the project directory dialog
        final Object[] elements = openAddDirectoryDialog( propertyPage.getShell(), propertyPage.getCurrentProject() );
        // adding selected paths to List view
        addPathToList( elements );
    }

    /**
     * Opening the selection dialog for adding workspace directories
     * 
     * @param shell parent shell
     * @param project the selected project
     * @return array of selected paths
     */
    public static Object[] openAddDirectoryDialog( final Shell shell, final IProject project ) {

        final CheckedTreeSelectionDialog dialog = new CheckedTreeSelectionDialog(
            shell,
            new WorkbenchLabelProvider(),
            new BaseWorkbenchContentProvider() );

        dialog.setTitle( INPUT_DIR_MSG );

        dialog.setMessage( INPUT_DIR_MSG );

        dialog.setInput( project );
        // filtering to show directories only
        final ViewerFilter viewerFilter = new ViewerFilter() {

            @Override
            public boolean select( final Viewer viewer, final Object parentElement, final Object element ) {
                final IResource resource = (IResource)element;
                final File file = new File( resource.getLocationURI() );
                if( file.isDirectory() ) {
                    return true;
                } else {
                    return false;
                }
            }
        };
        dialog.addFilter( viewerFilter );
        dialog.open();
        return dialog.getResult();
    }

    /**
     * Adding the selected paths to the List view
     * 
     * @param elements path elements to add
     */
    public void addPathToList( final Object[] elements ) {
        if( elements != null && elements.length > 0 ) {
            for( int i = 0; i < elements.length; i++ ) {
                final IResource elem = (IResource)elements[i];
                addPath( elem.getProjectRelativePath().toOSString() );
            }
        }

    }

    /**
     * Adding path to the input directory list
     * 
     * @param path path to add
     */
    public void addPath( final String path ) {
        final List<RETDirectory> directories = propertyPage.getInputDirs();
        if( directories == null || directories.isEmpty() ) {
            addDataToTable( path );
            return;
        } else {
            final IPath ipath = new Path( path );
            if( isAnyParentFolderAdded( ipath, directories ) ) {
                return;
            }
            removeExistingChildFolders( ipath, directories );
            addDataToTable( path );
        }
    }

    /**
     * If the path is parent of already added directories remove the child directories
     * 
     * @param path path to check
     * @param inputDirs the input directory list
     */
    public void removeExistingChildFolders( final IPath path, final List<RETDirectory> inputDirs ) {
        final List<RETDirectory> inputDirects = new ArrayList<RETDirectory>();
        inputDirects.addAll( inputDirs );
        for( final RETDirectory dir : inputDirects ) {
            final IPath dirPath = WorkspaceUtils.getIPath( dir.getPath() );
            if( path.isPrefixOf( dirPath ) ) {
                propertyPage.removeInputDirectory( dir );
            }
        }
    }

    /**
     * checks any of the parent of the given path is already added
     * 
     * @param path path to check
     * @param inputDirs
     * @return true if parent of the given path is already added else false
     */
    public boolean isAnyParentFolderAdded( final IPath path, final List<RETDirectory> inputDirs ) {
        boolean isAdded = false;
        for( final Iterator<RETDirectory> iterator = inputDirs.iterator(); iterator.hasNext(); ) {
            final RETDirectory dir = iterator.next();
            if( WorkspaceUtils.getIPath( dir.getPath() ).isPrefixOf( path ) ) {
                isAdded = true;
                break;
            }
        }
        return isAdded;
    }

    /**
     * Adds the newly selected input directory path to the input-directories table, and sets a default importer and
     * doctype. This also adds the path of the input directory to the stored internal List
     * 
     * @param String added input directory path
     */
    public void addDataToTable( final String dirPath ) {

        final RETDirectory addedDirectory = new RETDirectory();
        addedDirectory.setPath( dirPath );
        addedDirectory.setImporter( ImporterType.DOCBOOK );
        addedDirectory.setDocType( ReqM2Property.NOT_APPLICABLE );
        propertyPage.addInputDirectory( addedDirectory );

    }
}
