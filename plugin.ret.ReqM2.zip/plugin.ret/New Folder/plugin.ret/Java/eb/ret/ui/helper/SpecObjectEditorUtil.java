package eb.ret.ui.helper;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.editor.hyperlink.SpecObjectHyperLink;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.FindReplaceDocumentAdapter;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextOperationTarget;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.TextSelection;
import org.eclipse.jface.text.hyperlink.IHyperlink;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.ide.IGotoMarker;
import org.eclipse.ui.texteditor.ITextEditor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author anoopvn
 * 
 */
public final class SpecObjectEditorUtil {
    /**
     * ReqM2 LINKSTO format string
     */
    private static final String SPECOBJ_START = "!LINKSTO";

    /**
     * ReqM2 LINKSTO format regular expression
     */
    private static final String START_REGEX = "^\\s*(/)*(\\*)?\\s*![(LINKSTO)|(SPECOBJECT)].*";
    /**
     * ReqM2 LINKSTO format string
     */
    private static final String SPECOBJ_CONTINUE = "!";

    /**
     * String constant to represent ',' character used for chaining
     */
    private static final String COMMA_CHAR = ",";
    /**
     * Error message to be displayed if exception on CNTRL+click action
     */
    private static final String ERR_BAD_LOC = "Bad Location selected ";

    /**
     * Error message for the exceptions while identifying the specobject region.
     */
    private static final String ERR_REGION = "Exception when finding specObject id in the source file";

    /**
     * private constructor restricting object initialization
     */
    private SpecObjectEditorUtil() {
        super();
    }

    /**
     * retrieves the specObject hyperlinks in the given specobject region for the given document
     * 
     * @param document
     * @param cursorOffset
     * @return array of specObjLinks
     * @throws BadLocationException
     */
    public static IHyperlink[] getSpecObjectLinks( final IDocument document, final int cursorOffset )
        throws BadLocationException {
        final SpecObjectMatch specObjectMatch = getSpecObjectMatch( document, cursorOffset );

        if( specObjectMatch == null ) {
            return null;
        }
        final SpecObjectHyperLink hyperlink = new SpecObjectHyperLink(
            specObjectMatch.getRegion(),
            specObjectMatch.getId() );
        // we only support one hyperlink 
        return new SpecObjectHyperLink[]{hyperlink};
    }

    /**
     * Searches for a valid specObject Id at the given cursorOffset.
     * 
     * @param document the document to work on
     * @param cursorOffset the cursor offset to look at
     * @return returns a match, if the text at the cursor was parsed as a specobject
     * @throws BadLocationException
     */
    public static SpecObjectMatch getSpecObjectMatch( final IDocument document, final int cursorOffset )
        throws BadLocationException {
        final IRegion lineRegion = document.getLineInformationOfOffset( cursorOffset );
        final int lineStart = lineRegion.getOffset();
        final String line = document.get( lineRegion.getOffset(), lineRegion.getLength() );

        SpecObjectMatch result = null;
        if( isValidSpecObjectId( document, cursorOffset, true ) ) {
            // before a specobject ID there is either a whitespace or a comma
            final String patternBefore = "[\\s|,]";
            // the ID can be anything except comma, whitespace
            final String patternId = "([^,\\s]+?)";
            // after the ID there is either a whitespace or a comma
            // just do a lookahead because for multiple IDs in one line this matches the patternBefore of the next match
            final String patternAfterIdLookahead = "(?=[\\s|,])"; // NOPMD readability
            final Pattern pattern = Pattern.compile( patternBefore + patternId + patternAfterIdLookahead );
            final Matcher matcher = pattern.matcher( line );

            boolean found = false;
            int idStart = -1;
            int idEnd = -1;
            String linkstoId = null;
            while (matcher.find()) {
                linkstoId = matcher.group( 1 );
                idStart = matcher.start( 1 );
                idEnd = matcher.end( 1 );
                // for now we ignore the version information
                if( linkstoId.matches( "\\d+" ) ) {
                    continue;
                }
                // the cursorOffest must be insie the bounds of the found ID
                if( lineStart + idStart <= cursorOffset && cursorOffset <= lineStart + idEnd ) {
                    found = true;
                    break;
                }
            }
            if( found ) {
                final IRegion region = new Region( lineStart + idStart, idEnd - idStart );
                result = new SpecObjectMatch( linkstoId, region );
            }
        }
        return result;
    }

    /**
     * retrieves the corresponding source file for the given specObject
     * 
     * @param specObject
     * @return sourceFile corresponding to the specObject
     */
    public static IFile getSourceFile( final SpecobjectType specObject ) {
        IFile sourceFile = null;
        if( specObject != null && specObject.getSourcefile() != null ) {
            final IPath path = new Path( specObject.getSourcefile() );
            final IWorkspaceRoot workspaceRoot = ResourcesPlugin.getWorkspace().getRoot();
            final IContainer container = workspaceRoot.getContainerForLocation( path );
            if( container != null ) {
                sourceFile = workspaceRoot.getFile( container.getFullPath() );
            }
        }
        return sourceFile;
    }

    /**
     * validates whether the cursor position is on a valid LINKSTO region or not
     * 
     * @param document mouse clicked document
     * @param cursorOffset line offset which mouse clicked
     * @param isCursorLine flag to indicate the current line is the cursor selected line
     * @return true if a valid specobject id else false
     */
    public static boolean isValidSpecObjectId( final IDocument document,
                                               final int cursorOffset,
                                               final boolean isCursorLine ) {
        boolean isValid = false;
        IRegion lineInfo;
        String line;
        int lineNumber = 0;
        int commentOffset = -1;
        try {
            if( !Character.isSpaceChar( cursorOffset ) ) {
                lineInfo = document.getLineInformationOfOffset( cursorOffset );
                line = document.get( lineInfo.getOffset() + 1, lineInfo.getLength() - 1 );
                // validates the line contains !LINKSTO or ! elements for a valid
                // reqm2 parsing
                if( (line.matches( START_REGEX )) ) {
                    commentOffset = line.indexOf( SPECOBJ_START ) + SPECOBJ_START.length();
                    isValid = true;
                } else if( line.matches( ".*[!][\\s].*" ) ) {// checks for either '! '(the blank space or ' ' or \t)
                    commentOffset = line.indexOf( SPECOBJ_CONTINUE ) + SPECOBJ_CONTINUE.length() + 1;
                    lineNumber = document.getLineOfOffset( cursorOffset );
                    // recursively check the previous line till an invalid line is found.
                    final int prevLineOffset = document.getLineOffset( lineNumber - 1 );
                    //isCursorLine flag is set to false for previous line
                    isValid = isValidSpecObjectId( document, prevLineOffset, false );
                }

                if( isCursorLine ) {
                    //if cursor line verify the selection is after the '!LINKSTO' or chain '!' element
                    isValid = isValid && (cursorOffset > (lineInfo.getOffset() + commentOffset));
                } else {
                    //if previous line then check for chain character ',' exists
                    isValid = isValid && line.trim().endsWith( COMMA_CHAR );
                }
            }

        } catch( final BadLocationException e ) {
            ErrorLogger.logError( ERR_BAD_LOC, e );
        }
        return isValid;
    }

    /**
     * This utility class manages a specobject match as an Id and a region (relative to a document).
     * 
     * @author mawe2550
     * 
     */
    public static class SpecObjectMatch {
        private transient final String specObjectId;
        private transient final IRegion region;

        public SpecObjectMatch( final String specObjectId, final IRegion region ) {
            this.specObjectId = specObjectId;
            this.region = region;
        }

        public SpecObjectMatch( final String specObjectId, final int offset, final int length ) {
            this.specObjectId = specObjectId;
            this.region = new Region( offset, length );
        }

        public String getId() {
            return specObjectId;
        }

        public IRegion getRegion() {
            return region;
        }
    }

    /**
     * Reveals the specobject id in the opened file editor.
     * 
     * @param editorPart opened editor part.
     * @param specObject selected specobject.
     * @throws BadLocationException
     */
    public static void revealInEditor( final IEditorPart editorPart, final SpecobjectType specObject )
        throws BadLocationException {
        if( editorPart == null ) {
            return;
        }
        final ITextOperationTarget target = (ITextOperationTarget)editorPart.getAdapter( ITextOperationTarget.class );
        if( target instanceof ITextViewer ) {
            final ITextViewer textViewer = (ITextViewer)target;
            //gets the opened document
            final IDocument document = textViewer.getDocument();
            final IRegion specObjIdRegion = findSpecObjectIdRegion( document, specObject );
            if( specObjIdRegion != null ) {
                revealInEditor( editorPart, specObjIdRegion.getOffset(), specObjIdRegion.getLength() );
            }
        }

    }

    /**
     * Finds the specobject id in the opened document
     * 
     * @param document opened document.
     * @param specObject selected specobject.
     * @return the region of the specobject id
     * @throws BadLocationException
     */
    private static IRegion findSpecObjectIdRegion( final IDocument document, final SpecobjectType specObject )
        throws BadLocationException {
        int specLineOffset = 0;
        int searchLength = 0;
        final String specObjectId = specObject.getId();
        try {
            // find the line details from specobject resource with document
            final int line = Integer.parseInt( specObject.getSourceline() );
            specLineOffset = document.getLineOffset( line );
            searchLength = document.getLineLength( line );
            final String specLine = document.get( specLineOffset, searchLength );
            String searchId = specObjectId;
            //search for the specobject id in the specline, if complete id is not found try with string after the prefix
            if( specLine != null ) {
                int specIndex = specLine.indexOf( specObjectId );
                if( specIndex == -1 ) {
                    searchId = specObjectId.substring( specObjectId.lastIndexOf( '.' ) + 1 );
                    specIndex = specLine.indexOf( searchId );
                }
                //find the new offset and length with respect to the search id index
                if( specIndex != -1 ) {
                    specLineOffset = specLineOffset + specIndex;
                    searchLength = searchId.length();
                }
            }
        } catch( final Exception e ) {
            ErrorLogger.logError( ERR_REGION, e );
        }
        return new Region( specLineOffset, searchLength );
    }

    /**
     * Reveals the corresponding offset in the editor
     * 
     * @param editor opened editor
     * @param offset character start offset to mark
     * @param length length of the marking string
     */
    public static void revealInEditor( final IEditorPart editor, final int offset, final int length ) {
        //if the opened editor is a text editor
        if( editor instanceof ITextEditor ) {
            ((ITextEditor)editor).selectAndReveal( offset, length );
            return;
        }
        //gets the IGotoMarker object to go to a marker in a file
        final IGotoMarker gotoMarkerTarget;
        if( editor instanceof IGotoMarker ) {
            gotoMarkerTarget = (IGotoMarker)editor;
        } else {
            gotoMarkerTarget = editor == null ? null : (IGotoMarker)editor.getAdapter( IGotoMarker.class );
        }
        if( gotoMarkerTarget != null ) {
            final IFileEditorInput input = (IFileEditorInput)editor.getEditorInput();
            IMarker marker = null;
            try {
                //creates a marker in the file and goes to the marker
                marker = input.getFile().createMarker( IMarker.TEXT );
                if( marker != null ) {
                    marker.setAttribute( IMarker.CHAR_START, offset );
                    marker.setAttribute( IMarker.CHAR_END, offset + length );
                    gotoMarkerTarget.gotoMarker( marker );
                    marker.delete();
                }
            } catch( final CoreException ex ) {
                ErrorLogger.logError( ex.getMessage(), ex );
            }
            final ISelectionProvider provider = editor.getEditorSite().getSelectionProvider();
            if( provider != null ) {
                provider.setSelection( new TextSelection( offset, length ) );
            }
        }
    }

    /**
     * Gets the specobject id prefix value from the document if it is present
     * 
     * @param document
     * @return id prefix string
     */
    public static String getIDPrefixFromDoc( final IDocument document ) {

        String idPrefix = "";
        final FindReplaceDocumentAdapter findAdapter = new FindReplaceDocumentAdapter( document );
        try {
            final IRegion startRegion = findAdapter.find( 0, "<idprefix>", true, true, false, false );
            if( startRegion != null ) {
                final int startOffset = startRegion.getOffset() + startRegion.getLength();
                final IRegion endRegion = findAdapter.find( startOffset, "</idprefix>", true, true, false, false );
                final int length = endRegion.getOffset() - startOffset;
                idPrefix = document.get( startOffset, length );
            }

        } catch( final BadLocationException e ) {
            ErrorLogger.logError( e.getMessage(), e );
        }
        return idPrefix;
    }
}
