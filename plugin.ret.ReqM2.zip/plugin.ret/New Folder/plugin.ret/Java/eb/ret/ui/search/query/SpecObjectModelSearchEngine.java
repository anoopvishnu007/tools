package eb.ret.ui.search.query;

import eb.ret.core.model.data.SpecObjectSearchParams;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.plugin.RETPlugin;
import eb.ret.ui.MessageFormatter;
import eb.ret.ui.RETPluginMessages;
import eb.ret.ui.helper.SpecObjectEditorUtil;
import eb.ret.util.PatternConstructor;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Specobject model search engine class. This class contains the search functionality of specobject search
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectModelSearchEngine {

    /**
     * Search result collector
     */
    private final SpecObjectSearchResultCollector resultCollector;
    /**
     * Search progress monitor
     */
    private IProgressMonitor progressMonitor;
    /**
     * holds the number of files scanned
     */
    private int noOfScannedFiles;
    /**
     * holds the number of files needs to scan
     */
    private int noOfFilesToScan;
    /**
     * The current scanning file
     */
    private IFile currentFile;
    /**
     * Status of the search
     */
    private final MultiStatus status;
    /**
     * Map holds the file and containing specobjects as key value pairs respectively
     */
    private Map<IFile, List<SpecobjectType>> specObjSearchMap = new HashMap<IFile, List<SpecobjectType>>();

    /**
     * search parameters for specobject search
     */
    private final SpecObjectSearchParams searchParams;

    /**
     * Constructor
     * 
     * @param collector search result collector
     * @param params search parameters
     */
    public SpecObjectModelSearchEngine( final SpecObjectSearchResultCollector collector,
                                        final SpecObjectSearchParams params ) {
        resultCollector = collector;
        status = new MultiStatus(
            RETPlugin.PLUGIN_ID,
            IStatus.OK,
            RETPluginMessages.SpecObjectModelSearch_statusMessage,
            null );
        searchParams = params;

    }

    /**
     * This method does the search in the specobject model with the search parameters and after that locate the
     * specobjects in the files corresponding files and shows in the result view
     * 
     * @param monitor the the progress monitor
     * @return the status of the search
     */
    public IStatus search( final IProgressMonitor monitor ) {

        specObjSearchMap = new HashMap<IFile, List<SpecobjectType>>();
        //gets the files in the scope
        final IFile[] filesInScope = searchParams.getScope().evaluateFilesInScope( status );
        final List<IFile> filesInScopeList = Arrays.asList( filesInScope );
        final List<IFile> fileList = new ArrayList<IFile>();
        //Query the model with the search parameters
        final List<SpecobjectType> specObjects = SpecObjectSearchEngineUtils.getSpecobjects( searchParams );
        SpecObjectSearchEngineUtils.addSpecObjects( fileList, filesInScopeList, specObjects, specObjSearchMap );
        return search( fileList.toArray( new IFile[fileList.size()] ), monitor );
    }

    /**
     * Searches the specobject search string matches in the files
     * 
     * @param files array of files
     * @param monitor progress monitor
     * @return the status of the search
     */
    public IStatus search( final IFile[] files, final IProgressMonitor monitor ) {
        progressMonitor = monitor == null ? new NullProgressMonitor() : monitor;
        noOfScannedFiles = 0;
        noOfFilesToScan = files.length;
        currentFile = null;

        final Job monitorUpdateJob = getSearchProgressMonitorJob();

        try {
            final String taskName = searchParams.getSearchString() == null
                ? RETPluginMessages.SpecObjectModelSearch_filesearch_task_label
                : MessageFormatter.format( RETPluginMessages.SpecObjectModelSearch_textsearch_task_label,
                                           searchParams.getSearchString() );
            progressMonitor.beginTask( taskName, noOfFilesToScan );
            monitorUpdateJob.setSystem( true );
            monitorUpdateJob.schedule();
            try {
                resultCollector.beginReporting();
                processFiles( files );
                return status;
            } finally {
                monitorUpdateJob.cancel();
            }
        } finally {
            progressMonitor.done();
            resultCollector.endReporting();
        }
    }

    /**
     * gets a search progress monitor job
     * 
     * @return
     */
    private Job getSearchProgressMonitorJob() {
        return new Job( RETPluginMessages.SpecObjectModelSearch_progress_updating_job ) {
            private int lastNoScanedFiles = 0;

            @Override
            public IStatus run( final IProgressMonitor inner ) {
                while (!inner.isCanceled()) {
                    final IFile file = currentFile;
                    if( file != null ) {
                        final String fileName = file.getName();
                        final Object[] args = {
                            fileName,
                            Integer.valueOf( noOfScannedFiles ),
                            Integer.valueOf( noOfFilesToScan )};
                        progressMonitor.subTask( MessageFormatter.format( RETPluginMessages.SpecObjectModelSearch_scanning,
                                                                          args ) );
                        final int steps = noOfScannedFiles - lastNoScanedFiles;
                        progressMonitor.worked( steps );
                        lastNoScanedFiles += steps;
                    }
                    try {
                        Thread.sleep( 100 );
                    } catch( final InterruptedException e ) {
                        return Status.OK_STATUS;
                    }
                }
                return Status.OK_STATUS;
            }
        };
    }

    /**
     * Execute the search files
     * 
     * @param files array of files
     */
    public void processFiles( final IFile[] files ) {
        final Map<?, ?> docsInEditors = FileUtils.evalNonFileBufferDocuments();

        for( int i = 0; i < files.length; i++ ) {
            currentFile = files[i];
            final boolean res = processFile( currentFile, docsInEditors );
            if( !res ) {
                break;
            }
        }
    }

    /**
     * Execute the search in each files
     * 
     * @param file the current file to search
     * @param docsInEditors map containing documents opened in editors
     * @return true if search is completed without any exception
     */
    public boolean processFile( final IFile file, final Map<?, ?> docsInEditors ) {
        try {
            final IDocument document = FileUtils.getDocument( file, docsInEditors );
            final List<SpecobjectType> specObjects = specObjSearchMap.get( file );
            for( final SpecobjectType specobject : specObjects ) {
                locateMatches( file, document, specobject, searchParams );
            }
        } catch( final CoreException e ) {
            ErrorLogger.logError( e.getMessage(), e );
            status.add( new Status( IStatus.ERROR, RETPlugin.PLUGIN_ID, IStatus.ERROR, e.getMessage(), e ) );
        } catch( final IOException e ) {
            final String[] args = {e.getMessage(), file.getFullPath().makeRelative().toString()};
            final String message = MessageFormatter.format( RETPluginMessages.SpecObjectSearch_error, args );
            status.add( new Status( IStatus.ERROR, RETPlugin.PLUGIN_ID, IStatus.ERROR, message, e ) );
        } finally {
            noOfScannedFiles++;
        }
        if( progressMonitor.isCanceled() ) {
            throw new OperationCanceledException( RETPluginMessages.SpecObjectModelSearch_canceled );
        }

        return true;
    }

    /**
     * Locate specobject string matches in the file
     * 
     * @param file file to match
     * @param document document of the corresponding file to match
     * @param specobject search string containing specobject
     * @param searchParams search parameters
     * @throws CoreException
     */
    public void locateMatches( final IFile file,
                               final IDocument document,
                               final SpecobjectType specobject,
                               final SpecObjectSearchParams searchParams ) throws CoreException {

        final List<IRegion> regionList = SpecObjectSearchEngineUtils.getSearchRegionList( file,
                                                                                          specobject,
                                                                                          document,
                                                                                          searchParams );
        //locate matches in each region in the list 
        for( final IRegion searchRegion : regionList ) {
            locateMatches( file, document, searchRegion, searchParams.getSearchString(), specobject );
        }

    }

    /**
     * Gets the xml file search string. If id prefix is present in the xml file, then substrings it from the search
     * string
     * 
     * @param document document of the file currently searching
     * @return
     */
    public String getXMLFileSearchText( final IDocument document ) {

        String searchText = searchParams.getSearchString();
        int index = -1;
        if( searchText != null
            && !searchText.isEmpty()
            && SpecObjectSearchParams.SearchForType.ID.equals( searchParams.getSearchFor() ) ) {

            final String idPrefix = SpecObjectEditorUtil.getIDPrefixFromDoc( document );
            if( !idPrefix.isEmpty() ) {
                index = searchText.indexOf( idPrefix );
            }
            if( index != -1 ) {
                searchText = searchText.substring( index + idPrefix.length() );
            }

        }
        return searchText;
    }

    /**
     * Does the actual file matching and adds to the result collector
     * 
     * @param file file to search
     * @param document document of the file to search
     * @param searchRegion region to search
     * @param fileSearchText the search string
     * @throws CoreException
     */
    public void locateMatches( final IFile file,
                               final IDocument document,
                               final IRegion searchRegion,
                               final String fileSearchText,
                               final SpecobjectType specobject ) throws CoreException {

        int index = 0;
        String searchText = fileSearchText;
        if( "xml".equals( file.getFileExtension() ) ) {
            searchText = getXMLFileSearchText( document );
        }
        final Matcher matcher = getSearchStringMatcher( document, searchText );
        final int regionStart = searchRegion.getOffset();
        final int regionEnd = searchRegion.getOffset() + searchRegion.getLength();
        int start = regionStart;
        while (matcher.find( start )) {
            start = matcher.start();
            final int end = matcher.end();
            if( !(start >= regionStart && end <= regionEnd) ) {
                return; // no further reporting requested
            }
            if( end != start ) { // don't report 0-length matches
                final int length = end - start;
                resultCollector.acceptPatternMatch( file, start, length, document.get(), specobject );
            }
            if( index++ == 20 ) {
                if( progressMonitor.isCanceled() ) {
                    throw new OperationCanceledException( RETPluginMessages.SpecObjectModelSearch_canceled );
                }
                index = 0;
            }
            start = matcher.end();

        }
    }

    /**
     * Gets the search string matcher to perform file search
     * 
     * @param document document of the file to search
     * @param fileSearchText search string
     * @return Matcher object
     */
    public Matcher getSearchStringMatcher( final IDocument document, final String fileSearchText ) {
        Pattern pattern = null;
        //if there is a metacharacter or regex search flag is true, create the pattern considering the regex options
        if( PatternConstructor.isMetaCharacterPresent( fileSearchText ) || searchParams.isRegExSearch() ) {
            pattern = PatternConstructor.createPattern( fileSearchText,
                                                        searchParams.isCaseSensitive(),
                                                        searchParams.isRegExSearch(),
                                                        searchParams.isWholeWordSearch() );
        }
        if( pattern == null ) {
            pattern = PatternConstructor.createPattern( fileSearchText, searchParams.isCaseSensitive() );
        }
        return pattern.matcher( document.get() );
    }

}
