/**
 * 
 */
package eb.ret.ui.search.result.view;

import org.eclipse.search.ui.text.AbstractTextSearchResult;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * This class provides utility methods for search result view page
 * 
 * @author anoopvn
 * 
 */
public final class SearchResultProviderUtils {
    /**
     * Constructor
     */
    private SearchResultProviderUtils() {

    }

    /**
     * Gets line element object array with line element and and it s parent file
     * 
     * @param lineElement line element
     * @return a new array containing line element and line element parent file
     */
    public static Object[] getObject( final SpecObjectFileMatch lineElement ) {
        return new Object[]{lineElement, lineElement.getParent()};
    }

    /**
     * Checks whether the parent and child already have an entry in the map
     * 
     * @param parent parent object
     * @param child child object
     * @param childrenMap map containing parent as key and children list as value
     * @return true if already contains else false
     */
    public static boolean hasChild( final Object parent,
                                    final Object child,
                                    final Map<Object, Set<Object>> childrenMap ) {
        final Set<?> children = childrenMap.get( parent );
        return children != null && children.contains( child );
    }

    /**
     * Returns the element has matches in the search result
     * 
     * @param element the element
     * @param searchResult search result
     * @return true if the element has matches else false
     */
    public static boolean hasMatches( final Object element, final AbstractTextSearchResult searchResult ) {
        if( element instanceof SpecObjectFileMatch ) {
            final SpecObjectFileMatch lineElement = (SpecObjectFileMatch)element;
            return lineElement.getNumberOfMatches( searchResult ) > 0;
        }
        return searchResult.getMatchCount( element ) > 0;
    }

    /**
     * Removes a child element
     * 
     * @param element the element to remove
     * @param parent parent of the child
     * @param childrenMap children map
     */
    public static void removeFromSiblings( final Object element,
                                           final Object parent,
                                           final Map<Object, Set<Object>> childrenMap ) {
        final Set<?> siblings = childrenMap.get( parent );
        if( siblings != null ) {
            siblings.remove( element );
        }
    }

    /**
     * Adds the child to the parent.
     * 
     * @param parent the parent
     * @param child the child
     * @return <code>true</code> if this set did not already contain the specified element
     */
    public static boolean insertChild( final Object parent,
                                       final Object child,
                                       final Map<Object, Set<Object>> childrenMap ) {
        Set<Object> children = childrenMap.get( parent );
        if( children == null ) {
            children = new HashSet<Object>();
            childrenMap.put( parent, children );
        }
        return children.add( child );
    }
}
