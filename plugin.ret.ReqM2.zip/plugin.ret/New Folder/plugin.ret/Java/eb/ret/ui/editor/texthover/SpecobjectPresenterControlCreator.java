package eb.ret.ui.editor.texthover;

import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.text.AbstractReusableInformationControlCreator;
import org.eclipse.jface.text.DefaultInformationControl;
import org.eclipse.jface.text.IInformationControl;
import org.eclipse.jface.text.IInputChangedListener;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Shell;

/**
 * Reusable information control creator for creating linksTo element hover control.
 * 
 * @author tintobaby
 * 
 */
public class SpecobjectPresenterControlCreator extends AbstractReusableInformationControlCreator {

    private final SpecobjectType specObject;

    public SpecobjectPresenterControlCreator( final SpecobjectType specObject ) {
        super();
        this.specObject = specObject;
    }

    @Override
    public IInformationControl doCreateInformationControl( final Shell parent ) {

        //Check whether the browser input is available or not.
        if( SpecobjectToolTipBrowserControl.isBrowserAvailable( parent ) && specObject != null ) {
            //ToolBarManager to introduce the toolbar in hover control.
            final ToolBarManager tbrManager = new ToolBarManager( SWT.FLAT );
            //Creating the instance of information control.
            final SpecobjectToolTipBrowserControl iControl = new SpecobjectToolTipBrowserControl( parent, tbrManager );
            //Action to open the the corresponding file which contains the specobject.
            final OpenDeclarationAction openAction = new OpenDeclarationAction( specObject, iControl );

            tbrManager.add( openAction );
            tbrManager.update( true );

            final IInputChangedListener inChangedListener = new IInputChangedListener() {

                @Override
                public void inputChanged( final Object newInput ) {
                    if( newInput instanceof SpecobjectType ) {
                        openAction.setSpecObject( (SpecobjectType)newInput );
                    }
                }
            };

            iControl.addInputChangeListener( inChangedListener );

            return iControl;
        } else {
            //Return the instance of DefaultInformationControl, if the SWT browser widget is not available with  SpecobjectToolTipBrowserControl.
            return new DefaultInformationControl( parent, true );
        }

    }
}