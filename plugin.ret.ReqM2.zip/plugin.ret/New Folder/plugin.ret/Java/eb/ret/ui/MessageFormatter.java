/**
 * 
 */
package eb.ret.ui;

import java.text.MessageFormat;

/**
 * Helper class to format message strings.
 * 
 * @author anoopvn
 * 
 */

public final class MessageFormatter {

    /**
     * Formatting the message string with argument passed
     * 
     * @param message the string message
     * @param argument message argument
     * @return formatted message
     */
    public static String format( final String message, final Object argument ) {
        return MessageFormat.format( message, new Object[]{argument} );
    }

    /**
     * Formatting the message string with arguments passed
     * 
     * @param message the string message
     * @param args array of message arguments
     * @return formatted message
     */
    public static String format( final String message, final Object[] args ) {
        return MessageFormat.format( message, args );
    }

    /**
     * Constructor
     */
    private MessageFormatter() {
        // Not for instantiation
    }
}
