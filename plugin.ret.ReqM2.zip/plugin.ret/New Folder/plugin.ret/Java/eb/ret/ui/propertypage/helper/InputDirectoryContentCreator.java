package eb.ret.ui.propertypage.helper;

import eb.ret.core.reqm2.data.RETDirectory;
import eb.ret.core.reqm2.data.ReqM2InputData;
import eb.ret.ui.propertypage.ReqM2PropertyPage;

import org.eclipse.core.resources.IProject;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import java.util.Iterator;

/**
 * Creates the RET input directories view
 * 
 * @author nikhilcr
 * 
 */
public class InputDirectoryContentCreator {
    /**
     * The ret table viewer
     */
    private TableViewer viewer = null;

    /**
     * ReqM2PropertyPage object
     */
    private final ReqM2PropertyPage propertypage;

    /**
     * Label for table column Folder
     */
    private static final String LABEL_FOLDER_COL = "Folder";

    /**
     * Size for table column Folder
     */
    private static final int SIZE_FOLDER_COL = 190;

    /**
     * Label for table column Importer
     */
    private static final String LABEL_IMPO_COL = "Importer";

    /**
     * Size for table column Importer
     */
    private static final int SIZE_IMPORTER_COL = 120;

    /**
     * Label for table column DocType
     */
    private static final String LABEL_DOCTYPE_COL = "DocType";

    /**
     * Size for table column DocType
     */
    private static final int SIZE_DOCTYPE_COL = 170;

    /**
     * Layout spacing for property page
     */
    private static final int LAYOUT_SPACING = 5;

    /**
     * Grid horizontal span for property page
     */
    private static final int GRID_HORIZ_SPAN = 2;

    /**
     * Layout number of columns
     */
    private static final int COLMN_COUNT = 2;

    /**
     * Constant for title of property page input directories
     */
    private static final String TITLE_INPUT_DIR = "Input Directories";

    /**
     * Constant for remove button label
     */
    public static final String LABEL_REMOVE = "Remove";

    /**
     * Constant for add directory button label
     */
    public static final String LABEL_ADD_DIR = "Add Directory";

    /**
     * Button for adding workspace input directories
     */
    private Button addDirectoryBut;

    /**
     * Button for removing input directories
     */
    private Button removeButton;

    /**
     * Constructor
     * 
     * @param propertyPage
     */
    public InputDirectoryContentCreator( final ReqM2PropertyPage propertyPage ) {
        this.propertypage = propertyPage;
    }

    /**
     * Creates the RET input directory property page contents
     * 
     * @param parent
     * @return Composite the property-page
     */
    public Composite createContents( final Composite parent ) {
        final Composite pageComposite = new Composite( parent, SWT.WRAP );
        final IProject currentProject = propertypage.getCurrentProject();
        if( currentProject != null && currentProject.isOpen() ) {

            final GridLayout layout = new GridLayout();
            layout.numColumns = COLMN_COUNT;
            pageComposite.setLayout( layout );

            final GridData data = new GridData();
            data.verticalAlignment = GridData.FILL;
            data.horizontalAlignment = GridData.FILL;
            // for resizing according to parent control
            data.grabExcessVerticalSpace = true;
            data.grabExcessHorizontalSpace = true;

            pageComposite.setLayoutData( data );

            addPropertyPageUIControls( pageComposite );

            propertypage.checkState();
            pageComposite.pack();
        }

        return pageComposite;
    }

    /*
     * !LINKSTO eclipse.ret.req.InputDirectorySelection,1
     */
    /**
     * This method used to add all the UI controls in property page
     * 
     * @param parent parent composite of property page
     * 
     */
    private void addPropertyPageUIControls( final Composite parent ) {
        final IProject currentProject = propertypage.getCurrentProject();
        // Create the list to display the directory tree
        if( currentProject != null && currentProject.isOpen() ) {

            propertypage.setDocTypeCache( ReqM2InputData.getRETData().getDocTypes( currentProject ) );
            // Title for input directories
            final Label inputDirLabel = new Label( parent, SWT.NONE );
            inputDirLabel.setText( TITLE_INPUT_DIR );
            final GridData gridData = new GridData();
            gridData.verticalAlignment = GridData.FILL;
            gridData.horizontalSpan = GRID_HORIZ_SPAN;
            inputDirLabel.setLayoutData( gridData );

            // Creating the table
            viewer = new TableViewer( parent, SWT.MULTI
                | SWT.H_SCROLL
                | SWT.V_SCROLL
                | SWT.FULL_SELECTION
                | SWT.BORDER );

            createColumns();

            final Table table = viewer.getTable();
            table.setHeaderVisible( true );
            table.setLinesVisible( true );
            viewer.setContentProvider( new ArrayContentProvider() );
            viewer.setInput( propertypage.getInputDirs() );

            final GridData gData = new GridData();
            gData.verticalAlignment = GridData.FILL;
            gData.grabExcessHorizontalSpace = true;
            gData.grabExcessVerticalSpace = true;
            gData.horizontalAlignment = GridData.FILL;
            viewer.getControl().setLayoutData( gData );

            table.addControlListener( createControlAdapter() );

            final FillLayout fillLayout = new FillLayout();
            fillLayout.type = SWT.VERTICAL;
            fillLayout.spacing = LAYOUT_SPACING;

            // composite for buttons
            final Composite buttonArea = new Composite( parent, SWT.FILL );
            buttonArea.setLayout( fillLayout );

            addDirectoryBut = new Button( buttonArea, SWT.PUSH );
            addDirectoryBut.setText( LABEL_ADD_DIR );

            removeButton = new Button( buttonArea, SWT.PUSH );
            removeButton.setText( LABEL_REMOVE );
            removeButton.setEnabled( false );

            viewer.addSelectionChangedListener( getSelectionChangedListener() );

            final AddDirectoryButtonListner addButListner = new AddDirectoryButtonListner( propertypage );
            final RemoveDirectoryButtonListner removeButListner = new RemoveDirectoryButtonListner( propertypage );
            addDirectoryBut.addSelectionListener( addButListner );
            removeButton.addSelectionListener( removeButListner );
            // for selecting the first row of the table, if any rows are present
            if( table.getItemCount() >= 1 ) {
                table.setSelection( 0 );
            }
        }
    }

    /**
     * Control adapter to make the table cover the complete viewer area
     * 
     * @return
     */
    private ControlAdapter createControlAdapter() {
        return new ControlAdapter() {
            @Override
            public void controlResized( final ControlEvent event ) {
                final Table table = viewer.getTable();
                final Rectangle area = viewer.getControl().getBounds();
                final Point preferredSize = table.computeSize( SWT.DEFAULT, SWT.DEFAULT );
                int width = area.width - 2 * table.getBorderWidth();
                if( preferredSize.y > area.height + table.getHeaderHeight() ) {
                    // Subtract the scrollbar width from the total column width
                    // if a vertical scrollbar will be required
                    final Point vBarSize = table.getVerticalBar().getSize();
                    width -= vBarSize.x;
                }

                for( final TableColumn column : table.getColumns() ) {
                    column.setWidth( width / 3 );
                }

            }
        };
    }

    /**
     * creates the selection changed listener for the viewer
     * 
     * @return
     */
    private ISelectionChangedListener getSelectionChangedListener() {
        return new ISelectionChangedListener() {
            @Override
            public void selectionChanged( final SelectionChangedEvent event ) {
                final IStructuredSelection selection = (IStructuredSelection)event.getSelection();
                final Iterator<?> selectionIterator = selection.iterator();
                while (selectionIterator.hasNext()) {
                    final Object selectedObject = selectionIterator.next();
                    if( selectedObject.getClass().isAssignableFrom( RETDirectory.class ) ) {
                        removeButton.setEnabled( true );
                        propertypage.checkState( ((RETDirectory)selectedObject).getPath() );
                    } else {
                        removeButton.setEnabled( false );
                    }

                }
            }
        };
    }

    /**
     * Creates all the table columns
     */
    public void createColumns() {
        // Folder column
        TableViewerColumn col = createTableViewerColumn( LABEL_FOLDER_COL, SIZE_FOLDER_COL );
        col.setLabelProvider( new ColumnLabelProvider() {
            @Override
            public String getText( final Object element ) {
                return ((RETDirectory)element).getPath();
            }
        } );
        // Importer column
        col = createTableViewerColumn( LABEL_IMPO_COL, SIZE_IMPORTER_COL );
        col.setLabelProvider( new ColumnLabelProvider() {
            @Override
            public String getText( final Object element ) {
                final RETDirectory directory = (RETDirectory)element;

                return directory.getImporter().name();
            }
        } );
        col.setEditingSupport( new ImporterEditingSupport( propertypage ) );
        // DocType column
        col = createTableViewerColumn( LABEL_DOCTYPE_COL, SIZE_DOCTYPE_COL );
        col.setLabelProvider( new ColumnLabelProvider() {
            @Override
            public String getText( final Object element ) {
                return ((RETDirectory)element).getDocType();
            }
        } );
        col.setEditingSupport( new DocTypeEditingSupport( propertypage ) );
    }

    /**
     * Creates a table column and sets it properties
     * 
     * @param title
     * @param bound
     * @return TableViewerColumn
     */
    private TableViewerColumn createTableViewerColumn( final String title, final int bound ) {
        final TableViewerColumn viewerColumn = new TableViewerColumn( viewer, SWT.NONE );
        final TableColumn column = viewerColumn.getColumn();
        column.setText( title );
        column.setWidth( bound );
        column.setResizable( true );
        column.setMoveable( true );

        return viewerColumn;
    }

    /**
     * Returns the removeButton
     * 
     * @return
     */
    public Button getRemoveButton() {
        return removeButton;
    }

    /**
     * Returns the viewer instance
     * 
     * @return TableViewer
     */
    public TableViewer getViewer() {
        return viewer;
    }
}
