package eb.ret.ui.search.result.view;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.viewers.DecoratingStyledCellLabelProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.search.ui.text.AbstractTextSearchViewPage;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.IShowInSource;
import org.eclipse.ui.part.IShowInTargetList;
import org.eclipse.ui.part.ShowInContext;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Parent page of specobject result view page
 * 
 * @author anoopvn
 * 
 */
public class SpecObjectSearchResultParentPage extends AbstractTextSearchViewPage implements IAdaptable {

    /**
     * The content provider of search result page
     */
    protected IFileSearchContentProvider contentProvider;

    /**
     * Show in targets to show in the context menu of search result view line element
     */
    private static final String[] SHOW_IN_TARGETS = new String[]{IPageLayout.ID_PROJECT_EXPLORER};
    /**
     * Show in target list to show in the context menu of search result view line element
     */
    private static final IShowInTargetList SHOW_TARGET_LIST = new IShowInTargetList() {
        @Override
        public String[] getShowInTargetIds() {
            return SHOW_IN_TARGETS;
        }
    };

    @Override
    protected void elementsChanged( final Object[] objects ) {
        if( contentProvider != null ) {
            contentProvider.elementsChanged( objects );
        }
    }

    @Override
    protected void clear() {
        if( contentProvider != null ) {
            contentProvider.clear();
        }
    }

    @Override
    protected void configureTreeViewer( final TreeViewer viewer ) {
        viewer.setUseHashlookup( true );
        final FileLabelProvider innerLabProvder = new FileLabelProvider( this );
        viewer.setLabelProvider( new DecoratingStyledCellLabelProvider(
            innerLabProvder,
            PlatformUI.getWorkbench().getDecoratorManager().getLabelDecorator(),
            null ) );
        viewer.setContentProvider( new FileTreeContentProvider( this, viewer ) );
        viewer.setComparator( new SpecObjectSearchResultViewerSorter( innerLabProvder ) );
        contentProvider = (IFileSearchContentProvider)viewer.getContentProvider();
    }

    @Override
    protected void configureTableViewer( final TableViewer viewer ) {
        viewer.setUseHashlookup( true );
        final FileLabelProvider innerLabProvder = new FileLabelProvider( this );
        viewer.setLabelProvider( new DecoratingStyledCellLabelProvider(
            innerLabProvder,
            PlatformUI.getWorkbench().getDecoratorManager().getLabelDecorator(),
            null ) );
        viewer.setContentProvider( new FileTableContentProvider( this ) );
        viewer.setComparator( new SpecObjectSearchResultViewerSorter( innerLabProvder ) );
        contentProvider = (IFileSearchContentProvider)viewer.getContentProvider();
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Object getAdapter( final Class adapter ) {
        //to support the show in menu in the context menu  
        if( IShowInTargetList.class.equals( adapter ) ) {
            return SHOW_TARGET_LIST;
        }

        if( adapter == IShowInSource.class ) {
            final ISelectionProvider selectionProvider = getSite().getSelectionProvider();
            if( selectionProvider == null ) {
                return null;
            }

            final ISelection selection = selectionProvider.getSelection();
            if( selection instanceof IStructuredSelection ) {
                return getStructuredSelection( selection );
            }
            return null;
        }

        return null;
    }

    /**
     * Line element also to support the show in menu in the context menu
     * 
     * @param selection the selection
     * @return the structured selection show in source
     */
    public Object getStructuredSelection( final ISelection selection ) {
        final IStructuredSelection structSelection = ((StructuredSelection)selection);
        final Set<Object> newSelection = new HashSet<Object>( structSelection.size() );
        final Iterator<?> iter = structSelection.iterator();
        while (iter.hasNext()) {
            Object element = iter.next();
            if( element instanceof SpecObjectFileMatch ) {
                // to support the show in menu in the context menu  
                element = ((SpecObjectFileMatch)element).getParent();
            }
            newSelection.add( element );
        }

        return new IShowInSource() {
            @Override
            public ShowInContext getShowInContext() {
                return new ShowInContext( null, new StructuredSelection( new ArrayList<Object>( newSelection ) ) );
            }
        };
    }

}
