package eb.ret.ui.text.specobject;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.FindReplaceDocumentAdapter;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Region;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Generic implementation for region identification in java files (non xml)
 * 
 * @author kirensk
 * 
 */
public class GenericSpecObjectRegion extends AbstractSpecObjectRegion {

    /**
     * Regular expression to match generic specobject element start. It represents a combination of space + java comment
     * elements + !LINKSTO or !SPECOBJECT
     */
    private static final String START_REGEX = "^\\s*(/)*(\\*)?\\s*![(LINKSTO)|(SPECOBJECT)]";

    /**
     * Regular expression to match next element in a specobject region with in a generic file. Next element shall start
     * with out a space after the ! element
     */
    private static final String NEXT_ELEM_REGEX = ".*![^\\s].*";

    /**
     * Regular expression for links element start
     */
    private static final String COMM_REGEX = "[!]comment\\s*";
    /**
     * Regular expression for linksto element start
     */
    private static final String LINKSTO_REGEX = "([!]LINKSTO)|[!]linksto";
    /**
     * Regular expression for id element start
     */
    private static final String ID_REGEX = "!id\\s*";
    /**
     * Regular expression for description element start
     */
    private static final String DESC_REGEX = "[!]description\\s*";

    /**
     * Constructor with inputs as specobject and its document for the sourcefile
     * 
     * @param specObject
     * @param document
     */
    public GenericSpecObjectRegion( final SpecobjectType specObject, final IDocument document ) {
        super( specObject, document );
    }

    /**
     * Constructor with specobject as the input
     * 
     * @param specObject
     * @throws IOException
     */
    public GenericSpecObjectRegion( final SpecobjectType specObject ) throws IOException {
        super( specObject );
    }

    @Override
    public IRegion getSpecObjectRegion() {
        try {
            final int lineNumber = Integer.parseInt( specObject.getSourceline() );
            final int endOffset = document.getLineOffset( lineNumber - 2 ) + document.getLineLength( lineNumber - 2 );
            final int startOffset = getSpecObjectStartOffset( endOffset );
            final int length = endOffset - startOffset;
            specObjectRegion = new Region( startOffset, length );
            document.get( startOffset, length );
        } catch( final BadLocationException be ) {
            ErrorLogger.logError( MSG_BAD_LOC + specObject.getId(), be );
        } catch( final NumberFormatException ne ) {
            ErrorLogger.logError( MSG_INVLD_LINE + specObject.getSourceline(), ne );
        } catch( final Exception e ) {
            ErrorLogger.logError( MSG_EXCPTN, e );
        }
        return specObjectRegion;
    }

    @Override
    public IRegion getRegion( final String region ) {
        return getRegionUsingStartPattern( "[!]" + region + "\\s*" );
    }

    @Override
    public IRegion getDescriptionRegion() {

        return getRegionUsingStartPattern( DESC_REGEX );
    }

    @Override
    public IRegion getIdRegion() {
        return getRegionUsingStartPattern( ID_REGEX );
    }

    @Override
    public IRegion getLinksToRegion() {
        return getRegionUsingStartPattern( LINKSTO_REGEX );
    }

    @Override
    public IRegion getCommentsRegion() {
        return getRegionUsingStartPattern( COMM_REGEX );
    }

    @Override
    public IRegion getLinksRegion() {
        // links is not supported in the generic importers
        return null;
    }

    /**
     * 
     * searches backwards for a specobject start element either !LINKSTO or !SPECOBJECT and returns the corresponding
     * start offset
     * 
     * 
     * @param endOffset
     * @return startOffset for the Linksto region start
     * @throws BadLocationException
     */
    private int getSpecObjectStartOffset( final int endOffset ) throws BadLocationException {
        final String regEx = START_REGEX;
        final FindReplaceDocumentAdapter findAdapter = new FindReplaceDocumentAdapter( document );
        final IRegion region = findAdapter.find( endOffset, regEx, false, true, false, true );
        return region.getOffset();
    }

    /**
     * returns the region for the given start pattern. The end region is searched for "![character]" pattern. The region
     * is found between the startPattern and the next element start
     * 
     * @param searchStartRegex
     * @return
     */

    private IRegion getRegionUsingStartPattern( final String searchStartRegex ) {
        IRegion matchRegion = null;
        int endOffset = -1;
        int startOffset = -1;
        int length = 0;

        try {
            final String searchString = searchStartRegex;

            specObjectRegion = getSpecObjectRegion();

            final int specObjEndOffset = specObjectRegion.getOffset() + specObjectRegion.getLength();

            startOffset = getStartOffset( searchString, specObjEndOffset );

            if( startOffset >= 0 && startOffset <= specObjEndOffset ) {
                endOffset = getEndOffset( startOffset, specObjEndOffset );
            }

            if( endOffset > startOffset ) {
                length = endOffset - startOffset;
                matchRegion = new Region( startOffset, length );
            }
        } catch( final Exception e ) {
            ErrorLogger.logError( "Error while searching specobject with start pattern " + searchStartRegex, e );
        }

        return matchRegion;

    }

    /**
     * 
     * helper method to find the start offset for the searchString with in the specobject region
     * 
     * @param searchString
     * @param specObjEndOffset
     * @return startOffset
     * @throws BadLocationException
     */

    private int getStartOffset( final String searchString, final int specObjEndOffset ) throws BadLocationException {
        int startOffset = -1;
        final int regexOptions = getRegExOptions( false );

        final Matcher matcher = Pattern.compile( searchString, regexOptions ).matcher( document.get() );
        if( matcher.find( getSpecObjectRegion().getOffset() ) ) {
            startOffset = matcher.start();
            if( startOffset > specObjEndOffset ) {
                startOffset = -1;
            }

        }
        return startOffset;
    }

    /**
     * 
     * helper method to find the end offset for the searchString with in the specobject region
     * 
     * @param searchString
     * @param specObjEndOffset
     * @return endOffset
     * @throws BadLocationException
     */
    private int getEndOffset( final int startOffset, final int specObjEndOffset ) throws BadLocationException {
        int endOffset;
        int matchLine;
        int startLineOffset;
        final Matcher endMatcher = Pattern.compile( NEXT_ELEM_REGEX ).matcher( document.get() );
        matchLine = document.getLineOfOffset( startOffset );
        startLineOffset = document.getLineOffset( matchLine + 1 );
        if( endMatcher.find( startLineOffset ) ) {
            endOffset = endMatcher.start();
            final int endLine = document.getLineOfOffset( endOffset );
            endOffset = document.getLineOffset( endLine - 1 ) + document.getLineLength( endLine - 1 );
            if( endOffset > specObjEndOffset || endOffset < startOffset ) {
                endOffset = specObjEndOffset;
            }
        } else {
            endOffset = specObjEndOffset;
        }
        return endOffset;
    }

}
