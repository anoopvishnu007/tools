package eb.ret.ui.views.specobjects.contents;

import eb.ret.model.specobject.SpecobjectType;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

/**
 * For filtering of specobjects in the specobjects view table
 * 
 * @author nikhilcr
 * 
 */
public class SpecObjectFilter extends ViewerFilter {
    /**
     * Regular expression string to represent any character pattern
     */
    private static final String ANY_CHAR_REGX = ".*";
    /**
     * The string to be searched for
     */
    private String searchString;

    /**
     * Creates the regex pattern for searching
     * 
     * @param searchContent
     */
    public void setSearchText( final String searchContent ) {
        // Search must be a substring of the existing value
        this.searchString = ANY_CHAR_REGX + searchContent + ANY_CHAR_REGX;
    }

    @Override
    public boolean select( final Viewer viewer, final Object parentElement, final Object element ) {
        if( searchString == null || searchString.length() == 0 ) {
            return true;
        }
        final SpecobjectType specobjectType = (SpecobjectType)element;
        if( specobjectType.getId().toLowerCase().matches( searchString.toLowerCase() ) ) {
            return true;
        }
        return false;
    }

}
