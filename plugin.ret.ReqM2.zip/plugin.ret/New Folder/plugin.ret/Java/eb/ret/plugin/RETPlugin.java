package eb.ret.plugin;

import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.ui.helper.RETNatureCommand;

import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.Parameterization;
import org.eclipse.core.commands.ParameterizedCommand;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.ui.IStartup;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandService;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * Activator class of RET Plugin.
 * 
 * @author tintobaby
 * 
 */

public class RETPlugin extends AbstractUIPlugin implements IStartup {

    /**
     * PluginId representing RETPlugin
     */
    public static final String PLUGIN_ID = "eb.ret.plugin"; //$NON-NLS-1$

    /**
     * Error message to be displayed when Exception in early start up
     */
    private static final String MSG_ERR_STARTUP = "Exception in starting up RET Context menu command";

    /**
     * private instance for the RETPlugin
     */
    private static RETPlugin plugin;

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext
     * )
     */
    @Override
    public void start( final BundleContext context ) throws Exception {//NOPMD need to throw generic exception since subclass of a eclipse framework file
        super.start( context );
        plugin = this;
        // Load all the SpecObject resources with the available reqm Files in the input directories
        //WorkspaceUtils.loadAllSpecObjectResources();
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext
     * )
     */
    @Override
    public void stop( final BundleContext context ) throws Exception {//NOPMD need to throw generic exception since subclass of a eclipse framework file
        plugin = null;
        super.stop( context );
    }

    /**
     * Returns the shared instance
     * 
     * @return the shared instance
     */
    public static RETPlugin getDefault() {
        return plugin;
    }

    /**
     * This is invoked for enabling the checking in Add/Remove RET Nature context menu option early. This will
     * initialize the command and store in the updateElement List
     */
    @Override
    public void earlyStartup() {
        final ICommandService commandService = (ICommandService)PlatformUI.getWorkbench()
                                                                          .getService( ICommandService.class );
        final IHandlerService handlerService = (IHandlerService)PlatformUI.getWorkbench()
                                                                          .getService( IHandlerService.class );

        final Command command = commandService.getCommand( RETNatureCommand.COMMAND_ID );
        final ParameterizedCommand parmCommand = new ParameterizedCommand( command, new Parameterization[]{} );
        try {
            handlerService.executeCommand( parmCommand, null );
        } catch( final Exception e ) {
            ErrorLogger.logError( MSG_ERR_STARTUP, e );
        }

    }

    /**
     * Gets the dialog settings section of RET plug-in
     * 
     * @param name section
     * @return the dialog settings
     */
    public IDialogSettings getDialogSettingsSection( final String name ) {
        final IDialogSettings dialogSettings = getDialogSettings();
        IDialogSettings section = dialogSettings.getSection( name );
        if( section == null ) {
            section = dialogSettings.addNewSection( name );
        }
        return section;
    }
}