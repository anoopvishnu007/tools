/**
 * 
 */
package eb.ret.util;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * This class creates regular expression patterns using the parameters
 * 
 * @author anoopvn
 * 
 */
public final class PatternConstructor {
    /**
     * Boundary condition for regular expression
     */
    private static final String BOUNDARY_CHAR = "\\b";
    /**
     * /** Prefix for matching whole characters
     */
    private static final String EXP_PREFIX = ".*";

    /**
     * Constructor
     */
    private PatternConstructor() {
        // don't instantiate
    }

    /**
     * Creates a pattern element from the pattern string which is either a reg-ex expression or normal string
     * 
     * @param patternText The search pattern
     * @param isCaseSensitive Set to <code>true</code> to create a case insensitive pattern
     * @param isRegex <code>true</code> if the passed string already is a reg-ex pattern
     * @param isWholeWordsearch <code>true</code> if the passed string already is a reg-ex pattern
     * @return The created pattern
     * @throws PatternSyntaxException
     */
    public static Pattern createPattern( final String patternText,
                                         final boolean isCaseSensitive,
                                         final boolean isRegex,
                                         final boolean isWholeWordsearch ) throws PatternSyntaxException {
        String pattern = patternText;
        if( isRegex ) {
            pattern = createRegExPattern( pattern, isWholeWordsearch );
        } else {
            final int len = pattern.length();
            final StringBuffer buffer = new StringBuffer( len + 10 );
            if( isWholeWordsearch && len > 0 && Character.isLetterOrDigit( pattern.charAt( 0 ) ) ) {
                buffer.append( BOUNDARY_CHAR );
            }
            PatternHelper.appendAsRegEx( pattern, buffer );
            if( isWholeWordsearch && len > 0 && Character.isLetterOrDigit( pattern.charAt( len - 1 ) ) ) {
                buffer.append( BOUNDARY_CHAR );
            }
            pattern = buffer.toString();
            if( !isWholeWordsearch ) {
                pattern = addPrefix( pattern, patternText );
            }
        }
        return createPattern( pattern, isCaseSensitive );
    }

    /**
     * Creates a pattern using the pattern string
     * 
     * @param patternText pattern string
     * @param isCaseSensitive the pattern is case sensitive or not
     * 
     * @return pattern
     */
    public static Pattern createPattern( final String patternText, final boolean isCaseSensitive ) {
        int regexOptions = Pattern.MULTILINE;
        if( !isCaseSensitive ) {
            regexOptions |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
        }
        return Pattern.compile( patternText, regexOptions );
    }

    /**
     * Checks the meta characters "*" and "?" present in the string
     * 
     * @param patternText
     * @return true if meta characters present else false
     */
    public static boolean isMetaCharacterPresent( final String patternText ) {
        boolean isMetCharFound = false;
        if( patternText != null && patternText.contains( "*" ) || patternText.contains( "?" ) ) {
            isMetCharFound = true;
        }
        return isMetCharFound;
    }

    /**
     * Adds prefix to the pattern
     * 
     * @param pattern pattern text after escaping
     * @param enteredPattern actual pattern entered
     * @return
     */
    private static String addPrefix( final String pattern, final String enteredPattern ) {

        if( !isMetaCharacterPresent( enteredPattern ) ) {
            final StringBuilder builder = new StringBuilder();
            if( !pattern.startsWith( EXP_PREFIX ) ) {
                builder.append( EXP_PREFIX );
            }
            builder.append( pattern );
            if( !pattern.endsWith( EXP_PREFIX ) ) {
                builder.append( EXP_PREFIX );
            }
            return builder.toString();
        }
        return pattern;
    }

    /**
     * Creates a regex pattern with the string is taken as a regular expression string
     * 
     * @param patternText the pattern text
     * @param isWholeWordSearch parameter to decide search is an exact word search
     * @return
     */
    private static String createRegExPattern( final String patternText, final boolean isWholeWordSearch ) {
        String pattern = patternText;
        pattern = PatternHelper.substituteLinebreak( pattern );
        if( isWholeWordSearch ) {
            final StringBuffer buffer = new StringBuffer();
            buffer.append( "\\b(?:" );
            buffer.append( pattern );
            buffer.append( ")\\b" );
            pattern = buffer.toString();
        }
        return pattern;
    }

}
