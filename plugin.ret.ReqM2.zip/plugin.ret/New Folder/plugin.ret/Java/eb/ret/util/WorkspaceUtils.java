package eb.ret.util;

import eb.ret.core.model.SpecObjectResourceManager;
import eb.ret.core.reqm2.ReqM2Manager;
import eb.ret.core.reqm2.processor.ErrorLogger;
import eb.ret.model.specobject.SpecobjectType;
import eb.ret.ui.text.specobject.AbstractSpecObjectRegion;
import eb.ret.ui.text.specobject.GenericSpecObjectRegion;
import eb.ret.ui.text.specobject.XMLSpecObjectRegion;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jface.text.IDocument;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;

import java.util.ArrayList;
import java.util.List;

/**
 * To support workspace related functionalities.
 * 
 * @author tintobaby
 * 
 */
public final class WorkspaceUtils {

    private static final String ERR_RESOURCE_LOAD = "Error while loading all the SpecObjects in the workspace";

    private WorkspaceUtils() {

    }

    /*
     * !LINKSTO eclipse.ret.req.ReqM2PreferencePage,1
     */
    /**
     * Returns the List of open projects in the workspace
     * 
     * @return List of IProject
     */
    public static List<IProject> getOpenProjects() {
        final List<IProject> openProjects = new ArrayList<IProject>();
        final IWorkspace workspace = ResourcesPlugin.getWorkspace();
        IWorkspaceRoot root = null;
        if( workspace != null ) {
            root = workspace.getRoot();
        }
        IProject[] allProjects = null;
        if( root != null ) {
            allProjects = root.getProjects();
        }
        for( final IProject project : allProjects ) {
            if( project.isOpen() ) {
                openProjects.add( project );
            }
        }
        return openProjects;
    }

    /**
     * gets the actual location of the given path
     * 
     * @param path
     * @return actual location
     */

    public static String getLocation( final IPath path ) {

        final IResource res = ResourcesPlugin.getWorkspace().getRoot().findMember( path );
        String actualPath = null;
        if( res == null || (res != null && res.equals( ResourcesPlugin.getWorkspace().getRoot() )) ) {
            actualPath = path.toOSString();
        } else {
            final IProject project = res.getProject();
            if( res instanceof IProject || res instanceof IJavaProject ) {
                actualPath = project.getLocation().toOSString();
            } else {
                actualPath = res.getLocation().toOSString();
            }
        }
        return actualPath;
    }

    /**
     * gets the IPath object
     * 
     * @param actualPath
     * @return IPath
     */
    public static IPath getIPath( final String actualPath ) {
        return new Path( actualPath );
    }

    /**
     * Load resources for all available .reqm files.
     */
    public static void loadAllSpecObjectResources() {

        final List<IProject> projects = getOpenProjects();
        for( final IProject project : projects ) {
            try {
                final IFolder reqm2Folder = ReqM2Manager.getInstance().getReqM2ImpOutputFolder( project );
                loadFolderSpectObjectResources( reqm2Folder );
            } catch( final Exception e ) {
                ErrorLogger.logError( ERR_RESOURCE_LOAD, e );
            }

        }

    }

    /**
     * Recursively search for reqm files in the folder and its children and load it
     * 
     * @param folder
     * @throws CoreException
     */

    private static void loadFolderSpectObjectResources( final IFolder folder ) throws CoreException {
        final IResource[] childResources = folder.members();
        for( final IResource resource : childResources ) {
            if( resource.getType() == IResource.FOLDER ) {
                loadFolderSpectObjectResources( (IFolder)resource );
            } else if( resource.getType() == IResource.FILE ) {
                SpecObjectResourceManager.getInstance().loadSpecObjectResource( (IFile)resource );
            }
        }
    }

    /**
     * determines the specobject region depends on the file type
     * 
     * @param specObject
     * @param file
     * @param document
     * @return
     */
    public static AbstractSpecObjectRegion getSpecObjectRegion( final SpecobjectType specObject,
                                                                final IFile file,
                                                                final IDocument document ) {
    
        if( file.getFileExtension().equals( "xml" ) || file.getFileExtension().equals( "reqm" ) ) {
            return new XMLSpecObjectRegion( specObject, document );
        }
        return new GenericSpecObjectRegion( specObject, document );
    }

    /**
     * Checks if a viewpart created by the provided Class is active. If its active, returns the active viewpart, else
     * return null
     * 
     * @param clazz provided class
     * @return
     */
    public static <T> IWorkbenchPart getViewPart( final Class<T> clazz ) {
        IWorkbenchPart viewPart = null;
        final IWorkbenchWindow[] windows = PlatformUI.getWorkbench().getWorkbenchWindows();
        for( int i = 0; i < windows.length; i++ ) {
            final IWorkbenchPage[] pages = windows[i].getPages();
            if( pages != null && pages.length > 0 ) {
                for( int j = 0; j < pages.length; j++ ) {
                    final IViewReference[] viewRefs = pages[j].getViewReferences();
                    for( int k = 0; k < viewRefs.length; k++ ) {
                        final IViewReference viewRef = viewRefs[k];
                        viewPart = viewRef.getPart( false );
                        if( viewPart != null && clazz.equals( viewPart.getClass() ) ) {
                            return viewPart;
                        } else {
                            viewPart = null;
                        }
                    }
                }
            }
        }

        return viewPart;
    }

}
