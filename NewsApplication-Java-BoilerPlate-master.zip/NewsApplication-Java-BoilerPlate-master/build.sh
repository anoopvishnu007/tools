# bin/bash

cd AuthenticateService
source ./env-variable.sh
mvn clean package
cd ..
cd Server
source ./env-variable.sh
mvn clean package
