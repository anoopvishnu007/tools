import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContainerComponent } from './components/container/container.component';
import { NewsAPIContainerComponent } from './components/newsapi-container/newsapi-container.component';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import { SearchComponent } from './components/search/search.component';
import { AuthguardService } from '../../authGuard.service';
import { RoleguardService } from '../../roleGuard.service';
import { NewsDataResolver } from './news.dataresolver';
//This is the router module which is used for routing the application based on the incoming
//requests. While simply hitting the localhost:4200 the application will redirect to all the 
//popular news from tmdb. If the url is appended with /top-rated, it will sho all the top-rated
//newss and the url is appended with /watchlist it will display all the newss that are added 
//into the MyWatchList segment. If the url is appened with /search, the application redirects to
//the search segment in the application. There one user can easily search various newss based on 
//there interest.
const newsRoutes: Routes=[
{
    path: 'news',
    children: [
        {
            path: '',
            redirectTo: '/news/top-headlines',
            pathMatch: 'full',
	    canActivate: [AuthguardService]
        },
        {
            path: 'top-headlines',
            component: NewsAPIContainerComponent,
        canActivate: [AuthguardService],
        runGuardsAndResolvers: 'always',
            data: {
                 newsType : ''       
            },
            resolve: {
                newses: NewsDataResolver
              }
        },
            //children: [
                 {
                    path: 'top-headlines:sports',
                    component: NewsAPIContainerComponent,
                canActivate: [AuthguardService],
                    data: {
                        newsType : 'sports',
                    },
                    resolve: {
                        newses: NewsDataResolver
                      }
                    
                },
                {
                    path: 'top-headlines:business',
                    component: NewsAPIContainerComponent,
                canActivate: [AuthguardService],
                    data: {
                        newsType : 'business',
                    },
                    resolve: {
                        newses: NewsDataResolver
                      },
                      
                },
                {
                    path: 'top-headlines:politics',
                    component: NewsAPIContainerComponent,
                canActivate: [AuthguardService],
                    data: {
                        newsType : 'politics',
                    },
                    resolve: {
                        newses: NewsDataResolver
                      }
                }
                
           // ],
            
        ,
         
        {
            path: 'watchlist',
            component: WatchlistComponent,
	        canActivate: [AuthguardService]
        },
        
        {
            path: 'search',
            component: SearchComponent,
	    canActivate: [AuthguardService]
        }
    ]
  }
];

@NgModule({
    imports: [
        RouterModule.forRoot(newsRoutes,{onSameUrlNavigation: 'reload'}),
    ],
    exports: [
        RouterModule,
    ],
    providers: [
        NewsDataResolver
      ]
})

export class NewsRouterModule{}
