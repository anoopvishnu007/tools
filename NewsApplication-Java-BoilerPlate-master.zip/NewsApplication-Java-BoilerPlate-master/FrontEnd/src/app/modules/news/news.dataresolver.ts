import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { News } from './news';
import { NewsService } from './news.service';

@Injectable()
export class NewsDataResolver implements Resolve<Observable<Array<News>>> {
    newses: Observable<Array<News>>;
    newsType: string;
  constructor(private newsService: NewsService) {
  }

  public resolve(
    route: ActivatedRouteSnapshot, 
    state: RouterStateSnapshot
  ): Observable<Array<News>> {
    this.newsType=route.data.newsType;
    console.log("newsType:"+ this.newsType) ; 
    this.newses = this.newsService.getNews(this.newsType);
    console.log(this.newses)
    return this.newses;
  }
}