import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Input } from '@angular/core';
import { News } from '../../news';
import { NewsService } from '../../news.service';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'news-container',
  templateUrl: './container.component.html',
  styleUrls: [
    './container.component.css'
  ]
})
export class ContainerComponent implements OnInit {
  
  @Input()
  newses: Array<News>; 
  
  @Input()
  useWatchlistApi:boolean;

  constructor(private httpClient : HttpClient,private newsService: NewsService,private matSnackBar
    : MatSnackBar) {     
  }

  ngOnInit() {
  }
  //logic for adding new newss into the watchlist
  addNewsToWatchList(news){
     console.log(news);
    this.newsService.saveWatchListNews(news).subscribe((response) =>{
        this.matSnackBar.open(response,'',{
            duration:1000
        });
    });
   }
   //logic for deleting news from the componenet
   deleteNewsFromWatchList(news){
          
     //logic for deleting the news from the back-end
     this.newsService.deleteFromMyWatchList(news).subscribe((response)=>{
      let newsIndex=this.newses.indexOf(news)
      this.newses.splice(newsIndex,1);       
        this.matSnackBar.open(response,'',{
            duration:1000
        });
     });
   }

   //logic for updating news inside the watchlist
   updateNewsInsidetheWatchList(news){
     
   }
}
