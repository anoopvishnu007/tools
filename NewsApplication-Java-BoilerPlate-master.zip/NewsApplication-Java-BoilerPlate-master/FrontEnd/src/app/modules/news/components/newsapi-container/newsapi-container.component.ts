import { Component, OnInit } from '@angular/core';
import { News } from '../../news';
import { NewsService } from '../../news.service';
import { ActivatedRoute,Router,NavigationEnd,NavigationStart} from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
@Component({
  selector: 'news-newsdb-container',
  template: `
    <news-container [newses]="newses"></news-container>
  `,
  styles: []
})
//Component class for holding tmdb news list
export class NewsAPIContainerComponent implements OnInit {
  newses: Array<News>;
  newsType: string;

  constructor(private newsService: NewsService, private route: ActivatedRoute,private router:Router) { 
    
    console.log("Inside constructor  call1");
    
  }

  ngOnInit() {
    console.log("Inside ngoninit  call");
    
    this.route.data
    .map((data) => data['newses'])
    .subscribe(
      (newses) => {
        console.log(this.route.snapshot.data["newses"])
        console.log(this.route.data["newsType"])
        console.log("Inside ngoninit subscribe");
        this.newses = newses;
      }
    );
    if(this.newses== undefined){
      //this.reloadNewsCategory();
    }
    
      
  }
  reloadNewsCategory() {
    console.log("Inside topheadline news call");
    this.route.data.subscribe((data)=>{
      this.newses=[];
      this.newsType=data.newsType;       
        this.newsService.getNews(this.newsType).subscribe(
          (newss)=> {
            this.newses.push(...newss);
          });
      
  });
    
      
  }


}
