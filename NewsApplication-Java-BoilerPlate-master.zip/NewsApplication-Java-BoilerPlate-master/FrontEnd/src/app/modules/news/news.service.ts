import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators/map';
import { News } from './news';
import { Observable } from 'rxjs/Observable';
import { retry } from 'rxjs/operators';


@Injectable()
export class NewsService {

  tmdbEndpoint : string; 
  imagePrefix : string;
  apiKey : string;
  watchlistEndPoint : string;
  newsBackendServiceEndPoint: string;
  search: string;

  constructor(private http : HttpClient) { 
    this.apiKey='apikey=f16fc5a655964233b76ee81217a0f779';
    this.tmdbEndpoint='https://newsapi.org/v2/top-headlines?';
    this.imagePrefix = 'https://image.tmdb.org/t/p/w200'; 
    //this.watchlistEndPoint='http://localhost:3000/watchlist';
    this.newsBackendServiceEndPoint='http://localhost:8081/api/v1/newsservice';
    this.search='https://newsapi.org/v2/everything?';
  }

  
  getNews(type : string, page: number=1): Observable<Array<News>>{
    const endPoint=`${this.tmdbEndpoint}category=${type}&country=in&${this.apiKey}&page=${page}`;
    console.log(endPoint);
    
    return this.http.get(endPoint).pipe(
      retry(3),
      map(this.pickNewsResults),
      map(this.transformPosterPath.bind(this))
    );
  }

  
  transformPosterPath(News): Array<News>{
    return News.map(news => {
      news.urlToImage=`${news.urlToImage}`;
        return news;
    });    
  }

  pickNewsResults(response){
    return response['articles'];
  }

  
  saveWatchListNews(news){
      return this.http.post(this.newsBackendServiceEndPoint+'/news', news,{responseType:'text'});
  }

  //Calling the backend for retrieving all the watchlisted newss
  getMyWatchList() : Observable<Array<News>>{
    return this.http.get<Array<News>>(this.newsBackendServiceEndPoint+'/myNews');
  }

  //Method for deleting news from the WatchList
  deleteFromMyWatchList(news : News){
    const url = `${this.newsBackendServiceEndPoint}/news/${news.id}`;
    return this.http.delete(url,{responseType:'text'});
  }

  
  updateComments(news){
    const url = `${this.newsBackendServiceEndPoint}/news/${news.id}`;
    return this.http.put(url,news,{responseType:'text'});
  }

  
  searchNews(searchKey:string) : Observable<Array<News>>{
    if(searchKey.length > 0){
      const url=`${this.search}${this.apiKey}&language=en&page=1&q=${searchKey}`;
      return this.http.get(url).
      pipe(retry(3),
      map(this.pickNewsResults),
      map(this.transformPosterPath.bind(this)));
    }
  }
}
