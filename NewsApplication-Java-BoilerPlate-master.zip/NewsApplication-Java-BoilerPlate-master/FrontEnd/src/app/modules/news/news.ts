export interface News{
    //variable declaration which are required for this application
    id : number;
    title: string;
    author: string;
    description: string;
    publishedAt: Date; 
    comments: string;
    urlToImage: string;
    content: string;
    
};