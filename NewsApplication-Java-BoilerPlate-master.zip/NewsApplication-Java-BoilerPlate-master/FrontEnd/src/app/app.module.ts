import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes} from '@angular/router';
import { NewsModule } from './modules/news/news.module';
import { AuthenticationModule } from './modules/authentication/authentication.module'
import { AppComponent } from './app.component';
import { Route } from '@angular/compiler/src/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule, MatButton } from '@angular/material/button';
import { MatMenuModule} from '@angular/material';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { AuthguardService } from './authGuard.service';
import { RoleguardService } from './roleGuard.service';
import { ShowAuthedDirective } from './showAuthed.directive';
const appRoutes : Routes = [
  {
    path:'',
    redirectTo:'/login',
    pathMatch:'full',
  }
]

@NgModule({
  declarations: [
    AppComponent,
    ShowAuthedDirective
  ],
  exports:[
    ShowAuthedDirective
  ],  
  imports: [
    NewsModule,
    BrowserModule,
    AuthenticationModule,    
    FormsModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    MatDialogModule,
    MatInputModule,
    MatMenuModule,
    MatCardModule,
    RouterModule.forRoot(appRoutes),
  ],
  providers: [AuthguardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
