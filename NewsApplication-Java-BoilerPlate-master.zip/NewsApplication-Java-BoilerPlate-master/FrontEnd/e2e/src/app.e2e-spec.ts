import { browser, by, element } from 'protractor';
import { AppPage } from './app.po';
import { protractor } from 'protractor/built/ptor';
import { async } from 'q';

describe('frontend App', () => {
    let page:AppPage;

    beforeEach(() => {
        page=new AppPage();
        browser.manage().window().setSize(1600, 1000);
    });
    
    it('should display Title', ()=>{
        page.navigateTo();
        browser.driver.sleep(2000);
        expect(browser.getTitle()).toEqual('NewsAppBoilerplateJava');
    });

    it('should be redirected to /login route on opening the application',() => {
        expect(browser.getCurrentUrl()).toContain('/')
    });

    it('should be able to login user and navigate to top headline news',() => {
        browser.element(by.id('userId')).sendKeys('anoopvn');
        browser.element(by.id('password')).sendKeys('Anoop12#');
        browser.element(by.css('.login-user')).click();
        expect(browser.getCurrentUrl()).toContain('/news/top-headlines');
    });

    it('should be able to see the watchlist',() => {
        //browser.driver.manage().window().maximize();
        browser.driver.sleep(2000);
        browser.element(by.css('.watch-button')).click();
        expect(browser.getCurrentUrl()).toContain('/watchlist');
        
    });

    it('should be able to see the category news',() => {
        //browser.driver.manage().window().maximize();
        browser.driver.sleep(2000);
        browser.element(by.css('.top-button')).click();
        browser.element(by.css('.sports')).click();
        expect(browser.getCurrentUrl()).toContain('/news/top-headlines:sports');
        
    });

    it('should be able to add news to WatchList', async() => {
        const searchItems=element.all(by.css('.news-thumbnail'));
        //expect(searchItems.count()).toBe(20);
        searchItems.get(0).click();
        browser.driver.sleep(2000);
        browser.element(by.id('addButton')).click();
    });

    it('should be able to delete news from WatchList', async() => {
        //browser.driver.manage().window().maximize();
        browser.driver.sleep(2000);
        browser.element(by.css('.watch-button')).click();
        const searchItems=element.all(by.css('.news-thumbnail'));
        searchItems.get(0).click();
        browser.driver.sleep(2000);
        browser.element(by.id('deleteButton')).click();
    });

    it('should be able to logout from the application' ,() => {
        //browser.driver.manage().window().maximize();
        browser.driver.sleep(3000);        
        browser.element(by.css('.logout-button')).click()
        expect(browser.getCurrentUrl()).toContain('/login')
    });

    it('should be redirected to /register route' ,() => {
        browser.element(by.css('.register-button')).click()
        expect(browser.getCurrentUrl()).toContain('/register')
    });

    it('should be redirected to register user' ,() => {
        browser.driver.manage().window().maximize();
        browser.element(by.id('firstname')).sendKeys('Tom');
        browser.element(by.id('lastname')).sendKeys('Moody');
        browser.element(by.id('userId')).sendKeys('Tom');
        browser.element(by.id('password')).sendKeys('abc');
        browser.element(by.id('userRole')).sendKeys('admin');
        browser.driver.sleep(2000);

        var registerButton = element(by.css('.register-user'));
        browser.actions().mouseMove(registerButton).perform();
        browser.driver.sleep(2000);
        registerButton.click();

        browser.driver.sleep(2000);
        
        expect(browser.getCurrentUrl()).toContain('login');
        
    });

    it('should be able to login user and navigate to popular movies',() => {
        browser.element(by.id('userId')).sendKeys('Tom');
        browser.element(by.id('password')).sendKeys('abc');
        browser.element(by.css('.login-user')).click();
        expect(browser.getCurrentUrl()).toContain('/news/top-headlines');
    });

    it('should be able to logout from the application' ,() => {
        browser.driver.sleep(2000);
        browser.element(by.css('.logout-button')).click()
        expect(browser.getCurrentUrl()).toContain('/login')
    });

    
});
