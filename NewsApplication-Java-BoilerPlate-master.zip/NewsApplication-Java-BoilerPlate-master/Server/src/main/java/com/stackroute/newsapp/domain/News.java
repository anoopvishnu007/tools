package com.stackroute.newsapp.domain;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="news")
public class News {
	/**
	 * id for news
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name = "news_id")
	private String newsId;
	/**
	 * name of the news
	 */
	@Column(name="title")
	private String title;
	
	/**
	 * name of the news
	 */
	@Column(name="author")
	private String author;
	
	/**
	 * field for comments of news
	 */
	@Column(name="content", columnDefinition="LONGTEXT")
	private String content;
	/**
	 * field for comments of news
	 */
	@Column(name="comments", columnDefinition="LONGTEXT")
	private String comments;
	/**
	 * field for poster path for news
	 */
	@Column(name="url_to_image")
	private String urlToImage;
	/**
	 * field for release date of news
	 */
	@Column(name="published_at")
	private String publishedAt;
	
	@Column(name="user_id")
	private String userId;

	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	 
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	 
	 
	public News() {
		
	}
	 
	public News(int id,String newsId,String userId, String title, String comments, String urlToImage, String publishedAt,String content) {
		super();
		this.id = id;
		this.newsId =newsId;
		this.userId = userId;
		this.title = title;
		this.comments = comments;
		this.urlToImage = urlToImage;
		this.publishedAt = publishedAt;
		this.content = content;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNewsId() {
		return newsId;
	}
	public void setNewsId(String newsId) {
		this.newsId = newsId;
	}
	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}
	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}
	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}
	/**
	 * @return the urlToImage
	 */
	public String getUrlToImage() {
		return urlToImage;
	}
	/**
	 * @param urlToImage the urlToImage to set
	 */
	public void setUrlToImage(String urlToImage) {
		this.urlToImage = urlToImage;
	}
	/**
	 * @return the publishedAt
	 */
	public String getPublishedAt() {
		return publishedAt;
	}
	/**
	 * @param publishedAt the publishedAt to set
	 */
	public void setPublishedAt(String publishedAt) {
		this.publishedAt = publishedAt;
	}
	 
	 


}
