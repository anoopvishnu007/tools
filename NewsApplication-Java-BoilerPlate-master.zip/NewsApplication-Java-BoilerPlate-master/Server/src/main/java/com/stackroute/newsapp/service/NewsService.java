package com.stackroute.newsapp.service;

import java.util.List;

import com.stackroute.newsapp.domain.News;
import com.stackroute.newsapp.exception.NewsAlreadyExistsException;
import com.stackroute.newsapp.exception.NewsNotFoundException;

public interface NewsService {
	/**
	 * method declaration for save news
	 * 
	 * @param news
	 * @return
	 * @throws NewsAlreadyExistsException
	 */
	boolean saveNews(News news) throws NewsAlreadyExistsException;
	/**
	 * method declaration for updating news
	 * 
	 * @param news
	 * @return
	 * @throws NewsNotFoundException
	 */
	boolean updateNews(News news) throws NewsNotFoundException;
	/**
	 * method declaration for deleting a news
	 * 
	 * @param id
	 * @return
	 * @throws NewsNotFoundException
	 */
	boolean deleteNewsById(int id) throws NewsNotFoundException;
	/**
	 * method declaration for getting any news by its id
	 * 
	 * @param id
	 * @return News
	 * @throws NewsNotFoundException
	 */
	News getNewsById(int id) throws NewsNotFoundException;
	/**
	 * Method declaration for retrieving all the news from database
	 * 
	 * @return List<News>
	 */
	List<News> getAllNews();
	
	List<News> getMyNews(String userId);

}
