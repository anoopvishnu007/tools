package com.stackroute.newsapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.newsapp.domain.News;
import com.stackroute.newsapp.exception.NewsAlreadyExistsException;
import com.stackroute.newsapp.exception.NewsNotFoundException;
import com.stackroute.newsapp.repository.NewsRepository;

@Service
public class NewsServiceImpl implements NewsService {
	
	private final transient NewsRepository newsRepo;
	
	@Autowired
	public NewsServiceImpl(NewsRepository newsRepo) {
		super();
		this.newsRepo = newsRepo;
	}

	@Override
	public boolean saveNews(final News news) throws NewsAlreadyExistsException {
		final Optional<News> object=newsRepo.findById(news.getId());
		if(object.isPresent()) {
			throw new NewsAlreadyExistsException("Could not save news. News already exists.");
		}
		newsRepo.save(news);
		return true;
	}

	@Override
	public boolean updateNews(News updateNews) throws NewsNotFoundException {
		boolean isUpdated=false;
		final Optional<News> object=newsRepo.findById(updateNews.getId());
		if(!object.isPresent()) {
			throw new NewsNotFoundException("Could not update news. News not found.");
		}
		News updatedNews=newsRepo.save(updateNews);
		if(updatedNews != null) {
			isUpdated=true;
		}
		return isUpdated;
	}

	@Override
	public boolean deleteNewsById(int id) throws NewsNotFoundException {
		final Optional<News> object=newsRepo.findById(id);
		if(!object.isPresent()) {
			throw new NewsNotFoundException("Could not delete news. News not found.");
		}
		newsRepo.delete(object.get());
		return true;
	}

	@Override
	public News getNewsById(int id) throws NewsNotFoundException {
		final Optional<News> object=newsRepo.findById(id);
		if(!object.isPresent()) {
			throw new NewsNotFoundException("News not found.");
		}
		return object.get();
	}

	@Override
	public List<News> getAllNews() {
 		return newsRepo.findAll();
	}
	@Override
	public List<News> getMyNews(String userId) {
		return newsRepo.findByUserId(userId);
	}

}
