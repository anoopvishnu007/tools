package com.stackroute.newsapp.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.newsapp.domain.News;
import com.stackroute.newsapp.exception.NewsAlreadyExistsException;
import com.stackroute.newsapp.exception.NewsNotFoundException;
import com.stackroute.newsapp.repository.NewsRepository;
import com.stackroute.newsapp.service.NewsServiceImpl;

public class NewsServiceImplTest {
	@Mock
	private transient NewsRepository NewsRepo;
	private transient News news;
	@InjectMocks
	private transient NewsServiceImpl NewsServiceImpl;
	transient Optional<News> options;
	@Before
	public void setUpMock() {
		MockitoAnnotations.initMocks(this);
		news = new News(1, "2", "Anoop86", "Spiderman", "Superman News", "www.superman.com", "10-10-2018","");
		options = Optional.of(news);
	}
	@Test
	public void testMockCreation() {
		assertNotNull("jpa repository creation fails: use @injectMocks on NewsServiceImpl", NewsRepo);
	}
	@Test
	public void testSaveNewsSuccess() throws NewsAlreadyExistsException {
		when(NewsRepo.save(news)).thenReturn(news);
		final boolean flag = NewsServiceImpl.saveNews(news);
		assertTrue("saving News failed , the call to NewsDAOImpl is returning false , check this method",flag);
		//assertTrue(flag);
		verify(NewsRepo, times(1)).save(news);
		verify(NewsRepo, times(1)).findById(news.getId());
	}
	@Test(expected = NewsAlreadyExistsException.class)
	public void testSaveNewsFailure() throws NewsAlreadyExistsException {
		when(NewsRepo.findById(1)).thenReturn(options);
		when(NewsRepo.save(news)).thenReturn(news);
		final boolean flag = NewsServiceImpl.saveNews(news);
		assertFalse("Saving News failed",flag);
		verify(NewsRepo, times(1)).findById(news.getId());
	}
	@Test
	public void testUpdateNews() throws NewsNotFoundException {
		when(NewsRepo.findById(1)).thenReturn(options);
		when(NewsRepo.save(news)).thenReturn(news);
		news.setComments("Not so good News");
		boolean isUpdated = NewsServiceImpl.updateNews(news);
		assertEquals("Update News failed", true, isUpdated);
		verify(NewsRepo, times(1)).save(news);
		verify(NewsRepo, times(1)).findById(news.getId());
	}

	@Test
	public void testDeleteNews() throws NewsNotFoundException {
		when(NewsRepo.findById(1)).thenReturn(options);
		doNothing().when(NewsRepo).delete(news);
		final boolean flag = NewsServiceImpl.deleteNewsById(news.getId());
		assertTrue("Delete News failed", flag);
		verify(NewsRepo, times(1)).delete(news);
		verify(NewsRepo, times(1)).findById(news.getId());
	}
	@Test
	public void testGetNewsById() throws NewsNotFoundException {
		when(NewsRepo.findById(1)).thenReturn(options);
		final News News1 = NewsServiceImpl.getNewsById(1);
		assertEquals("fetching News by id failed", News1, news);
		verify(NewsRepo, times(1)).findById(news.getId());
	}
	@Test
	public void testGetAllNewss(){
		final List<News> Newss = new ArrayList<>(1);
		when(NewsRepo.findAll()).thenReturn(Newss);
		final List<News> NewsList = NewsServiceImpl.getAllNews();
		assertEquals(Newss, NewsList);
		verify(NewsRepo, times(1)).findAll();
	}

}
