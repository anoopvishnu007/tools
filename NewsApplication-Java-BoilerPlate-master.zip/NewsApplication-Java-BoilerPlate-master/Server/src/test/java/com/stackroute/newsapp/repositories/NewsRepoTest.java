package com.stackroute.newsapp.repositories;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.stackroute.newsapp.domain.News;
import com.stackroute.newsapp.repository.NewsRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Transactional
public class NewsRepoTest {
	@Autowired
	private NewsRepository NewsRepository;
	
	public void setRepository(NewsRepository NewsRepository) {
		this.NewsRepository=NewsRepository;
	}
	@Before
	public void setup() {
		NewsRepository.deleteAll();
	}
	@Test
	public void testSaveNews() {
		NewsRepository.save(new News(1,"2","Anoop86","Superman","good News","www.abc.com","2015-03-23",""));
		final News News =NewsRepository.getOne(1);
		assertThat(News.getId()).isEqualTo(1);
		
		
	}
	@Test
	public void testUpdateNews() {
		News news = NewsRepository.save(new News(1,"2","Anoop86","Superman","good News","www.abc.com","2015-03-23",""));
		final News News =NewsRepository.getOne(news.getId());
		assertThat(News.getTitle()).isEqualTo("Superman");
		News.setComments("hi");
		NewsRepository.save(News);
		
		News updatedNews =NewsRepository.getOne(news.getId());
		assertEquals("hi",updatedNews.getComments());
	}
	@Test
	public void testDeleteNews() {
		News news = NewsRepository.save(new News(1,"2","Anoop86","Superman","good News","www.abc.com","2015-03-23",""));
		final News News =NewsRepository.getOne(news.getId());
		assertThat(News.getId()).isEqualTo(news.getId());
		NewsRepository.delete(News);
		assertEquals(Optional.empty(), NewsRepository.findById(1));
		
	}
	@Test
	public void testGetNews() {
		News news = NewsRepository.save(new News(1,"2","Anoop86","Superman","good News","www.abc.com","2015-03-23",""));
		final News News =NewsRepository.getOne(news.getId());
		assertThat(News.getTitle()).isEqualTo("Superman");
		
	}
	@Test
	public void testGetAllNewss() {
		NewsRepository.save(new News(1,"2","Anoop86","Superman","good News","www.abc.com","2015-03-23",""));
		final List<News> newsList =NewsRepository.findAll();
		assertThat(newsList.size()).isEqualTo(1);
		
	}
	@Test
	public void testGetAllMyNewss() {
		NewsRepository.save(new News(1,"2","Anoop86","Superman","good News","www.abc.com","2015-03-23",""));
		NewsRepository.save(new News(2,"3","Anoop86","Superman-1","good News","www.abc.com","2015-03-23",""));
		final List<News> newsList =NewsRepository.findByUserId("Anoop86");
 		assertThat(newsList.size()).isEqualTo(2);
		
	}

}
