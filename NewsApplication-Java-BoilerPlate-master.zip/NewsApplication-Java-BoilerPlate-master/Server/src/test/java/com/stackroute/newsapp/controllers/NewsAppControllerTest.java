package com.stackroute.newsapp.controllers;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.newsapp.controller.NewsAppController;
import com.stackroute.newsapp.domain.News;
import com.stackroute.newsapp.service.NewsService;

@RunWith(SpringRunner.class)
@WebMvcTest(NewsAppController.class)
public class NewsAppControllerTest {
	@Autowired
	private transient MockMvc mvc;
	@MockBean
	private transient NewsService service;
	@InjectMocks
	private NewsAppController newsAppController;
	
	private transient News news;
	static List<News> newsList;
	String token;
	@Before
	public void setUp() {
		newsList = new ArrayList<News>();
		news = new News(1,"2","Anoop86", "Spiderman", "Superman news", "www.superman.com", "10-10-2018","");
		newsList.add(news);
		news = new News(2,"3","Anoop86", "Spiderman 1", "Superman news", "www.superman.com", "10-10-2018","");
		newsList.add(news);
		token ="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJBbm9vcDg2IiwiaWF0IjoxNTUzNzc1NTQ5LCJleHAiOjE1NTQyMDc1NDksImFsZyI6IkhTMjU2IiwidHlwIjoiSldUIiwicm9sZSI6ImFkbWluIn0.8TYJRL6dwB4LOWszTI_S_s3oPEVYuN4S-0MsMVy3zvI";
	}
	@Test
	public void testNewnewsSuccess() throws Exception{
		when(service.saveNews(news)).thenReturn(true);
		mvc.perform(post("/api/v1/newsservice/news").header("authorization", "Bearer " + token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(news))).andExpect(status().isCreated());
		verify(service, times(1)).saveNews(Mockito.any(News.class));
		verifyNoMoreInteractions(service);
	}
	@Test
	public void testUpdatenewsSuccess() throws Exception{
		news.setComments("Test Comment");
		when(service.updateNews(news)).thenReturn(true);
		mvc.perform(put("/api/v1/newsservice/news/{id}",1).header("authorization", "Bearer " + token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(news))).andExpect(status().isOk());
		verify(service, times(1)).updateNews(Mockito.any(News.class));
		verifyNoMoreInteractions(service);
	}
	@Test
	public void testDeletenewsById() throws Exception{
		when(service.deleteNewsById(1)).thenReturn(true);
		mvc.perform(delete("/api/v1/newsservice/news/{id}",1).header("authorization", "Bearer " + token)
		.contentType(MediaType.APPLICATION_JSON).content(jsonToString(news))).andExpect(status().isOk());
		verify(service, times(1)).deleteNewsById(1);
		verifyNoMoreInteractions(service);
	}
	@Test
	public void testFetchnewsById() throws Exception{
		when(service.getNewsById(1)).thenReturn(newsList.get(0));
		mvc.perform(get("/api/v1/newsservice/news/{id}",1).header("authorization", "Bearer " + token)).andExpect(status().isOk());
		verify(service, times(1)).getNewsById(1);
		verifyNoMoreInteractions(service);
	}
	@Test
	public void testGetAllnewss() throws Exception{
		when(service.getAllNews()).thenReturn(null);
		mvc.perform(get("/api/v1/newsservice/allnews",1).header("authorization", "Bearer " + token)).andExpect(status().isOk());
		verify(service, times(1)).getAllNews();
		verifyNoMoreInteractions(service);
	}
	@Test
	public void testGetMynewss() throws Exception {
		when(service.getMyNews("Anoop86")).thenReturn(newsList);
		mvc.perform(get("/api/v1/newsservice/myNews").header("authorization", "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print());
		verify(service, times(1)).getMyNews("Anoop86");
		verifyNoMoreInteractions(service);
	}
	private static String jsonToString(final Object object) {
		String result;
		try {
			final ObjectMapper mapper = new ObjectMapper();
			result = mapper.writeValueAsString(object);
		}catch(JsonProcessingException e) {
			result = "Json processing error";
		}
		return result;
	}
}