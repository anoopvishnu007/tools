package com.stackroute.newsapp.service;

import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.stackroute.newsapp.model.User;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


@Service
public class JWTSecurityTokenGeneratorImpl implements SecurityTokenGenerator {

	@Override
	public Map<String, String> generateToken(User user) { 
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
		final String SECRET = Base64.getEncoder().encodeToString("ThisIsASecret".getBytes());
		Calendar c = Calendar.getInstance();
		Date now = c.getTime();
		c.add(Calendar.MINUTE, 7200);
		Date expirationDate = c.getTime();
		Claims headerClaims =  Jwts.claims().setSubject(user.getUserId()).setIssuedAt(now).setExpiration(expirationDate);
		headerClaims.put("alg", "HS256");
		headerClaims.put("typ", "JWT");
		headerClaims.put("role", user.getUserRole());
 		
		String jwtToken = Jwts.builder().setClaims(headerClaims).signWith(signatureAlgorithm, SECRET).compact();
		Map<String, String> map = new HashMap<>();
		map.put("token", jwtToken);
		map.put("message", "User successfully logged in");
		return map;
	}
}
