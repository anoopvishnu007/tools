/**
 * 
 */
package com.stackroute.newsapp.service;

import com.stackroute.newsapp.exceptions.UserAlreadyExistsException;
import com.stackroute.newsapp.exceptions.UserNotFoundException;
import com.stackroute.newsapp.model.User;

/**
 * @author ubuntu
 *
 */
public interface UserService {

	boolean saveUser(User user) throws UserAlreadyExistsException;

	public User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException;;

}
