/**
 * 
 */
package com.stackroute.newsapp.service;

import java.util.Map;

import com.stackroute.newsapp.model.User;

/**
 * @author ubuntu
 * Interface declaration for JWT Token generation
 */
public interface SecurityTokenGenerator {

	Map<String, String> generateToken(User user);

}
